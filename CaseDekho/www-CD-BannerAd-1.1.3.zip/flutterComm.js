const flutterDomId = "flutterAppWr";

// -- Console log state --
const consoleLogStore = {
  logs: [], // { time, level, message, detail }
};

// Util: pretty print JSON
function pretty(obj) {
  if (typeof obj === "string") return obj;
  return JSON.stringify(obj, null, 2).replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// --- FLUTTER LOGS ---
const flutterLogStore = {
  logs: [],   // {id, corr, type: 'request'|'response'|'error', envelope, response, error, time}
  pending: {}, // {id: {module, action, payload, time}}
  logMap: {}, // id/corr -> position in logs
};

// Renders flutter logs (app logs) paired with responses
function renderFlutterLogs() {
  if (!document.getElementById(flutterDomId)) return;
  const logDiv = document.getElementById('log');
  if (!logDiv) return;
  let html = '';

  flutterLogStore.logs.forEach(entry => {
    if (entry.type === 'request') {
      html += `<div class="flog-req" style="margin-bottom:8px;">
<hr/><b>🔥 ${entry.module}.${entry.action}</b> <span style="color:gray;">[${entry.id}]</span>
<pre style="color:#0ff; margin:4px 0 0 0; word-break:break-word; white-space:pre-wrap;">${pretty(entry.payload)}</pre>`;
      if (entry.response) {
        html += `<div class="flog-resp" style="margin-top:2px;color:#0f0;">◀ Response:<pre style="color:#8f8;margin:0;word-break:break-word;white-space:pre-wrap;">${pretty(entry.response)}</pre></div>`;
      } else if (entry.error) {
        html += `<div class="flog-err" style="margin-top:2px;color:red;">❌ Error:<pre style="color:red;margin:0;word-break:break-word;white-space:pre-wrap;">${pretty(entry.error)}</pre></div>`;
      } else {
        html += `<div class="flog-pending" style="color:#fd0;margin-top:2px;">⏳ Pending...</div>`;
      }
      html += `</div>`;
    }
  });
  // Pending requests at end
  const pendingIds = Object.keys(flutterLogStore.pending);
  if (pendingIds.length > 0) {
    html += `<hr/><div class="flog-pending-all" style="margin-top:8px;">
      <b>⏳ Pending Requests:</b>
      <ul style="margin:0 0 8px 0;padding-left:18px;">`;
    pendingIds.forEach(pid => {
      const p = flutterLogStore.pending[pid];
      html += `<li>[${pid}] <b>${p.module}.${p.action}</b> <pre style="color:#dd0;display:inline;">${pretty(p.payload)}</pre></li>`;
    });
    html += `</ul></div>`;
  }
  if (html === '') html = '<span style="color:#ccc;">No logs yet...</span>';
  logDiv.innerHTML = html;
  logDiv.scrollTop = logDiv.scrollHeight;
}

// --- CONSOLE LOGS ---
function renderConsoleLogs() {
  if (!document.getElementById(flutterDomId)) return;
  const consoleDiv = document.getElementById('consoleLog');
  if (!consoleDiv) return;
  let html = '';
  if (!consoleLogStore.logs.length) {
    html = '<span style="color:#ccc;">No console logs yet...</span>';
  } else {
    html = consoleLogStore.logs.map(entry => {
      let clr = entry.level.toLowerCase() === "error" ? "#f66" : (entry.level === "warn" ? "#fd0" : "#8e8");
      let msg = typeof entry.message === "string" ? entry.message : pretty(entry.message);
      let ddetail = entry.detail ? `<pre style="color:#ccc;margin:0;">${pretty(entry.detail)}</pre>` : '';
      return `<div style="margin-bottom:7px;">
        <span style="color:gray;font-size:12px;">[${new Date(entry.time).toLocaleTimeString()}]</span>
        <span style="color:${clr};margin-left:4px;"><b>${entry.level.toLowerCase()=="log"? "⭐️":entry.level}</b>:</span>
        <span style="color:#eee;margin-left:4px;">${msg}</span>
        ${ddetail}
      </div><hr/>`;
    }).join("");
  }
  consoleDiv.innerHTML = html;
  consoleDiv.scrollTop = consoleDiv.scrollHeight;
}

// Logging method: saves to flutter log store and triggers re-render
function logFlutterEntry({ type, envelope, response, error }) {
  if (!document.getElementById(flutterDomId)) return;
  let id = (envelope && envelope.id) || (response && (response.corr || response.id)) || (error && (error.corr || error.id));
  let corr = (envelope && envelope.corr) || (response && (response.corr || response.id)) || (error && (error.corr || error.id));
  let idx = flutterLogStore.logMap[id];
  if (type === 'request') {
    const entry = {
      id, corr, type, time: Date.now(), envelope,
      module: envelope.module, action: envelope.action, payload: envelope.payload,
      response: null, error: null
    };
    flutterLogStore.logs.push(entry);
    flutterLogStore.logMap[id] = flutterLogStore.logs.length - 1;
    flutterLogStore.pending[id] = { module: envelope.module, action: envelope.action, payload: envelope.payload, time: entry.time };
  } else if (type === 'response' || type === 'error') {

    idx = flutterLogStore.logMap[corr];
    if (typeof idx === 'number') {
      let entry = flutterLogStore.logs[idx];
      if (type === 'response') {
        entry.response = response;
      } else {
        entry.error = error;
      }
      delete flutterLogStore.pending[corr];
    } else {

      flutterLogStore.logs.push({
        id: corr, corr, type, time: Date.now(),
        envelope: null, module: null, action: null, payload: null,
        response: type === 'response' ? response : null,
        error:    type === 'error'    ? error    : null
      });
      flutterLogStore.logMap[corr] = flutterLogStore.logs.length - 1;
    }
  }
  renderFlutterLogs();
}

// Logging method: saves to console log store and triggers re-render
function logConsoleEntry({ level, message, detail }) {
  if (!document.getElementById(flutterDomId)) return;
  consoleLogStore.logs.push({
    time: Date.now(),
    level: level || "log",
    message,
    detail
  });
  renderConsoleLogs();
}

// --- UI: Log/Console container ---
function ensureLogUI() {
  if (!document.getElementById(flutterDomId)) return;

  // Only inject once
  if (document.getElementById('logWr')) return; // NOTE: check logWr, not just log

  // Create and append floating button(s)
  if (!document.getElementById('logBtn')) {
    const btn1 = document.createElement('button');
    btn1.id = 'logBtn';
    btn1.textContent = '🕹️';
    btn1.style.padding = '6px';
    btn1.style.fontSize = '16px';
    btn1.style.marginRight = '6px';
    btn1.onclick = function() {
      var logWr = document.getElementById('logWr');
      if (logWr) {
        logWr.style.display = (logWr.style.display === 'none' || logWr.style.display === '') ? 'block' : 'none';
      }
    };

    const parentWr = document.getElementById(flutterDomId);    
    parentWr.style.position = 'fixed';
    parentWr.style.zIndex = '2147483647';
    parentWr.style.top = '10px';
    parentWr.style.left = '40px';
    parentWr.appendChild(btn1);
  }

  // Log container section/tab UI
  let logWr = document.getElementById('logWr');
  if (!logWr) {
    logWr = document.createElement('div');
    logWr.id = 'logWr';

    Object.assign(logWr.style, {
      position: 'fixed',
      left: '0',
      right: '0',
      bottom: '0',
      display: 'none',
      zIndex: '99999',
      maxHeight: '50vh',
      width: '100%',
      background: '#200',
      overflowY: 'auto',
      boxShadow: '0 -2px 18px #0006'
    });
    document.body.appendChild(logWr);
  }

  // -- Header with tab switch and clear --
  let header = document.createElement('div'); // switch from h4 to div (for richer controls)
  header.id = 'logHeader';
  header.style.padding = '6px';
  header.style.display = 'flex';
  header.style.justifyContent = 'space-between';
  header.style.alignItems = 'center';
  header.style.margin = '0';
  header.style.top = '0';
  header.style.background = '#320000';
  header.style.color = '#fff';

  // Tabs: Logs | Console
  let tabBar = document.createElement('div');
  tabBar.style.display = 'flex';
  tabBar.style.gap = '12px';

  let logTabBtn = document.createElement('button');
  logTabBtn.id = 'logTabBtn';
  logTabBtn.textContent = 'Logs';
  logTabBtn.style.padding = '4px 8px';
  logTabBtn.style.fontWeight = 'bold';
  logTabBtn.onclick = function() { showTab('log'); };

  let consoleTabBtn = document.createElement('button');
  consoleTabBtn.id = 'consoleTabBtn';
  consoleTabBtn.textContent = 'Console';
  consoleTabBtn.style.padding = '4px 8px';
  consoleTabBtn.onclick = function() { showTab('consoleLog'); };

  tabBar.appendChild(logTabBtn);
  tabBar.appendChild(consoleTabBtn);
  header.appendChild(tabBar);

  // --- clear buttons ---
  let clearBar = document.createElement('div');
  clearBar.style.display = 'flex';
  clearBar.style.gap = '7px';

  var clearLogsBtn = document.createElement('button');
  clearLogsBtn.style.padding = '6px';
  clearLogsBtn.style.fontSize = '16px';
  clearLogsBtn.textContent = '🗑️ Logs';
  clearLogsBtn.onclick = function() {
    flutterLogStore.logs.length = 0;
    flutterLogStore.logMap = {};
    flutterLogStore.pending = {};
    renderFlutterLogs();
  };

  var clearConsoleBtn = document.createElement('button');
  clearConsoleBtn.style.padding = '6px';
  clearConsoleBtn.style.fontSize = '16px';
  clearConsoleBtn.textContent = '🗑️ Console';
  clearConsoleBtn.onclick = function() {
    consoleLogStore.logs.length = 0;
    renderConsoleLogs();
  };

  clearBar.appendChild(clearLogsBtn);
  clearBar.appendChild(clearConsoleBtn);

  header.appendChild(clearBar);

  // ---- Content areas: logs/console ---
  // Logs
  let logDiv = document.createElement('div');
  logDiv.id = 'log';
  logDiv.style.background = '#490000';
  logDiv.style.color = 'rgb(69, 205, 80)';
  logDiv.style.padding = '8px 16px';
  logDiv.style.overflowY = 'auto';
  logDiv.style.maxHeight = '44vh';
  logDiv.textContent = 'No logs yet...';

  // Console
  let consoleDiv = document.createElement('div');
  consoleDiv.id = 'consoleLog';
  consoleDiv.style.background = '#142300';
  consoleDiv.style.color = '#8e8';
  consoleDiv.style.padding = '8px 16px';
  consoleDiv.style.overflowY = 'auto';
  consoleDiv.style.maxHeight = '44vh';
  consoleDiv.style.display = 'none';
  consoleDiv.textContent = 'No console logs yet...';

  // Remove old children if any (to avoid multi headers on reload)
  while (logWr.firstChild) logWr.removeChild(logWr.firstChild);

  logWr.appendChild(header);
  logWr.appendChild(logDiv);
  logWr.appendChild(consoleDiv);

  // Init state (show logs)
  showTab('log');
}

// Switch tab: "log" or "consoleLog"
function showTab(tab) {
  let logDiv = document.getElementById('log');
  let consoleDiv = document.getElementById('consoleLog');
  let logTabBtn = document.getElementById('logTabBtn');
  let consoleTabBtn = document.getElementById('consoleTabBtn');
  if (!logDiv || !consoleDiv) return;

  if (tab === 'log') {
    logDiv.style.display = '';
    consoleDiv.style.display = 'none';
    if (logTabBtn) {
      logTabBtn.style.background = '#620000';
      logTabBtn.style.color = '#fff';
    }
    if (consoleTabBtn) {
      consoleTabBtn.style.background = '';
      consoleTabBtn.style.color = '';
    }
  } else {
    logDiv.style.display = 'none';
    consoleDiv.style.display = '';
    if (consoleTabBtn) {
      consoleTabBtn.style.background = '#1c3600';
      consoleTabBtn.style.color = '#fff';
    }
    if (logTabBtn) {
      logTabBtn.style.background = '';
      logTabBtn.style.color = '';
    }
  }
}

// --- Listen for custom event to capture console log messages ---
window.addEventListener('onFlutterConsoleMessage', function(evt) {
  // You can dispatch like:
  // window.dispatchEvent(new CustomEvent('onFlutterConsoleMessage', { detail: { level: "log", message: "your log" }}));
  let d = evt && evt.detail;
  if (d) {
    logConsoleEntry({
      level: d.level || 'log',
      message: d.message,
      detail: d.detail
    });
  }
});


// Init flutter interaction plus console UI
(function () {
  init()

  renderFlutterLogs();
  renderConsoleLogs();
})();

function init(){
  if (window.bridgeSend) return;

  setTimeout(() => {  
    ensureLogUI();
  }, 3000);

  const pendingPromises = {};
  function uuid() { return 'id-' + Math.random().toString(36).slice(2, 9); }
  window.bridgeSend = function (module, action, payload = {}, target = 'native', opts = { timeout: 30000 }) {
    const id = uuid();
    const envelope = { v: '1.0', id, corr: id, origin: 'webview:test', target, module, action, payload, expectsResponse: true };
    logFlutterEntry({ type: 'request', envelope });
    opts.timeout = payload.timeout || opts.timeout;
    return new Promise((resolve, reject) => {
      let timer = setTimeout(() => {
        delete pendingPromises[id];
        logFlutterEntry({ type: 'error', error: { message:"timeout", id, corr: id } });
        reject({ message: "timeout" });
      }, opts.timeout || 30000);
      pendingPromises[id] = { resolve, reject, timer };
      if (window.flutter_inappwebview && window.flutter_inappwebview.callHandler) {
        window.flutter_inappwebview.callHandler('FlutterBridge', envelope).then(function (response) {
          try {
            const corr = response && (response.corr || response.id);
            if (pendingPromises[corr]) {
              clearTimeout(pendingPromises[corr].timer);
              if (response.ok)
                pendingPromises[corr].resolve(response.result);
              else
                pendingPromises[corr].reject(response.error || response);
              delete pendingPromises[corr];
            }
            logFlutterEntry({ type: response.ok ? 'response' : 'error', response: response.ok ? response : null, error: response.ok ? null : response });
          } catch (e) {
            logFlutterEntry({ type:'error', error: { message:'response handling error '+e, id, corr: id }});
          }
        }).catch(err => {
          logFlutterEntry({ type:'error', error: { message:'callHandler error '+err, id, corr: id }});
          reject(err);
        });
      } else {
        // Simulate for web
        console.error('No flutter_inappwebview available - simulating response');
        setTimeout(() => {
          const resp = { id: 'resp-' + id, corr: id, ok: true, result: null };
          logFlutterEntry({ type:'response', response: resp });
          resolve(resp.result);
        }, 500);
      }
    });
  };

  // Optionally handle incoming messages
  window.__bridge_receive = function (msg) {
    // Could receive streamed events here - Extend as needed.
    console.log('incoming', msg);
  };
}
init();

window.addEventListener("onFlutterBackPressed", () => {
  var logWr = document.getElementById('logWr');
  if (logWr) {
    logWr.style.display = 'none';
  }
}); 