import{r as W,e as tt,aJ as xt,f as ft,aK as yt,j as r,h as ot,aL as wt,au as Ie,at as We,d as $e,aB as vt,aM as Nt,l as Te,c as Se,s as ye,aN as St,a as He,ax as Me,m as Le,aO as Ct,aP as ht,n as Tt,a4 as Ae,aQ as jt,ay as Pt,t as Ge,B as U,G as ae,H as je,E as O,T as A,K as _,S as K,P as Ne,w as ie,C as mt,I as Ee,aj as Rt,a7 as kt,aH as At,v as It,ar as Wt,ap as $t,Z as Mt,ak as Lt,aR as zt,L as De,aS as Ve,x as we,N as Et,aT as Ot,ah as Ft,aU as Bt,aV as rt,ac as _t,aW as Ht,aX as Dt,aY as Vt,aZ as nt,a_ as at,a$ as Kt,b0 as Ut,b1 as qt,b2 as Jt,b3 as Xt,b4 as Yt,b5 as Gt,b6 as Qt,b7 as Zt,b8 as eo,b9 as to,ba as oo,bb as ro}from"./index-BEnOtY9m.js";import{B as no}from"./BreadcrumbsNav-B21euE0P.js";import{T as ao,a as io,b as Ke,c as Ue,d as so}from"./TableRow-BJopsPv3.js";import{A as co,g as qe,s as it,p as lo,W as po}from"./Index-DvX54GeN.js";import{T as uo,a as st}from"./ToggleButtonGroup-fkxi1lrE.js";import"./MyInputField-DvOBKiY-.js";import"./dataConversion-BwDSRPg6.js";import"./MyForm-CpsCQVTO.js";import"./FormControlLabel-B7hDf4J1.js";import"./SwitchBase-BAjfF59q.js";import"./Alert-XSpT0Utc.js";import"./Collapse-Cfi-Yne5.js";const fo={entering:{transform:"none"},entered:{transform:"none"}},ho=W.forwardRef(function(o,n){const i=tt(),h={enter:i.transitions.duration.enteringScreen,exit:i.transitions.duration.leavingScreen},{addEndListener:f,appear:u=!0,children:p,easing:g,in:T,onEnter:m,onEntered:C,onEntering:I,onExit:P,onExited:H,onExiting:D,style:V,timeout:q=h,TransitionComponent:G=xt,...X}=o,F=W.useRef(null),z=ft(F,yt(p),n),y=w=>N=>{if(w){const b=F.current;N===void 0?w(b):w(b,N)}},L=y(I),$=y((w,N)=>{wt(w);const b=ot({style:V,timeout:q,easing:g},{mode:"enter"});w.style.webkitTransition=i.transitions.create("transform",b),w.style.transition=i.transitions.create("transform",b),m&&m(w,N)}),J=y(C),x=y(D),ee=y(w=>{const N=ot({style:V,timeout:q,easing:g},{mode:"exit"});w.style.webkitTransition=i.transitions.create("transform",N),w.style.transition=i.transitions.create("transform",N),P&&P(w)}),l=y(H),R=w=>{f&&f(F.current,w)};return r.jsx(G,{appear:u,in:T,nodeRef:F,onEnter:$,onEntered:J,onEntering:L,onExit:ee,onExited:l,onExiting:x,addEndListener:R,timeout:q,...X,children:(w,{ownerState:N,...b})=>W.cloneElement(p,{style:{transform:"scale(0)",visibility:w==="exited"&&!T?"hidden":void 0,...fo[w],...V,...p.props.style},ref:z,...b})})});function mo(e){return We("MuiSpeedDial",e)}const Oe=Ie("MuiSpeedDial",["root","fab","directionUp","directionDown","directionLeft","directionRight","actions","actionsClosed"]),go=e=>{const{classes:o,open:n,direction:i}=e,h={root:["root",`direction${He(i)}`],fab:["fab"],actions:["actions",!n&&"actionsClosed"]};return Me(h,mo,o)};function Pe(e){if(e==="up"||e==="down")return"vertical";if(e==="right"||e==="left")return"horizontal"}const ve=32,Fe=16,bo=ye("div",{name:"MuiSpeedDial",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:n}=e;return[o.root,o[`direction${He(n.direction)}`]]}})(Le(({theme:e})=>({zIndex:(e.vars||e).zIndex.speedDial,display:"flex",alignItems:"center",pointerEvents:"none",variants:[{props:{direction:"up"},style:{flexDirection:"column-reverse",[`& .${Oe.actions}`]:{flexDirection:"column-reverse",marginBottom:-ve,paddingBottom:Fe+ve}}},{props:{direction:"down"},style:{flexDirection:"column",[`& .${Oe.actions}`]:{flexDirection:"column",marginTop:-ve,paddingTop:Fe+ve}}},{props:{direction:"left"},style:{flexDirection:"row-reverse",[`& .${Oe.actions}`]:{flexDirection:"row-reverse",marginRight:-ve,paddingRight:Fe+ve}}},{props:{direction:"right"},style:{flexDirection:"row",[`& .${Oe.actions}`]:{flexDirection:"row",marginLeft:-ve,paddingLeft:Fe+ve}}}]}))),xo=ye(ht,{name:"MuiSpeedDial",slot:"Fab",overridesResolver:(e,o)=>o.fab})({pointerEvents:"auto"}),yo=ye("div",{name:"MuiSpeedDial",slot:"Actions",overridesResolver:(e,o)=>{const{ownerState:n}=e;return[o.actions,!n.open&&o.actionsClosed]}})({display:"flex",pointerEvents:"auto",variants:[{props:({ownerState:e})=>!e.open,style:{transition:"top 0s linear 0.2s",pointerEvents:"none"}}]}),wo=W.forwardRef(function(o,n){const i=$e({props:o,name:"MuiSpeedDial"}),h=tt(),f={enter:h.transitions.duration.enteringScreen,exit:h.transitions.duration.leavingScreen},{ariaLabel:u,FabProps:{ref:p,...g}={},children:T,className:m,direction:C="up",hidden:I=!1,icon:P,onBlur:H,onClose:D,onFocus:V,onKeyDown:q,onMouseEnter:G,onMouseLeave:X,onOpen:F,open:z,openIcon:y,slots:L={},slotProps:$={},TransitionComponent:J,TransitionProps:x,transitionDuration:ee=f,...l}=i,[R,w]=vt({controlled:z,default:!1,name:"SpeedDial",state:"open"}),N={...i,open:R,direction:C},b=go(N),d=Nt(),S=W.useRef(0),t=W.useRef(),E=W.useRef([]);E.current=[E.current[0]];const te=W.useCallback(v=>{E.current[0]=v},[]),le=ft(p,te),me=(v,M)=>Y=>{E.current[v+1]=Y,M&&M(Y)},Z=v=>{q&&q(v);const M=v.key.replace("Arrow","").toLowerCase(),{current:Y=M}=t;if(v.key==="Escape"){w(!1),E.current[0].focus(),D&&D(v,"escapeKeyDown");return}if(Pe(M)===Pe(Y)&&Pe(M)!==void 0){v.preventDefault();const ne=M===Y?1:-1,xe=Ct(S.current+ne,0,E.current.length-1);E.current[xe].focus(),S.current=xe,t.current=Y}};W.useEffect(()=>{R||(S.current=0,t.current=void 0)},[R]);const se=v=>{v.type==="mouseleave"&&X&&X(v),v.type==="blur"&&H&&H(v),d.clear(),v.type==="blur"?d.start(0,()=>{w(!1),D&&D(v,"blur")}):(w(!1),D&&D(v,"mouseLeave"))},ge=v=>{g.onClick&&g.onClick(v),d.clear(),R?(w(!1),D&&D(v,"toggle")):(w(!0),F&&F(v,"toggle"))},re=v=>{v.type==="mouseenter"&&G&&G(v),v.type==="focus"&&V&&V(v),d.clear(),R||d.start(0,()=>{w(!0),F&&F(v,{focus:"focus",mouseenter:"mouseEnter"}[v.type])})},k=u.replace(/^[^a-z]+|[^\w:.-]+/gi,""),Q=W.Children.toArray(T).filter(v=>W.isValidElement(v)),be=Q.map((v,M)=>{const{FabProps:{ref:Y,...ne}={},tooltipPlacement:xe}=v.props,ce=xe||(Pe(C)==="vertical"?"left":"top");return W.cloneElement(v,{FabProps:{...ne,ref:me(M,Y)},delay:30*(R?M:Q.length-M),open:R,tooltipPlacement:ce,id:`${k}-action-${M}`})}),de={transition:J,...L},ue={transition:x,...$},B={slots:de,slotProps:ue},[s,a]=Te("root",{elementType:bo,externalForwardedProps:{...B,...l},ownerState:N,ref:n,className:Se(b.root,m),additionalProps:{role:"presentation"},getSlotProps:v=>({...v,onKeyDown:M=>{var Y;(Y=v.onKeyDown)==null||Y.call(v,M),Z(M)},onBlur:M=>{var Y;(Y=v.onBlur)==null||Y.call(v,M),se(M)},onFocus:M=>{var Y;(Y=v.onFocus)==null||Y.call(v,M),re(M)},onMouseEnter:M=>{var Y;(Y=v.onMouseEnter)==null||Y.call(v,M),re(M)},onMouseLeave:M=>{var Y;(Y=v.onMouseLeave)==null||Y.call(v,M),se(M)}})}),[j,c]=Te("transition",{elementType:ho,externalForwardedProps:B,ownerState:N});return r.jsxs(s,{...a,children:[r.jsx(j,{in:!I,timeout:ee,unmountOnExit:!0,...c,children:r.jsx(xo,{color:"primary","aria-label":u,"aria-haspopup":"true","aria-expanded":R,"aria-controls":`${k}-actions`,...g,onClick:ge,className:Se(b.fab,g.className),ref:le,ownerState:N,children:W.isValidElement(P)&&St(P,["SpeedDialIcon"])?W.cloneElement(P,{open:R}):P})}),r.jsx(yo,{id:`${k}-actions`,role:"menu","aria-orientation":Pe(C),className:Se(b.actions,!R&&b.actionsClosed),ownerState:N,children:be})]})});function vo(e){return We("MuiSpeedDialAction",e)}const Be=Ie("MuiSpeedDialAction",["fab","fabClosed","staticTooltip","staticTooltipClosed","staticTooltipLabel","tooltipPlacementLeft","tooltipPlacementRight"]),No=e=>{const{open:o,tooltipPlacement:n,classes:i}=e,h={fab:["fab",!o&&"fabClosed"],staticTooltip:["staticTooltip",`tooltipPlacement${He(n)}`,!o&&"staticTooltipClosed"],staticTooltipLabel:["staticTooltipLabel"]};return Me(h,vo,i)},So=ye(ht,{name:"MuiSpeedDialAction",slot:"Fab",skipVariantsResolver:!1,overridesResolver:(e,o)=>{const{ownerState:n}=e;return[o.fab,!n.open&&o.fabClosed]}})(Le(({theme:e})=>({margin:8,color:(e.vars||e).palette.text.secondary,backgroundColor:(e.vars||e).palette.background.paper,"&:hover":{backgroundColor:e.vars?e.vars.palette.SpeedDialAction.fabHoverBg:jt(e.palette.background.paper,.15)},transition:`${e.transitions.create("transform",{duration:e.transitions.duration.shorter})}, opacity 0.8s`,opacity:1,variants:[{props:({ownerState:o})=>!o.open,style:{opacity:0,transform:"scale(0)"}}]}))),Co=ye("span",{name:"MuiSpeedDialAction",slot:"StaticTooltip",overridesResolver:(e,o)=>{const{ownerState:n}=e;return[o.staticTooltip,!n.open&&o.staticTooltipClosed,o[`tooltipPlacement${He(n.tooltipPlacement)}`]]}})(Le(({theme:e})=>({position:"relative",display:"flex",alignItems:"center",[`& .${Be.staticTooltipLabel}`]:{transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.shorter}),opacity:1},variants:[{props:({ownerState:o})=>!o.open,style:{[`& .${Be.staticTooltipLabel}`]:{opacity:0,transform:"scale(0.5)"}}},{props:{tooltipPlacement:"left"},style:{[`& .${Be.staticTooltipLabel}`]:{transformOrigin:"100% 50%",right:"100%",marginRight:8}}},{props:{tooltipPlacement:"right"},style:{[`& .${Be.staticTooltipLabel}`]:{transformOrigin:"0% 50%",left:"100%",marginLeft:8}}}]}))),To=ye("span",{name:"MuiSpeedDialAction",slot:"StaticTooltipLabel",overridesResolver:(e,o)=>o.staticTooltipLabel})(Le(({theme:e})=>({position:"absolute",...e.typography.body1,backgroundColor:(e.vars||e).palette.background.paper,borderRadius:(e.vars||e).shape.borderRadius,boxShadow:(e.vars||e).shadows[1],color:(e.vars||e).palette.text.secondary,padding:"4px 16px",wordBreak:"keep-all"}))),Je=W.forwardRef(function(o,n){var S;const i=$e({props:o,name:"MuiSpeedDialAction"}),{className:h,delay:f=0,FabProps:u={},icon:p,id:g,open:T,TooltipClasses:m,tooltipOpen:C=!1,tooltipPlacement:I="left",tooltipTitle:P,slots:H={},slotProps:D={},...V}=i,q={...i,tooltipPlacement:I},G=No(q),X={slots:H,slotProps:{fab:u,...D,tooltip:Tt(typeof D.tooltip=="function"?D.tooltip(q):D.tooltip,{title:P,open:C,placement:I,classes:m})}},[F,z]=W.useState((S=X.slotProps.tooltip)==null?void 0:S.open),y=()=>{z(!1)},L=()=>{z(!0)},$={transitionDelay:`${f}ms`},[J,x]=Te("fab",{elementType:So,externalForwardedProps:X,ownerState:q,shouldForwardComponentProp:!0,className:Se(G.fab,h),additionalProps:{style:$,tabIndex:-1,role:"menuitem",size:"small"}}),[ee,l]=Te("tooltip",{elementType:Ae,externalForwardedProps:X,shouldForwardComponentProp:!0,ref:n,additionalProps:{id:g},ownerState:q,getSlotProps:t=>({...t,onClose:E=>{var te;(te=t.onClose)==null||te.call(t,E),y()},onOpen:E=>{var te;(te=t.onOpen)==null||te.call(t,E),L()}})}),[R,w]=Te("staticTooltip",{elementType:Co,externalForwardedProps:X,ownerState:q,ref:n,className:G.staticTooltip,additionalProps:{id:g}}),[N,b]=Te("staticTooltipLabel",{elementType:To,externalForwardedProps:X,ownerState:q,className:G.staticTooltipLabel,additionalProps:{style:$,id:`${g}-label`}}),d=r.jsx(J,{...x,children:p});return l.open?r.jsxs(R,{...w,...V,children:[r.jsx(N,{...b,children:l.title}),W.cloneElement(d,{"aria-labelledby":`${g}-label`})]}):(!T&&F&&z(!1),r.jsx(ee,{...l,title:l.title,open:T&&F,placement:l.placement,classes:l.classes,...V,children:d}))}),jo=Pt(r.jsx("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"}),"Add");function Po(e){return We("MuiSpeedDialIcon",e)}const fe=Ie("MuiSpeedDialIcon",["root","icon","iconOpen","iconWithOpenIconOpen","openIcon","openIconOpen"]),Ro=e=>{const{classes:o,open:n,openIcon:i}=e;return Me({root:["root"],icon:["icon",n&&"iconOpen",i&&n&&"iconWithOpenIconOpen"],openIcon:["openIcon",n&&"openIconOpen"]},Po,o)},ko=ye("span",{name:"MuiSpeedDialIcon",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:n}=e;return[{[`& .${fe.icon}`]:o.icon},{[`& .${fe.icon}`]:n.open&&o.iconOpen},{[`& .${fe.icon}`]:n.open&&n.openIcon&&o.iconWithOpenIconOpen},{[`& .${fe.openIcon}`]:o.openIcon},{[`& .${fe.openIcon}`]:n.open&&o.openIconOpen},o.root]}})(Le(({theme:e})=>({height:24,[`& .${fe.icon}`]:{transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.short})},[`& .${fe.openIcon}`]:{position:"absolute",transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.short}),opacity:0,transform:"rotate(-45deg)"},variants:[{props:({ownerState:o})=>o.open,style:{[`& .${fe.icon}`]:{transform:"rotate(45deg)"}}},{props:({ownerState:o})=>o.open&&o.openIcon,style:{[`& .${fe.icon}`]:{opacity:0}}},{props:({ownerState:o})=>o.open,style:{[`& .${fe.openIcon}`]:{transform:"rotate(0deg)",opacity:1}}}]}))),gt=W.forwardRef(function(o,n){const i=$e({props:o,name:"MuiSpeedDialIcon"}),{className:h,icon:f,open:u,openIcon:p,...g}=i,T=i,m=Ro(T);function C(I,P){return W.isValidElement(I)?W.cloneElement(I,{className:P}):I}return r.jsxs(ko,{className:Se(m.root,h),ref:n,ownerState:T,...g,children:[p?C(p,m.openIcon):null,f?C(f,m.icon):r.jsx(jo,{className:m.icon})]})});gt.muiName="SpeedDialIcon";function Ao(e){return We("MuiTableContainer",e)}Ie("MuiTableContainer",["root"]);const Io=e=>{const{classes:o}=e;return Me({root:["root"]},Ao,o)},Wo=ye("div",{name:"MuiTableContainer",slot:"Root",overridesResolver:(e,o)=>o.root})({width:"100%",overflowX:"auto"}),$o=W.forwardRef(function(o,n){const i=$e({props:o,name:"MuiTableContainer"}),{className:h,component:f="div",...u}=i,p={...i,component:f},g=Io(p);return r.jsx(Wo,{ref:n,as:f,className:Se(g.root,h),ownerState:p,...u})});function Mo(e){return We("MuiTableHead",e)}Ie("MuiTableHead",["root"]);const Lo=e=>{const{classes:o}=e;return Me({root:["root"]},Mo,o)},zo=ye("thead",{name:"MuiTableHead",slot:"Root",overridesResolver:(e,o)=>o.root})({display:"table-header-group"}),Eo={variant:"head"},ct="thead",Oo=W.forwardRef(function(o,n){const i=$e({props:o,name:"MuiTableHead"}),{className:h,component:f=ct,...u}=i,p={...i,component:f},g=Lo(p);return r.jsx(ao.Provider,{value:Eo,children:r.jsx(zo,{as:f,className:Se(g.root,h),ref:n,role:f===ct?null:"rowgroup",ownerState:p,...u})})});function Qe(e){"@babel/helpers - typeof";return Qe=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(o){return typeof o}:function(o){return o&&typeof Symbol=="function"&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},Qe(e)}function pe(e,o){if(o.length<e)throw new TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+o.length+" present")}function oe(e){pe(1,arguments);var o=Object.prototype.toString.call(e);return e instanceof Date||Qe(e)==="object"&&o==="[object Date]"?new Date(e.getTime()):typeof e=="number"||o==="[object Number]"?new Date(e):((typeof e=="string"||o==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}var Fo={};function Bo(){return Fo}function lt(e){var o=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds()));return o.setUTCFullYear(e.getFullYear()),e.getTime()-o.getTime()}function _e(e,o){pe(2,arguments);var n=oe(e),i=oe(o),h=n.getTime()-i.getTime();return h<0?-1:h>0?1:h}function _o(e,o){pe(2,arguments);var n=oe(e),i=oe(o),h=n.getFullYear()-i.getFullYear(),f=n.getMonth()-i.getMonth();return h*12+f}function Ho(e,o){return pe(2,arguments),oe(e).getTime()-oe(o).getTime()}var Do={ceil:Math.ceil,round:Math.round,floor:Math.floor,trunc:function(o){return o<0?Math.ceil(o):Math.floor(o)}},Vo="trunc";function Ko(e){return Do[Vo]}function Uo(e){pe(1,arguments);var o=oe(e);return o.setHours(23,59,59,999),o}function qo(e){pe(1,arguments);var o=oe(e),n=o.getMonth();return o.setFullYear(o.getFullYear(),n+1,0),o.setHours(23,59,59,999),o}function Jo(e){pe(1,arguments);var o=oe(e);return Uo(o).getTime()===qo(o).getTime()}function Xo(e,o){pe(2,arguments);var n=oe(e),i=oe(o),h=_e(n,i),f=Math.abs(_o(n,i)),u;if(f<1)u=0;else{n.getMonth()===1&&n.getDate()>27&&n.setDate(30),n.setMonth(n.getMonth()-h*f);var p=_e(n,i)===-h;Jo(oe(e))&&f===1&&_e(e,i)===1&&(p=!1),u=h*(f-Number(p))}return u===0?0:u}function Yo(e,o,n){pe(2,arguments);var i=Ho(e,o)/1e3;return Ko()(i)}var Go={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},Qo=function(o,n,i){var h,f=Go[o];return typeof f=="string"?h=f:n===1?h=f.one:h=f.other.replace("{{count}}",n.toString()),i!=null&&i.addSuffix?i.comparison&&i.comparison>0?"in "+h:h+" ago":h};function Xe(e){return function(){var o=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=o.width?String(o.width):e.defaultWidth,i=e.formats[n]||e.formats[e.defaultWidth];return i}}var Zo={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},er={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},tr={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},or={date:Xe({formats:Zo,defaultWidth:"full"}),time:Xe({formats:er,defaultWidth:"full"}),dateTime:Xe({formats:tr,defaultWidth:"full"})},rr={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},nr=function(o,n,i,h){return rr[o]};function Re(e){return function(o,n){var i=n!=null&&n.context?String(n.context):"standalone",h;if(i==="formatting"&&e.formattingValues){var f=e.defaultFormattingWidth||e.defaultWidth,u=n!=null&&n.width?String(n.width):f;h=e.formattingValues[u]||e.formattingValues[f]}else{var p=e.defaultWidth,g=n!=null&&n.width?String(n.width):e.defaultWidth;h=e.values[g]||e.values[p]}var T=e.argumentCallback?e.argumentCallback(o):o;return h[T]}}var ar={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},ir={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},sr={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},cr={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},lr={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},dr={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},pr=function(o,n){var i=Number(o),h=i%100;if(h>20||h<10)switch(h%10){case 1:return i+"st";case 2:return i+"nd";case 3:return i+"rd"}return i+"th"},ur={ordinalNumber:pr,era:Re({values:ar,defaultWidth:"wide"}),quarter:Re({values:ir,defaultWidth:"wide",argumentCallback:function(o){return o-1}}),month:Re({values:sr,defaultWidth:"wide"}),day:Re({values:cr,defaultWidth:"wide"}),dayPeriod:Re({values:lr,defaultWidth:"wide",formattingValues:dr,defaultFormattingWidth:"wide"})};function ke(e){return function(o){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=n.width,h=i&&e.matchPatterns[i]||e.matchPatterns[e.defaultMatchWidth],f=o.match(h);if(!f)return null;var u=f[0],p=i&&e.parsePatterns[i]||e.parsePatterns[e.defaultParseWidth],g=Array.isArray(p)?hr(p,function(C){return C.test(u)}):fr(p,function(C){return C.test(u)}),T;T=e.valueCallback?e.valueCallback(g):g,T=n.valueCallback?n.valueCallback(T):T;var m=o.slice(u.length);return{value:T,rest:m}}}function fr(e,o){for(var n in e)if(e.hasOwnProperty(n)&&o(e[n]))return n}function hr(e,o){for(var n=0;n<e.length;n++)if(o(e[n]))return n}function mr(e){return function(o){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},i=o.match(e.matchPattern);if(!i)return null;var h=i[0],f=o.match(e.parsePattern);if(!f)return null;var u=e.valueCallback?e.valueCallback(f[0]):f[0];u=n.valueCallback?n.valueCallback(u):u;var p=o.slice(h.length);return{value:u,rest:p}}}var gr=/^(\d+)(th|st|nd|rd)?/i,br=/\d+/i,xr={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},yr={any:[/^b/i,/^(a|c)/i]},wr={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},vr={any:[/1/i,/2/i,/3/i,/4/i]},Nr={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},Sr={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},Cr={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},Tr={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},jr={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},Pr={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},Rr={ordinalNumber:mr({matchPattern:gr,parsePattern:br,valueCallback:function(o){return parseInt(o,10)}}),era:ke({matchPatterns:xr,defaultMatchWidth:"wide",parsePatterns:yr,defaultParseWidth:"any"}),quarter:ke({matchPatterns:wr,defaultMatchWidth:"wide",parsePatterns:vr,defaultParseWidth:"any",valueCallback:function(o){return o+1}}),month:ke({matchPatterns:Nr,defaultMatchWidth:"wide",parsePatterns:Sr,defaultParseWidth:"any"}),day:ke({matchPatterns:Cr,defaultMatchWidth:"wide",parsePatterns:Tr,defaultParseWidth:"any"}),dayPeriod:ke({matchPatterns:jr,defaultMatchWidth:"any",parsePatterns:Pr,defaultParseWidth:"any"})},kr={code:"en-US",formatDistance:Qo,formatLong:or,formatRelative:nr,localize:ur,match:Rr,options:{weekStartsOn:0,firstWeekContainsDate:1}};function bt(e,o){if(e==null)throw new TypeError("assign requires that input parameter not be null or undefined");for(var n in o)Object.prototype.hasOwnProperty.call(o,n)&&(e[n]=o[n]);return e}function Ar(e){return bt({},e)}var dt=1440,Ir=2520,Ye=43200,Wr=86400;function $r(e,o,n){var i,h;pe(2,arguments);var f=Bo(),u=(i=(h=n==null?void 0:n.locale)!==null&&h!==void 0?h:f.locale)!==null&&i!==void 0?i:kr;if(!u.formatDistance)throw new RangeError("locale must contain formatDistance property");var p=_e(e,o);if(isNaN(p))throw new RangeError("Invalid time value");var g=bt(Ar(n),{addSuffix:!!(n!=null&&n.addSuffix),comparison:p}),T,m;p>0?(T=oe(o),m=oe(e)):(T=oe(e),m=oe(o));var C=Yo(m,T),I=(lt(m)-lt(T))/1e3,P=Math.round((C-I)/60),H;if(P<2)return n!=null&&n.includeSeconds?C<5?u.formatDistance("lessThanXSeconds",5,g):C<10?u.formatDistance("lessThanXSeconds",10,g):C<20?u.formatDistance("lessThanXSeconds",20,g):C<40?u.formatDistance("halfAMinute",0,g):C<60?u.formatDistance("lessThanXMinutes",1,g):u.formatDistance("xMinutes",1,g):P===0?u.formatDistance("lessThanXMinutes",1,g):u.formatDistance("xMinutes",P,g);if(P<45)return u.formatDistance("xMinutes",P,g);if(P<90)return u.formatDistance("aboutXHours",1,g);if(P<dt){var D=Math.round(P/60);return u.formatDistance("aboutXHours",D,g)}else{if(P<Ir)return u.formatDistance("xDays",1,g);if(P<Ye){var V=Math.round(P/dt);return u.formatDistance("xDays",V,g)}else if(P<Wr)return H=Math.round(P/Ye),u.formatDistance("aboutXMonths",H,g)}if(H=Xo(m,T),H<12){var q=Math.round(P/Ye);return u.formatDistance("xMonths",q,g)}else{var G=H%12,X=Math.floor(H/12);return G<3?u.formatDistance("aboutXYears",X,g):G<9?u.formatDistance("overXYears",X,g):u.formatDistance("almostXYears",X+1,g)}}function Mr(e,o){return pe(1,arguments),$r(e,Date.now(),o)}function Lr(e){return new Promise(o=>{setTimeout(()=>{o({html:`
            <div style="position:relative; width:100%; min-height:100vh;">

  <!-- Full page watermark -->
  <div style="
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background-repeat:repeat;
    background-image: repeating-linear-gradient(
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 100px
    ),
    repeating-linear-gradient(
      90deg,
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 300px
    );
    z-index:9999;
  ">
    <div style="
      position:absolute;      
      top:50%;
      left:50%;
      transform:translate(-50%,-50%) rotate(-60deg);
      font-size:72px;
      color:rgba(150,150,150,0.2);
      font-weight:bold;
      white-space:nowrap;
      font-family:Arial, sans-serif;
      pointer-events:none;
    ">
      DEMO DATA - NOT REAL
    </div>
  </div>

  <!-- Disclaimer Banner -->
  <div style="
    position:sticky;
    top:0;
    background-color:rgba(255,255,0,0.9);
    color:#000;
    padding:10px;
    font-size:16px;
    text-align:center;
    font-weight:bold;
    border-bottom:2px solid #000;
    z-index:1000;
  ">
    This page displays DEMO DATA for review purposes only. No real information is shown.
  </div>

  <!-- Your existing dummy HTML -->
  <div style="position:relative; z-index:1; padding:20px; background-color:white;">

    <table width="100%" border="1" style="border-collapse: collapse;">
      <tr>
        <td width="55%">
          <div style="border: thin; position: relative; width: 100%;">
            <b style="color:#0000FF;">
              <font face="Verdana">(Demo Data Generated on 08/08/2025, 12:00:00)</font>
            </b><br/>
            <b style="color:#660033;">&nbsp;<label><font face='BN BIDISHA Opentype'>J.L No </font>:</label>&nbsp;</b>999
            <b style="color:#660033;">&nbsp;&nbsp; <font face='BN BIDISHA Opentype'>Thana </font>:&nbsp;</b>
            <font face='BN BIDISHA Opentype'>Demo Thana</font>&nbsp;<br/>
          </div>

          <div class="table-responsive" style="border: thin; position: relative; left: 3px; width: 97%;">
            <table class="table" width="95%" border="1" style="border-collapse: collapse;">
              <tr>
                <th width="43%"><div align="left"><font face='BN BIDISHA Opentype'>Khatian No</font>&nbsp;&nbsp;:&nbsp;</div></th>
                <th width="57%" bgcolor="#CCCCCC"><div align="left"><font face='BN BIDISHA Opentype'>00</font></div></th>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Nam</font>&nbsp;&nbsp;:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Name</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Pita/Swami</font>&nbsp;&nbsp;:</td>
                <td bgcolor="#CCCCCC"><font face='BN BIDISHA Opentype'>Demo Parent</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Dharan</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Type</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Thikana</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Address</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Zamir Pariman</font>:</td>
                <td bgcolor="#CCCCCC">0.00 Ekar</td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Dager Sankhyan</font>:</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <p><strong><font style="color: #0048FF;font-size:18px" face='BN BIDISHA Opentype'>Atrasbatber Dager Bibaran O Pariman:</font></strong></p>
          <p><font style="color: #8000ff;font-size:12px" face='BN BIDISHA Opentype'>(This is demo data only. No real land records are shown.)</font></p>

          <div class="table-responsive" style="border: thin none; position: relative; left: 5px; width: 97%; overflow: auto; top: -10px; margin-top:1em; margin-right: 5px;">
            <table class="table table-fixed" width="95%" align="center" style="border-collapse: collapse">
              <thead>
                <tr>
                  <th><center>Dag No</center></th>
                  <th><center>Shreni</center></th>
                  <th><center>Ansh</center></th>
                  <th><center>Ansh Pariman (ekar)</center></th>
                  <th><center>Dakhaldar</center></th>
                  <th><center>Mantaby</center></th>
                </tr>
              </thead>
              <tbody>
                <tr bgcolor="#CCCCCC">
                  <td align="center">0001</td>
                  <td align="center">Demo Class</td>
                  <td align="center">1.0000</td>
                  <td align="center">0.00</td>
                  <td align="center">Demo Holder</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
                <tr>
                  <td align="center">0002</td>
                  <td align="center">Demo Class</td>
                  <td align="center">0.5000</td>
                  <td align="center">0.00</td>
                  <td align="center">Nil</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>

        <td width="45%" valign="top">
          <div class="table-responsive" style="border: thin; width: 95%; height: 300px; overflow: auto;">
            <center style="color:gray; padding-top:120px;">Demo Map / Additional Info</center>
          </div>
        </td>
      </tr>
    </table>

  </div>
</div>
          `})},1e3)})}function zr(e){if(!e)return null;const o=parseFloat(e.replace(/[^0-9.]/g,""));if(isNaN(o)||o<=0)return null;const n=(o*100).toFixed(2),i=(o*60.5).toFixed(2);return{acre:o.toFixed(4),satak:n,katha:i}}function Er(e){if(!e)return"default";const o=e.toLowerCase();return o.includes("executed")||o.includes("completed")||o.includes("approved")||o.includes("success")?"success":o.includes("under mutation")||o.includes("pending")||o.includes("in progress")||o.includes("process")?"warning":o.includes("registered")||o.includes("initiated")||o.includes("hearing")?"info":o.includes("rejected")||o.includes("dismissed")||o.includes("error")||o.includes("cancelled")?"error":"primary"}function Or({parsedData:e,locationInfo:o={},landDetails:n={},onCaseAction:i,onSwitchToHtml:h,onSavePdf:f,onSharePdf:u,onPrintPdf:p,onRetry:g,onBack:T,darkMode:m}){var k,Q,be,de,ue;const{t:C}=Ge(),I=tt(),[P,H]=W.useState(null),[D,V]=W.useState(""),{isError:q,errorType:G,title:X,errorMessage:F,isPdf:z,docTitle:y,docSubtitle:L,fileSizeKb:$,pdfData:J,moduleType:x="kyp",isWarishNotice:ee,metadata:l={},tables:R=[],rsLrPairs:w=[],mutationCases:N=[]}=e||{},b=!!(ee||l!=null&&l.warishNotice),d=(l==null?void 0:l.warishNotice)||{},{selectedDistrict:S,selectedBlock:t,selectedMouza:E}=o,te=(B,s)=>{var a;B&&(ie(),(a=navigator.clipboard)==null||a.writeText(B),H(s),setTimeout(()=>H(null),2e3))},le=W.useMemo(()=>zr(l.totalArea),[l.totalArea]),me=W.useMemo(()=>{if(!D.trim())return R;const B=D.toLowerCase();return R.map(s=>({...s,rows:s.rows.filter(a=>a.some(j=>j.toLowerCase().includes(B)))}))},[R,D]),Z=l.ownerName||(l.khatianNo?`Khatian #${l.khatianNo}`:"")||(n!=null&&n.mainNo?`${n.searchBy==="plot"?"Plot":"Khatian"} #${n.mainNo}`:"")||(n!=null&&n.caseNumber||n!=null&&n.caseNo?`Case #${n.caseNumber||n.caseNo}`:"")||(n!=null&&n.applicationNo||n!=null&&n.appNo?`App #${n.applicationNo||n.appNo}`:"")||(n!=null&&n.grnNo?`GRN #${n.grnNo}`:"")||"Land Record",se=le||l.plotCount;if(q){const B=G==="no_record",a=B?"search_off":G==="captcha"?"vpn_key_alert":"warning_amber";return r.jsx(U,{sx:{p:{xs:2,sm:3},maxWidth:720,mx:"auto",width:"100%",boxSizing:"border-box"},children:r.jsxs(ae,{elevation:0,sx:{borderRadius:4,overflow:"hidden",border:`1.5px solid ${je(I.palette.warning.main,m?.4:.25)}`,bgcolor:m?"rgba(28, 22, 18, 0.85)":"rgba(255, 251, 245, 0.95)",backdropFilter:"blur(12px)",boxShadow:m?"0 8px 32px rgba(0, 0, 0, 0.5)":"0 8px 32px rgba(217, 119, 6, 0.08)",textAlign:"center",p:{xs:3,sm:4}},children:[r.jsx(U,{sx:{width:72,height:72,borderRadius:"50%",mx:"auto",mb:2.5,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:je(I.palette.warning.main,.14),color:I.palette.warning.main},children:r.jsx(O,{sx:{fontSize:40},children:a})}),r.jsx(A,{variant:"h5",fontWeight:800,color:"text.primary",gutterBottom:!0,children:X||(B?"Record Not Found":"Notice / Alert")}),r.jsx(A,{variant:"body1",color:"text.secondary",sx:{maxWidth:520,mx:"auto",mb:3,lineHeight:1.6},children:F||"No matching record was returned by the portal for this query."}),r.jsxs(U,{sx:{p:2,mb:3.5,borderRadius:3,bgcolor:m?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.03)",border:`1px solid ${I.palette.divider}`,display:"flex",flexWrap:"wrap",gap:1.5,justifyContent:"center",alignItems:"center"},children:[(S==null?void 0:S.name)&&r.jsx(_,{size:"small",label:`District: ${S.name}`,variant:"outlined"}),(t==null?void 0:t.name)&&r.jsx(_,{size:"small",label:`Block: ${t.name}`,variant:"outlined"}),(E==null?void 0:E.name)&&r.jsx(_,{size:"small",label:`Mouza: ${E.name}`,variant:"outlined"}),(n==null?void 0:n.mainNo)&&r.jsx(_,{size:"small",color:"primary",label:`${n.searchBy==="plot"?C("recentSearch.plotNo","Plot"):C("recentSearch.khatianNo","Khatian")}: ${n.mainNo}${n.subNo?"/"+n.subNo:""}`,sx:{fontWeight:700}}),((n==null?void 0:n.caseNumber)||(n==null?void 0:n.caseNo))&&r.jsx(_,{size:"small",color:"primary",label:`${C("recentSearch.caseNo","Case No")}: ${(n==null?void 0:n.caseNumber)||(n==null?void 0:n.caseNo)}`,sx:{fontWeight:700}}),!(n!=null&&n.caseNumber)&&!(n!=null&&n.caseNo)&&((n==null?void 0:n.applicationNo)||(n==null?void 0:n.appNo))&&r.jsx(_,{size:"small",color:"primary",label:`${C("recentSearch.appNo","App No")}: ${(n==null?void 0:n.applicationNo)||(n==null?void 0:n.appNo)}`,sx:{fontWeight:700}}),(n==null?void 0:n.grnNo)&&r.jsx(_,{size:"small",color:"primary",label:`GRN: ${n.grnNo}`,sx:{fontWeight:700}})]}),r.jsxs(K,{direction:{xs:"column",sm:"row"},spacing:1.5,justifyContent:"center",alignItems:"center",children:[T&&r.jsx(Ne,{variant:"outlined",color:"primary",startIcon:r.jsx(O,{children:"arrow_back"}),onClick:()=>{ie(),T()},sx:{borderRadius:2.5,px:2.5,py:1,textTransform:"none",fontWeight:700},children:C("kyp.recordView.editSearchQuery","Edit Search Query")}),g&&r.jsx(Ne,{variant:"contained",color:"primary",startIcon:r.jsx(O,{children:"refresh"}),onClick:()=>{ie(),g()},sx:{borderRadius:2.5,px:3,py:1,textTransform:"none",fontWeight:700},children:C("kyp.recordView.retrySearch","Retry Search")}),h&&r.jsx(Ne,{variant:"text",color:"inherit",startIcon:r.jsx(O,{children:"html"}),onClick:()=>{ie(),h()},sx:{borderRadius:2.5,textTransform:"none",fontWeight:600},children:"View Portal Page"})]})]})})}if(z)return r.jsx(U,{sx:{p:{xs:1.5,sm:2},maxWidth:860,mx:"auto",width:"100%",boxSizing:"border-box"},children:r.jsxs(K,{spacing:2,children:[r.jsx(ae,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",border:`1.5px solid ${m?"rgba(225, 29, 72, 0.35)":"rgba(225, 29, 72, 0.25)"}`,background:m?"linear-gradient(135deg, #2b1318 0%, #15161d 100%)":"linear-gradient(135deg, #fff1f2 0%, #ffffff 100%)",boxShadow:m?"0 6px 24px rgba(0, 0, 0, 0.45)":"0 6px 24px rgba(225, 29, 72, 0.08)",p:{xs:2.5,sm:3}},children:r.jsxs(K,{spacing:2,children:[r.jsxs(K,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:[r.jsxs(K,{direction:"row",spacing:1,alignItems:"center",children:[r.jsx(U,{sx:{width:44,height:44,borderRadius:2.5,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:"error.main",color:"#fff",boxShadow:"0 4px 12px rgba(225, 29, 72, 0.35)"},children:r.jsx(O,{children:"picture_as_pdf"})}),r.jsxs(U,{children:[r.jsx(A,{variant:"h6",fontWeight:800,color:"text.primary",sx:{lineHeight:1.2},children:y||"Official Land Record PDF"}),r.jsx(A,{variant:"caption",color:"text.secondary",children:L||"Certified Government Statement"})]})]}),r.jsxs(K,{direction:"row",spacing:1,alignItems:"center",children:[$&&r.jsx(_,{size:"small",label:`~${$} KB`,sx:{fontWeight:700,fontSize:"0.75rem"}}),r.jsx(_,{size:"small",color:"success",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"verified"}),label:"Official Seal",sx:{fontWeight:700,fontSize:"0.75rem"}})]})]}),r.jsx(mt,{}),r.jsxs(K,{direction:"row",spacing:1.5,flexWrap:"wrap",children:[f&&r.jsx(Ne,{variant:"contained",color:"error",startIcon:r.jsx(O,{children:"download"}),onClick:()=>{ie(),f()},sx:{borderRadius:2.5,px:2.5,textTransform:"none",fontWeight:700},children:"Download PDF"}),u&&r.jsx(Ne,{variant:"outlined",color:"inherit",startIcon:r.jsx(O,{children:"share"}),onClick:()=>{ie(),u()},sx:{borderRadius:2.5,px:2,textTransform:"none",fontWeight:600},children:"Share"}),p&&r.jsx(Ne,{variant:"outlined",color:"inherit",startIcon:r.jsx(O,{children:"print"}),onClick:()=>{ie(),p()},sx:{borderRadius:2.5,px:2,textTransform:"none",fontWeight:600},children:"Print"})]})]})}),r.jsx(ae,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",border:`1px solid ${I.palette.divider}`,bgcolor:m?"#1a222c":"#525659",height:"70vh",minHeight:520,width:"100%",position:"relative"},children:r.jsx("iframe",{src:J!=null&&J.startsWith("data:application/pdf;base64,")?J:`data:application/pdf;base64,${J}#toolbar=0`,title:"PDF Document",style:{width:"100%",height:"100%",border:"none"}})})]})});const ge=x==="rs-lr",re=w[0]||((Q=(k=R[0])==null?void 0:k.rows)!=null&&Q[0]?{lrPlot:R[0].rows[0][0],rsPlot:R[0].rows[0][1]}:null);return r.jsx(U,{sx:{p:{xs:1.5,sm:2},maxWidth:1e3,width:"100%",mx:"auto",boxSizing:"border-box",overflowX:"hidden"},children:r.jsxs(K,{spacing:2,sx:{width:"100%",maxWidth:"100%",overflowX:"hidden"},children:[ge&&re&&r.jsx(ae,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",background:m?"linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%)":"linear-gradient(135deg, #eef2ff 0%, #faf5ff 100%)",border:`1.5px solid ${m?"rgba(79, 70, 229, 0.4)":"rgba(79, 70, 229, 0.25)"}`,boxShadow:m?"0 4px 18px rgba(0, 0, 0, 0.4)":"0 4px 18px rgba(79, 70, 229, 0.08)",p:{xs:2,sm:2.5}},children:r.jsxs(K,{spacing:2,children:[r.jsx(U,{children:r.jsx(A,{variant:"caption",fontWeight:800,color:"primary",letterSpacing:"0.04em",children:"RS ⇄ LR PLOT MAPPING (দাগ রূপান্তর)"})}),r.jsxs(U,{sx:{display:"grid",gridTemplateColumns:{xs:"1fr auto 1fr"},alignItems:"center",justifyContent:"center",textAlign:"center",gap:1.5,p:2,borderRadius:3,bgcolor:m?"rgba(255, 255, 255, 0.04)":"rgba(255, 255, 255, 0.8)",border:`1px solid ${I.palette.divider}`},children:[r.jsxs(U,{children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"LR PLOT (হাল দাগ)"}),r.jsx(A,{variant:"h4",fontWeight:900,color:"primary.main",children:re.lrPlot}),r.jsx(Ae,{title:P==="lr"?"Copied!":"Copy LR Plot",children:r.jsx(Ee,{size:"small",onClick:()=>te(re.lrPlot,"lr"),children:r.jsx(O,{sx:{fontSize:16},children:P==="lr"?"done":"content_copy"})})})]}),r.jsx(U,{sx:{color:"primary.main"},children:r.jsx(O,{sx:{fontSize:32},children:"sync_alt"})}),r.jsxs(U,{children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"RS PLOT (সাবেক দাগ)"}),r.jsx(A,{variant:"h4",fontWeight:900,color:"secondary.main",children:re.rsPlot}),r.jsx(Ae,{title:P==="rs"?"Copied!":"Copy RS Plot",children:r.jsx(Ee,{size:"small",onClick:()=>te(re.rsPlot,"rs"),children:r.jsx(O,{sx:{fontSize:16},children:P==="rs"?"done":"content_copy"})})})]})]}),(l.jlNo||l.thana)&&r.jsxs(K,{direction:"row",spacing:1,flexWrap:"wrap",children:[l.jlNo&&r.jsx(_,{size:"small",label:`J.L. No: ${l.jlNo}`,sx:{fontWeight:700}}),l.thana&&r.jsx(_,{size:"small",label:`Thana: ${l.thana}`,sx:{fontWeight:600}})]})]})}),b&&r.jsx(ae,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",width:"100%",boxSizing:"border-box",background:m?"linear-gradient(135deg, #1c1917 0%, #291e12 100%)":"linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)",border:`1.5px solid ${m?"rgba(245, 158, 11, 0.35)":"rgba(245, 158, 11, 0.25)"}`,boxShadow:m?"0 4px 18px rgba(0, 0, 0, 0.4)":"0 4px 18px rgba(245, 158, 11, 0.12)",p:{xs:2,sm:2.5}},children:r.jsxs(K,{spacing:2,children:[r.jsx(K,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:r.jsxs(K,{direction:"row",spacing:.8,flexWrap:"wrap",alignItems:"center",children:[r.jsx(_,{size:"small",color:d.noticeType==="investigation"?"info":"warning",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:d.noticeType==="investigation"?"policy":"gavel"}),label:d.noticeType==="investigation"?C("wb.warish.investigationNoticeTitle","Inquiry / Investigation Notice (তদন্তের নোটিশ)"):C("wb.warish.hearingNoticeTitle","Hearing Notice (শুনানীর নোটিশ)"),sx:{fontWeight:800,fontSize:"0.78rem"}}),d.caseNo&&r.jsx(_,{size:"small",label:`Case: ${d.caseNo}`,variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}}),d.caseDate&&r.jsx(_,{size:"small",label:`Date: ${d.caseDate}`,sx:{fontWeight:600,fontSize:"0.75rem"}})]})}),r.jsxs(U,{children:[r.jsx(A,{variant:"caption",color:"warning.main",fontWeight:800,letterSpacing:"0.04em",children:d.authorityLaw||"প: ব: ভূ: স: আইনের ৫০ ধারা অনুসারে"}),r.jsxs(K,{direction:"row",spacing:1,alignItems:"center",flexWrap:"wrap",children:[r.jsx(A,{variant:"h5",fontWeight:800,color:"text.primary",sx:{fontSize:{xs:"1.2rem",sm:"1.45rem"},whiteSpace:"normal",wordBreak:"break-word"},children:d.noticeTitle||"উত্তরাধিকার নথিভুক্তকরণ শুনানীর নোটিশ"}),d.caseNo&&r.jsx(Ae,{title:P==="warishCase"?"Copied!":"Copy Case No",children:r.jsx(Ee,{size:"small",onClick:()=>te(d.caseNo,"warishCase"),children:r.jsx(O,{sx:{fontSize:18},children:P==="warishCase"?"done":"content_copy"})})})]}),r.jsxs(K,{direction:"row",spacing:1,flexWrap:"wrap",sx:{mt:1},children:[d.district&&r.jsx(_,{size:"small",label:`District: ${d.district}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.block&&r.jsx(_,{size:"small",label:`Block: ${d.block}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.mouza&&r.jsx(_,{size:"small",label:`Mouza: ${d.mouza}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.mouzaCode&&r.jsx(_,{size:"small",label:`Code: ${d.mouzaCode}`,variant:"outlined",sx:{fontWeight:600,fontSize:"0.75rem"}})]})]}),(d.hearingDate||d.hearingTime)&&r.jsx(U,{sx:{p:1.5,borderRadius:2.5,bgcolor:m?"rgba(245, 158, 11, 0.08)":"rgba(245, 158, 11, 0.12)",border:`1px solid ${je(I.palette.warning.main,.3)}`},children:r.jsxs(K,{direction:{xs:"column",sm:"row"},spacing:2,alignItems:{xs:"flex-start",sm:"center"},justifyContent:"space-between",children:[r.jsxs(K,{direction:"row",spacing:1.5,alignItems:"center",children:[r.jsx(U,{sx:{p:1,borderRadius:2,bgcolor:je(I.palette.warning.main,.2),color:"warning.main",display:"flex"},children:r.jsx(O,{sx:{fontSize:28},children:"event_upcoming"})}),r.jsxs(U,{children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:C("wb.warish.hearingSchedule","Hearing / Appearance Schedule")}),r.jsxs(A,{variant:"h6",fontWeight:900,color:"text.primary",children:[d.hearingDate," ",d.hearingTime?`@ ${d.hearingTime}`:""]})]})]}),d.authorityOffice&&r.jsx(A,{variant:"caption",color:"text.secondary",sx:{fontStyle:"italic",maxWidth:300},children:d.authorityOffice})]})}),(d.predecessorKhatian||d.predecessorPlots&&d.predecessorPlots.length>0)&&r.jsx(ae,{elevation:0,sx:{p:1.5,borderRadius:2.5,bgcolor:m?"rgba(255, 255, 255, 0.03)":"rgba(255, 255, 255, 0.75)",border:`1px solid ${I.palette.divider}`},children:r.jsxs(K,{spacing:1.2,children:[r.jsxs(K,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:[r.jsx(A,{variant:"caption",fontWeight:800,color:"primary",letterSpacing:"0.04em",children:C("wb.warish.predecessorRecord","PREDECESSOR'S LAND RECORD (পূর্বসূরীর খতিয়ান ও দাগ)")}),((be=d.predecessorPlots)==null?void 0:be.length)>0&&r.jsx(Ne,{size:"small",variant:"outlined",startIcon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"content_copy"}),onClick:()=>te(d.predecessorPlots.join(", "),"allPlots"),sx:{textTransform:"none",py:.2,px:1,fontSize:"0.75rem",borderRadius:2},children:P==="allPlots"?C("wb.warish.allPlotsCopied","Copied!"):C("wb.warish.copyAllPlots","Copy All Plots")})]}),r.jsxs(K,{direction:"row",spacing:1,flexWrap:"wrap",alignItems:"center",children:[d.predecessorKhatian&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"badge"}),label:`Khatian: ${d.predecessorKhatian}`,color:"primary",sx:{fontWeight:800,fontSize:"0.78rem"}}),d.predecessorJlNo&&r.jsx(_,{size:"small",label:`J.L. No: ${d.predecessorJlNo}`,sx:{fontWeight:700,fontSize:"0.75rem"}}),((de=d.predecessorPlots)==null?void 0:de.length)>0&&r.jsx(_,{size:"small",label:`${d.predecessorPlots.length} Plots`,color:"secondary",variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}})]}),((ue=d.predecessorPlots)==null?void 0:ue.length)>0&&r.jsx(U,{sx:{display:"flex",flexWrap:"wrap",gap:.6,pt:.5},children:d.predecessorPlots.map((B,s)=>r.jsx(_,{size:"small",label:B,variant:"outlined",sx:{fontSize:"0.75rem",fontWeight:600,bgcolor:m?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.02)"}},s))})]})}),d.hearingNoticeText&&r.jsxs(U,{sx:{p:1.5,borderRadius:2,bgcolor:m?"rgba(0, 0, 0, 0.25)":"rgba(0, 0, 0, 0.03)",borderLeft:`4px solid ${I.palette.warning.main}`},children:[r.jsxs(A,{variant:"caption",color:"text.secondary",fontWeight:700,sx:{display:"block",mb:.5},children:[C("wb.warish.legalNoticeDirectives","Official Directives / নোটিশের নির্দেশাবলী"),":"]}),r.jsx(A,{variant:"body2",color:"text.primary",sx:{lineHeight:1.6,textAlign:"justify"},children:d.hearingNoticeText})]}),(d.authorityDesignation||d.authorityDate)&&r.jsxs(K,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,sx:{pt:.5},children:[r.jsxs(K,{direction:"row",spacing:1,alignItems:"center",children:[r.jsx(O,{color:"action",sx:{fontSize:18},children:"verified_user"}),r.jsxs(A,{variant:"caption",color:"text.secondary",fontWeight:600,children:[d.authorityDesignation||"রাজস্ব আধিকারিক"," ",d.authorityOffice?`· ${d.authorityOffice}`:""]})]}),d.authorityDate&&r.jsxs(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:["Issued: ",d.authorityDate]})]})]})}),!ge&&!b&&r.jsx(ae,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",width:"100%",boxSizing:"border-box",wordBreak:"break-word",background:m?"linear-gradient(135deg, #132f2b 0%, #0d1b1e 100%)":"linear-gradient(135deg, #e8f5f1 0%, #f0fdf4 100%)",border:`1.5px solid ${m?"rgba(33, 122, 100, 0.35)":"rgba(33, 122, 100, 0.25)"}`,boxShadow:m?"0 4px 16px rgba(0, 0, 0, 0.35)":"0 4px 16px rgba(33, 122, 100, 0.06)"},children:r.jsx(Rt,{sx:{p:{xs:2,sm:2.5}},children:r.jsxs(K,{spacing:1.5,children:[r.jsx(K,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:r.jsxs(K,{direction:"row",spacing:.8,flexWrap:"wrap",alignItems:"center",children:[l.jlNo&&r.jsx(_,{size:"small",label:`J.L. No: ${l.jlNo}`,sx:{fontWeight:700,fontSize:"0.75rem",bgcolor:m?"rgba(255, 255, 255, 0.08)":"rgba(33, 122, 100, 0.12)",color:"primary.main"}}),l.thana&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"local_police"}),label:`Thana: ${l.thana}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),l.classification&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"landscape"}),label:`Character: ${l.classification}`,variant:"outlined",color:"primary",sx:{fontWeight:600,fontSize:"0.75rem"}})]})}),r.jsxs(U,{children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,letterSpacing:"0.04em",children:l.ownerName?"RAYAT / OWNER":"PROPERTY DETAILS"}),r.jsxs(K,{direction:"row",spacing:1,alignItems:"center",flexWrap:"wrap",children:[r.jsx(A,{variant:"h5",fontWeight:800,color:"text.primary",sx:{fontSize:{xs:"1.2rem",sm:"1.45rem"},whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word"},children:Z}),l.ownerName&&r.jsx(Ae,{title:P==="owner"?"Copied!":"Copy Name",children:r.jsx(Ee,{size:"small",onClick:()=>te(l.ownerName,"owner"),children:r.jsx(O,{sx:{fontSize:18},children:P==="owner"?"done":"content_copy"})})})]}),l.address&&r.jsxs(A,{variant:"body2",color:"text.secondary",sx:{mt:.5,whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word"},children:[r.jsx("strong",{children:"Address:"})," ",l.address]})]}),r.jsxs(K,{direction:"row",flexWrap:"wrap",gap:1,children:[l.khatianNo&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"badge"}),label:`Khatian: ${l.khatianNo}`,color:"primary",variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}}),l.fatherHusband&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"person"}),label:`Father/Husband: ${l.fatherHusband}`,sx:{fontWeight:600,fontSize:"0.75rem",maxWidth:"100%",wordBreak:"break-word"}}),l.tenantType&&r.jsx(_,{size:"small",icon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"shield"}),label:`Type: ${l.tenantType}`,color:"info",variant:"outlined",sx:{fontWeight:600,fontSize:"0.75rem"}})]})]})})}),se&&!b&&r.jsxs(U,{sx:{display:"grid",gridTemplateColumns:{xs:"repeat(2, 1fr)",sm:l.plotCount?"repeat(4, 1fr)":"repeat(3, 1fr)"},gap:1.2,width:"100%",boxSizing:"border-box"},children:[le&&r.jsxs(r.Fragment,{children:[r.jsxs(ae,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${I.palette.divider}`,textAlign:"center"},children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"ACRES"}),r.jsx(A,{variant:"h6",fontWeight:800,color:"primary.main",sx:{my:.2},children:le.acre}),r.jsx(A,{variant:"caption",color:"text.secondary",children:"Total Land"})]}),r.jsxs(ae,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${I.palette.divider}`,textAlign:"center"},children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"SATAK / DECIMAL"}),r.jsx(A,{variant:"h6",fontWeight:800,sx:{my:.2},children:le.satak}),r.jsx(A,{variant:"caption",color:"text.secondary",children:"1 Acre = 100 Satak"})]}),r.jsxs(ae,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${I.palette.divider}`,textAlign:"center"},children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"KATHA (APPROX)"}),r.jsx(A,{variant:"h6",fontWeight:800,sx:{my:.2},children:le.katha}),r.jsx(A,{variant:"caption",color:"text.secondary",children:"WB Measure"})]})]}),l.plotCount&&r.jsxs(ae,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${I.palette.divider}`,textAlign:"center"},children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:700,children:"TOTAL PLOTS"}),r.jsx(A,{variant:"h6",fontWeight:800,color:"secondary.main",sx:{my:.2},children:l.plotCount}),r.jsx(A,{variant:"caption",color:"text.secondary",children:"Plots in Khatian"})]})]}),l.summaryItems&&l.summaryItems.length>0&&r.jsxs(ae,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${I.palette.divider}`,width:"100%",boxSizing:"border-box"},children:[r.jsx(A,{variant:"caption",fontWeight:800,color:"text.secondary",letterSpacing:"0.04em",sx:{mb:1,display:"block"},children:"ADDITIONAL PARTICULARS"}),r.jsx(U,{sx:{display:"grid",gridTemplateColumns:{xs:"1fr",sm:"repeat(2, 1fr)"},gap:1,width:"100%",boxSizing:"border-box"},children:l.summaryItems.map((B,s)=>r.jsxs(U,{sx:{p:1,borderRadius:2,bgcolor:m?"rgba(255, 255, 255, 0.03)":"rgba(0, 0, 0, 0.02)",display:"flex",justifyContent:"space-between",alignItems:"center",gap:1.5},children:[r.jsx(A,{variant:"caption",color:"text.secondary",fontWeight:600,sx:{flexShrink:0},children:B.key}),r.jsx(A,{variant:"body2",fontWeight:700,color:"text.primary",sx:{whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word",textAlign:"right"},children:B.value})]},s))})]}),R.length>0&&r.jsxs(K,{spacing:1.5,sx:{width:"100%",maxWidth:"100%"},children:[r.jsxs(K,{direction:{xs:"column",sm:"row"},justifyContent:"space-between",alignItems:{xs:"flex-start",sm:"center"},gap:1,sx:{width:"100%"},children:[r.jsxs(A,{variant:"subtitle1",fontWeight:800,color:"text.primary",children:["Detailed Records (",R.reduce((B,s)=>B+s.rows.length,0)," entries)"]}),r.jsx(kt,{size:"small",placeholder:"Filter in records...",value:D,onChange:B=>V(B.target.value),InputProps:{startAdornment:r.jsx(At,{position:"start",children:r.jsx(O,{fontSize:"small",children:"search"})})},sx:{width:{xs:"100%",sm:220}}})]}),me.map((B,s)=>r.jsxs(ae,{elevation:0,sx:{borderRadius:3,overflow:"hidden",border:`1px solid ${I.palette.divider}`,bgcolor:m?"rgba(22, 27, 34, 0.7)":"#ffffff",width:"100%",maxWidth:"100%",boxSizing:"border-box"},children:[B.title&&r.jsx(U,{sx:{p:1.2,px:2,bgcolor:m?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.02)"},children:r.jsx(A,{variant:"subtitle2",fontWeight:800,color:"primary.main",children:B.title})}),r.jsx($o,{sx:{maxHeight:440,width:"100%",maxWidth:"100%",overflowX:"auto",display:"block",WebkitOverflowScrolling:"touch",boxSizing:"border-box"},children:r.jsxs(io,{stickyHeader:!0,size:"small",sx:{minWidth:540,width:"100%"},children:[r.jsx(Oo,{children:r.jsx(Ke,{children:B.headers.map((a,j)=>{const c=typeof a=="string"&&(a.length>12||a.includes(" "));return r.jsx(Ue,{sx:{fontWeight:700,bgcolor:m?"#1a222c":"#f1f5f9",color:"text.primary",whiteSpace:c?"normal":"nowrap",wordBreak:c?"break-word":"normal",overflowWrap:"break-word",minWidth:c?110:80,maxWidth:c?200:"none",py:1.2,px:1.5,fontSize:"0.8rem",lineHeight:1.35,verticalAlign:"bottom"},children:a},j)})})}),r.jsx(so,{children:B.rows.length===0?r.jsx(Ke,{children:r.jsx(Ue,{colSpan:B.headers.length,align:"center",sx:{py:3},children:r.jsx(A,{variant:"body2",color:"text.secondary",children:"No matching records found"})})}):B.rows.map((a,j)=>r.jsx(Ke,{hover:!0,sx:{"&:nth-of-type(even)":{bgcolor:m?"rgba(255, 255, 255, 0.02)":"rgba(0, 0, 0, 0.015)"}},children:a.map((c,v)=>{const M=c.match(/((?:MN|WR|CN)\/\d{4}\/\d+\/\d+)/i),Y=typeof c=="string"&&(c.toLowerCase().includes("executed")||c.toLowerCase().includes("mutation")||c.toLowerCase().includes("registered")||c.toLowerCase().includes("completed")),ne=typeof c=="string"&&(c.length>12||c.includes(" "));return r.jsx(Ue,{sx:{fontSize:"0.84rem",whiteSpace:ne?"normal":"nowrap",wordBreak:ne?"break-word":"normal",overflowWrap:"break-word",minWidth:ne?120:80,maxWidth:ne?260:"none",py:1.1,px:1.5,color:c==="—"?"text.disabled":"text.primary",verticalAlign:"top",lineHeight:1.35},children:M?r.jsx(_,{size:"small",label:c,color:"primary",variant:"filled",clickable:!0,onClick:()=>i==null?void 0:i(c),deleteIcon:r.jsx(O,{sx:{fontSize:"14px !important"},children:"arrow_forward"}),onDelete:()=>i==null?void 0:i(c),sx:{fontWeight:700,fontSize:"0.75rem"}}):Y?r.jsx(_,{size:"small",label:c,color:Er(c),variant:"outlined",sx:{fontWeight:700,fontSize:"0.72rem"}}):c},v)})},j))})]})})]},s))]})]})})}function Ce(e){if(!e||typeof e!="string")return e;const o=["০","১","২","৩","৪","৫","৬","৭","৮","৯"];return e.replace(/[০-৯]/g,n=>o.indexOf(n))}function he(e){return e?e.replace(/&nbsp;/g," ").replace(/\s+/g," ").replace(/^[:\-–\s]+/,"").replace(/[:\-–\s]+$/,"").trim():""}const Fr={"dag no":"Plot No (দাগ নং)",dag:"Plot No (দাগ নং)",dags:"Plot No (দাগ নং)","দাগ নং":"Plot No (দাগ নং)",দাগ:"Plot No (দাগ নং)","lr dag no":"LR Plot (এল.আর দাগ)","lr plotno":"LR Plot (এল.আর দাগ)","lr plot":"LR Plot (এল.আর দাগ)","হাল দাগ নং":"LR Plot (এল.আর দাগ)","rs dag no":"RS Plot (আর.এস দাগ)","rs plotno":"RS Plot (আর.এস দাগ)","rs plot":"RS Plot (আর.এস দাগ)","সাবেক দাগ নং":"RS Plot (আর.এস দাগ)",shreni:"Land Character (শ্রেণি)",classification:"Land Character (শ্রেণি)",শ্রেণি:"Land Character (শ্রেণি)",শ্রেণী:"Land Character (শ্রেণি)","land code":"Land Code (শ্রেণী কোড)","classification of land":"Classification of Land (জমির শ্রেণী)",ansh:"Share (অংশ)",অংশ:"Share (অংশ)","ansh pariman (ekar)":"Share Area (Acres)","ansh pariman":"Share Area (Acres)","অংশ পরিমাণ(একর)":"Share Area (Acres)","অংশ পরিমাণ":"Share Area (Acres)",pariman:"Area (Acres)",পরিমাণ:"Area (Acres)","zamir moat pariman(ekar)":"Total Plot Area (Acres)","জমির মোট পরিমাণ(একর)":"Total Plot Area (Acres)",dakhaldar:"Possessor / Bargadar (দখলদার)",দখলদার:"Possessor / Bargadar (দখলদার)",mantaby:"Remarks (মন্তব্য)",mantabya:"Remarks (মন্তব্য)",remarks:"Remarks (মন্তব্য)",মন্তব্য:"Remarks (মন্তব্য)","raiter nam":"Owner Name (মালিকের নাম)","owner name":"Owner Name (মালিকের নাম)","রায়তের নাম":"Owner Name (মালিকের নাম)","মালিকের নাম":"Owner Name (মালিকের নাম)","pita/swami":"Father/Husband (পিতা/স্বামী)","পিতা/স্বামী":"Father/Husband (পিতা/স্বামী)",পিতা:"Father (পিতা)",স্বামী:"Husband (স্বামী)","seller name":"Seller Name (বিক্রেতার নাম)","seller khatian":"Seller Khatian (বিক্রেতার খতিয়ান)","seller guardian name":"Seller Guardian (অভিভাবকের নাম)","buyer name":"Buyer Name (ক্রেতার নাম)","buyer khatian":"Buyer Khatian (ক্রেতার খতিয়ান)","buyer address":"Buyer Address (ক্রেতার ঠিকানা)","applicant's name":"Applicant Name (আবেদনকারী)","applicant name":"Applicant Name (আবেদনকারী)","applicant's address":"Applicant Address (ঠিকানা)","applicant address":"Applicant Address (ঠিকানা)","applicant's khatian":"Applicant Khatian (খতিয়ান)","case no":"Case No (কেস নং)",txtcaseno:"Case No (কেস নং)","কেস নং":"Case No (কেস নং)","case date":"Case Date (কেসের তারিখ)","deed no":"Deed No (দলিল নং)","deed year":"Deed Year (দলিলের বছর)","execution date":"Execution Date (সম্পাদনের তারিখ)","hearing date":"Hearing Date (শুনানির তারিখ)","date & time":"Date & Time (তারিখ ও সময়)",venue:"Venue (স্থান)",status:"Status (অবস্থা)","view plot / ror":"Plot / ROR (দাগ/খতিয়ান)","view plot":"Plot (দাগ)",download:"Document (ডকুমেন্ট)","application no.":"Application No (আবেদন নং)","application no":"Application No (আবেদন নং)","application date":"Application Date (আবেদনের তারিখ)","application type":"Application Type (আবেদনের ধরণ)","nature of application":"Nature of Application (প্রকৃতি)",demand:"Demand (দাবি)",due:"Dues (বকেয়া)","dager myap":"Plot Map (নকশা)","দাগের ম্যাপ":"Plot Map (নকশা)","khatian no":"Khatian No (খতিয়ান নং)",khatian:"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)"};function pt(e){const o=he(e).toLowerCase();for(const[n,i]of Object.entries(Fr))if(o===n.toLowerCase()||o.includes(n.toLowerCase()))return i;return he(e)}function ut(e){if(!e)return"";let o=he(e);return(o.includes("Demo Data")||o.includes("demo data"))&&(o=o.replace(/\(.*Demo Data.*?\)/gi,"").replace(/Demo Data.*?Generated.*?\)/gi,"")),o.includes("Atrasbatber Dager Bibaran")||o.includes("Bibaran O Pariman")||o.includes("দাগের বিবরণ ও পরিমাণ")?"Plot Details & Area Share (দাগের বিবরণ ও পরিমাণ)":(o.includes("Khatian")||o.includes("খতিয়ান")||o.includes("খতিয়ান"))&&(o.includes("Bibaran")||o.includes("বিবরণ")||o.includes("List"))?"Associated Khatians & Owners (খতিয়ান ও মালিকের বিবরণ)":(o.includes("RS")||o.includes("সাবেক"))&&(o.includes("LR")||o.includes("হাল"))?"RS-LR Plot Cross Reference (আর.এস - এল.আর দাগ রূপান্তর)":o.includes("Mutation")||o.includes("মিউটেশন")?"Mutation Case Docket (মিউটেশন কেস বিবরণ)":o.includes("Barga")||o.includes("বর্গাদার")?"Recorded Bargadars / Sharecroppers (বর্গাদার তথ্য)":o.includes("Land Class")||o.includes("শ্রেণী কোড")?"Land Classification Directory (জমির শ্রেণী)":he(o)}function Br(e){if(!e||typeof e!="string")return{isError:!0,errorType:"empty",message:"No data received from portal server."};const o=e.trim();if(o.length===0)return{isError:!0,errorType:"empty",message:"Empty response received."};if(/invalid\s*captcha|captcha\s*not\s*match|enter\s*proper\s*captcha/i.test(o))return{isError:!0,errorType:"captcha",title:"Captcha Verification Failed",message:"The portal rejected the security captcha. Please go back and retry with a fresh captcha image."};if(/session\s*expired|please\s*login\s*again/i.test(o))return{isError:!0,errorType:"session_expired",title:"Session Expired",message:"Your Banglarbhumi session has timed out. Please login again to continue."};if(/record\s*not\s*found|case\s*details\s*not\s*found|no\s*record\s*found|no\s*data\s*found|sorry\s*no\s*data|no\s*land\s*revenue.*?found|কোন\s*তথ্য\s*পাওয়া\s*যায়নি|তথ্য\s*পাওয়া\s*যায়নি/i.test(o)){let n="No land records found matching your query in the government registry.";return/no\s*land\s*revenue.*?found/i.test(o)?n="No Land Revenue (Khajna) application found for this Khatian.":/case\s*details\s*not\s*found/i.test(o)?n="Case details not found for the entered Case Number. Please verify the case number format.":/sorry\s*no\s*data\s*found\s*or\s*30\s*days/i.test(o)?n="No certified copy record found, or application validity period (30 days) has expired.":/record\s*not\s*found/i.test(o)&&(n="No record found for the entered Plot, Khatian, or Case Number."),{isError:!0,errorType:"no_record",title:"No Record Found",message:n}}return/the\s*length\s*of\s*case\s*no\s*cannot\s*be\s*less/i.test(o)||/application\s*no\.\s*not\s*valid/i.test(o)?{isError:!0,errorType:"invalid_input",title:"Invalid Input Format",message:o.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim()}:null}function _r(e=""){const o=e.toLowerCase();return o.includes("/rs-lr")?"rs-lr":o.includes("/khajna-status")?"khajna-status":o.includes("/mutation-case-details")?"mutation-case-details":o.includes("/mutation-case-status")?"mutation-case-status":o.includes("/mutation-status")||o.includes("/mutation")?"mutation-status":o.includes("/land-class")?"land-class":o.includes("/warish-status")?"warish-status":o.includes("/conversion-status")?"conversion-status":o.includes("/revenue-no-dues")?"revenue-no-dues":o.includes("/barga-info")?"barga-info":o.includes("/app-reprint")?"app-reprint":o.includes("/signed-copy")?"signed-copy":o.includes("/grn-search")?"grn-search":(o.includes("/kyp"),"kyp")}function Hr(e,o="warish-status"){if(!e||typeof e!="string"||!(o==="warish-status"||e.includes("notice-table")&&(e.includes("উত্তরাধিকার")||e.includes("শুনানী")||e.includes("তদন্ত")))||!e.includes("বাদী")&&!e.includes("পূর্বসূরী")&&!e.includes("notice-table"))return null;const i=k=>(k||"").replace(/<[^>]+>/g," ").replace(/&nbsp;/g," ").replace(/\s+/g," ").trim();let h="উত্তরাধিকার নথিভুক্তকরণ নোটিশ",f="hearing";e.includes("শুনানীর নোটিশ")?(h="উত্তরাধিকার নথিভুক্তকরণ শুনানীর নোটিশ",f="hearing"):e.includes("তদন্তের নোটিশ")&&(h="উত্তরাধিকার নথিভুক্তকরণ তদন্তের নোটিশ",f="investigation");let u="";const p=e.match(/কেস\s*নং\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([A-Za-z0-9_\/]+)/i)||e.match(/কেস\s*নং\s*[:\-]?\s*([A-Za-z0-9_\/]+)/i);p&&(u=i(p[1]));let g="";const T=e.match(/কেস\s*তারিখ\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([\d\/]+)/i)||e.match(/কেস\s*তারিখ\s*[:\-]?\s*([\d\/]+)/i);T&&(g=i(T[1]));let m="";const C=e.match(/জেলা\s*:\s*([^<]+)/);C&&(m=i(C[1]));let I="";const P=e.match(/ব্লক\s*:\s*([^<]+)/);P&&(I=i(P[1]));let H="";const D=e.match(/মৌজা\s*:\s*([^<]+)/);D&&(H=i(D[1]));let V="";const q=e.match(/মৌজা\s*কোড\s*:\s*([^<]+)/);q&&(V=i(q[1]));function G(k){if(!k)return[];const Q=[],be=/<TR[^>]*>([\s\S]*?)<\/TR>/gi;let de;for(;(de=be.exec(k))!==null;){const ue=/<TD[^>]*>([\s\S]*?)<\/TD>/gi,B=[];let s;for(;(s=ue.exec(de[1]))!==null;)B.push(i(s[1]));const a=B.filter(Boolean);a.length>=2&&!a.some(j=>j.includes("নাম")||j.includes("বাদী")||j.includes("বিবাদী")||j.includes("ঠিকানা"))&&Q.push({name:a[0]||"",guardian:a[1]||"",address:a[2]||""})}return Q}const X=e.indexOf("বাদী"),F=e.indexOf("বিবাদী"),z=e.indexOf("justified-text")!==-1?e.indexOf("justified-text"):e.indexOf("এতদ্বারা জানানো");let y=[];if(X!==-1){const k=F!==-1?F:z;y=G(e.substring(X,k!==-1?k:void 0))}let L=[];if(F!==-1){const k=z!==-1?z:e.indexOf("পূর্বসূরী");L=G(e.substring(F,k!==-1?k:void 0))}let $="",J="",x="";const ee=e.match(/<TD[^>]*class=["']justified-text["'][^>]*>([\s\S]*?)<\/TD>/i)||e.match(/(এতদ্বারা\s*জানানো\s*যাইতেছে[\s\S]*?আইন\s*মোতাবেক\s*ব্যবস্থা\s*গ্রহণ\s*করা\s*হইবে।?)/i);if(ee){$=i(ee[1]);const k=$.match(/(\d{1,2}\/\d{1,2}\/\d{4})\s*তারিখে\s*বেলা/);k&&(J=i(k[1]));const Q=$.match(/বেলা\s*([^ঘ]+)ঘটিকায়/);Q&&(x=i(Q[1]))}let l="";const R=e.match(/খতিয়ান\s*নং\s*[:\-]?\s*([০-৯\d]+)/);R&&(l=i(R[1]));let w="";const N=e.match(/জে\.?এল\.?নং\s*[:\-]?\s*([০-৯\d]+)/);N&&(w=i(N[1]));let b=[];const d=e.match(/দাগ\s*নং\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>([\s\S]*?)<\/TD>/i)||e.match(/দাগ\s*নং\s*[:\-]?\s*([\d\s,\/]+)/i);d&&(b=i(d[1]).split(",").map(k=>k.trim()).filter(Boolean));let S="";const t=e.indexOf("রাজস্ব আধিকারিক");if(t!==-1){const k=e.substring(Math.max(0,t-200),t+300),Q=k.match(/তারিখ\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([\d\/]+)/i)||k.match(/তারিখ\s*[:\-]?\s*([\d\/]+)/i);Q&&(S=i(Q[1]))}const E=e.includes("রাজস্ব আধিকারিক")?"রাজস্ব আধিকারিক (Revenue Officer)":"",te=e.includes("সমষ্টি ভূমি ও ভূমি সংস্কার")?"সমষ্টি ভূমি ও ভূমি সংস্কার আধিকারিকের করণ (Office of the BL&LRO)":"",le=e.includes("৫০ ধারা")?"প: ব: ভূ: স: আইনের ৫০ ধারা অনুসারে":"",me={noticeTitle:h,noticeType:f,caseNo:u,caseDate:g,district:m,block:I,mouza:H,mouzaCode:V,petitioners:y,respondents:L,hearingNoticeText:$,hearingDate:J,hearingTime:x,predecessorKhatian:l,predecessorJlNo:w,predecessorPlots:b,authorityDate:S,authorityDesignation:E,authorityOffice:te,authorityLaw:le},Z=[];u&&Z.push({key:"Case Number (কেস নং)",value:u}),g&&Z.push({key:"Case Date (কেস তারিখ)",value:g}),J&&Z.push({key:f==="hearing"?"Hearing Schedule (শুনানীর সময়সূচী)":"Inquiry Schedule (তদন্তের সময়সূচী)",value:`${J}${x?" @ "+x:""}`}),l&&Z.push({key:"Predecessor Khatian (পূর্বসূরীর খতিয়ান)",value:l}),w&&Z.push({key:"J.L. No (জে.এল. নং)",value:w}),b.length>0&&Z.push({key:"Plots Involved (দাগের সংখ্যা)",value:`${b.length} Plots`}),m&&Z.push({key:"District (জেলা)",value:m}),I&&Z.push({key:"Block (ব্লক)",value:I}),H&&Z.push({key:"Mouza (মৌজা)",value:H}),E&&Z.push({key:"Issuing Officer (আধিকারিক)",value:E}),S&&Z.push({key:"Notice Issue Date (ইস্যু তারিখ)",value:S});const se=[];y.length>0&&se.push({title:`বাদী / Petitioner(s) (${y.length})`,headers:["#","নাম (Name)","পিতা/স্বামীর নাম (Guardian)","ঠিকানা (Address)"],rows:y.map((k,Q)=>[String(Q+1),k.name,k.guardian||"—",k.address||"—"])}),L.length>0&&se.push({title:`বিবাদী / Respondent(s) & Other Heirs (${L.length})`,headers:["#","নাম (Name)","পিতা/স্বামীর নাম (Guardian)","ঠিকানা (Address)"],rows:L.map((k,Q)=>[String(Q+1),k.name,k.guardian||"—",k.address||"—"])}),b.length>0&&se.push({title:`পূর্বসূরীর দাগ ও খতিয়ানের বিবরণ (Predecessor Plots) (${b.length})`,headers:["#","দাগ নং (Plot No)","পূর্বসূরীর খতিয়ান নং","জে.এল.নং","মৌজা"],rows:b.map((k,Q)=>[String(Q+1),k,l||"—",w||"—",H||"—"])});const re=y.map(k=>k.name).join(", ")||(u?`Case: ${u}`:"Succession Application");return{success:!0,isError:!1,errorType:null,title:null,errorMessage:null,moduleType:o,isWarishNotice:!0,metadata:{ownerName:re,caseNo:u,caseDate:g,khatianNo:l,jlNo:w,plotCount:b.length?String(b.length):"",summaryItems:Z,warishNotice:me},tables:se,caseNumbers:[u].filter(Boolean),rsLrPairs:[],mutationCases:[],rawHtml:e}}function Dr(e,o=""){const n=_r(o);if(!e||typeof e!="string")return{success:!1,isError:!0,errorType:"empty",title:"No Data",errorMessage:"No response received from the server.",moduleType:n,metadata:{},tables:[],rawHtml:e};if(e.startsWith("JVBERi0x")||e.startsWith("%PDF")||e.length>500&&e.includes("JVBERi0x")){const f=n==="revenue-no-dues"||o.includes("revenue-no-dues");return{success:!0,isPdf:!0,pdfData:e,moduleType:n,docTitle:f?"Land Revenue Clearance Certificate (No Dues)":"Application & Payment Reprint Docket",docSubtitle:f?"Certified clearance issued by the Directorate of Land Records & Surveys, West Bengal":"Official application acknowledgement docket & fee receipt",fileSizeKb:Math.round(e.length*.75/1024),metadata:{docType:f?"Revenue Clearance Certificate":"Reprint Docket",format:"Certified PDF Document"},tables:[],caseNumbers:[],rawHtml:e}}const i=Br(e);if(i)return{success:!1,isError:!0,errorType:i.errorType,title:i.title,errorMessage:i.message,moduleType:n,metadata:{},tables:[],caseNumbers:[],rawHtml:e};if((n==="warish-status"||e.includes("notice-table")&&(e.includes("উত্তরাধিকার")||e.includes("শুনানী")||e.includes("তদন্ত")))&&(e.includes("বাদী")||e.includes("পূর্বসূরী")||e.includes("শুনানী")||e.includes("তদন্ত"))){const f=Hr(e,n);if(f)return f}try{const u=new DOMParser().parseFromString(e,"text/html");u.querySelectorAll("script, style, noscript").forEach(z=>z.remove());const p={},g=[],T=[],m=/((?:MN|WR|CN|REV)\/\d{4}\/\d+\/\d+)/gi,I=(u.body.innerText||"").match(m);I&&I.forEach(z=>{const y=z.toUpperCase();T.includes(y)||T.push(y)}),u.querySelectorAll("b, label, span, div, td").forEach(z=>{const y=z.innerText.trim();if(y.includes("J.L No")||y.includes("J.L. No")||y.includes("JL No")||y.includes("J.l No")||y.includes("জে.এল নং")||y.includes("জে.এল. নং")||y.includes("জে.এল")){const L=y.match(/(?:J\.?[Ll]\.?\s*No|জে\.?এল\.?\s*নং|জে\.?এল)\s*[:\-]?\s*([০-৯\d]+)/i);L&&!p.jlNo&&(p.jlNo=Ce(L[1]))}if(y.includes("Thana")||y.includes("Police Station")||y.includes("থানা")){const L=y.match(/(?:Thana|Police Station|থানা)\s*[:\-]?\s*([A-Za-z\u0980-\u09FF\s]+)/i);if(L&&!p.thana){const $=he(L[1].split(`
`)[0]);$&&$.length>1&&!$.includes("Live Data")&&(p.thana=$)}}});const P=u.querySelectorAll("table"),H=[],D=[],V=[];P.forEach(z=>{var ee;if(z.querySelector("table"))return;const y=Array.from(z.querySelectorAll("tr")).filter(l=>l.closest("table")===z);if(y.length===0)return;if(y.length===2||y.length===1&&z.querySelector("th")&&z.querySelector("td")){const l=y[0],R=y.length>1?y[1]:null;if(l&&R){const w=Array.from(l.querySelectorAll("th, td")).filter(S=>S.closest("tr")===l).map(S=>he(S.innerText).toLowerCase()),N=Array.from(R.querySelectorAll("td, th")).filter(S=>S.closest("tr")===R).map(S=>he(S.innerText)),b=w.some(S=>S.includes("dag no")||S.includes("দাগ নং")),d=w.some(S=>S.includes("pariman")||S.includes("পরিমাণ"));if(b&&d&&N.length>=3){w.forEach((S,t)=>{const E=N[t];E&&((S.includes("dag no")||S.includes("দাগ নং"))&&!p.plotNo&&(p.plotNo=Ce(E)),(S.includes("shreni")||S.includes("শ্রেণি")||S.includes("শ্রেণী"))&&!p.classification&&(p.classification=E),(S.includes("pariman")||S.includes("পরিমাণ"))&&!p.totalArea&&(p.totalArea=Ce(E)))});return}}}let L=!0;const $=[];if(y.forEach(l=>{const R=Array.from(l.querySelectorAll("td, th")).filter(w=>w.closest("tr")===l);if(R.length===2){const w=he(R[0].innerText),N=he(R[1].innerText);if(w&&N&&N!=="-"){$.push({key:w,value:N});const b=w.toLowerCase();(b.includes("khatian")||b.includes("খতিয়ান")||b.includes("খতিয়ান"))&&!p.khatianNo&&(p.khatianNo=Ce(N)),(b.includes("raiter nam")||b.includes("owner name")||b.includes("রায়তের নাম")||b.includes("মালিকের নাম"))&&!p.ownerName&&(p.ownerName=N),(b.includes("pita")||b.includes("father")||b.includes("husband")||b.includes("পিতা")||b.includes("স্বামী"))&&!p.fatherHusband&&(p.fatherHusband=N),(b.includes("thikana")||b.includes("address")||b.includes("ঠিকানা"))&&!p.address&&(p.address=N),(b.includes("pariman")||b.includes("area")||b.includes("পরিমাণ"))&&!p.totalArea&&(p.totalArea=Ce(N)),(b.includes("sankhya")||b.includes("count")||b.includes("সংখ্যা"))&&!p.plotCount&&(p.plotCount=Ce(N)),(b.includes("shreni")||b.includes("classification")||b.includes("শ্রেণি")||b.includes("শ্রেণী"))&&!p.classification&&(p.classification=N),(b.includes("dharan")||b.includes("type")||b.includes("ধরন"))&&!p.tenantType&&(p.tenantType=N)}}else L=!1}),L&&$.length>=2){H.push(...$);return}let J=[];const x=Array.from(z.querySelectorAll("thead")).find(l=>l.closest("table")===z);if(x){const l=Array.from(x.querySelectorAll("th, td")).filter(R=>R.closest("table")===z);J=Array.from(l).map(R=>pt(R.innerText))}else if(y.length>1){const l=Array.from(y[0].querySelectorAll("th, td")).filter(w=>w.closest("tr")===y[0]);(y[0].querySelector("th")!==null||l.length>2)&&(J=l.map(w=>pt(w.innerText)))}if(J.length>=2){const l=[],R=x?0:1;for(let w=R;w<y.length;w++){const N=y[w];if(x&&N.parentElement===x)continue;const b=Array.from(N.querySelectorAll("td, th")).filter(d=>d.closest("tr")===N).map(d=>he(d.innerText));if(b.length>0&&b.some(d=>d.length>0)){const d=b.map(S=>{const t=S.toLowerCase();return t==="nil"||S==="-"||t==="na"||t==="n/a"?"—":S});n==="rs-lr"&&d.length>=2&&D.push({lrPlot:d[0],rsPlot:d[1]}),n.startsWith("mutation")&&((ee=d[0])!=null&&ee.match(/(MN\/\d{4}\/\d+\/\d+)/i))&&V.push({caseNo:d[0],caseDate:d[1]||"",seller:d[2]||"",buyer:d[4]||d[3]||"",status:d[d.length-1]||""}),l.push(d)}}if(l.length>0){let w="",N=z.previousElementSibling;for(;N&&!w;)N.tagName.match(/^H[1-6]|P|STRONG|B$/i)&&(w=ut(N.innerText)),N=N.previousElementSibling;g.push({title:w||ut(n)||"Detailed Records",headers:J,rows:l})}}});const q=["khatian","খতিয়ান","খতিয়ান","raiter nam","owner name","রায়তের নাম","মালিকের নাম","pita","swami","father","husband","পিতা","স্বামী","zamir pariman","জমির পরিমাণ","pariman","পরিমাণ","dager sankhyan","dager sankhya","দাগের সংখ্যা","plot count","jl no","জে.এল নং","thana","থানা"],G=[],X=new Set;H.forEach(z=>{const y=z.key.toLowerCase().trim();!q.some($=>y.includes($))&&!X.has(y)&&(X.add(y),G.push(z))}),G.length>0&&(p.summaryItems=G);const F=Object.keys(p).length>0||g.length>0;return{success:F,isError:!F,errorType:F?null:"no_record",title:F?null:"No Record Found",errorMessage:F?null:"No record details could be extracted from this response.",moduleType:n,metadata:p,tables:g,caseNumbers:T,rsLrPairs:D,mutationCases:V,rawHtml:e}}catch(f){return console.warn("Failed to parse WB HTML:",f),{success:!1,isError:!0,errorType:"parse_error",title:"Parse Error",errorMessage:"Could not interpret portal response.",moduleType:n,metadata:{},tables:[],caseNumbers:[],rawHtml:e}}}function Ze(e){if(!e||typeof e!="string")return!1;const o=e.trim();return!!(o.startsWith("%PDF-")||o.startsWith("%PDF")||o.startsWith("JVBE")||o.startsWith("data:application/pdf")||o.substring(0,200).includes("%PDF-")&&!o.substring(0,200).toLowerCase().includes("<html"))}function et(e){if(!e||typeof e!="string")return"";const o=e.trim();if(o.startsWith("JVBE"))return o;if(o.startsWith("data:application/pdf;base64,"))return o.replace("data:application/pdf;base64,","").trim();try{const n=e.length;let i="";const h=8192;for(let f=0;f<n;f+=h){const u=Math.min(f+h,n),p=new Uint8Array(u-f);for(let g=f;g<u;g++)p[g-f]=e.charCodeAt(g)&255;i+=String.fromCharCode.apply(null,p)}return btoa(i)}catch(n){return console.error("[pdfViewerHelper] Failed to convert raw PDF to Base64",n),""}}function Vr({pdfData:e,title:o="Certificate PDF",caption:n=""}){const i=et(e);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=yes">
  <title>${o}</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"><\/script>
  <style>
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      min-height: 100%;
      background: #343a40;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #fff;
    }

    .pdf-top-bar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: #212529;
      padding: 10px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.4);
      border-bottom: 1px solid #444;
    }

    .pdf-meta {
      display: flex;
      flex-direction: column;
      overflow: hidden;
      margin-right: 12px;
    }

    .pdf-main-title {
      font-size: 14px;
      font-weight: 700;
      color: #f8f9fa;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-sub-title {
      font-size: 12px;
      color: #adb5bd;
      margin-top: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-btn-group {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }

    .pdf-btn {
      background: #1976d2;
      color: #fff;
      border: none;
      padding: 7px 14px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: background 0.15s ease-in-out;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    .pdf-btn:hover, .pdf-btn:active {
      background: #1565c0;
    }

    .pdf-btn.secondary {
      background: #495057;
    }

    .pdf-btn.secondary:hover, .pdf-btn.secondary:active {
      background: #5a6268;
    }

    #loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 50px 20px;
      gap: 16px;
      text-align: center;
    }

    .loading-spinner {
      width: 44px;
      height: 44px;
      border: 4px solid rgba(255, 255, 255, 0.2);
      border-top-color: #1976d2;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading-text {
      font-size: 14px;
      font-weight: 600;
      color: #dee2e6;
    }

    #pages-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px 8px 80px;
      gap: 20px;
      width: 100%;
    }

    .pdf-page-card {
      background: #ffffff;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35);
      border-radius: 4px;
      overflow: hidden;
      max-width: 100%;
      display: flex;
      justify-content: center;
    }

    .pdf-page-card canvas {
      display: block;
      max-width: 100%;
      height: auto !important;
    }

    .fallback-box {
      max-width: 440px;
      margin: 10px auto;
      background: #2b3035;
      border-radius: 12px;
      padding: 30px 24px;
      text-align: center;
      border: 1px solid #444;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }

    @media print {
      .pdf-top-bar {
        display: none !important;
      }
      body {
        background: #fff !important;
      }
      #pages-wrapper {
        padding: 0 !important;
        gap: 0 !important;
      }
      .pdf-page-card {
        box-shadow: none !important;
        border-radius: 0 !important;
        margin: 0 !important;
        page-break-after: always;
      }
    }
  </style>
</head>
<body>
  <div class="pdf-top-bar no-print">
    <div class="pdf-meta">
      <div class="pdf-main-title">${o||"Revenue No Due Certificate"}</div>
      <div class="pdf-sub-title">${n||"Certified Document"}</div>
    </div>
    <div class="pdf-btn-group">
      <button class="pdf-btn" onclick="downloadPdf()">
        Download
      </button>
      <button class="pdf-btn secondary" onclick="printPdf()">
        Print
      </button>
    </div>
  </div>

  <div id="loading-container">
    <div class="loading-spinner"></div>
    <div class="loading-text">Loading Certificate PDF...</div>
  </div>

  <div id="pages-wrapper"></div>

  <script>
    const base64Data = "${i}";

    function getPdfBytes() {
      const raw = atob(base64Data);
      const len = raw.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = raw.charCodeAt(i);
      }
      return bytes;
    }

    function downloadPdf() {
      // Primary: notify container through WebView console message bridge
      try {
        console.log(JSON.stringify({ action: "DOWNLOAD_PDF" }));
      } catch (e) {}

      // Fallback for standard browser
      try {
        const bytes = getPdfBytes();
        const blob = new Blob([bytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = '${(o||"Certificate").replace(/[^a-zA-Z0-9_-]/g,"_")}.pdf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 10000);
      } catch (_) {}
    }

    function printPdf() {
      try {
        console.log(JSON.stringify({ action: "PRINT_PDF" }));
      } catch (e) {}
      try {
        window.print();
      } catch (_) {}
    }

    function renderPdf() {
      if (!window.pdfjsLib) {
        showFallback('PDF renderer not available');
        return;
      }

      try {
        // Disable external worker to avoid Cross-Origin SecurityError in WebView.
        // PDF.js will use FakeWorker in main thread.
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = '';

        const bytes = getPdfBytes();
        const loadingTask = pdfjsLib.getDocument({
          data: bytes,
        });

        loadingTask.promise.then(function(pdf) {
          const loadingEl = document.getElementById('loading-container');
          if (loadingEl) loadingEl.style.display = 'none';

          const container = document.getElementById('pages-wrapper');
          container.innerHTML = '';

          for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            pdf.getPage(pageNum).then(function(page) {
              const scale = 1.5; // High resolution rendering
              const viewport = page.getViewport({ scale: scale });

              const pageCard = document.createElement('div');
              pageCard.className = 'pdf-page-card';

              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              canvas.height = viewport.height;
              canvas.width = viewport.width;

              pageCard.appendChild(canvas);
              container.appendChild(pageCard);

              page.render({ canvasContext: ctx, viewport: viewport });
            });
          }
        }).catch(function(err) {
          console.error('[PDF.js] Render Error:', err);
          showFallback(err.message);
        });
      } catch (e) {
        showFallback(e.message);
      }
    }

    function showFallback(msg) {
      const loadingEl = document.getElementById('loading-container');
      if (loadingEl) {
        loadingEl.innerHTML = \`
          <div class="fallback-box">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: #1976d2; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
            </div>
            <h3 style="margin-top:0; color:#fff; font-size:17px;">\${'${o||"Revenue No Due Certificate"}'}</h3>
            <p style="color:#ced4da; font-size:14px; line-height: 1.5; margin-bottom: 24px;">
              Certified PDF certificate ready. Tap below to download and save it to your device.
            </p>
            <button onclick="downloadPdf()" class="pdf-btn" style="padding:12px 28px; font-size:15px; margin: 0 auto; box-shadow: 0 4px 12px rgba(25, 118, 210, 0.4);">
              Download Certificate PDF
            </button>
          </div>
        \`;
      }
    }

    if (window.pdfjsLib) {
      renderPdf();
    } else {
      let attempts = 0;
      const timer = setInterval(() => {
        attempts++;
        if (window.pdfjsLib) {
          clearInterval(timer);
          renderPdf();
        } else if (attempts > 30) { // 3 seconds timeout
          clearInterval(timer);
          showFallback('PDF engine timed out');
        }
      }, 100);
    }
  <\/script>
</body>
</html>`}function nn(){const{t:e}=Ge(),{t:o}=Ge("inputField"),{errorAlert:n,setHeaderButtons:i,successAlert:h,darkMode:f}=It(),{user:u,logoutUser:p,isLoggedIn:g}=Wt(),{selectedDistrict:T,selectedBlock:m,selectedMouza:C,searchLandDetails:I,setSearchLandDetails:P}=$t(),[H,D]=W.useState(!1),[V,q]=W.useState(""),[G,X]=W.useState(!0),F=Mt(),z=Lt(),{districtId:y,blockId:L,mouzaId:$,recordData:J}=zt(),x=z.pathname,ee=W.useRef(""),l=W.useMemo(()=>{const s=(x||"").split("/").filter(Boolean);if(s.length>1&&s[0]==="wb"){const a=s[1];return a.startsWith("mutation")?"mutation":a}return s[0]||"general"},[x]),R=Ot==="dual",[w,N]=W.useState(()=>{const s=De.get(`${Ve}${l}`);return s==="app"||s==="html"?s:"app"}),b=s=>{s&&(s==="app"||s==="html")&&(N(s),De.set(`${Ve}${l}`,s))};W.useEffect(()=>{{const s=De.get(`${Ve}${l}`);N(s==="app"||s==="html"?s:"app")}},[l,R]);const[d,S]=W.useState(!1),t=W.useMemo(()=>{if(J)try{return JSON.parse(J)}catch(s){console.error("Failed to parse recordData from params",s)}return I},[J,I]),E=W.useMemo(()=>Dr(V,x),[V,x]),te=s=>{if(!(!y||!L||!$||!s)){if(x.includes("/mutation-status/")){const a={...t,caseNumber:s},j=encodeURIComponent(JSON.stringify(a));F(`/wb/mutation-case-status/${y}/${L}/${$}/${j}`)}else if(x.includes("/mutation-case-status/")){const a=s.replace(/\//g,"_"),j={...t,caseNumber:a},c=encodeURIComponent(JSON.stringify(j));F(`/wb/mutation-case-details/${y}/${L}/${$}/${c}`)}}},le=()=>{ie(),P(a=>({...a,...t,caseNumber:String((t==null?void 0:t.caseNumber)||(t==null?void 0:t.caseNo)||(a==null?void 0:a.caseNumber)||"").toUpperCase(),caseNo:String((t==null?void 0:t.caseNo)||(t==null?void 0:t.caseNumber)||(a==null?void 0:a.caseNo)||"").toUpperCase(),applicationNo:String((t==null?void 0:t.applicationNo)||(t==null?void 0:t.appNo)||(a==null?void 0:a.applicationNo)||"").toUpperCase(),appNo:String((t==null?void 0:t.appNo)||(t==null?void 0:t.applicationNo)||(a==null?void 0:a.appNo)||"").toUpperCase(),applnNo:String((t==null?void 0:t.applicationNo)||(t==null?void 0:t.caseNo)||(a==null?void 0:a.applnNo)||"").toUpperCase(),mainNo:(t==null?void 0:t.mainNo)!==void 0?t.mainNo:(a==null?void 0:a.mainNo)||"",subNo:(t==null?void 0:t.subNo)!==void 0?t.subNo:(a==null?void 0:a.subNo)||"",searchBy:(t==null?void 0:t.searchBy)||(a==null?void 0:a.searchBy)||"Khatian",grnNo:String((t==null?void 0:t.grnNo)||(a==null?void 0:a.grnNo)||"").toUpperCase(),requestType:(t==null?void 0:t.requestType)||(a==null?void 0:a.requestType)||"",khatianType:(t==null?void 0:t.khatianType)||(a==null?void 0:a.khatianType)||"Normal",rslrSearchBy:(t==null?void 0:t.rslrSearchBy)||(a==null?void 0:a.rslrSearchBy)||"LR"}));const s=x.split("/").filter(Boolean);J&&s.length>2?(s.pop(),F("/"+s.join("/"))):F(-1)},me=(s=!0)=>{s||(ee.current=""),Ft(),X(!0);let a=Bt;x.includes("/rs-lr/")?a=Kt:x.includes("/khajna-status/")?a=Ut:x.includes("/mutation-case-status/")?a=qt:x.includes("/mutation-case-details/")?a=Jt:x.includes("/mutation-status/")?a=Xt:x.includes("/land-class/")?a=Yt:x.includes("/warish-status/")?a=Gt:x.includes("/conversion-status/")?a=Qt:x.includes("/signed-copy/")?a=Zt:x.includes("/revenue-no-dues/")?a=eo:x.includes("/barga-info/")?a=to:x.includes("/grn-search/")?a=oo:x.includes("/app-reprint/")&&(a=ro);const j={...t,districtName:(T==null?void 0:T.name)||"",blockName:(m==null?void 0:m.name)||"",mouzaName:(C==null?void 0:C.name)||""};g&&a(j,y,L,$,s).then(async c=>{if(c&&c.html){let v=localStorage.getItem(rt)??0;c.cached&&v++,localStorage.setItem(rt,v);const M=await _t(Ht)??10;v>M&&Dt(),console.log("html Received=>",v,c.html);const ne=new DOMParser().parseFromString(c.html,"text/html");ne.querySelectorAll("a").forEach(ce=>{const ze=ce.innerText.trim().toLowerCase();!ze.includes("view ror")&&!ze.includes("certified copy")&&ce.removeAttribute("href")});const xe=/(MN\/\d{4}\/\d+\/\d+)/g;x.includes("/mutation-status/")?ne.querySelectorAll("td").forEach(ce=>{ce.innerText.trim().match(xe)&&(ce.innerHTML=ce.innerHTML.replace(xe,`<a href="javascript:void(0)" onclick="onCaseClick('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}):x.includes("/mutation-case-status/")&&ne.querySelectorAll("td").forEach(ce=>{ce.innerText.trim().match(xe)&&(ce.innerHTML=ce.innerHTML.replace(xe,`<a href="javascript:void(0)" onclick="showMutationCaseDetails('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}),c.html=ne.body.innerHTML,q(c.html),D(c.cached),Vt("high-low",3),we("success_record_fetch",{totalCount:v,cached:c.cached?"true":"false",useCache:s?"true":"false"})}else p(),ie(),q(""),n("auth.sessionTimeout")}).catch(c=>{q(""),console.red("Error in record fetching",c.message),we("record_fetch_error",{message:c.message}),n("kyp.recordView.errorLandRecordFetch",{error:c.message}),F(-1)}).finally(c=>X(!1))};W.useEffect(()=>{if(g&&ee.current!==x){if(ee.current=x,u=="demo"){Lr().then(s=>{q(s.html),X(!1),we("demo_record_fetched")});return}me()}},[g,x,J,u]);const Z=o("wb.landDetails.khatianType.option",{returnObjects:!0})||{},se=o("wb.landDetails.searchBy.option",{returnObjects:!0})||{},ge=String((t==null?void 0:t.searchBy)||"").trim().toLowerCase(),re=ge==="plot"||ge==="lrtors"||ge==="rstolr"||!!(t!=null&&t.plotNo)||x.includes("/rs-lr/")||x.includes("/mouza-map/"),k=`wb-record-${x.split("/")[2]}`,Q=W.useMemo(()=>{var s,a,j;if(x.includes("/land-class"))return e("recentSearch.districtClassification","District Classification");if(x.includes("/warish-status")){const c=(t==null?void 0:t.caseNo)||(t==null?void 0:t.caseNumber)||(t==null?void 0:t.applicationNo)||(t==null?void 0:t.applnNo)||"";return c?`${e("wb.warish.applnNoLabel","Warish Application Number")}: ${c}`:""}if(x.includes("/conversion-status")){const c=(t==null?void 0:t.caseNo)||(t==null?void 0:t.caseNumber)||(t==null?void 0:t.applicationNo)||(t==null?void 0:t.applnNo)||"";return c?`${e("wb.conversion.applnNoLabel","Conversion Case / Application Number")}: ${c}`:""}if(x.includes("/grn-search")){const c=[];return t!=null&&t.grnNo&&c.push(`${e("recentSearch.grnNo","GRN")}: ${t.grnNo}`),(t!=null&&t.appNo||t!=null&&t.applicationNo)&&c.push(`${e("recentSearch.appNo","App No")}: ${t.appNo||t.applicationNo}`),c.join(" | ")}if(x.includes("/app-reprint")){const c=(t==null?void 0:t.appNo)||(t==null?void 0:t.applicationNo)||(t==null?void 0:t.mainNo)||"",v=t!=null&&t.requestTypeName?`${t.requestTypeName} - `:"",M=t!=null&&t.khatian&&t.khatian!=="-1"?` | ${e("recentSearch.khatianNo","Khatian No")}: ${t.khatian}`:"";return c?`${v}${e("recentSearch.appNo","App No")}: ${c}${M}`:""}if(x.includes("/mutation-case-")){const c=(t==null?void 0:t.caseNumber)||(t==null?void 0:t.caseNo)||"";return c?`${e("recentSearch.caseNo","Case No")}: ${c}`:""}if(x.includes("/signed-copy")&&((t==null?void 0:t.searchBy)==="application"||!(t!=null&&t.mainNo)&&(t!=null&&t.applicationNo||t!=null&&t.appliNo))){const c=(t==null?void 0:t.applicationNo)||(t==null?void 0:t.appliNo)||(t==null?void 0:t.mainNo)||"";return c?`${e("recentSearch.appNo","App No")}: ${c}`:""}if(x.includes("/revenue-no-dues")&&((t==null?void 0:t.searchBy)==="Application"||!(t!=null&&t.mainNo)&&(t!=null&&t.appNo||t!=null&&t.applicationNo))){const c=(t==null?void 0:t.appNo)||(t==null?void 0:t.applicationNo)||"";return c?`${e("recentSearch.appNo","App No")}: ${c}`:""}if((t==null?void 0:t.mainNo)!==void 0&&(t==null?void 0:t.mainNo)!==null&&String(t.mainNo).trim()!==""){const c=!re&&((s=Z[t==null?void 0:t.khatianType])!=null&&s.text)?`${(a=Z[t==null?void 0:t.khatianType])==null?void 0:a.text} `:"",v=((j=se[t==null?void 0:t.searchBy])==null?void 0:j.text)||(re?e("recentSearch.plotNo","Plot No"):e("recentSearch.khatianNo","Khatian No")),M=t!=null&&t.subNo?`/${t.subNo}`:"";return`${c}${v} - ${t.mainNo}${M}`}return t!=null&&t.caseNumber||t!=null&&t.caseNo?`${e("recentSearch.caseNo","Case No")}: ${t.caseNumber||t.caseNo}`:t!=null&&t.applicationNo||t!=null&&t.appNo?`${e("recentSearch.appNo","App No")}: ${t.applicationNo||t.appNo}`:""},[x,t,re,Z,se,e]),be=()=>{const s=Math.random().toString(36).substring(2,7),a=`${y||"0"}_${L||"0"}_${$||"0"}_`;let j="";x.includes("/land-class")?j="Land_Classification":x.includes("/warish-status")?j=`Warish_${(t==null?void 0:t.caseNo)||(t==null?void 0:t.applicationNo)||"Record"}`:x.includes("/conversion-status")?j=`Conversion_${(t==null?void 0:t.caseNo)||(t==null?void 0:t.applicationNo)||"Record"}`:x.includes("/mutation-case-")?j=`Mutation_${(t==null?void 0:t.caseNumber)||(t==null?void 0:t.caseNo)||"Record"}`:x.includes("/grn-search")?j=`GRN_${(t==null?void 0:t.grnNo)||(t==null?void 0:t.appNo)||"Record"}`:x.includes("/app-reprint")?j=`Reprint_${(t==null?void 0:t.appNo)||"Record"}`:x.includes("/revenue-no-dues")?j=`Revenue_${(t==null?void 0:t.appNo)||(t==null?void 0:t.mainNo)||"Record"}`:x.includes("/signed-copy")?j=`SignedCopy_${(t==null?void 0:t.applicationNo)||(t==null?void 0:t.appliNo)||(t==null?void 0:t.mainNo)||"Record"}`:(j=t!=null&&t.mainNo?String(t.mainNo):"Record",t!=null&&t.subNo&&(j+="_"+t.subNo));let c=`${a}${j}_${s}`;return c=c.replace(/[^a-zA-Z0-9_.-]/g,"_"),`${c}.pdf`},de=async()=>{ie();try{await nt("downloads");const s=be(),a=`/storage/emulated/0/Download/${s}`;if(Ze(V)){const c=et(V);await window.bridgeSend("storage","fileSave",{path:a,data:c}),h("PDF saved at: "+a),we("pdf_saved",{path:a}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+s,payload:a});return}const j=await qe(k);if(!j)throw new Error("WebView not ready yet.");it({id:j,path:a}).then(c=>{h("PDF saved at: "+c.path),we("pdf_saved",{path:c.path}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+s,payload:c.path})}).catch(c=>{n("Failed to save PDF"),console.error("PDF Save Error:",c)})}catch(s){n("Failed to initialize PDF save"),console.error("PDF init error",s)}},ue=async()=>{ie();try{await nt("downloads");const a=`/storage/emulated/0/Download/${be()}`;if(Ze(V)){const c=et(V);await window.bridgeSend("storage","fileSave",{path:a,data:c}),we("pdf_shared",{path:a}),at({filePaths:[a],text:"Here is the certified PDF."});return}const j=await qe(k);if(!j)throw new Error("WebView not ready yet.");it({id:j,path:a}).then(c=>{we("pdf_shared",{path:c.path}),at({filePaths:[c.path],text:"Here is the land record PDF."})}).catch(c=>{n("Failed to share PDF"),console.error("PDF Share Error:",c)})}catch(s){n("Failed to initialize PDF share"),console.error("PDF share init error",s)}},B=async()=>{ie();try{const s=await qe(k);if(!s)throw new Error("WebView not ready yet.");await lo({id:s}),we("pdf_printed",{url:x})}catch(s){n("Failed to print record"),console.error("Print Error:",s)}};return W.useEffect(()=>(i(s=>s.filter(a=>a.id!=="save_pdf_btn"&&a.id!=="share_pdf_btn"&&a.id!=="print_pdf_btn")),()=>{i(s=>s.filter(a=>a.id!=="save_pdf_btn"&&a.id!=="share_pdf_btn"&&a.id!=="print_pdf_btn"))}),[i]),!g&&!V?r.jsx(co,{}):r.jsxs(U,{sx:{width:"100%",maxWidth:"100vw",overflowX:"hidden",boxSizing:"border-box"},children:[r.jsxs(U,{sx:{py:1},children:[r.jsx(no,{heading:!0}),Q&&r.jsx(A,{variant:"subtitle2",align:"center",sx:{mt:0},children:Q}),!G&&V&&(E.success||H)&&r.jsxs(U,{sx:{px:2,py:.8,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1},children:[(E.success||E.isError||E.isPdf)&&r.jsxs(uo,{value:w,exclusive:!0,onChange:(s,a)=>{a&&(ie(),b(a))},size:"small",sx:{bgcolor:f?"rgba(255, 255, 255, 0.06)":"rgba(0, 0, 0, 0.04)",borderRadius:2,p:.3},children:[r.jsxs(st,{value:"app",sx:{borderRadius:2,px:1.5,py:.4,fontWeight:700,fontSize:"0.78rem",textTransform:"none",gap:.6},children:[r.jsx(O,{sx:{fontSize:18},children:"dashboard"}),e("kyp.recordView.appView","App View")]}),r.jsxs(st,{value:"html",sx:{borderRadius:2,px:1.5,py:.4,fontWeight:700,fontSize:"0.78rem",textTransform:"none",gap:.6},children:[r.jsx(O,{sx:{fontSize:18},children:"html"}),e("kyp.recordView.originalView","Original View")]})]}),H&&r.jsx(_,{sx:{fontSize:"0.75rem",color:"text.disabled",border:"none","& span.MuiIcon-root":{color:"text.primary"},ml:"auto"},onDelete:()=>{me(!1)},deleteIcon:r.jsx(O,{children:"refresh"}),variant:"outlined",size:"small",color:"primary",label:e("kyp.recordView.cachedRecord",{timeago:H?Mr(new Date(H),{addSuffix:!0}):""})})]}),r.jsx(mt,{})]}),G?r.jsx(K,{alignItems:"center",sx:{py:10},children:r.jsx(Et,{})}):r.jsxs(r.Fragment,{children:[(E.success||E.isError||E.isPdf)&&r.jsx(U,{sx:{width:"100%",maxWidth:"100%",overflowX:"hidden",boxSizing:"border-box",display:w==="app"?"block":"none",pb:"80px"},children:r.jsx(Or,{parsedData:E,locationInfo:{selectedDistrict:T,selectedBlock:m,selectedMouza:C},landDetails:t,onCaseAction:te,onSwitchToHtml:()=>b("html"),onSavePdf:de,onSharePdf:ue,onPrintPdf:B,onRetry:()=>me(!1),onBack:le,darkMode:f})}),r.jsx(U,{sx:{display:w==="html"?"block":"none"},children:r.jsx(Kr,{id:k,isVisible:w==="html",html:V,title:(T==null?void 0:T.en)+" ➧ "+(m==null?void 0:m.en)+" ➧"+(C==null?void 0:C.en),caption:Q,onAction:s=>{if(console.green("Action received from WebView",JSON.stringify(s)),s.action==="DOWNLOAD_PDF"||s.action==="ACTION_SAVE_PDF"){de();return}if(s.action==="SHARE_PDF"||s.action==="ACTION_SHARE"){ue();return}if(s.action==="PRINT_PDF"){B();return}if(!y||!L||!$){console.error("Location params missing during onAction",{districtId:y,blockId:L,mouzaId:$});return}if(s.action==="MUTATION_STEP_2"){const a={...t,caseNumber:s.caseNo},j=encodeURIComponent(JSON.stringify(a));console.green("MUTATION_STEP_2 URL",`/wb/mutation-case-status/${y}/${L}/${$}/${j}`),F(`/wb/mutation-case-status/${y}/${L}/${$}/${j}`)}else if(s.action==="MUTATION_STEP_3"){const a=s.caseNo.replace(/\//g,"_"),j={...t,caseNumber:a},c=encodeURIComponent(JSON.stringify(j));console.green("MUTATION_STEP_3 URL",`/wb/mutation-case-details/${y}/${L}/${$}/${c}`),F(`/wb/mutation-case-details/${y}/${L}/${$}/${c}`)}}})})]}),!G&&V&&r.jsxs(wo,{ariaLabel:e("wb.record.recordActions","Record Actions"),sx:{position:"fixed",bottom:24,right:20,zIndex:1200,"& .MuiFab-primary":{bgcolor:s=>je(s.palette.primary.main,.82),backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",color:"#ffffff !important",width:56,height:56,border:"1px solid rgba(255, 255, 255, 0.35)",boxShadow:"0 8px 32px 0 rgba(0,0,0,0.28), inset 0 1px 1px 0 rgba(255, 255, 255, 0.4)",transition:"all 0.3s cubic-bezier(0.4, 0, 0.2, 1)","&:hover":{bgcolor:s=>je(s.palette.primary.dark||s.palette.primary.main,.92),boxShadow:"0 12px 36px 0 rgba(0,0,0,0.35), inset 0 1px 1px 0 rgba(255, 255, 255, 0.5)",transform:"translateY(-2px)"},"& .MuiIcon-root":{color:"#ffffff !important"},"& .MuiSpeedDialIcon-icon, & .MuiSpeedDialIcon-openIcon":{color:"#ffffff !important"}},"& .MuiSpeedDialAction-fab":{backdropFilter:"blur(10px)",WebkitBackdropFilter:"blur(10px)",bgcolor:s=>s.palette.mode==="dark"?"rgba(22, 27, 34, 0.82)":"rgba(255, 255, 255, 0.85)",border:s=>s.palette.mode==="dark"?"1px solid rgba(255, 255, 255, 0.15)":"1px solid rgba(255, 255, 255, 0.6)",boxShadow:"0 6px 20px rgba(0,0,0,0.18)","&:hover":{bgcolor:s=>s.palette.mode==="dark"?"rgba(30, 41, 59, 0.95)":"rgba(255, 255, 255, 0.95)",transform:"scale(1.08)"}},"& .MuiSpeedDialAction-staticTooltipLabel":{whiteSpace:"nowrap",fontWeight:600,fontSize:"0.82rem",backdropFilter:"blur(10px)",WebkitBackdropFilter:"blur(10px)",bgcolor:s=>s.palette.mode==="dark"?"rgba(22, 27, 34, 0.88)":"rgba(255, 255, 255, 0.9)",color:s=>s.palette.mode==="dark"?"#f1f5f9":"#1e293b",border:s=>s.palette.mode==="dark"?"1px solid rgba(255, 255, 255, 0.1)":"1px solid rgba(255, 255, 255, 0.5)",borderRadius:2,boxShadow:"0 4px 16px rgba(0,0,0,0.15)"}},icon:r.jsx(gt,{icon:r.jsx(O,{sx:{color:"#ffffff !important"},children:"print"}),openIcon:r.jsx(O,{sx:{color:"#ffffff !important"},children:"close"})}),onClose:()=>S(!1),onOpen:()=>S(!0),open:d,children:[r.jsx(Je,{icon:r.jsx(O,{sx:{color:"#d97706 !important"},children:"download"}),tooltipTitle:e("wb.record.savePdf","Save PDF"),tooltipOpen:!0,onClick:()=>{S(!1),de()}}),r.jsx(Je,{icon:r.jsx(O,{sx:{color:"#059669 !important"},children:"share"}),tooltipTitle:e("wb.record.sharePdf","Share Record"),tooltipOpen:!0,onClick:()=>{S(!1),ue()}}),r.jsx(Je,{icon:r.jsx(O,{sx:{color:"#2563eb !important"},children:"print"}),tooltipTitle:e("wb.record.printPdf","Print Record"),tooltipOpen:!0,onClick:()=>{S(!1),B()}})]})]})}function Kr({id:e,html:o,title:n,caption:i,onAction:h,isVisible:f=!0}){const p=Ze(o)?Vr({pdfData:o,title:n,caption:i}):`
  <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      @media screen {
        .only-print { display: none !important; }
      }
      @media print {
        .only-print { display: block !important; }
        .no-print { display: none !important; }
      }
      #print-btn {
        z-index: 10000;
        padding: 8px 18px;
        margin: 16px;
        font-size: 1.1rem;
        background: #1976d2;
        color: #fff;
        border: none;
        border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        cursor: pointer;
        transition: background 0.2s;
      }
      #print-btn:hover {
        background: #115293;
      }
      .book > .row {display:none!important}
      
      html, body { width: 100%; margin: 0; padding: 0; }
      .content-wrapper { padding: 16px; padding-bottom: 80px; }
      
    </style>
    </head>
    <body>
    <div class="content-wrapper">
      <div style="padding: 10px;" class="only-print">
        <h3>${n}</h3>
        <h4>${i}</h4>
      </div>
      ${o}
    </div>    
    <script>
      function onCaseClick(caseNo) {
        console.log("onCaseClick triggered: " + caseNo);
        console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
      }
      function showMutationCaseDetails(caseNo, idn) {
        console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
        console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
      }
    <\/script>
    </body>
  </html>
  `;return r.jsx(po,{id:e,isVisible:f,html:p,onConsoleMessage:g=>{try{const T=JSON.parse(g.message.message);T.action&&h&&h(T)}catch{}}})}export{nn as default};
