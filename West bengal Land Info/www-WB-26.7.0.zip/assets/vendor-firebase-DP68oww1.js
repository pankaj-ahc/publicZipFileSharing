var NE=Object.defineProperty;var PE=(n,e,t)=>e in n?NE(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var U=(n,e,t)=>PE(n,typeof e!="symbol"?e+"":e,t);/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FE=()=>{};var ff={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kC={NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const H=function(n,e){if(!n)throw br(e)},br=function(n){return new Error("Firebase Database ("+kC.SDK_VERSION+") INTERNAL ASSERT FAILED: "+n)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const MC=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let r=n.charCodeAt(s);r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):(r&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(r=65536+((r&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},OE=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const r=n[t++];if(r<128)e[s++]=String.fromCharCode(r);else if(r>191&&r<224){const i=n[t++];e[s++]=String.fromCharCode((r&31)<<6|i&63)}else if(r>239&&r<365){const i=n[t++],o=n[t++],a=n[t++],B=((r&7)<<18|(i&63)<<12|(o&63)<<6|a&63)-65536;e[s++]=String.fromCharCode(55296+(B>>10)),e[s++]=String.fromCharCode(56320+(B&1023))}else{const i=n[t++],o=n[t++];e[s++]=String.fromCharCode((r&15)<<12|(i&63)<<6|o&63)}}return e.join("")},mc={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let r=0;r<n.length;r+=3){const i=n[r],o=r+1<n.length,a=o?n[r+1]:0,B=r+2<n.length,c=B?n[r+2]:0,u=i>>2,f=(i&3)<<4|a>>4;let C=(a&15)<<2|c>>6,g=c&63;B||(g=64,o||(C=64)),s.push(t[u],t[f],t[C],t[g])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(MC(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):OE(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let r=0;r<n.length;){const i=t[n.charAt(r++)],a=r<n.length?t[n.charAt(r)]:0;++r;const c=r<n.length?t[n.charAt(r)]:64;++r;const f=r<n.length?t[n.charAt(r)]:64;if(++r,i==null||a==null||c==null||f==null)throw new LE;const C=i<<2|a>>4;if(s.push(C),c!==64){const g=a<<4&240|c>>2;if(s.push(g),f!==64){const E=c<<6&192|f;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class LE extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const VC=function(n){const e=MC(n);return mc.encodeByteArray(e,!0)},ha=function(n){return VC(n).replace(/\./g,"")},vB=function(n){try{return mc.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xE(n){return GC(void 0,n)}function GC(n,e){if(!(e instanceof Object))return e;switch(e.constructor){case Date:const t=e;return new Date(t.getTime());case Object:n===void 0&&(n={});break;case Array:n=[];break;default:return e}for(const t in e)!e.hasOwnProperty(t)||!kE(t)||(n[t]=GC(n[t],e[t]));return n}function kE(n){return n!=="__proto__"}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ME(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VE=()=>ME().__FIREBASE_DEFAULTS__,GE=()=>{if(typeof process>"u"||typeof ff>"u")return;const n=ff.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},HE=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&vB(n[1]);return e&&JSON.parse(e)},_c=()=>{try{return FE()||VE()||GE()||HE()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},UE=n=>{var e,t;return(t=(e=_c())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},HC=n=>{const e=UE(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const s=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),s]:[e.substring(0,t),s]},UC=()=>{var n;return(n=_c())==null?void 0:n.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class so{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qC(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},s=e||"demo-project",r=n.iat||0,i=n.sub||n.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o={iss:`https://securetoken.google.com/${s}`,aud:s,iat:r,exp:r+3600,auth_time:r,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...n};return[ha(JSON.stringify(t)),ha(JSON.stringify(o)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function JC(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function jC(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(JC())}function qE(){var e;const n=(e=_c())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function JE(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function jE(){return kC.NODE_ADMIN===!0}function KE(){return!qE()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function KC(){try{return typeof indexedDB=="object"}catch{return!1}}function QE(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(s);r.onsuccess=()=>{r.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},r.onupgradeneeded=()=>{t=!1},r.onerror=()=>{var i;e(((i=r.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zE="FirebaseError";class bn extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=zE,Object.setPrototypeOf(this,bn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,qa.prototype.create)}}class qa{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},r=`${this.service}/${e}`,i=this.errors[e],o=i?WE(i,s):"Error",a=`${this.serviceName}: ${o} (${r}).`;return new bn(r,a,s)}}function WE(n,e){try{let t=0,s="";for(;t<n.length;){const r=n.indexOf("{$",t);if(r===-1){s+=n.substring(t);break}const i=n.indexOf("}",r+2);if(i===-1){s+=n.substring(t);break}const o=n.substring(r+2,i),a=e[o];s+=n.substring(t,r)+(a!=null?String(a):`<${o}?>`),t=i+1}return s}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bi(n){return JSON.parse(n)}function $e(n){return JSON.stringify(n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const QC=function(n){let e={},t={},s={},r="";try{const i=n.split(".");e=bi(vB(i[0])||""),t=bi(vB(i[1])||""),r=i[2],s=t.d||{},delete t.d}catch{}return{header:e,claims:t,data:s,signature:r}},$E=function(n){const e=QC(n),t=e.claims;return!!t&&typeof t=="object"&&t.hasOwnProperty("iat")},YE=function(n){const e=QC(n).claims;return typeof e=="object"&&e.admin===!0};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function un(n,e){return Object.prototype.hasOwnProperty.call(n,e)}function dr(n,e){if(Object.prototype.hasOwnProperty.call(n,e))return n[e]}function df(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function fa(n,e,t){const s={};for(const r in n)Object.prototype.hasOwnProperty.call(n,r)&&(s[r]=e.call(t,n[r],r,n));return s}function ks(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const r of t){if(!s.includes(r))return!1;const i=n[r],o=e[r];if(Cf(i)&&Cf(o)){if(!ks(i,o))return!1}else if(i!==o)return!1}for(const r of s)if(!t.includes(r))return!1;return!0}function Cf(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function XE(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(r=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(r))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ZE{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=512/8,this.pad_[0]=128;for(let e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(e,t){t||(t=0);const s=this.W_;if(typeof e=="string")for(let f=0;f<16;f++)s[f]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(let f=0;f<16;f++)s[f]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(let f=16;f<80;f++){const C=s[f-3]^s[f-8]^s[f-14]^s[f-16];s[f]=(C<<1|C>>>31)&4294967295}let r=this.chain_[0],i=this.chain_[1],o=this.chain_[2],a=this.chain_[3],B=this.chain_[4],c,u;for(let f=0;f<80;f++){f<40?f<20?(c=a^i&(o^a),u=1518500249):(c=i^o^a,u=1859775393):f<60?(c=i&o|a&(i|o),u=2400959708):(c=i^o^a,u=3395469782);const C=(r<<5|r>>>27)+c+B+u+s[f]&4294967295;B=a,a=o,o=(i<<30|i>>>2)&4294967295,i=r,r=C}this.chain_[0]=this.chain_[0]+r&4294967295,this.chain_[1]=this.chain_[1]+i&4294967295,this.chain_[2]=this.chain_[2]+o&4294967295,this.chain_[3]=this.chain_[3]+a&4294967295,this.chain_[4]=this.chain_[4]+B&4294967295}update(e,t){if(e==null)return;t===void 0&&(t=e.length);const s=t-this.blockSize;let r=0;const i=this.buf_;let o=this.inbuf_;for(;r<t;){if(o===0)for(;r<=s;)this.compress_(e,r),r+=this.blockSize;if(typeof e=="string"){for(;r<t;)if(i[o]=e.charCodeAt(r),++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}else for(;r<t;)if(i[o]=e[r],++o,++r,o===this.blockSize){this.compress_(i),o=0;break}}this.inbuf_=o,this.total_+=t}digest(){const e=[];let t=this.total_*8;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let r=this.blockSize-1;r>=56;r--)this.buf_[r]=t&255,t/=256;this.compress_(this.buf_);let s=0;for(let r=0;r<5;r++)for(let i=24;i>=0;i-=8)e[s]=this.chain_[r]>>i&255,++s;return e}}function Ja(n,e){return`${n} failed: ${e} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eD=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let r=n.charCodeAt(s);if(r>=55296&&r<=56319){const i=r-55296;s++,H(s<n.length,"Surrogate pair missing trail surrogate.");const o=n.charCodeAt(s)-56320;r=65536+(i<<10)+o}r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):r<65536?(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},ja=function(n){let e=0;for(let t=0;t<n.length;t++){const s=n.charCodeAt(t);s<128?e++:s<2048?e+=2:s>=55296&&s<=56319?(e+=4,t++):e+=3}return e};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tD=1e3,nD=2,sD=4*60*60*1e3,rD=.5;function zC(n,e=tD,t=nD){const s=e*Math.pow(t,n),r=Math.round(rD*s*(Math.random()-.5)*2);return Math.min(sD,s+r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ie(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ka(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function WC(n){return(await fetch(n,{credentials:"include"})).ok}class wn{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ts="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iD{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new so;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const r=this.getOrInitializeService({instanceIdentifier:t});r&&s.resolve(r)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),s=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(r){if(s)return null;throw r}else{if(s)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(aD(e))try{this.getOrInitializeService({instanceIdentifier:Ts})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:r});s.resolve(i)}catch{}}}}clearInstance(e=Ts){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Ts){return this.instances.has(e)}getOptions(e=Ts){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[i,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(i);s===a&&o.resolve(r)}return r}onInit(e,t){const s=this.normalizeInstanceIdentifier(t),r=this.onInitCallbacks.get(s)??new Set;r.add(e),this.onInitCallbacks.set(s,r);const i=this.instances.get(s);return i&&e(i,s),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const r of s)try{r(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:oD(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=Ts){return this.component?this.component.multipleInstances?e:Ts:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function oD(n){return n===Ts?void 0:n}function aD(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lD{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new iD(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var he;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(he||(he={}));const BD={debug:he.DEBUG,verbose:he.VERBOSE,info:he.INFO,warn:he.WARN,error:he.ERROR,silent:he.SILENT},cD=he.INFO,uD={[he.DEBUG]:"log",[he.VERBOSE]:"log",[he.INFO]:"info",[he.WARN]:"warn",[he.ERROR]:"error"},hD=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),r=uD[e];if(r)console[r](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Qa{constructor(e){this.name=e,this._logLevel=cD,this._logHandler=hD,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in he))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?BD[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,he.DEBUG,...e),this._logHandler(this,he.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,he.VERBOSE,...e),this._logHandler(this,he.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,he.INFO,...e),this._logHandler(this,he.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,he.WARN,...e),this._logHandler(this,he.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,he.ERROR,...e),this._logHandler(this,he.ERROR,...e)}}const fD=(n,e)=>e.some(t=>n instanceof t);let pf,gf;function dD(){return pf||(pf=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function CD(){return gf||(gf=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const $C=new WeakMap,RB=new WeakMap,YC=new WeakMap,tB=new WeakMap,Ec=new WeakMap;function pD(n){const e=new Promise((t,s)=>{const r=()=>{n.removeEventListener("success",i),n.removeEventListener("error",o)},i=()=>{t(jn(n.result)),r()},o=()=>{s(n.error),r()};n.addEventListener("success",i),n.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&$C.set(t,n)}).catch(()=>{}),Ec.set(e,n),e}function gD(n){if(RB.has(n))return;const e=new Promise((t,s)=>{const r=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",o),n.removeEventListener("abort",o)},i=()=>{t(),r()},o=()=>{s(n.error||new DOMException("AbortError","AbortError")),r()};n.addEventListener("complete",i),n.addEventListener("error",o),n.addEventListener("abort",o)});RB.set(n,e)}let SB={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return RB.get(n);if(e==="objectStoreNames")return n.objectStoreNames||YC.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return jn(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function mD(n){SB=n(SB)}function _D(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(nB(this),e,...t);return YC.set(s,e.sort?e.sort():[e]),jn(s)}:CD().includes(n)?function(...e){return n.apply(nB(this),e),jn($C.get(this))}:function(...e){return jn(n.apply(nB(this),e))}}function ED(n){return typeof n=="function"?_D(n):(n instanceof IDBTransaction&&gD(n),fD(n,dD())?new Proxy(n,SB):n)}function jn(n){if(n instanceof IDBRequest)return pD(n);if(tB.has(n))return tB.get(n);const e=ED(n);return e!==n&&(tB.set(n,e),Ec.set(e,n)),e}const nB=n=>Ec.get(n);function XC(n,e,{blocked:t,upgrade:s,blocking:r,terminated:i}={}){const o=indexedDB.open(n,e),a=jn(o);return s&&o.addEventListener("upgradeneeded",B=>{s(jn(o.result),B.oldVersion,B.newVersion,jn(o.transaction),B)}),t&&o.addEventListener("blocked",B=>t(B.oldVersion,B.newVersion,B)),a.then(B=>{i&&B.addEventListener("close",()=>i()),r&&B.addEventListener("versionchange",c=>r(c.oldVersion,c.newVersion,c))}).catch(()=>{}),a}const DD=["get","getKey","getAll","getAllKeys","count"],yD=["put","add","delete","clear"],sB=new Map;function mf(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(sB.get(e))return sB.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,r=yD.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(r||DD.includes(t)))return;const i=async function(o,...a){const B=this.transaction(o,r?"readwrite":"readonly");let c=B.store;return s&&(c=c.index(a.shift())),(await Promise.all([c[t](...a),r&&B.done]))[0]};return sB.set(e,i),i}mD(n=>({...n,get:(e,t,s)=>mf(e,t)||n.get(e,t,s),has:(e,t)=>!!mf(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wD{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(TD(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function TD(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const bB="@firebase/app",_f="0.16.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tn=new Qa("@firebase/app"),ID="@firebase/app-compat",AD="@firebase/analytics-compat",vD="@firebase/analytics",RD="@firebase/app-check-compat",SD="@firebase/app-check",bD="@firebase/auth",ND="@firebase/auth-compat",PD="@firebase/database",FD="@firebase/data-connect",OD="@firebase/database-compat",LD="@firebase/functions",xD="@firebase/functions-compat",kD="@firebase/installations",MD="@firebase/installations-compat",VD="@firebase/messaging",GD="@firebase/messaging-compat",HD="@firebase/performance",UD="@firebase/performance-compat",qD="@firebase/remote-config",JD="@firebase/remote-config-compat",jD="@firebase/storage",KD="@firebase/storage-compat",QD="@firebase/firestore",zD="@firebase/ai",WD="@firebase/firestore-compat",$D="firebase",YD="12.19.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const NB="[DEFAULT]",XD={[bB]:"fire-core",[ID]:"fire-core-compat",[vD]:"fire-analytics",[AD]:"fire-analytics-compat",[SD]:"fire-app-check",[RD]:"fire-app-check-compat",[bD]:"fire-auth",[ND]:"fire-auth-compat",[PD]:"fire-rtdb",[FD]:"fire-data-connect",[OD]:"fire-rtdb-compat",[LD]:"fire-fn",[xD]:"fire-fn-compat",[kD]:"fire-iid",[MD]:"fire-iid-compat",[VD]:"fire-fcm",[GD]:"fire-fcm-compat",[HD]:"fire-perf",[UD]:"fire-perf-compat",[qD]:"fire-rc",[JD]:"fire-rc-compat",[jD]:"fire-gcs",[KD]:"fire-gcs-compat",[QD]:"fire-fst",[WD]:"fire-fst-compat",[zD]:"fire-vertex","fire-js":"fire-js",[$D]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ni=new Map,ZD=new Map,PB=new Map;function Ef(n,e){try{n.container.addComponent(e)}catch(t){Tn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function es(n){const e=n.name;if(PB.has(e))return Tn.debug(`There were multiple attempts to register component ${e}.`),!1;PB.set(e,n);for(const t of Ni.values())Ef(t,n);for(const t of ZD.values())Ef(t,n);return!0}function ro(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function ZC(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ey={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},gn=new qa("app","Firebase",ey);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ty{constructor(e,t,s){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new wn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw gn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const da=YD;function ny(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s={name:NB,automaticDataCollectionEnabled:!0,...e},r=s.name;if(typeof r!="string"||!r)throw gn.create("bad-app-name",{appName:String(r)});if(t||(t=UC()),!t)throw gn.create("no-options");const i=Ni.get(r);if(i)if(ks(t,i.options)){if(ks(s,i.config))return i;throw gn.create("duplicate-app",{appName:r,mismatchedParam:"config",oldValue:JSON.stringify(i.config),newValue:JSON.stringify(s)})}else throw gn.create("duplicate-app",{appName:r,mismatchedParam:"options",oldValue:JSON.stringify(i.options),newValue:JSON.stringify(t)});const o=new lD(r);for(const B of PB.values())o.addComponent(B);const a=new ty(t,s,o);return Ni.set(r,a),a}function Dc(n=NB){const e=Ni.get(n);if(!e&&n===NB&&UC())return ny();if(!e)throw gn.create("no-app",{appName:n});return e}function IN(){return Array.from(Ni.values())}function Ht(n,e,t){let s=XD[n]??n;t&&(s+=`-${t}`);const r=s.match(/\s|\//),i=e.match(/\s|\//);if(r||i){const o=[`Unable to register library "${s}" with version "${e}":`];r&&o.push(`library name "${s}" contains illegal characters (whitespace or "/")`),r&&i&&o.push("and"),i&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Tn.warn(o.join(" "));return}es(new wn(`${s}-version`,()=>({library:s,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sy="firebase-heartbeat-database",ry=1,Pi="firebase-heartbeat-store";let rB=null;function ep(){return rB||(rB=XC(sy,ry,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(Pi)}catch(t){console.warn(t)}}}}).catch(n=>{throw gn.create("idb-open",{originalErrorMessage:n.message})})),rB}async function iy(n){try{const t=(await ep()).transaction(Pi),s=await t.objectStore(Pi).get(tp(n));return await t.done,s}catch(e){if(e instanceof bn)Tn.warn(e.message);else{const t=gn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Tn.warn(t.message)}}}async function Df(n,e){try{const s=(await ep()).transaction(Pi,"readwrite");await s.objectStore(Pi).put(e,tp(n)),await s.done}catch(t){if(t instanceof bn)Tn.warn(t.message);else{const s=gn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Tn.warn(s.message)}}}function tp(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oy=1024,ay=30;class ly{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new cy(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;try{const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=yf();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:r}),this._heartbeatsCache.heartbeats.length>ay){const o=uy(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(s){Tn.warn(s)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=yf(),{heartbeatsToSend:s,unsentEntries:r}=By(this._heartbeatsCache.heartbeats),i=ha(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return Tn.warn(t),""}}}function yf(){return new Date().toISOString().substring(0,10)}function By(n,e=oy){const t=[];let s=n.slice();for(const r of n){const i=t.find(o=>o.agent===r.agent);if(i){if(i.dates.push(r.date),wf(t)>e){i.dates.pop();break}}else if(t.push({agent:r.agent,dates:[r.date]}),wf(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class cy{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return KC()?QE().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await iy(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return Df(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const s=await this.read();return Df(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??s.lastSentHeartbeatDate,heartbeats:[...s.heartbeats,...e.heartbeats]})}else return}}function wf(n){return ha(JSON.stringify({version:2,heartbeats:n})).length}function uy(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let s=1;s<n.length;s++)n[s].date<t&&(t=n[s].date,e=s);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hy(n){es(new wn("platform-logger",e=>new wD(e),"PRIVATE")),es(new wn("heartbeat",e=>new ly(e),"PRIVATE")),Ht(bB,_f,n),Ht(bB,_f,"esm2020"),Ht("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */hy("");var fy="firebase",dy="12.19.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ht(fy,dy,"app");const np="@firebase/installations",yc="0.6.24";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sp=1e4,rp=`w:${yc}`,ip="FIS_v2",Cy="https://firebaseinstallations.googleapis.com/v1",py=60*60*1e3,gy="installations",my="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _y={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},Ms=new qa(gy,my,_y);function op(n){return n instanceof bn&&n.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ap({projectId:n}){return`${Cy}/projects/${n}/installations`}function lp(n){return{token:n.token,requestStatus:2,expiresIn:Dy(n.expiresIn),creationTime:Date.now()}}async function Bp(n,e){const s=(await e.json()).error;return Ms.create("request-failed",{requestName:n,serverCode:s.code,serverMessage:s.message,serverStatus:s.status})}function cp({apiKey:n}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":n})}function Ey(n,{refreshToken:e}){const t=cp(n);return t.append("Authorization",yy(e)),t}async function up(n){const e=await n();return e.status>=500&&e.status<600?n():e}function Dy(n){return Number(n.replace("s","000"))}function yy(n){return`${ip} ${n}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function wy({appConfig:n,heartbeatServiceProvider:e},{fid:t}){const s=ap(n),r=cp(n),i=e.getImmediate({optional:!0});if(i){const c=await i.getHeartbeatsHeader();c&&r.append("x-firebase-client",c)}const o={fid:t,authVersion:ip,appId:n.appId,sdkVersion:rp},a={method:"POST",headers:r,body:JSON.stringify(o)},B=await up(()=>fetch(s,a));if(B.ok){const c=await B.json();return{fid:c.fid||t,registrationStatus:2,refreshToken:c.refreshToken,authToken:lp(c.authToken)}}else throw await Bp("Create Installation",B)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hp(n){return new Promise(e=>{setTimeout(e,n)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ty(n){return btoa(String.fromCharCode(...n)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Iy=/^[cdef][\w-]{21}$/,FB="";function Ay(){try{const n=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(n),n[0]=112+n[0]%16;const t=vy(n);return Iy.test(t)?t:FB}catch{return FB}}function vy(n){return Ty(n).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function za(n){return`${n.appName}!${n.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fp=new Map;function dp(n,e){const t=za(n);Cp(t,e),Ry(t,e)}function Cp(n,e){const t=fp.get(n);if(t)for(const s of t)s(e)}function Ry(n,e){const t=Sy();t&&t.postMessage({key:n,fid:e}),by()}let Rs=null;function Sy(){return!Rs&&"BroadcastChannel"in self&&(Rs=new BroadcastChannel("[Firebase] FID Change"),Rs.onmessage=n=>{Cp(n.data.key,n.data.fid)}),Rs}function by(){fp.size===0&&Rs&&(Rs.close(),Rs=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ny="firebase-installations-database",Py=1,Vs="firebase-installations-store";let iB=null;function wc(){return iB||(iB=XC(Ny,Py,{upgrade:(n,e)=>{switch(e){case 0:n.createObjectStore(Vs)}}})),iB}async function Ca(n,e){const t=za(n),r=(await wc()).transaction(Vs,"readwrite"),i=r.objectStore(Vs),o=await i.get(t);return await i.put(e,t),await r.done,(!o||o.fid!==e.fid)&&dp(n,e.fid),e}async function pp(n){const e=za(n),s=(await wc()).transaction(Vs,"readwrite");await s.objectStore(Vs).delete(e),await s.done}async function Wa(n,e){const t=za(n),r=(await wc()).transaction(Vs,"readwrite"),i=r.objectStore(Vs),o=await i.get(t),a=e(o);return a===void 0?await i.delete(t):await i.put(a,t),await r.done,a&&(!o||o.fid!==a.fid)&&dp(n,a.fid),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Tc(n){let e;const t=await Wa(n.appConfig,s=>{const r=Fy(s),i=Oy(n,r);return e=i.registrationPromise,i.installationEntry});return t.fid===FB?{installationEntry:await e}:{installationEntry:t,registrationPromise:e}}function Fy(n){const e=n||{fid:Ay(),registrationStatus:0};return gp(e)}function Oy(n,e){if(e.registrationStatus===0){if(!navigator.onLine){const r=Promise.reject(Ms.create("app-offline"));return{installationEntry:e,registrationPromise:r}}const t={fid:e.fid,registrationStatus:1,registrationTime:Date.now()},s=Ly(n,t);return{installationEntry:t,registrationPromise:s}}else return e.registrationStatus===1?{installationEntry:e,registrationPromise:xy(n)}:{installationEntry:e}}async function Ly(n,e){try{const t=await wy(n,e);return Ca(n.appConfig,t)}catch(t){throw op(t)&&t.customData.serverCode===409?await pp(n.appConfig):await Ca(n.appConfig,{fid:e.fid,registrationStatus:0}),t}}async function xy(n){let e=await Tf(n.appConfig);for(;e.registrationStatus===1;)await hp(100),e=await Tf(n.appConfig);if(e.registrationStatus===0){const{installationEntry:t,registrationPromise:s}=await Tc(n);return s||t}return e}function Tf(n){return Wa(n,e=>{if(!e)throw Ms.create("installation-not-found");return gp(e)})}function gp(n){return ky(n)?{fid:n.fid,registrationStatus:0}:n}function ky(n){return n.registrationStatus===1&&n.registrationTime+sp<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function My({appConfig:n,heartbeatServiceProvider:e},t){const s=Vy(n,t),r=Ey(n,t),i=e.getImmediate({optional:!0});if(i){const c=await i.getHeartbeatsHeader();c&&r.append("x-firebase-client",c)}const o={installation:{sdkVersion:rp,appId:n.appId}},a={method:"POST",headers:r,body:JSON.stringify(o)},B=await up(()=>fetch(s,a));if(B.ok){const c=await B.json();return lp(c)}else throw await Bp("Generate Auth Token",B)}function Vy(n,{fid:e}){return`${ap(n)}/${e}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ic(n,e=!1){let t;const s=await Wa(n.appConfig,i=>{if(!mp(i))throw Ms.create("not-registered");const o=i.authToken;if(!e&&Uy(o))return i;if(o.requestStatus===1)return t=Gy(n,e),i;{if(!navigator.onLine)throw Ms.create("app-offline");const a=Jy(i);return t=Hy(n,a),a}});return t?await t:s.authToken}async function Gy(n,e){let t=await If(n.appConfig);for(;t.authToken.requestStatus===1;)await hp(100),t=await If(n.appConfig);const s=t.authToken;return s.requestStatus===0?Ic(n,e):s}function If(n){return Wa(n,e=>{if(!mp(e))throw Ms.create("not-registered");const t=e.authToken;return jy(t)?{...e,authToken:{requestStatus:0}}:e})}async function Hy(n,e){try{const t=await My(n,e),s={...e,authToken:t};return await Ca(n.appConfig,s),t}catch(t){if(op(t)&&(t.customData.serverCode===401||t.customData.serverCode===404))await pp(n.appConfig);else{const s={...e,authToken:{requestStatus:0}};await Ca(n.appConfig,s)}throw t}}function mp(n){return n!==void 0&&n.registrationStatus===2}function Uy(n){return n.requestStatus===2&&!qy(n)}function qy(n){const e=Date.now();return e<n.creationTime||n.creationTime+n.expiresIn<e+py}function Jy(n){const e={requestStatus:1,requestTime:Date.now()};return{...n,authToken:e}}function jy(n){return n.requestStatus===1&&n.requestTime+sp<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ky(n){const e=n,{installationEntry:t,registrationPromise:s}=await Tc(e);return s?s.catch(console.error):Ic(e).catch(console.error),t.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Qy(n,e=!1){const t=n;return await zy(t),(await Ic(t,e)).token}async function zy(n){const{registrationPromise:e}=await Tc(n);e&&await e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wy(n){if(!n||!n.options)throw oB("App Configuration");if(!n.name)throw oB("App Name");const e=["projectId","apiKey","appId"];for(const t of e)if(!n.options[t])throw oB(t);return{appName:n.name,projectId:n.options.projectId,apiKey:n.options.apiKey,appId:n.options.appId}}function oB(n){return Ms.create("missing-app-config-values",{valueName:n})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _p="installations",$y="installations-internal",Yy=n=>{const e=n.getProvider("app").getImmediate(),t=Wy(e),s=ro(e,"heartbeat");return{app:e,appConfig:t,heartbeatServiceProvider:s,_delete:()=>Promise.resolve()}},Xy=n=>{const e=n.getProvider("app").getImmediate(),t=ro(e,_p).getImmediate();return{getId:()=>Ky(t),getToken:r=>Qy(t,r)}};function Zy(){es(new wn(_p,Yy,"PUBLIC")),es(new wn($y,Xy,"PRIVATE"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Zy();Ht(np,yc);Ht(np,yc,"esm2020");const aB="@firebase/remote-config",Af="0.9.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ep{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dp="remote-config",vf=100;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ew={"already-initialized":"Remote Config already initialized","registration-window":"Undefined window object. This SDK only supports usage in a browser environment.","registration-project-id":"Undefined project identifier. Check Firebase app initialization.","registration-api-key":"Undefined API key. Check Firebase app initialization.","registration-app-id":"Undefined app identifier. Check Firebase app initialization.","storage-open":"Error thrown when opening storage. Original error: {$originalErrorMessage}.","storage-get":"Error thrown when reading from storage. Original error: {$originalErrorMessage}.","storage-set":"Error thrown when writing to storage. Original error: {$originalErrorMessage}.","storage-delete":"Error thrown when deleting from storage. Original error: {$originalErrorMessage}.","fetch-client-network":"Fetch client failed to connect to a network. Check Internet connection. Original error: {$originalErrorMessage}.","fetch-timeout":'The config fetch request timed out.  Configure timeout using "fetchTimeoutMillis" SDK setting.',"fetch-throttle":'The config fetch request timed out while in an exponential backoff state. Configure timeout using "fetchTimeoutMillis" SDK setting. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.',"fetch-client-parse":"Fetch client could not parse response. Original error: {$originalErrorMessage}.","fetch-status":"Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.","indexed-db-unavailable":"Indexed DB is not supported by current browser","custom-signal-max-allowed-signals":"Setting more than {$maxSignals} custom signals is not supported.","stream-error":"The stream was not able to connect to the backend: {$originalErrorMessage}.","realtime-unavailable":"The Realtime service is unavailable: {$originalErrorMessage}","update-message-invalid":"The stream invalidation message was unparsable: {$originalErrorMessage}","update-not-fetched":"Unable to fetch the latest config: {$originalErrorMessage}","analytics-unavailable":"Connection to Firebase Analytics failed: {$originalErrorMessage}"},Ve=new qa("remoteconfig","Remote Config",ew);function tw(n,e){return n instanceof bn&&n.code.indexOf(e)!==-1}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nw=!1,sw="",Rf=0,rw=["1","true","t","yes","y","on"];class lB{constructor(e,t=sw){this._source=e,this._value=t}asString(){return this._value}asBoolean(){return this._source==="static"?nw:rw.indexOf(this._value.toLowerCase())>=0}asNumber(){if(this._source==="static")return Rf;let e=Number(this._value);return isNaN(e)&&(e=Rf),e}getSource(){return this._source}}class iw{constructor(e){this.storage=e._storage,this.logger=e._logger,this.analyticsProvider=e._analyticsProvider}async updateActiveExperiments(e){const t=await this.storage.getActiveExperiments()||new Set,s=this.createExperimentInfoMap(e);return this.addActiveExperiments(s),this.removeInactiveExperiments(t,s),this.storage.setActiveExperiments(new Set(s.keys()))}createExperimentInfoMap(e){const t=new Map;for(const s of e)t.set(s.experimentId,s);return t}addActiveExperiments(e){const t={};for(const[s,r]of e.entries())t[`firebase${s}`]=r.variantId;this.addExperimentToAnalytics(t)}removeInactiveExperiments(e,t){const s={};for(const r of e)t.has(r)||(s[`firebase${r}`]=null);this.addExperimentToAnalytics(s)}addExperimentToAnalytics(e){if(Object.keys(e).length!==0)try{const t=this.analyticsProvider.getImmediate({optional:!0});t?(t.setUserProperties(e),t.logEvent("set_firebase_experiment_state")):this.logger.warn("Analytics import failed. Verify if you have imported Firebase Analytics in your app code.")}catch(t){throw Ve.create("analytics-unavailable",{originalErrorMessage:t==null?void 0:t.message})}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function AN(n=Dc(),e={}){var r,i;n=Ie(n);const t=ro(n,Dp);if(t.isInitialized()){const o=t.getOptions();if(ks(o,e))return t.getImmediate();throw Ve.create("already-initialized")}t.initialize({options:e});const s=t.getImmediate();return e.initialFetchResponse&&(s._initializePromise=Promise.all([s._storage.setLastSuccessfulFetchResponse(e.initialFetchResponse),s._storage.setActiveConfigEtag(((r=e.initialFetchResponse)==null?void 0:r.eTag)||""),s._storage.setActiveConfigTemplateVersion(e.initialFetchResponse.templateVersion||0),s._storageCache.setLastSuccessfulFetchTimestampMillis(Date.now()),s._storageCache.setLastFetchStatus("success"),s._storageCache.setActiveConfig(((i=e.initialFetchResponse)==null?void 0:i.config)||{})]).then(),s._isInitializationComplete=!0),s}async function ow(n){const e=Ie(n),[t,s]=await Promise.all([e._storage.getLastSuccessfulFetchResponse(),e._storage.getActiveConfigEtag()]);if(!t||!t.config||!t.eTag||!t.templateVersion||t.eTag===s)return!1;const i=new iw(e).updateActiveExperiments(t.experiments||[]);return await Promise.all([e._storageCache.setActiveConfig(t.config),e._storage.setActiveConfigEtag(t.eTag),e._storage.setActiveConfigTemplateVersion(t.templateVersion),i]),!0}function aw(n){const e=Ie(n);return e._initializePromise||(e._initializePromise=e._storageCache.loadFromStorage().then(()=>{e._isInitializationComplete=!0})),e._initializePromise}async function lw(n){const e=Ie(n),t=new Ep;setTimeout(async()=>{t.abort()},e.settings.fetchTimeoutMillis);const s=e._storageCache.getCustomSignals();s&&e._logger.debug(`Fetching config with custom signals: ${JSON.stringify(s)}`);try{await e._client.fetch({cacheMaxAgeMillis:e.settings.minimumFetchIntervalMillis,signal:t,customSignals:s}),await e._storageCache.setLastFetchStatus("success")}catch(r){const i=tw(r,"fetch-throttle")?"throttle":"failure";throw await e._storageCache.setLastFetchStatus(i),r}}function vN(n,e){const t=Ie(n);t._isInitializationComplete||t._logger.debug(`A value was requested for key "${e}" before SDK initialization completed. Await on ensureInitialized if the intent was to get a previously activated value.`);const s=t._storageCache.getActiveConfig();return s&&s[e]!==void 0?new lB("remote",s[e]):t.defaultConfig&&t.defaultConfig[e]!==void 0?new lB("default",String(t.defaultConfig[e])):(t._logger.debug(`Returning static value for key "${e}". Define a default or remote value if this is unintentional.`),new lB("static"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bw{constructor(e,t,s,r){this.client=e,this.storage=t,this.storageCache=s,this.logger=r}isCachedDataFresh(e,t){if(!t)return this.logger.debug("Config fetch cache check. Cache unpopulated."),!1;const s=Date.now()-t,r=s<=e;return this.logger.debug(`Config fetch cache check. Cache age millis: ${s}. Cache max age millis (minimumFetchIntervalMillis setting): ${e}. Is cache hit: ${r}.`),r}async fetch(e){const[t,s]=await Promise.all([this.storage.getLastSuccessfulFetchTimestampMillis(),this.storage.getLastSuccessfulFetchResponse()]);if(s&&this.isCachedDataFresh(e.cacheMaxAgeMillis,t))return s;e.eTag=s&&s.eTag;const r=await this.client.fetch(e),i=[this.storageCache.setLastSuccessfulFetchTimestampMillis(Date.now())];return r.status===200&&i.push(this.storage.setLastSuccessfulFetchResponse(r)),await Promise.all(i),r}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cw(n=navigator){return n.languages&&n.languages[0]||n.language}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uw{constructor(e,t,s,r,i,o){this.firebaseInstallations=e,this.sdkVersion=t,this.namespace=s,this.projectId=r,this.apiKey=i,this.appId=o}async fetch(e){const[t,s]=await Promise.all([this.firebaseInstallations.getId(),this.firebaseInstallations.getToken()]),i=`${window.FIREBASE_REMOTE_CONFIG_URL_BASE||"https://firebaseremoteconfig.googleapis.com"}/v1/projects/${this.projectId}/namespaces/${this.namespace}:fetch?key=${this.apiKey}`,o={"Content-Type":"application/json","Content-Encoding":"gzip","If-None-Match":e.eTag||"*"},a={sdk_version:this.sdkVersion,app_instance_id:t,app_instance_id_token:s,app_id:this.appId,language_code:cw(),custom_signals:e.customSignals},B={method:"POST",headers:o,body:JSON.stringify(a)},c=fetch(i,B),u=new Promise((ie,me)=>{e.signal.addEventListener(()=>{const Me=new Error("The operation was aborted.");Me.name="AbortError",me(Me)})});let f;try{await Promise.race([c,u]),f=await c}catch(ie){let me="fetch-client-network";throw(ie==null?void 0:ie.name)==="AbortError"&&(me="fetch-timeout"),Ve.create(me,{originalErrorMessage:ie==null?void 0:ie.message})}let C=f.status;const g=f.headers.get("ETag")||void 0;let E,b,F,j,te;if(f.status===200){let ie;try{ie=await f.json()}catch(me){throw Ve.create("fetch-client-parse",{originalErrorMessage:me==null?void 0:me.message})}E=ie.entries,b=ie.state,F=ie.templateVersion,j=ie.experimentDescriptions,te=ie.rolloutMetadata}if(b==="INSTANCE_STATE_UNSPECIFIED"?C=500:b==="NO_CHANGE"?C=304:(b==="NO_TEMPLATE"||b==="EMPTY_CONFIG")&&(E={},j=[],te=[]),C!==304&&C!==200)throw Ve.create("fetch-status",{httpStatus:C});return{status:C,eTag:g,config:E,templateVersion:F,experiments:j,rollouts:te}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hw(n,e){return new Promise((t,s)=>{const r=Math.max(e-Date.now(),0),i=setTimeout(t,r);n.addEventListener(()=>{clearTimeout(i),s(Ve.create("fetch-throttle",{throttleEndTimeMillis:e}))})})}function fw(n){if(!(n instanceof bn)||!n.customData)return!1;const e=Number(n.customData.httpStatus);return e===429||e===500||e===503||e===504}class dw{constructor(e,t){this.client=e,this.storage=t}async fetch(e){const t=await this.storage.getThrottleMetadata()||{backoffCount:0,throttleEndTimeMillis:Date.now()};return this.attemptFetch(e,t)}async attemptFetch(e,{throttleEndTimeMillis:t,backoffCount:s}){await hw(e.signal,t);try{const r=await this.client.fetch(e);return await this.storage.deleteThrottleMetadata(),r}catch(r){if(!fw(r))throw r;const i={throttleEndTimeMillis:Date.now()+zC(s),backoffCount:s+1};return await this.storage.setThrottleMetadata(i),this.attemptFetch(e,i)}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cw=60*1e3,pw=12*60*60*1e3;class gw{get fetchTimeMillis(){return this._storageCache.getLastSuccessfulFetchTimestampMillis()||-1}get lastFetchStatus(){return this._storageCache.getLastFetchStatus()||"no-fetch-yet"}constructor(e,t,s,r,i,o,a){this.app=e,this._client=t,this._storageCache=s,this._storage=r,this._logger=i,this._realtimeHandler=o,this._analyticsProvider=a,this._isInitializationComplete=!1,this.settings={fetchTimeoutMillis:Cw,minimumFetchIntervalMillis:pw},this.defaultConfig={}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sa(n,e){const t=n.target.error||void 0;return Ve.create(e,{originalErrorMessage:t&&(t==null?void 0:t.message)})}const Vn="app_namespace_store",mw="firebase_remote_config",_w=1;function Ew(){return new Promise((n,e)=>{try{const t=indexedDB.open(mw,_w);t.onerror=s=>{e(sa(s,"storage-open"))},t.onsuccess=s=>{n(s.target.result)},t.onupgradeneeded=s=>{const r=s.target.result;switch(s.oldVersion){case 0:r.createObjectStore(Vn,{keyPath:"compositeKey"})}}}catch(t){e(Ve.create("storage-open",{originalErrorMessage:t==null?void 0:t.message}))}})}class yp{getLastFetchStatus(){return this.get("last_fetch_status")}setLastFetchStatus(e){return this.set("last_fetch_status",e)}getLastSuccessfulFetchTimestampMillis(){return this.get("last_successful_fetch_timestamp_millis")}setLastSuccessfulFetchTimestampMillis(e){return this.set("last_successful_fetch_timestamp_millis",e)}getLastSuccessfulFetchResponse(){return this.get("last_successful_fetch_response")}setLastSuccessfulFetchResponse(e){return this.set("last_successful_fetch_response",e)}getActiveConfig(){return this.get("active_config")}setActiveConfig(e){return this.set("active_config",e)}getActiveConfigEtag(){return this.get("active_config_etag")}setActiveConfigEtag(e){return this.set("active_config_etag",e)}getActiveExperiments(){return this.get("active_experiments")}setActiveExperiments(e){return this.set("active_experiments",e)}getThrottleMetadata(){return this.get("throttle_metadata")}setThrottleMetadata(e){return this.set("throttle_metadata",e)}deleteThrottleMetadata(){return this.delete("throttle_metadata")}getCustomSignals(){return this.get("custom_signals")}getRealtimeBackoffMetadata(){return this.get("realtime_backoff_metadata")}setRealtimeBackoffMetadata(e){return this.set("realtime_backoff_metadata",e)}getActiveConfigTemplateVersion(){return this.get("last_known_template_version")}setActiveConfigTemplateVersion(e){return this.set("last_known_template_version",e)}}class Dw extends yp{constructor(e,t,s,r=Ew()){super(),this.appId=e,this.appName=t,this.namespace=s,this.openDbPromise=r}async setCustomSignals(e){const s=(await this.openDbPromise).transaction([Vn],"readwrite"),r=await this.getWithTransaction("custom_signals",s),i=wp(e,r||{});return await this.setWithTransaction("custom_signals",i,s),i}async getWithTransaction(e,t){return new Promise((s,r)=>{const i=t.objectStore(Vn),o=this.createCompositeKey(e);try{const a=i.get(o);a.onerror=B=>{r(sa(B,"storage-get"))},a.onsuccess=B=>{const c=B.target.result;s(c?c.value:void 0)}}catch(a){r(Ve.create("storage-get",{originalErrorMessage:a==null?void 0:a.message}))}})}async setWithTransaction(e,t,s){return new Promise((r,i)=>{const o=s.objectStore(Vn),a=this.createCompositeKey(e);try{const B=o.put({compositeKey:a,value:t});B.onerror=c=>{i(sa(c,"storage-set"))},B.onsuccess=()=>{r()}}catch(B){i(Ve.create("storage-set",{originalErrorMessage:B==null?void 0:B.message}))}})}async get(e){const s=(await this.openDbPromise).transaction([Vn],"readonly");return this.getWithTransaction(e,s)}async set(e,t){const r=(await this.openDbPromise).transaction([Vn],"readwrite");return this.setWithTransaction(e,t,r)}async delete(e){const t=await this.openDbPromise;return new Promise((s,r)=>{const o=t.transaction([Vn],"readwrite").objectStore(Vn),a=this.createCompositeKey(e);try{const B=o.delete(a);B.onerror=c=>{r(sa(c,"storage-delete"))},B.onsuccess=()=>{s()}}catch(B){r(Ve.create("storage-delete",{originalErrorMessage:B==null?void 0:B.message}))}})}createCompositeKey(e){return[this.appId,this.appName,this.namespace,e].join()}}class yw extends yp{constructor(){super(...arguments),this.storage={}}async get(e){return Promise.resolve(this.storage[e])}async set(e,t){return this.storage[e]=t,Promise.resolve(void 0)}async delete(e){return this.storage[e]=void 0,Promise.resolve()}async setCustomSignals(e){const t=this.storage.custom_signals||{};return this.storage.custom_signals=wp(e,t),Promise.resolve(this.storage.custom_signals)}}function wp(n,e){const t={...e,...n},s=Object.fromEntries(Object.entries(t).filter(([r,i])=>i!==null).map(([r,i])=>typeof i=="number"?[r,i.toString()]:[r,i]));if(Object.keys(s).length>vf)throw Ve.create("custom-signal-max-allowed-signals",{maxSignals:vf});return s}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ww{constructor(e){this.storage=e}getLastFetchStatus(){return this.lastFetchStatus}getLastSuccessfulFetchTimestampMillis(){return this.lastSuccessfulFetchTimestampMillis}getActiveConfig(){return this.activeConfig}getCustomSignals(){return this.customSignals}async loadFromStorage(){const e=this.storage.getLastFetchStatus(),t=this.storage.getLastSuccessfulFetchTimestampMillis(),s=this.storage.getActiveConfig(),r=this.storage.getCustomSignals(),i=await e;i&&(this.lastFetchStatus=i);const o=await t;o&&(this.lastSuccessfulFetchTimestampMillis=o);const a=await s;a&&(this.activeConfig=a);const B=await r;B&&(this.customSignals=B)}setLastFetchStatus(e){return this.lastFetchStatus=e,this.storage.setLastFetchStatus(e)}setLastSuccessfulFetchTimestampMillis(e){return this.lastSuccessfulFetchTimestampMillis=e,this.storage.setLastSuccessfulFetchTimestampMillis(e)}setActiveConfig(e){return this.activeConfig=e,this.storage.setActiveConfig(e)}async setCustomSignals(e){this.customSignals=await this.storage.setCustomSignals(e)}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Tw=class{constructor(e){this.allowedEvents_=e,this.listeners_={},H(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const s=[...this.listeners_[e]];for(let r=0;r<s.length;r++)s[r].callback.apply(s[r].context,t)}}on(e,t,s){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:s});const r=this.getInitialEvent(e);r&&t.apply(s,r)}off(e,t,s){this.validateEventType_(e);const r=this.listeners_[e]||[];for(let i=0;i<r.length;i++)if(r[i].callback===t&&(!s||s===r[i].context)){r.splice(i,1);return}}validateEventType_(e){H(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}};/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Iw=class Tp extends Tw{static getInstance(){return new Tp}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const s=!document[e];s!==this.visible_&&(this.visible_=s,this.trigger("visible",s))},!1)}getInitialEvent(e){return H(e==="visible","Unknown event type: "+e),[this.visible_]}};/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Aw="X-Goog-Api-Key",vw="X-Goog-Firebase-Installations-Auth",BB=8,Sf=3,bf=-1,Nf=0,Pf="featureDisabled",Ff="retryIntervalSeconds",Of="latestTemplateVersionNumber",Rw="_exp_rollout";class Sw{constructor(e,t,s,r,i,o,a,B,c,u){this.firebaseInstallations=e,this.storage=t,this.sdkVersion=s,this.namespace=r,this.projectId=i,this.apiKey=o,this.appId=a,this.logger=B,this.storageCache=c,this.cachingClient=u,this.observers=new Set,this.isConnectionActive=!1,this.isRealtimeDisabled=!1,this.httpRetriesRemaining=BB,this.isInBackground=!1,this.decoder=new TextDecoder("utf-8"),this.isClosingConnection=!1,this.propagateError=f=>this.observers.forEach(C=>{var g;return(g=C.error)==null?void 0:g.call(C,f)}),this.isStatusCodeRetryable=f=>!f||[408,429,502,503,504].includes(f),this.setRetriesRemaining(),Iw.getInstance().on("visible",this.onVisibilityChange,this)}async setRetriesRemaining(){const e=await this.storage.getRealtimeBackoffMetadata(),t=(e==null?void 0:e.numFailedStreams)||0;this.httpRetriesRemaining=Math.max(BB-t,1)}async updateBackoffMetadataWithLastFailedStreamConnectionTime(e){var r;const t=(((r=await this.storage.getRealtimeBackoffMetadata())==null?void 0:r.numFailedStreams)||0)+1,s=zC(t,6e4,2);await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:new Date(e.getTime()+s),numFailedStreams:t})}async updateBackoffMetadataWithRetryInterval(e){const t=Date.now(),s=e*1e3,r=new Date(t+s);await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:r,numFailedStreams:0}),await this.retryHttpConnectionWhenBackoffEnds()}async closeRealtimeHttpConnection(){if(!this.isClosingConnection){this.isClosingConnection=!0;try{this.reader&&await this.reader.cancel()}catch{this.logger.debug("Failed to cancel the reader, connection was lost.")}finally{this.reader=void 0}this.controller&&(await this.controller.abort(),this.controller=void 0),this.isClosingConnection=!1}}async resetRealtimeBackoff(){await this.storage.setRealtimeBackoffMetadata({backoffEndTimeMillis:new Date(-1),numFailedStreams:0})}resetRetryCount(){this.httpRetriesRemaining=BB}async establishRealtimeConnection(e,t,s,r){const i=await this.storage.getActiveConfigEtag(),o=await this.storage.getActiveConfigTemplateVersion(),a={[Aw]:this.apiKey,[vw]:s,"Content-Type":"application/json",Accept:"application/json","If-None-Match":i||"*","Content-Encoding":"gzip"},B={project:this.projectId,namespace:this.namespace,lastKnownVersionNumber:o,appId:this.appId,sdkVersion:this.sdkVersion,appInstanceId:t};return await fetch(e,{method:"POST",headers:a,body:JSON.stringify(B),signal:r})}getRealtimeUrl(){const t=`${window.FIREBASE_REMOTE_CONFIG_URL_BASE||"https://firebaseremoteconfigrealtime.googleapis.com"}/v1/projects/${this.projectId}/namespaces/${this.namespace}:streamFetchInvalidations?key=${this.apiKey}`;return new URL(t)}async createRealtimeConnection(){const[e,t]=await Promise.all([this.firebaseInstallations.getId(),this.firebaseInstallations.getToken(!1)]);this.controller=new AbortController;const s=this.getRealtimeUrl();return await this.establishRealtimeConnection(s,e,t,this.controller.signal)}async retryHttpConnectionWhenBackoffEnds(){let e=await this.storage.getRealtimeBackoffMetadata();e||(e={backoffEndTimeMillis:new Date(bf),numFailedStreams:Nf});const t=new Date(e.backoffEndTimeMillis).getTime(),s=Date.now(),r=Math.max(0,t-s);await this.makeRealtimeHttpConnection(r)}setIsHttpConnectionRunning(e){this.isConnectionActive=e}checkAndSetHttpConnectionFlagIfNotRunning(){const e=this.canEstablishStreamConnection();return e&&this.setIsHttpConnectionRunning(!0),e}fetchResponseIsUpToDate(e,t){return e.config!=null&&e.templateVersion?e.templateVersion>=t:this.storageCache.getLastFetchStatus()==="success"}parseAndValidateConfigUpdateMessage(e){const t=e.indexOf("{"),s=e.indexOf("}",t);return t<0||s<0||t>=s?"":e.substring(t,s+1)}isEventListenersEmpty(){return this.observers.size===0}getRandomInt(e){return Math.floor(Math.random()*e)}executeAllListenerCallbacks(e){this.observers.forEach(t=>t.next(e))}getChangedParams(e,t,s,r){const i=new Set,o=new Set(Object.keys(e||{})),a=new Set(Object.keys(t||{})),B=s.experiments||[],c=(r==null?void 0:r.experiments)||[],u=this.createExperimentsMap(B),f=this.createExperimentsMap(c),C=s.rollouts||[],g=(r==null?void 0:r.rollouts)||[],E=this.createRolloutsMap(C),b=this.createRolloutsMap(g);for(const F of o){if(!a.has(F)||e[F]!==t[F]){i.add(F);continue}if(u.has(F)!==f.has(F)){i.add(F);continue}const j=u.get(F),te=f.get(F);if(j&&te&&!this.areExperimentsEqual(j,te)){i.add(F);continue}if(E.has(F)!==b.has(F)){i.add(F);continue}const ie=E.get(F),me=b.get(F);ie&&me&&!this.areRolloutsEqual(ie,me)&&i.add(F)}for(const F of a)o.has(F)||i.add(F);return i}areExperimentsEqual(e,t){return e.experimentId===t.experimentId&&e.variantId===t.variantId&&e.timeToLiveMillis===t.timeToLiveMillis&&e.triggerTimeoutMillis===t.triggerTimeoutMillis}areRolloutsEqual(e,t){if(e.size!==t.size)return!1;for(const[s,r]of e)if(t.get(s)!==r)return!1;return!0}createExperimentsMap(e){const t=new Map;for(const s of e)if(!(!s.affectedParameterKeys||s.experimentId.startsWith(Rw)))for(const r of s.affectedParameterKeys)t.set(r,s);return t}createRolloutsMap(e){const t=new Map;for(const s of e){const r=s.rolloutId,i=s.variantId,o=s.affectedParameterKeys||[];for(const a of o){let B=t.get(a);B||(B=new Map,t.set(a,B)),B.set(r,i)}}return t}async fetchLatestConfig(e,t){const s=e-1,r=Sf-s,i=this.storageCache.getCustomSignals();i&&this.logger.debug(`Fetching config with custom signals: ${JSON.stringify(i)}`);const o=new Ep;try{const a={cacheMaxAgeMillis:0,signal:o,customSignals:i,fetchType:"REALTIME",fetchAttempt:r},B=await this.storage.getLastSuccessfulFetchResponse(),c=await this.cachingClient.fetch(a);let u=await this.storage.getActiveConfig();if(!this.fetchResponseIsUpToDate(c,t)){this.logger.debug("Fetched template version is the same as SDK's current version. Retrying fetch."),await this.autoFetch(s,t);return}if(c.config==null){this.logger.debug("The fetch succeeded, but the backend had no updates.");return}u==null&&(u={});const f=this.getChangedParams(c.config,u,c,B);if(f.size===0){this.logger.debug("Config was fetched, but no params changed.");return}const C={getUpdatedKeys(){return new Set(f)}};this.executeAllListenerCallbacks(C)}catch(a){const B=a instanceof Error?a.message:String(a),c=Ve.create("update-not-fetched",{originalErrorMessage:`Failed to auto-fetch config update: ${B}`});this.propagateError(c)}}async autoFetch(e,t){if(e===0){const i=Ve.create("update-not-fetched",{originalErrorMessage:"Unable to fetch the latest version of the template."});this.propagateError(i);return}const r=this.getRandomInt(4)*1e3;await new Promise(i=>setTimeout(i,r)),await this.fetchLatestConfig(e,t)}async handleNotifications(e){let t,s="";for(;;){const{done:r,value:i}=await e.read();if(r)break;if(t=this.decoder.decode(i,{stream:!0}),s+=t,t.includes("}")){if(s=this.parseAndValidateConfigUpdateMessage(s),s.length===0)continue;try{const o=JSON.parse(s);if(this.isEventListenersEmpty())break;if(Pf in o&&o[Pf]===!0){const a=Ve.create("realtime-unavailable",{originalErrorMessage:"The server is temporarily unavailable. Try again in a few minutes."});this.propagateError(a);break}if(Of in o){const a=await this.storage.getActiveConfigTemplateVersion(),B=Number(o[Of]);a&&B>a&&await this.autoFetch(Sf,B)}if(Ff in o){const a=Number(o[Ff]);await this.updateBackoffMetadataWithRetryInterval(a)}}catch(o){this.logger.debug("Unable to parse latest config update message.",o);const a=o instanceof Error?o.message:String(o);this.propagateError(Ve.create("update-message-invalid",{originalErrorMessage:a}))}s=""}}}async listenForNotifications(e){try{await this.handleNotifications(e)}catch{this.isInBackground||this.logger.debug("Real-time connection was closed due to an exception.")}}async prepareAndBeginRealtimeHttpStream(){if(!this.checkAndSetHttpConnectionFlagIfNotRunning())return;let e=await this.storage.getRealtimeBackoffMetadata();e||(e={backoffEndTimeMillis:new Date(bf),numFailedStreams:Nf});const t=e.backoffEndTimeMillis.getTime();if(Date.now()<t){await this.retryHttpConnectionWhenBackoffEnds();return}let s,r;try{if(s=await this.createRealtimeConnection(),r=s.status,s.ok&&s.body){this.resetRetryCount(),await this.resetRealtimeBackoff();const i=s.body.getReader();this.reader=i,await this.listenForNotifications(i)}}catch(i){this.isInBackground?this.resetRetryCount():this.logger.debug("Exception connecting to real-time RC backend. Retrying the connection...:",i)}finally{await this.closeRealtimeHttpConnection(),this.setIsHttpConnectionRunning(!1);const i=!this.isInBackground&&(r===void 0||this.isStatusCodeRetryable(r));if(i&&await this.updateBackoffMetadataWithLastFailedStreamConnectionTime(new Date),i||s!=null&&s.ok)await this.retryHttpConnectionWhenBackoffEnds();else{const o=`Unable to connect to the server. HTTP status code: ${r}`,a=Ve.create("stream-error",{originalErrorMessage:o});this.propagateError(a)}}}canEstablishStreamConnection(){const e=this.observers.size>0,t=!this.isRealtimeDisabled,s=!this.isConnectionActive,r=!this.isInBackground;return e&&t&&s&&r}async makeRealtimeHttpConnection(e){if(this.canEstablishStreamConnection()){if(this.httpRetriesRemaining>0)this.httpRetriesRemaining--,await new Promise(t=>setTimeout(t,e)),this.prepareAndBeginRealtimeHttpStream();else if(!this.isInBackground){const t=Ve.create("stream-error",{originalErrorMessage:"Unable to connect to the server. Check your connection and try again."});this.propagateError(t)}}}async beginRealtime(){this.observers.size>0&&await this.makeRealtimeHttpConnection(0)}addObserver(e){this.observers.add(e),this.beginRealtime()}removeObserver(e){this.observers.has(e)&&this.observers.delete(e)}async onVisibilityChange(e){this.isInBackground=!e,e?e&&await this.beginRealtime():await this.closeRealtimeHttpConnection()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bw(){es(new wn(Dp,n,"PUBLIC").setMultipleInstances(!0)),Ht(aB,Af),Ht(aB,Af,"esm2020");function n(e,{options:t}){const s=e.getProvider("app").getImmediate(),r=e.getProvider("installations-internal").getImmediate(),i=e.getProvider("analytics-internal"),{projectId:o,apiKey:a,appId:B}=s.options;if(!o)throw Ve.create("registration-project-id");if(!a)throw Ve.create("registration-api-key");if(!B)throw Ve.create("registration-app-id");const c=(t==null?void 0:t.templateId)||"firebase",u=KC()?new Dw(B,s.name,c):new yw,f=new ww(u),C=new Qa(aB);C.logLevel=he.ERROR;const g=new uw(r,da,c,o,a,B),E=new dw(g,u),b=new Bw(E,u,f,C),F=new Sw(r,u,da,c,o,a,B,C,f,b),j=new gw(s,b,f,u,C,F,i);return aw(j),j}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function SN(n){return n=Ie(n),await lw(n),ow(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */bw();var Lf=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Kn,Ip;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(v,D){function w(){}w.prototype=D.prototype,v.F=D.prototype,v.prototype=new w,v.prototype.constructor=v,v.D=function(R,A,N){for(var y=Array(arguments.length-2),Et=2;Et<arguments.length;Et++)y[Et-2]=arguments[Et];return D.prototype[A].apply(R,y)}}function t(){this.blockSize=-1}function s(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(s,t),s.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function r(v,D,w){w||(w=0);const R=Array(16);if(typeof D=="string")for(var A=0;A<16;++A)R[A]=D.charCodeAt(w++)|D.charCodeAt(w++)<<8|D.charCodeAt(w++)<<16|D.charCodeAt(w++)<<24;else for(A=0;A<16;++A)R[A]=D[w++]|D[w++]<<8|D[w++]<<16|D[w++]<<24;D=v.g[0],w=v.g[1],A=v.g[2];let N=v.g[3],y;y=D+(N^w&(A^N))+R[0]+3614090360&4294967295,D=w+(y<<7&4294967295|y>>>25),y=N+(A^D&(w^A))+R[1]+3905402710&4294967295,N=D+(y<<12&4294967295|y>>>20),y=A+(w^N&(D^w))+R[2]+606105819&4294967295,A=N+(y<<17&4294967295|y>>>15),y=w+(D^A&(N^D))+R[3]+3250441966&4294967295,w=A+(y<<22&4294967295|y>>>10),y=D+(N^w&(A^N))+R[4]+4118548399&4294967295,D=w+(y<<7&4294967295|y>>>25),y=N+(A^D&(w^A))+R[5]+1200080426&4294967295,N=D+(y<<12&4294967295|y>>>20),y=A+(w^N&(D^w))+R[6]+2821735955&4294967295,A=N+(y<<17&4294967295|y>>>15),y=w+(D^A&(N^D))+R[7]+4249261313&4294967295,w=A+(y<<22&4294967295|y>>>10),y=D+(N^w&(A^N))+R[8]+1770035416&4294967295,D=w+(y<<7&4294967295|y>>>25),y=N+(A^D&(w^A))+R[9]+2336552879&4294967295,N=D+(y<<12&4294967295|y>>>20),y=A+(w^N&(D^w))+R[10]+4294925233&4294967295,A=N+(y<<17&4294967295|y>>>15),y=w+(D^A&(N^D))+R[11]+2304563134&4294967295,w=A+(y<<22&4294967295|y>>>10),y=D+(N^w&(A^N))+R[12]+1804603682&4294967295,D=w+(y<<7&4294967295|y>>>25),y=N+(A^D&(w^A))+R[13]+4254626195&4294967295,N=D+(y<<12&4294967295|y>>>20),y=A+(w^N&(D^w))+R[14]+2792965006&4294967295,A=N+(y<<17&4294967295|y>>>15),y=w+(D^A&(N^D))+R[15]+1236535329&4294967295,w=A+(y<<22&4294967295|y>>>10),y=D+(A^N&(w^A))+R[1]+4129170786&4294967295,D=w+(y<<5&4294967295|y>>>27),y=N+(w^A&(D^w))+R[6]+3225465664&4294967295,N=D+(y<<9&4294967295|y>>>23),y=A+(D^w&(N^D))+R[11]+643717713&4294967295,A=N+(y<<14&4294967295|y>>>18),y=w+(N^D&(A^N))+R[0]+3921069994&4294967295,w=A+(y<<20&4294967295|y>>>12),y=D+(A^N&(w^A))+R[5]+3593408605&4294967295,D=w+(y<<5&4294967295|y>>>27),y=N+(w^A&(D^w))+R[10]+38016083&4294967295,N=D+(y<<9&4294967295|y>>>23),y=A+(D^w&(N^D))+R[15]+3634488961&4294967295,A=N+(y<<14&4294967295|y>>>18),y=w+(N^D&(A^N))+R[4]+3889429448&4294967295,w=A+(y<<20&4294967295|y>>>12),y=D+(A^N&(w^A))+R[9]+568446438&4294967295,D=w+(y<<5&4294967295|y>>>27),y=N+(w^A&(D^w))+R[14]+3275163606&4294967295,N=D+(y<<9&4294967295|y>>>23),y=A+(D^w&(N^D))+R[3]+4107603335&4294967295,A=N+(y<<14&4294967295|y>>>18),y=w+(N^D&(A^N))+R[8]+1163531501&4294967295,w=A+(y<<20&4294967295|y>>>12),y=D+(A^N&(w^A))+R[13]+2850285829&4294967295,D=w+(y<<5&4294967295|y>>>27),y=N+(w^A&(D^w))+R[2]+4243563512&4294967295,N=D+(y<<9&4294967295|y>>>23),y=A+(D^w&(N^D))+R[7]+1735328473&4294967295,A=N+(y<<14&4294967295|y>>>18),y=w+(N^D&(A^N))+R[12]+2368359562&4294967295,w=A+(y<<20&4294967295|y>>>12),y=D+(w^A^N)+R[5]+4294588738&4294967295,D=w+(y<<4&4294967295|y>>>28),y=N+(D^w^A)+R[8]+2272392833&4294967295,N=D+(y<<11&4294967295|y>>>21),y=A+(N^D^w)+R[11]+1839030562&4294967295,A=N+(y<<16&4294967295|y>>>16),y=w+(A^N^D)+R[14]+4259657740&4294967295,w=A+(y<<23&4294967295|y>>>9),y=D+(w^A^N)+R[1]+2763975236&4294967295,D=w+(y<<4&4294967295|y>>>28),y=N+(D^w^A)+R[4]+1272893353&4294967295,N=D+(y<<11&4294967295|y>>>21),y=A+(N^D^w)+R[7]+4139469664&4294967295,A=N+(y<<16&4294967295|y>>>16),y=w+(A^N^D)+R[10]+3200236656&4294967295,w=A+(y<<23&4294967295|y>>>9),y=D+(w^A^N)+R[13]+681279174&4294967295,D=w+(y<<4&4294967295|y>>>28),y=N+(D^w^A)+R[0]+3936430074&4294967295,N=D+(y<<11&4294967295|y>>>21),y=A+(N^D^w)+R[3]+3572445317&4294967295,A=N+(y<<16&4294967295|y>>>16),y=w+(A^N^D)+R[6]+76029189&4294967295,w=A+(y<<23&4294967295|y>>>9),y=D+(w^A^N)+R[9]+3654602809&4294967295,D=w+(y<<4&4294967295|y>>>28),y=N+(D^w^A)+R[12]+3873151461&4294967295,N=D+(y<<11&4294967295|y>>>21),y=A+(N^D^w)+R[15]+530742520&4294967295,A=N+(y<<16&4294967295|y>>>16),y=w+(A^N^D)+R[2]+3299628645&4294967295,w=A+(y<<23&4294967295|y>>>9),y=D+(A^(w|~N))+R[0]+4096336452&4294967295,D=w+(y<<6&4294967295|y>>>26),y=N+(w^(D|~A))+R[7]+1126891415&4294967295,N=D+(y<<10&4294967295|y>>>22),y=A+(D^(N|~w))+R[14]+2878612391&4294967295,A=N+(y<<15&4294967295|y>>>17),y=w+(N^(A|~D))+R[5]+4237533241&4294967295,w=A+(y<<21&4294967295|y>>>11),y=D+(A^(w|~N))+R[12]+1700485571&4294967295,D=w+(y<<6&4294967295|y>>>26),y=N+(w^(D|~A))+R[3]+2399980690&4294967295,N=D+(y<<10&4294967295|y>>>22),y=A+(D^(N|~w))+R[10]+4293915773&4294967295,A=N+(y<<15&4294967295|y>>>17),y=w+(N^(A|~D))+R[1]+2240044497&4294967295,w=A+(y<<21&4294967295|y>>>11),y=D+(A^(w|~N))+R[8]+1873313359&4294967295,D=w+(y<<6&4294967295|y>>>26),y=N+(w^(D|~A))+R[15]+4264355552&4294967295,N=D+(y<<10&4294967295|y>>>22),y=A+(D^(N|~w))+R[6]+2734768916&4294967295,A=N+(y<<15&4294967295|y>>>17),y=w+(N^(A|~D))+R[13]+1309151649&4294967295,w=A+(y<<21&4294967295|y>>>11),y=D+(A^(w|~N))+R[4]+4149444226&4294967295,D=w+(y<<6&4294967295|y>>>26),y=N+(w^(D|~A))+R[11]+3174756917&4294967295,N=D+(y<<10&4294967295|y>>>22),y=A+(D^(N|~w))+R[2]+718787259&4294967295,A=N+(y<<15&4294967295|y>>>17),y=w+(N^(A|~D))+R[9]+3951481745&4294967295,v.g[0]=v.g[0]+D&4294967295,v.g[1]=v.g[1]+(A+(y<<21&4294967295|y>>>11))&4294967295,v.g[2]=v.g[2]+A&4294967295,v.g[3]=v.g[3]+N&4294967295}s.prototype.v=function(v,D){D===void 0&&(D=v.length);const w=D-this.blockSize,R=this.C;let A=this.h,N=0;for(;N<D;){if(A==0)for(;N<=w;)r(this,v,N),N+=this.blockSize;if(typeof v=="string"){for(;N<D;)if(R[A++]=v.charCodeAt(N++),A==this.blockSize){r(this,R),A=0;break}}else for(;N<D;)if(R[A++]=v[N++],A==this.blockSize){r(this,R),A=0;break}}this.h=A,this.o+=D},s.prototype.A=function(){var v=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);v[0]=128;for(var D=1;D<v.length-8;++D)v[D]=0;D=this.o*8;for(var w=v.length-8;w<v.length;++w)v[w]=D&255,D/=256;for(this.v(v),v=Array(16),D=0,w=0;w<4;++w)for(let R=0;R<32;R+=8)v[D++]=this.g[w]>>>R&255;return v};function i(v,D){var w=a;return Object.prototype.hasOwnProperty.call(w,v)?w[v]:w[v]=D(v)}function o(v,D){this.h=D;const w=[];let R=!0;for(let A=v.length-1;A>=0;A--){const N=v[A]|0;R&&N==D||(w[A]=N,R=!1)}this.g=w}var a={};function B(v){return-128<=v&&v<128?i(v,function(D){return new o([D|0],D<0?-1:0)}):new o([v|0],v<0?-1:0)}function c(v){if(isNaN(v)||!isFinite(v))return f;if(v<0)return F(c(-v));const D=[];let w=1;for(let R=0;v>=w;R++)D[R]=v/w|0,w*=4294967296;return new o(D,0)}function u(v,D){if(v.length==0)throw Error("number format error: empty string");if(D=D||10,D<2||36<D)throw Error("radix out of range: "+D);if(v.charAt(0)=="-")return F(u(v.substring(1),D));if(v.indexOf("-")>=0)throw Error('number format error: interior "-" character');const w=c(Math.pow(D,8));let R=f;for(let N=0;N<v.length;N+=8){var A=Math.min(8,v.length-N);const y=parseInt(v.substring(N,N+A),D);A<8?(A=c(Math.pow(D,A)),R=R.j(A).add(c(y))):(R=R.j(w),R=R.add(c(y)))}return R}var f=B(0),C=B(1),g=B(16777216);n=o.prototype,n.m=function(){if(b(this))return-F(this).m();let v=0,D=1;for(let w=0;w<this.g.length;w++){const R=this.i(w);v+=(R>=0?R:4294967296+R)*D,D*=4294967296}return v},n.toString=function(v){if(v=v||10,v<2||36<v)throw Error("radix out of range: "+v);if(E(this))return"0";if(b(this))return"-"+F(this).toString(v);const D=c(Math.pow(v,6));var w=this;let R="";for(;;){const A=me(w,D).g;w=j(w,A.j(D));let N=((w.g.length>0?w.g[0]:w.h)>>>0).toString(v);if(w=A,E(w))return N+R;for(;N.length<6;)N="0"+N;R=N+R}},n.i=function(v){return v<0?0:v<this.g.length?this.g[v]:this.h};function E(v){if(v.h!=0)return!1;for(let D=0;D<v.g.length;D++)if(v.g[D]!=0)return!1;return!0}function b(v){return v.h==-1}n.l=function(v){return v=j(this,v),b(v)?-1:E(v)?0:1};function F(v){const D=v.g.length,w=[];for(let R=0;R<D;R++)w[R]=~v.g[R];return new o(w,~v.h).add(C)}n.abs=function(){return b(this)?F(this):this},n.add=function(v){const D=Math.max(this.g.length,v.g.length),w=[];let R=0;for(let A=0;A<=D;A++){let N=R+(this.i(A)&65535)+(v.i(A)&65535),y=(N>>>16)+(this.i(A)>>>16)+(v.i(A)>>>16);R=y>>>16,N&=65535,y&=65535,w[A]=y<<16|N}return new o(w,w[w.length-1]&-2147483648?-1:0)};function j(v,D){return v.add(F(D))}n.j=function(v){if(E(this)||E(v))return f;if(b(this))return b(v)?F(this).j(F(v)):F(F(this).j(v));if(b(v))return F(this.j(F(v)));if(this.l(g)<0&&v.l(g)<0)return c(this.m()*v.m());const D=this.g.length+v.g.length,w=[];for(var R=0;R<2*D;R++)w[R]=0;for(R=0;R<this.g.length;R++)for(let A=0;A<v.g.length;A++){const N=this.i(R)>>>16,y=this.i(R)&65535,Et=v.i(A)>>>16,ms=v.i(A)&65535;w[2*R+2*A]+=y*ms,te(w,2*R+2*A),w[2*R+2*A+1]+=N*ms,te(w,2*R+2*A+1),w[2*R+2*A+1]+=y*Et,te(w,2*R+2*A+1),w[2*R+2*A+2]+=N*Et,te(w,2*R+2*A+2)}for(v=0;v<D;v++)w[v]=w[2*v+1]<<16|w[2*v];for(v=D;v<2*D;v++)w[v]=0;return new o(w,0)};function te(v,D){for(;(v[D]&65535)!=v[D];)v[D+1]+=v[D]>>>16,v[D]&=65535,D++}function ie(v,D){this.g=v,this.h=D}function me(v,D){if(E(D))throw Error("division by zero");if(E(v))return new ie(f,f);if(b(v))return D=me(F(v),D),new ie(F(D.g),F(D.h));if(b(D))return D=me(v,F(D)),new ie(F(D.g),D.h);if(v.g.length>30){if(b(v)||b(D))throw Error("slowDivide_ only works with positive integers.");for(var w=C,R=D;R.l(v)<=0;)w=Me(w),R=Me(R);var A=Le(w,1),N=Le(R,1);for(R=Le(R,2),w=Le(w,2);!E(R);){var y=N.add(R);y.l(v)<=0&&(A=A.add(w),N=y),R=Le(R,1),w=Le(w,1)}return D=j(v,A.j(D)),new ie(A,D)}for(A=f;v.l(D)>=0;){for(w=Math.max(1,Math.floor(v.m()/D.m())),R=Math.ceil(Math.log(w)/Math.LN2),R=R<=48?1:Math.pow(2,R-48),N=c(w),y=N.j(D);b(y)||y.l(v)>0;)w-=R,N=c(w),y=N.j(D);E(N)&&(N=C),A=A.add(N),v=j(v,y)}return new ie(A,v)}n.B=function(v){return me(this,v).h},n.and=function(v){const D=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<D;R++)w[R]=this.i(R)&v.i(R);return new o(w,this.h&v.h)},n.or=function(v){const D=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<D;R++)w[R]=this.i(R)|v.i(R);return new o(w,this.h|v.h)},n.xor=function(v){const D=Math.max(this.g.length,v.g.length),w=[];for(let R=0;R<D;R++)w[R]=this.i(R)^v.i(R);return new o(w,this.h^v.h)};function Me(v){const D=v.g.length+1,w=[];for(let R=0;R<D;R++)w[R]=v.i(R)<<1|v.i(R-1)>>>31;return new o(w,v.h)}function Le(v,D){const w=D>>5;D%=32;const R=v.g.length-w,A=[];for(let N=0;N<R;N++)A[N]=D>0?v.i(N+w)>>>D|v.i(N+w+1)<<32-D:v.i(N+w);return new o(A,v.h)}s.prototype.digest=s.prototype.A,s.prototype.reset=s.prototype.u,s.prototype.update=s.prototype.v,Ip=s,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.B,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=c,o.fromString=u,Kn=o}).apply(typeof Lf<"u"?Lf:typeof self<"u"?self:typeof window<"u"?window:{});var Jo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Ap,fi,vp,ra,OB,Rp,Sp,bp;(function(){var n,e=Object.defineProperty;function t(l){l=[typeof globalThis=="object"&&globalThis,l,typeof window=="object"&&window,typeof self=="object"&&self,typeof Jo=="object"&&Jo];for(var h=0;h<l.length;++h){var d=l[h];if(d&&d.Math==Math)return d}throw Error("Cannot find global object")}var s=t(this);function r(l,h){if(h)e:{var d=s;l=l.split(".");for(var p=0;p<l.length-1;p++){var S=l[p];if(!(S in d))break e;d=d[S]}l=l[l.length-1],p=d[l],h=h(p),h!=p&&h!=null&&e(d,l,{configurable:!0,writable:!0,value:h})}}r("Symbol.dispose",function(l){return l||Symbol("Symbol.dispose")}),r("Array.prototype.values",function(l){return l||function(){return this[Symbol.iterator]()}}),r("Object.entries",function(l){return l||function(h){var d=[],p;for(p in h)Object.prototype.hasOwnProperty.call(h,p)&&d.push([p,h[p]]);return d}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},o=this||self;function a(l){var h=typeof l;return h=="object"&&l!=null||h=="function"}function B(l,h,d){return l.call.apply(l.bind,arguments)}function c(l,h,d){return c=B,c.apply(null,arguments)}function u(l,h){var d=Array.prototype.slice.call(arguments,1);return function(){var p=d.slice();return p.push.apply(p,arguments),l.apply(this,p)}}function f(l,h){function d(){}d.prototype=h.prototype,l.Z=h.prototype,l.prototype=new d,l.prototype.constructor=l,l.Ob=function(p,S,P){for(var K=Array(arguments.length-2),oe=2;oe<arguments.length;oe++)K[oe-2]=arguments[oe];return h.prototype[S].apply(p,K)}}var C=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?l=>l&&AsyncContext.Snapshot.wrap(l):l=>l;function g(l){const h=l.length;if(h>0){const d=Array(h);for(let p=0;p<h;p++)d[p]=l[p];return d}return[]}function E(l,h){for(let p=1;p<arguments.length;p++){const S=arguments[p];var d=typeof S;if(d=d!="object"?d:S?Array.isArray(S)?"array":d:"null",d=="array"||d=="object"&&typeof S.length=="number"){d=l.length||0;const P=S.length||0;l.length=d+P;for(let K=0;K<P;K++)l[d+K]=S[K]}else l.push(S)}}class b{constructor(h,d){this.i=h,this.j=d,this.h=0,this.g=null}get(){let h;return this.h>0?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function F(l){o.setTimeout(()=>{throw l},0)}function j(){var l=v;let h=null;return l.g&&(h=l.g,l.g=l.g.next,l.g||(l.h=null),h.next=null),h}class te{constructor(){this.h=this.g=null}add(h,d){const p=ie.get();p.set(h,d),this.h?this.h.next=p:this.g=p,this.h=p}}var ie=new b(()=>new me,l=>l.reset());class me{constructor(){this.next=this.g=this.h=null}set(h,d){this.h=h,this.g=d,this.next=null}reset(){this.next=this.g=this.h=null}}let Me,Le=!1,v=new te,D=()=>{const l=Promise.resolve(void 0);Me=()=>{l.then(w)}};function w(){for(var l;l=j();){try{l.h.call(l.g)}catch(d){F(d)}var h=ie;h.j(l),h.h<100&&(h.h++,l.next=h.g,h.g=l)}Le=!1}function R(){this.u=this.u,this.C=this.C}R.prototype.u=!1,R.prototype.dispose=function(){this.u||(this.u=!0,this.N())},R.prototype[Symbol.dispose]=function(){this.dispose()},R.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function A(l,h){this.type=l,this.g=this.target=h,this.defaultPrevented=!1}A.prototype.h=function(){this.defaultPrevented=!0};var N=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var l=!1,h=Object.defineProperty({},"passive",{get:function(){l=!0}});try{const d=()=>{};o.addEventListener("test",d,h),o.removeEventListener("test",d,h)}catch{}return l}();function y(l){return/^[\s\xa0]*$/.test(l)}function Et(l,h){A.call(this,l?l.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,l&&this.init(l,h)}f(Et,A),Et.prototype.init=function(l,h){const d=this.type=l.type,p=l.changedTouches&&l.changedTouches.length?l.changedTouches[0]:null;this.target=l.target||l.srcElement,this.g=h,h=l.relatedTarget,h||(d=="mouseover"?h=l.fromElement:d=="mouseout"&&(h=l.toElement)),this.relatedTarget=h,p?(this.clientX=p.clientX!==void 0?p.clientX:p.pageX,this.clientY=p.clientY!==void 0?p.clientY:p.pageY,this.screenX=p.screenX||0,this.screenY=p.screenY||0):(this.clientX=l.clientX!==void 0?l.clientX:l.pageX,this.clientY=l.clientY!==void 0?l.clientY:l.pageY,this.screenX=l.screenX||0,this.screenY=l.screenY||0),this.button=l.button,this.key=l.key||"",this.ctrlKey=l.ctrlKey,this.altKey=l.altKey,this.shiftKey=l.shiftKey,this.metaKey=l.metaKey,this.pointerId=l.pointerId||0,this.pointerType=l.pointerType,this.state=l.state,this.i=l,l.defaultPrevented&&Et.Z.h.call(this)},Et.prototype.h=function(){Et.Z.h.call(this);const l=this.i;l.preventDefault?l.preventDefault():l.returnValue=!1};var ms="closure_listenable_"+(Math.random()*1e6|0),Z_=0;function eE(l,h,d,p,S){this.listener=l,this.proxy=null,this.src=h,this.type=d,this.capture=!!p,this.ha=S,this.key=++Z_,this.da=this.fa=!1}function So(l){l.da=!0,l.listener=null,l.proxy=null,l.src=null,l.ha=null}function bo(l,h,d){for(const p in l)h.call(d,l[p],p,l)}function tE(l,h){for(const d in l)h.call(void 0,l[d],d,l)}function uh(l){const h={};for(const d in l)h[d]=l[d];return h}const hh="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function fh(l,h){let d,p;for(let S=1;S<arguments.length;S++){p=arguments[S];for(d in p)l[d]=p[d];for(let P=0;P<hh.length;P++)d=hh[P],Object.prototype.hasOwnProperty.call(p,d)&&(l[d]=p[d])}}function No(l){this.src=l,this.g={},this.h=0}No.prototype.add=function(l,h,d,p,S){const P=l.toString();l=this.g[P],l||(l=this.g[P]=[],this.h++);const K=Pl(l,h,p,S);return K>-1?(h=l[K],d||(h.fa=!1)):(h=new eE(h,this.src,P,!!p,S),h.fa=d,l.push(h)),h};function Nl(l,h){const d=h.type;if(d in l.g){var p=l.g[d],S=Array.prototype.indexOf.call(p,h,void 0),P;(P=S>=0)&&Array.prototype.splice.call(p,S,1),P&&(So(h),l.g[d].length==0&&(delete l.g[d],l.h--))}}function Pl(l,h,d,p){for(let S=0;S<l.length;++S){const P=l[S];if(!P.da&&P.listener==h&&P.capture==!!d&&P.ha==p)return S}return-1}var Fl="closure_lm_"+(Math.random()*1e6|0),Ol={};function dh(l,h,d,p,S){if(Array.isArray(h)){for(let P=0;P<h.length;P++)dh(l,h[P],d,p,S);return null}return d=gh(d),l&&l[ms]?l.J(h,d,a(p)?!!p.capture:!1,S):nE(l,h,d,!1,p,S)}function nE(l,h,d,p,S,P){if(!h)throw Error("Invalid event type");const K=a(S)?!!S.capture:!!S;let oe=xl(l);if(oe||(l[Fl]=oe=new No(l)),d=oe.add(h,d,p,K,P),d.proxy)return d;if(p=sE(),d.proxy=p,p.src=l,p.listener=d,l.addEventListener)N||(S=K),S===void 0&&(S=!1),l.addEventListener(h.toString(),p,S);else if(l.attachEvent)l.attachEvent(ph(h.toString()),p);else if(l.addListener&&l.removeListener)l.addListener(p);else throw Error("addEventListener and attachEvent are unavailable.");return d}function sE(){function l(d){return h.call(l.src,l.listener,d)}const h=rE;return l}function Ch(l,h,d,p,S){if(Array.isArray(h))for(var P=0;P<h.length;P++)Ch(l,h[P],d,p,S);else p=a(p)?!!p.capture:!!p,d=gh(d),l&&l[ms]?(l=l.i,P=String(h).toString(),P in l.g&&(h=l.g[P],d=Pl(h,d,p,S),d>-1&&(So(h[d]),Array.prototype.splice.call(h,d,1),h.length==0&&(delete l.g[P],l.h--)))):l&&(l=xl(l))&&(h=l.g[h.toString()],l=-1,h&&(l=Pl(h,d,p,S)),(d=l>-1?h[l]:null)&&Ll(d))}function Ll(l){if(typeof l!="number"&&l&&!l.da){var h=l.src;if(h&&h[ms])Nl(h.i,l);else{var d=l.type,p=l.proxy;h.removeEventListener?h.removeEventListener(d,p,l.capture):h.detachEvent?h.detachEvent(ph(d),p):h.addListener&&h.removeListener&&h.removeListener(p),(d=xl(h))?(Nl(d,l),d.h==0&&(d.src=null,h[Fl]=null)):So(l)}}}function ph(l){return l in Ol?Ol[l]:Ol[l]="on"+l}function rE(l,h){if(l.da)l=!0;else{h=new Et(h,this);const d=l.listener,p=l.ha||l.src;l.fa&&Ll(l),l=d.call(p,h)}return l}function xl(l){return l=l[Fl],l instanceof No?l:null}var kl="__closure_events_fn_"+(Math.random()*1e9>>>0);function gh(l){return typeof l=="function"?l:(l[kl]||(l[kl]=function(h){return l.handleEvent(h)}),l[kl])}function Bt(){R.call(this),this.i=new No(this),this.M=this,this.G=null}f(Bt,R),Bt.prototype[ms]=!0,Bt.prototype.removeEventListener=function(l,h,d,p){Ch(this,l,h,d,p)};function dt(l,h){var d,p=l.G;if(p)for(d=[];p;p=p.G)d.push(p);if(l=l.M,p=h.type||h,typeof h=="string")h=new A(h,l);else if(h instanceof A)h.target=h.target||l;else{var S=h;h=new A(p,l),fh(h,S)}S=!0;let P,K;if(d)for(K=d.length-1;K>=0;K--)P=h.g=d[K],S=Po(P,p,!0,h)&&S;if(P=h.g=l,S=Po(P,p,!0,h)&&S,S=Po(P,p,!1,h)&&S,d)for(K=0;K<d.length;K++)P=h.g=d[K],S=Po(P,p,!1,h)&&S}Bt.prototype.N=function(){if(Bt.Z.N.call(this),this.i){var l=this.i;for(const h in l.g){const d=l.g[h];for(let p=0;p<d.length;p++)So(d[p]);delete l.g[h],l.h--}}this.G=null},Bt.prototype.J=function(l,h,d,p){return this.i.add(String(l),h,!1,d,p)},Bt.prototype.K=function(l,h,d,p){return this.i.add(String(l),h,!0,d,p)};function Po(l,h,d,p){if(h=l.i.g[String(h)],!h)return!0;h=h.concat();let S=!0;for(let P=0;P<h.length;++P){const K=h[P];if(K&&!K.da&&K.capture==d){const oe=K.listener,ze=K.ha||K.src;K.fa&&Nl(l.i,K),S=oe.call(ze,p)!==!1&&S}}return S&&!p.defaultPrevented}function iE(l,h){if(typeof l!="function")if(l&&typeof l.handleEvent=="function")l=c(l.handleEvent,l);else throw Error("Invalid listener argument");return Number(h)>2147483647?-1:o.setTimeout(l,h||0)}function mh(l){l.g=iE(()=>{l.g=null,l.i&&(l.i=!1,mh(l))},l.l);const h=l.h;l.h=null,l.m.apply(null,h)}class oE extends R{constructor(h,d){super(),this.m=h,this.l=d,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:mh(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function jr(l){R.call(this),this.h=l,this.g={}}f(jr,R);var _h=[];function Eh(l){bo(l.g,function(h,d){this.g.hasOwnProperty(d)&&Ll(h)},l),l.g={}}jr.prototype.N=function(){jr.Z.N.call(this),Eh(this)},jr.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ml=o.JSON.stringify,aE=o.JSON.parse,lE=class{stringify(l){return o.JSON.stringify(l,void 0)}parse(l){return o.JSON.parse(l,void 0)}};function Dh(){}function yh(){}var Kr={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Vl(){A.call(this,"d")}f(Vl,A);function Gl(){A.call(this,"c")}f(Gl,A);var _s={},wh=null;function Fo(){return wh=wh||new Bt}_s.Ia="serverreachability";function Th(l){A.call(this,_s.Ia,l)}f(Th,A);function Qr(l){const h=Fo();dt(h,new Th(h))}_s.STAT_EVENT="statevent";function Ih(l,h){A.call(this,_s.STAT_EVENT,l),this.stat=h}f(Ih,A);function Ct(l){const h=Fo();dt(h,new Ih(h,l))}_s.Ja="timingevent";function Ah(l,h){A.call(this,_s.Ja,l),this.size=h}f(Ah,A);function zr(l,h){if(typeof l!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){l()},h)}function Wr(){this.g=!0}Wr.prototype.ua=function(){this.g=!1};function BE(l,h,d,p,S,P){l.info(function(){if(l.g)if(P){var K="",oe=P.split("&");for(let ye=0;ye<oe.length;ye++){var ze=oe[ye].split("=");if(ze.length>1){const Xe=ze[0];ze=ze[1];const en=Xe.split("_");K=en.length>=2&&en[1]=="type"?K+(Xe+"="+ze+"&"):K+(Xe+"=redacted&")}}}else K=null;else K=P;return"XMLHTTP REQ ("+p+") [attempt "+S+"]: "+h+`
`+d+`
`+K})}function cE(l,h,d,p,S,P,K){l.info(function(){return"XMLHTTP RESP ("+p+") [ attempt "+S+"]: "+h+`
`+d+`
`+P+" "+K})}function Xs(l,h,d,p){l.info(function(){return"XMLHTTP TEXT ("+h+"): "+hE(l,d)+(p?" "+p:"")})}function uE(l,h){l.info(function(){return"TIMEOUT: "+h})}Wr.prototype.info=function(){};function hE(l,h){if(!l.g)return h;if(!h)return null;try{const P=JSON.parse(h);if(P){for(l=0;l<P.length;l++)if(Array.isArray(P[l])){var d=P[l];if(!(d.length<2)){var p=d[1];if(Array.isArray(p)&&!(p.length<1)){var S=p[0];if(S!="noop"&&S!="stop"&&S!="close")for(let K=1;K<p.length;K++)p[K]=""}}}}return Ml(P)}catch{return h}}var Oo={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},vh={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Rh;function Hl(){}f(Hl,Dh),Hl.prototype.g=function(){return new XMLHttpRequest},Rh=new Hl;function $r(l){return encodeURIComponent(String(l))}function fE(l){var h=1;l=l.split(":");const d=[];for(;h>0&&l.length;)d.push(l.shift()),h--;return l.length&&d.push(l.join(":")),d}function Nn(l,h,d,p){this.j=l,this.i=h,this.l=d,this.S=p||1,this.V=new jr(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Sh}function Sh(){this.i=null,this.g="",this.h=!1}var bh={},Ul={};function ql(l,h,d){l.M=1,l.A=xo(Zt(h)),l.u=d,l.R=!0,Nh(l,null)}function Nh(l,h){l.F=Date.now(),Lo(l),l.B=Zt(l.A);var d=l.B,p=l.S;Array.isArray(p)||(p=[String(p)]),Jh(d.i,"t",p),l.C=0,d=l.j.L,l.h=new Sh,l.g=Bf(l.j,d?h:null,!l.u),l.P>0&&(l.O=new oE(c(l.Y,l,l.g),l.P)),h=l.V,d=l.g,p=l.ba;var S="readystatechange";Array.isArray(S)||(S&&(_h[0]=S.toString()),S=_h);for(let P=0;P<S.length;P++){const K=dh(d,S[P],p||h.handleEvent,!1,h.h||h);if(!K)break;h.g[K.key]=K}h=l.J?uh(l.J):{},l.u?(l.v||(l.v="POST"),h["Content-Type"]="application/x-www-form-urlencoded",l.g.ea(l.B,l.v,l.u,h)):(l.v="GET",l.g.ea(l.B,l.v,null,h)),Qr(),BE(l.i,l.v,l.B,l.l,l.S,l.u)}Nn.prototype.ba=function(l){l=l.target;const h=this.O;h&&On(l)==3?h.j():this.Y(l)},Nn.prototype.Y=function(l){try{if(l==this.g)e:{const oe=On(this.g),ze=this.g.ya(),ye=this.g.ca();if(!(oe<3)&&(oe!=3||this.g&&(this.h.h||this.g.la()||Yh(this.g)))){this.K||oe!=4||ze==7||(ze==8||ye<=0?Qr(3):Qr(2)),Jl(this);var h=this.g.ca();this.X=h;var d=dE(this);if(this.o=h==200,cE(this.i,this.v,this.B,this.l,this.S,oe,h),this.o){if(this.U&&!this.L){t:{if(this.g){var p,S=this.g;if((p=S.g?S.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!y(p)){var P=p;break t}}P=null}if(l=P)Xs(this.i,this.l,l,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,jl(this,l);else{this.o=!1,this.m=3,Ct(12),Es(this),Yr(this);break e}}if(this.R){l=!0;let Xe;for(;!this.K&&this.C<d.length;)if(Xe=CE(this,d),Xe==Ul){oe==4&&(this.m=4,Ct(14),l=!1),Xs(this.i,this.l,null,"[Incomplete Response]");break}else if(Xe==bh){this.m=4,Ct(15),Xs(this.i,this.l,d,"[Invalid Chunk]"),l=!1;break}else Xs(this.i,this.l,Xe,null),jl(this,Xe);if(Ph(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),oe!=4||d.length!=0||this.h.h||(this.m=1,Ct(16),l=!1),this.o=this.o&&l,!l)Xs(this.i,this.l,d,"[Invalid Chunked Response]"),Es(this),Yr(this);else if(d.length>0&&!this.W){this.W=!0;var K=this.j;K.g==this&&K.aa&&!K.P&&(K.j.info("Great, no buffering proxy detected. Bytes received: "+d.length),Zl(K),K.P=!0,Ct(11))}}else Xs(this.i,this.l,d,null),jl(this,d);oe==4&&Es(this),this.o&&!this.K&&(oe==4?rf(this.j,this):(this.o=!1,Lo(this)))}else SE(this.g),h==400&&d.indexOf("Unknown SID")>0?(this.m=3,Ct(12)):(this.m=0,Ct(13)),Es(this),Yr(this)}}}catch{}finally{}};function dE(l){if(!Ph(l))return l.g.la();const h=Yh(l.g);if(h==="")return"";let d="";const p=h.length,S=On(l.g)==4;if(!l.h.i){if(typeof TextDecoder>"u")return Es(l),Yr(l),"";l.h.i=new o.TextDecoder}for(let P=0;P<p;P++)l.h.h=!0,d+=l.h.i.decode(h[P],{stream:!(S&&P==p-1)});return h.length=0,l.h.g+=d,l.C=0,l.h.g}function Ph(l){return l.g?l.v=="GET"&&l.M!=2&&l.j.Aa:!1}function CE(l,h){var d=l.C,p=h.indexOf(`
`,d);return p==-1?Ul:(d=Number(h.substring(d,p)),isNaN(d)?bh:(p+=1,p+d>h.length?Ul:(h=h.slice(p,p+d),l.C=p+d,h)))}Nn.prototype.cancel=function(){this.K=!0,Es(this)};function Lo(l){l.T=Date.now()+l.H,Fh(l,l.H)}function Fh(l,h){if(l.D!=null)throw Error("WatchDog timer not null");l.D=zr(c(l.aa,l),h)}function Jl(l){l.D&&(o.clearTimeout(l.D),l.D=null)}Nn.prototype.aa=function(){this.D=null;const l=Date.now();l-this.T>=0?(uE(this.i,this.B),this.M!=2&&(Qr(),Ct(17)),Es(this),this.m=2,Yr(this)):Fh(this,this.T-l)};function Yr(l){l.j.I==0||l.K||rf(l.j,l)}function Es(l){Jl(l);var h=l.O;h&&typeof h.dispose=="function"&&h.dispose(),l.O=null,Eh(l.V),l.g&&(h=l.g,l.g=null,h.abort(),h.dispose())}function jl(l,h){try{var d=l.j;if(d.I!=0&&(d.g==l||Kl(d.h,l))){if(!l.L&&Kl(d.h,l)&&d.I==3){try{var p=d.Ba.g.parse(h)}catch{p=null}if(Array.isArray(p)&&p.length==3){var S=p;if(S[0]==0){e:if(!d.v){if(d.g)if(d.g.F+3e3<l.F)Ho(d),Vo(d);else break e;Xl(d),Ct(18)}}else d.xa=S[1],0<d.xa-d.K&&S[2]<37500&&d.F&&d.A==0&&!d.C&&(d.C=zr(c(d.Va,d),6e3));xh(d.h)<=1&&d.ta&&(d.ta=void 0)}else ys(d,11)}else if((l.L||d.g==l)&&Ho(d),!y(h))for(S=d.Ba.g.parse(h),h=0;h<S.length;h++){let ye=S[h];const Xe=ye[0];if(!(Xe<=d.K))if(d.K=Xe,ye=ye[1],d.I==2)if(ye[0]=="c"){d.M=ye[1],d.ba=ye[2];const en=ye[3];en!=null&&(d.ka=en,d.j.info("VER="+d.ka));const ws=ye[4];ws!=null&&(d.za=ws,d.j.info("SVER="+d.za));const Ln=ye[5];Ln!=null&&typeof Ln=="number"&&Ln>0&&(p=1.5*Ln,d.O=p,d.j.info("backChannelRequestTimeoutMs_="+p)),p=d;const xn=l.g;if(xn){const qo=xn.g?xn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(qo){var P=p.h;P.g||qo.indexOf("spdy")==-1&&qo.indexOf("quic")==-1&&qo.indexOf("h2")==-1||(P.j=P.l,P.g=new Set,P.h&&(Ql(P,P.h),P.h=null))}if(p.G){const eB=xn.g?xn.g.getResponseHeader("X-HTTP-Session-Id"):null;eB&&(p.wa=eB,Se(p.J,p.G,eB))}}d.I=3,d.l&&d.l.ra(),d.aa&&(d.T=Date.now()-l.F,d.j.info("Handshake RTT: "+d.T+"ms")),p=d;var K=l;if(p.na=lf(p,p.L?p.ba:null,p.W),K.L){kh(p.h,K);var oe=K,ze=p.O;ze&&(oe.H=ze),oe.D&&(Jl(oe),Lo(oe)),p.g=K}else nf(p);d.i.length>0&&Go(d)}else ye[0]!="stop"&&ye[0]!="close"||ys(d,7);else d.I==3&&(ye[0]=="stop"||ye[0]=="close"?ye[0]=="stop"?ys(d,7):Yl(d):ye[0]!="noop"&&d.l&&d.l.qa(ye),d.A=0)}}Qr(4)}catch{}}var pE=class{constructor(l,h){this.g=l,this.map=h}};function Oh(l){this.l=l||10,o.PerformanceNavigationTiming?(l=o.performance.getEntriesByType("navigation"),l=l.length>0&&(l[0].nextHopProtocol=="hq"||l[0].nextHopProtocol=="h2")):l=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=l?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Lh(l){return l.h?!0:l.g?l.g.size>=l.j:!1}function xh(l){return l.h?1:l.g?l.g.size:0}function Kl(l,h){return l.h?l.h==h:l.g?l.g.has(h):!1}function Ql(l,h){l.g?l.g.add(h):l.h=h}function kh(l,h){l.h&&l.h==h?l.h=null:l.g&&l.g.has(h)&&l.g.delete(h)}Oh.prototype.cancel=function(){if(this.i=Mh(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const l of this.g.values())l.cancel();this.g.clear()}};function Mh(l){if(l.h!=null)return l.i.concat(l.h.G);if(l.g!=null&&l.g.size!==0){let h=l.i;for(const d of l.g.values())h=h.concat(d.G);return h}return g(l.i)}var Vh=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function gE(l,h){if(l){l=l.split("&");for(let d=0;d<l.length;d++){const p=l[d].indexOf("=");let S,P=null;p>=0?(S=l[d].substring(0,p),P=l[d].substring(p+1)):S=l[d],h(S,P?decodeURIComponent(P.replace(/\+/g," ")):"")}}}function Pn(l){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let h;l instanceof Pn?(this.l=l.l,Xr(this,l.j),this.o=l.o,this.g=l.g,Zr(this,l.u),this.h=l.h,zl(this,jh(l.i)),this.m=l.m):l&&(h=String(l).match(Vh))?(this.l=!1,Xr(this,h[1]||"",!0),this.o=ei(h[2]||""),this.g=ei(h[3]||"",!0),Zr(this,h[4]),this.h=ei(h[5]||"",!0),zl(this,h[6]||"",!0),this.m=ei(h[7]||"")):(this.l=!1,this.i=new ni(null,this.l))}Pn.prototype.toString=function(){const l=[];var h=this.j;h&&l.push(ti(h,Gh,!0),":");var d=this.g;return(d||h=="file")&&(l.push("//"),(h=this.o)&&l.push(ti(h,Gh,!0),"@"),l.push($r(d).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),d=this.u,d!=null&&l.push(":",String(d))),(d=this.h)&&(this.g&&d.charAt(0)!="/"&&l.push("/"),l.push(ti(d,d.charAt(0)=="/"?EE:_E,!0))),(d=this.i.toString())&&l.push("?",d),(d=this.m)&&l.push("#",ti(d,yE)),l.join("")},Pn.prototype.resolve=function(l){const h=Zt(this);let d=!!l.j;d?Xr(h,l.j):d=!!l.o,d?h.o=l.o:d=!!l.g,d?h.g=l.g:d=l.u!=null;var p=l.h;if(d)Zr(h,l.u);else if(d=!!l.h){if(p.charAt(0)!="/")if(this.g&&!this.h)p="/"+p;else{var S=h.h.lastIndexOf("/");S!=-1&&(p=h.h.slice(0,S+1)+p)}if(S=p,S==".."||S==".")p="";else if(S.indexOf("./")!=-1||S.indexOf("/.")!=-1){p=S.lastIndexOf("/",0)==0,S=S.split("/");const P=[];for(let K=0;K<S.length;){const oe=S[K++];oe=="."?p&&K==S.length&&P.push(""):oe==".."?((P.length>1||P.length==1&&P[0]!="")&&P.pop(),p&&K==S.length&&P.push("")):(P.push(oe),p=!0)}p=P.join("/")}else p=S}return d?h.h=p:d=l.i.toString()!=="",d?zl(h,jh(l.i)):d=!!l.m,d&&(h.m=l.m),h};function Zt(l){return new Pn(l)}function Xr(l,h,d){l.j=d?ei(h,!0):h,l.j&&(l.j=l.j.replace(/:$/,""))}function Zr(l,h){if(h){if(h=Number(h),isNaN(h)||h<0)throw Error("Bad port number "+h);l.u=h}else l.u=null}function zl(l,h,d){h instanceof ni?(l.i=h,wE(l.i,l.l)):(d||(h=ti(h,DE)),l.i=new ni(h,l.l))}function Se(l,h,d){l.i.set(h,d)}function xo(l){return Se(l,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),l}function ei(l,h){return l?h?decodeURI(l.replace(/%25/g,"%2525")):decodeURIComponent(l):""}function ti(l,h,d){return typeof l=="string"?(l=encodeURI(l).replace(h,mE),d&&(l=l.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),l):null}function mE(l){return l=l.charCodeAt(0),"%"+(l>>4&15).toString(16)+(l&15).toString(16)}var Gh=/[#\/\?@]/g,_E=/[#\?:]/g,EE=/[#\?]/g,DE=/[#\?@]/g,yE=/#/g;function ni(l,h){this.h=this.g=null,this.i=l||null,this.j=!!h}function Ds(l){l.g||(l.g=new Map,l.h=0,l.i&&gE(l.i,function(h,d){l.add(decodeURIComponent(h.replace(/\+/g," ")),d)}))}n=ni.prototype,n.add=function(l,h){Ds(this),this.i=null,l=Zs(this,l);let d=this.g.get(l);return d||this.g.set(l,d=[]),d.push(h),this.h+=1,this};function Hh(l,h){Ds(l),h=Zs(l,h),l.g.has(h)&&(l.i=null,l.h-=l.g.get(h).length,l.g.delete(h))}function Uh(l,h){return Ds(l),h=Zs(l,h),l.g.has(h)}n.forEach=function(l,h){Ds(this),this.g.forEach(function(d,p){d.forEach(function(S){l.call(h,S,p,this)},this)},this)};function qh(l,h){Ds(l);let d=[];if(typeof h=="string")Uh(l,h)&&(d=d.concat(l.g.get(Zs(l,h))));else for(l=Array.from(l.g.values()),h=0;h<l.length;h++)d=d.concat(l[h]);return d}n.set=function(l,h){return Ds(this),this.i=null,l=Zs(this,l),Uh(this,l)&&(this.h-=this.g.get(l).length),this.g.set(l,[h]),this.h+=1,this},n.get=function(l,h){return l?(l=qh(this,l),l.length>0?String(l[0]):h):h};function Jh(l,h,d){Hh(l,h),d.length>0&&(l.i=null,l.g.set(Zs(l,h),g(d)),l.h+=d.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const l=[],h=Array.from(this.g.keys());for(let p=0;p<h.length;p++){var d=h[p];const S=$r(d);d=qh(this,d);for(let P=0;P<d.length;P++){let K=S;d[P]!==""&&(K+="="+$r(d[P])),l.push(K)}}return this.i=l.join("&")};function jh(l){const h=new ni;return h.i=l.i,l.g&&(h.g=new Map(l.g),h.h=l.h),h}function Zs(l,h){return h=String(h),l.j&&(h=h.toLowerCase()),h}function wE(l,h){h&&!l.j&&(Ds(l),l.i=null,l.g.forEach(function(d,p){const S=p.toLowerCase();p!=S&&(Hh(this,p),Jh(this,S,d))},l)),l.j=h}function TE(l,h){const d=new Wr;if(o.Image){const p=new Image;p.onload=u(Fn,d,"TestLoadImage: loaded",!0,h,p),p.onerror=u(Fn,d,"TestLoadImage: error",!1,h,p),p.onabort=u(Fn,d,"TestLoadImage: abort",!1,h,p),p.ontimeout=u(Fn,d,"TestLoadImage: timeout",!1,h,p),o.setTimeout(function(){p.ontimeout&&p.ontimeout()},1e4),p.src=l}else h(!1)}function IE(l,h){const d=new Wr,p=new AbortController,S=setTimeout(()=>{p.abort(),Fn(d,"TestPingServer: timeout",!1,h)},1e4);fetch(l,{signal:p.signal}).then(P=>{clearTimeout(S),P.ok?Fn(d,"TestPingServer: ok",!0,h):Fn(d,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(S),Fn(d,"TestPingServer: error",!1,h)})}function Fn(l,h,d,p,S){try{S&&(S.onload=null,S.onerror=null,S.onabort=null,S.ontimeout=null),p(d)}catch{}}function AE(){this.g=new lE}function Wl(l){this.i=l.Sb||null,this.h=l.ab||!1}f(Wl,Dh),Wl.prototype.g=function(){return new ko(this.i,this.h)};function ko(l,h){Bt.call(this),this.H=l,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}f(ko,Bt),n=ko.prototype,n.open=function(l,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=l,this.D=h,this.readyState=1,ri(this)},n.send=function(l){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const h={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};l&&(h.body=l),(this.H||o).fetch(new Request(this.D,h)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,si(this)),this.readyState=0},n.Pa=function(l){if(this.g&&(this.l=l,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=l.headers,this.readyState=2,ri(this)),this.g&&(this.readyState=3,ri(this),this.g)))if(this.responseType==="arraybuffer")l.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in l){if(this.j=l.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Kh(this)}else l.text().then(this.Oa.bind(this),this.ga.bind(this))};function Kh(l){l.j.read().then(l.Ma.bind(l)).catch(l.ga.bind(l))}n.Ma=function(l){if(this.g){if(this.o&&l.value)this.response.push(l.value);else if(!this.o){var h=l.value?l.value:new Uint8Array(0);(h=this.B.decode(h,{stream:!l.done}))&&(this.response=this.responseText+=h)}l.done?si(this):ri(this),this.readyState==3&&Kh(this)}},n.Oa=function(l){this.g&&(this.response=this.responseText=l,si(this))},n.Na=function(l){this.g&&(this.response=l,si(this))},n.ga=function(){this.g&&si(this)};function si(l){l.readyState=4,l.l=null,l.j=null,l.B=null,ri(l)}n.setRequestHeader=function(l,h){this.A.append(l,h)},n.getResponseHeader=function(l){return this.h&&this.h.get(l.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const l=[],h=this.h.entries();for(var d=h.next();!d.done;)d=d.value,l.push(d[0]+": "+d[1]),d=h.next();return l.join(`\r
`)};function ri(l){l.onreadystatechange&&l.onreadystatechange.call(l)}Object.defineProperty(ko.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(l){this.m=l?"include":"same-origin"}});function Qh(l){let h="";return bo(l,function(d,p){h+=p,h+=":",h+=d,h+=`\r
`}),h}function $l(l,h,d){e:{for(p in d){var p=!1;break e}p=!0}p||(d=Qh(d),typeof l=="string"?d!=null&&$r(d):Se(l,h,d))}function xe(l){Bt.call(this),this.headers=new Map,this.L=l||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}f(xe,Bt);var vE=/^https?$/i,RE=["POST","PUT"];n=xe.prototype,n.Fa=function(l){this.H=l},n.ea=function(l,h,d,p){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+l);h=h?h.toUpperCase():"GET",this.D=l,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Rh.g(),this.g.onreadystatechange=C(c(this.Ca,this));try{this.B=!0,this.g.open(h,String(l),!0),this.B=!1}catch(P){zh(this,P);return}if(l=d||"",d=new Map(this.headers),p)if(Object.getPrototypeOf(p)===Object.prototype)for(var S in p)d.set(S,p[S]);else if(typeof p.keys=="function"&&typeof p.get=="function")for(const P of p.keys())d.set(P,p.get(P));else throw Error("Unknown input type for opt_headers: "+String(p));p=Array.from(d.keys()).find(P=>P.toLowerCase()=="content-type"),S=o.FormData&&l instanceof o.FormData,!(Array.prototype.indexOf.call(RE,h,void 0)>=0)||p||S||d.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[P,K]of d)this.g.setRequestHeader(P,K);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(l),this.v=!1}catch(P){zh(this,P)}};function zh(l,h){l.h=!1,l.g&&(l.j=!0,l.g.abort(),l.j=!1),l.l=h,l.o=5,Wh(l),Mo(l)}function Wh(l){l.A||(l.A=!0,dt(l,"complete"),dt(l,"error"))}n.abort=function(l){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=l||7,dt(this,"complete"),dt(this,"abort"),Mo(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Mo(this,!0)),xe.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?$h(this):this.Xa())},n.Xa=function(){$h(this)};function $h(l){if(l.h&&typeof i<"u"){if(l.v&&On(l)==4)setTimeout(l.Ca.bind(l),0);else if(dt(l,"readystatechange"),On(l)==4){l.h=!1;try{const P=l.ca();e:switch(P){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var d;if(!(d=h)){var p;if(p=P===0){let K=String(l.D).match(Vh)[1]||null;!K&&o.self&&o.self.location&&(K=o.self.location.protocol.slice(0,-1)),p=!vE.test(K?K.toLowerCase():"")}d=p}if(d)dt(l,"complete"),dt(l,"success");else{l.o=6;try{var S=On(l)>2?l.g.statusText:""}catch{S=""}l.l=S+" ["+l.ca()+"]",Wh(l)}}finally{Mo(l)}}}}function Mo(l,h){if(l.g){l.m&&(clearTimeout(l.m),l.m=null);const d=l.g;l.g=null,h||dt(l,"ready");try{d.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function On(l){return l.g?l.g.readyState:0}n.ca=function(){try{return On(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(l){if(this.g){var h=this.g.responseText;return l&&h.indexOf(l)==0&&(h=h.substring(l.length)),aE(h)}};function Yh(l){try{if(!l.g)return null;if("response"in l.g)return l.g.response;switch(l.F){case"":case"text":return l.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in l.g)return l.g.mozResponseArrayBuffer}return null}catch{return null}}function SE(l){const h={};l=(l.g&&On(l)>=2&&l.g.getAllResponseHeaders()||"").split(`\r
`);for(let p=0;p<l.length;p++){if(y(l[p]))continue;var d=fE(l[p]);const S=d[0];if(d=d[1],typeof d!="string")continue;d=d.trim();const P=h[S]||[];h[S]=P,P.push(d)}tE(h,function(p){return p.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function ii(l,h,d){return d&&d.internalChannelParams&&d.internalChannelParams[l]||h}function Xh(l){this.za=0,this.i=[],this.j=new Wr,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=ii("failFast",!1,l),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=ii("baseRetryDelayMs",5e3,l),this.Za=ii("retryDelaySeedMs",1e4,l),this.Ta=ii("forwardChannelMaxRetries",2,l),this.va=ii("forwardChannelRequestTimeoutMs",2e4,l),this.ma=l&&l.xmlHttpFactory||void 0,this.Ua=l&&l.Rb||void 0,this.Aa=l&&l.useFetchStreams||!1,this.O=void 0,this.L=l&&l.supportsCrossDomainXhr||!1,this.M="",this.h=new Oh(l&&l.concurrentRequestLimit),this.Ba=new AE,this.S=l&&l.fastHandshake||!1,this.R=l&&l.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=l&&l.Pb||!1,l&&l.ua&&this.j.ua(),l&&l.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&l&&l.detectBufferingProxy||!1,this.ia=void 0,l&&l.longPollingTimeout&&l.longPollingTimeout>0&&(this.ia=l.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=Xh.prototype,n.ka=8,n.I=1,n.connect=function(l,h,d,p){Ct(0),this.W=l,this.H=h||{},d&&p!==void 0&&(this.H.OSID=d,this.H.OAID=p),this.F=this.X,this.J=lf(this,null,this.W),Go(this)};function Yl(l){if(Zh(l),l.I==3){var h=l.V++,d=Zt(l.J);if(Se(d,"SID",l.M),Se(d,"RID",h),Se(d,"TYPE","terminate"),oi(l,d),h=new Nn(l,l.j,h),h.M=2,h.A=xo(Zt(d)),d=!1,o.navigator&&o.navigator.sendBeacon)try{d=o.navigator.sendBeacon(h.A.toString(),"")}catch{}!d&&o.Image&&(new Image().src=h.A,d=!0),d||(h.g=Bf(h.j,null),h.g.ea(h.A)),h.F=Date.now(),Lo(h)}af(l)}function Vo(l){l.g&&(Zl(l),l.g.cancel(),l.g=null)}function Zh(l){Vo(l),l.v&&(o.clearTimeout(l.v),l.v=null),Ho(l),l.h.cancel(),l.m&&(typeof l.m=="number"&&o.clearTimeout(l.m),l.m=null)}function Go(l){if(!Lh(l.h)&&!l.m){l.m=!0;var h=l.Ea;Me||D(),Le||(Me(),Le=!0),v.add(h,l),l.D=0}}function bE(l,h){return xh(l.h)>=l.h.j-(l.m?1:0)?!1:l.m?(l.i=h.G.concat(l.i),!0):l.I==1||l.I==2||l.D>=(l.Sa?0:l.Ta)?!1:(l.m=zr(c(l.Ea,l,h),of(l,l.D)),l.D++,!0)}n.Ea=function(l){if(this.m)if(this.m=null,this.I==1){if(!l){this.V=Math.floor(Math.random()*1e5),l=this.V++;const S=new Nn(this,this.j,l);let P=this.o;if(this.U&&(P?(P=uh(P),fh(P,this.U)):P=this.U),this.u!==null||this.R||(S.J=P,P=null),this.S)e:{for(var h=0,d=0;d<this.i.length;d++){t:{var p=this.i[d];if("__data__"in p.map&&(p=p.map.__data__,typeof p=="string")){p=p.length;break t}p=void 0}if(p===void 0)break;if(h+=p,h>4096){h=d;break e}if(h===4096||d===this.i.length-1){h=d+1;break e}}h=1e3}else h=1e3;h=tf(this,S,h),d=Zt(this.J),Se(d,"RID",l),Se(d,"CVER",22),this.G&&Se(d,"X-HTTP-Session-Id",this.G),oi(this,d),P&&(this.R?h="headers="+$r(Qh(P))+"&"+h:this.u&&$l(d,this.u,P)),Ql(this.h,S),this.Ra&&Se(d,"TYPE","init"),this.S?(Se(d,"$req",h),Se(d,"SID","null"),S.U=!0,ql(S,d,null)):ql(S,d,h),this.I=2}}else this.I==3&&(l?ef(this,l):this.i.length==0||Lh(this.h)||ef(this))};function ef(l,h){var d;h?d=h.l:d=l.V++;const p=Zt(l.J);Se(p,"SID",l.M),Se(p,"RID",d),Se(p,"AID",l.K),oi(l,p),l.u&&l.o&&$l(p,l.u,l.o),d=new Nn(l,l.j,d,l.D+1),l.u===null&&(d.J=l.o),h&&(l.i=h.G.concat(l.i)),h=tf(l,d,1e3),d.H=Math.round(l.va*.5)+Math.round(l.va*.5*Math.random()),Ql(l.h,d),ql(d,p,h)}function oi(l,h){l.H&&bo(l.H,function(d,p){Se(h,p,d)}),l.l&&bo({},function(d,p){Se(h,p,d)})}function tf(l,h,d){d=Math.min(l.i.length,d);const p=l.l?c(l.l.Ka,l.l,l):null;e:{var S=l.i;let oe=-1;for(;;){const ze=["count="+d];oe==-1?d>0?(oe=S[0].g,ze.push("ofs="+oe)):oe=0:ze.push("ofs="+oe);let ye=!0;for(let Xe=0;Xe<d;Xe++){var P=S[Xe].g;const en=S[Xe].map;if(P-=oe,P<0)oe=Math.max(0,S[Xe].g-100),ye=!1;else try{P="req"+P+"_"||"";try{var K=en instanceof Map?en:Object.entries(en);for(const[ws,Ln]of K){let xn=Ln;a(Ln)&&(xn=Ml(Ln)),ze.push(P+ws+"="+encodeURIComponent(xn))}}catch(ws){throw ze.push(P+"type="+encodeURIComponent("_badmap")),ws}}catch{p&&p(en)}}if(ye){K=ze.join("&");break e}}K=void 0}return l=l.i.splice(0,d),h.G=l,K}function nf(l){if(!l.g&&!l.v){l.Y=1;var h=l.Da;Me||D(),Le||(Me(),Le=!0),v.add(h,l),l.A=0}}function Xl(l){return l.g||l.v||l.A>=3?!1:(l.Y++,l.v=zr(c(l.Da,l),of(l,l.A)),l.A++,!0)}n.Da=function(){if(this.v=null,sf(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var l=4*this.T;this.j.info("BP detection timer enabled: "+l),this.B=zr(c(this.Wa,this),l)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Ct(10),Vo(this),sf(this))};function Zl(l){l.B!=null&&(o.clearTimeout(l.B),l.B=null)}function sf(l){l.g=new Nn(l,l.j,"rpc",l.Y),l.u===null&&(l.g.J=l.o),l.g.P=0;var h=Zt(l.na);Se(h,"RID","rpc"),Se(h,"SID",l.M),Se(h,"AID",l.K),Se(h,"CI",l.F?"0":"1"),!l.F&&l.ia&&Se(h,"TO",l.ia),Se(h,"TYPE","xmlhttp"),oi(l,h),l.u&&l.o&&$l(h,l.u,l.o),l.O&&(l.g.H=l.O);var d=l.g;l=l.ba,d.M=1,d.A=xo(Zt(h)),d.u=null,d.R=!0,Nh(d,l)}n.Va=function(){this.C!=null&&(this.C=null,Vo(this),Xl(this),Ct(19))};function Ho(l){l.C!=null&&(o.clearTimeout(l.C),l.C=null)}function rf(l,h){var d=null;if(l.g==h){Ho(l),Zl(l),l.g=null;var p=2}else if(Kl(l.h,h))d=h.G,kh(l.h,h),p=1;else return;if(l.I!=0){if(h.o)if(p==1){d=h.u?h.u.length:0,h=Date.now()-h.F;var S=l.D;p=Fo(),dt(p,new Ah(p,d)),Go(l)}else nf(l);else if(S=h.m,S==3||S==0&&h.X>0||!(p==1&&bE(l,h)||p==2&&Xl(l)))switch(d&&d.length>0&&(h=l.h,h.i=h.i.concat(d)),S){case 1:ys(l,5);break;case 4:ys(l,10);break;case 3:ys(l,6);break;default:ys(l,2)}}}function of(l,h){let d=l.Qa+Math.floor(Math.random()*l.Za);return l.isActive()||(d*=2),d*h}function ys(l,h){if(l.j.info("Error code "+h),h==2){var d=c(l.bb,l),p=l.Ua;const S=!p;p=new Pn(p||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||Xr(p,"https"),xo(p),S?TE(p.toString(),d):IE(p.toString(),d)}else Ct(2);l.I=0,l.l&&l.l.pa(h),af(l),Zh(l)}n.bb=function(l){l?(this.j.info("Successfully pinged google.com"),Ct(2)):(this.j.info("Failed to ping google.com"),Ct(1))};function af(l){if(l.I=0,l.ja=[],l.l){const h=Mh(l.h);(h.length!=0||l.i.length!=0)&&(E(l.ja,h),E(l.ja,l.i),l.h.i.length=0,g(l.i),l.i.length=0),l.l.oa()}}function lf(l,h,d){var p=d instanceof Pn?Zt(d):new Pn(d);if(p.g!="")h&&(p.g=h+"."+p.g),Zr(p,p.u);else{var S=o.location;p=S.protocol,h=h?h+"."+S.hostname:S.hostname,S=+S.port;const P=new Pn(null);p&&Xr(P,p),h&&(P.g=h),S&&Zr(P,S),d&&(P.h=d),p=P}return d=l.G,h=l.wa,d&&h&&Se(p,d,h),Se(p,"VER",l.ka),oi(l,p),p}function Bf(l,h,d){if(h&&!l.L)throw Error("Can't create secondary domain capable XhrIo object.");return h=l.Aa&&!l.ma?new xe(new Wl({ab:d})):new xe(l.ma),h.Fa(l.L),h}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function cf(){}n=cf.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function Uo(){}Uo.prototype.g=function(l,h){return new bt(l,h)};function bt(l,h){Bt.call(this),this.g=new Xh(h),this.l=l,this.h=h&&h.messageUrlParams||null,l=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(l?l["X-Client-Protocol"]="webchannel":l={"X-Client-Protocol":"webchannel"}),this.g.o=l,l=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(l?l["X-WebChannel-Content-Type"]=h.messageContentType:l={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.sa&&(l?l["X-WebChannel-Client-Profile"]=h.sa:l={"X-WebChannel-Client-Profile":h.sa}),this.g.U=l,(l=h&&h.Qb)&&!y(l)&&(this.g.u=l),this.A=h&&h.supportsCrossDomainXhr||!1,this.v=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!y(h)&&(this.g.G=h,l=this.h,l!==null&&h in l&&(l=this.h,h in l&&delete l[h])),this.j=new er(this)}f(bt,Bt),bt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},bt.prototype.close=function(){Yl(this.g)},bt.prototype.o=function(l){var h=this.g;if(typeof l=="string"){var d={};d.__data__=l,l=d}else this.v&&(d={},d.__data__=Ml(l),l=d);h.i.push(new pE(h.Ya++,l)),h.I==3&&Go(h)},bt.prototype.N=function(){this.g.l=null,delete this.j,Yl(this.g),delete this.g,bt.Z.N.call(this)};function uf(l){Vl.call(this),l.__headers__&&(this.headers=l.__headers__,this.statusCode=l.__status__,delete l.__headers__,delete l.__status__);var h=l.__sm__;if(h){e:{for(const d in h){l=d;break e}l=void 0}(this.i=l)&&(l=this.i,h=h!==null&&l in h?h[l]:void 0),this.data=h}else this.data=l}f(uf,Vl);function hf(){Gl.call(this),this.status=1}f(hf,Gl);function er(l){this.g=l}f(er,cf),er.prototype.ra=function(){dt(this.g,"a")},er.prototype.qa=function(l){dt(this.g,new uf(l))},er.prototype.pa=function(l){dt(this.g,new hf)},er.prototype.oa=function(){dt(this.g,"b")},Uo.prototype.createWebChannel=Uo.prototype.g,bt.prototype.send=bt.prototype.o,bt.prototype.open=bt.prototype.m,bt.prototype.close=bt.prototype.close,bp=function(){return new Uo},Sp=function(){return Fo()},Rp=_s,OB={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Oo.NO_ERROR=0,Oo.TIMEOUT=8,Oo.HTTP_ERROR=6,ra=Oo,vh.COMPLETE="complete",vp=vh,yh.EventType=Kr,Kr.OPEN="a",Kr.CLOSE="b",Kr.ERROR="c",Kr.MESSAGE="d",Bt.prototype.listen=Bt.prototype.J,fi=yh,xe.prototype.listenOnce=xe.prototype.K,xe.prototype.getLastError=xe.prototype.Ha,xe.prototype.getLastErrorCode=xe.prototype.ya,xe.prototype.getStatus=xe.prototype.ca,xe.prototype.getResponseJson=xe.prototype.La,xe.prototype.getResponseText=xe.prototype.la,xe.prototype.send=xe.prototype.ea,xe.prototype.setWithCredentials=xe.prototype.Fa,Ap=xe}).apply(typeof Jo<"u"?Jo:typeof self<"u"?self:typeof window<"u"?window:{});/*!
* re2js
* RE2JS is the JavaScript port of RE2, a regular expression engine that provides linear time matching
*
* @version v2.8.6
* @author Oleksii Vasyliev
* @homepage https://github.com/le0pard/re2js#readme
* @repository github:le0pard/re2js
* @license MIT
*/var we,V=(we=class{},U(we,"FOLD_CASE",1),U(we,"LITERAL",2),U(we,"CLASS_NL",4),U(we,"DOT_NL",8),U(we,"ONE_LINE",16),U(we,"NON_GREEDY",32),U(we,"PERL_X",64),U(we,"UNICODE_GROUPS",128),U(we,"WAS_DOLLAR",256),U(we,"LOOKBEHIND",512),U(we,"MATCH_NL",we.CLASS_NL|we.DOT_NL),U(we,"PERL",we.CLASS_NL|we.ONE_LINE|we.PERL_X|we.UNICODE_GROUPS),U(we,"POSIX",0),U(we,"UNANCHORED",0),U(we,"ANCHOR_START",1),U(we,"ANCHOR_BOTH",2),we);const tr={CASE_INSENSITIVE:1,DOTALL:2,MULTILINE:4,DISABLE_UNICODE_GROUPS:8,LONGEST_MATCH:16,LOOKBEHINDS:512},Fi=128,LB=new Int32Array(Fi),xB=new Int32Array(Fi),jo=65535;for(let n=0;n<Fi;n++)n>=97&&n<=122?LB[n]=n-32:LB[n]=n,n>=65&&n<=90?xB[n]=n+32:xB[n]=n;var AB,L=(AB=class{static toUpperCase(n){if(n<Fi)return LB[n];const e=String.fromCodePoint(n).toUpperCase(),t=e.codePointAt(0)>jo?2:1;if(e.length>t)return n;const s=String.fromCodePoint(e.codePointAt(0)).toLowerCase(),r=s.codePointAt(0)>jo?2:1;return s.length>r||s.codePointAt(0)!==n?n:e.codePointAt(0)}static toLowerCase(n){if(n<Fi)return xB[n];const e=String.fromCodePoint(n).toLowerCase(),t=e.codePointAt(0)>jo?2:1;if(e.length>t)return n;const s=String.fromCodePoint(e.codePointAt(0)).toUpperCase(),r=s.codePointAt(0)>jo?2:1;return s.length>r||s.codePointAt(0)!==n?n:e.codePointAt(0)}},U(AB,"CODES",new Map([["\x07",7],["\b",8],["	",9],[`
`,10],["\v",11],["\f",12],["\r",13],[" ",32],['"',34],["$",36],["&",38],["'",39],["(",40],[")",41],["*",42],["+",43],["-",45],[".",46],["0",48],["1",49],["2",50],["3",51],["4",52],["5",53],["6",54],["7",55],["8",56],["9",57],[":",58],["<",60],[">",62],["?",63],["A",65],["B",66],["C",67],["F",70],["P",80],["Q",81],["U",85],["Z",90],["[",91],["\\",92],["]",93],["^",94],["_",95],["`",96],["a",97],["b",98],["f",102],["i",105],["m",109],["n",110],["r",114],["s",115],["t",116],["v",118],["x",120],["z",122],["{",123],["|",124],["}",125]])),AB),m=class{constructor(n,e=!1){this.data=n,this.isStride1=e,this.SIZE=e?2:3}getLo(n){return this.data[n*this.SIZE]}getHi(n){return this.data[n*this.SIZE+1]}getStride(n){return this.isStride1?1:this.data[n*this.SIZE+2]}get length(){return this.data.length/this.SIZE}};const Np=new Uint8Array(256);for(let n=0,e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-";n<64;n++)Np[e.charCodeAt(n)]=n;const Pp=n=>{const e=[];let t=0,s=0;for(let r=0;r<n.length;r++){let i=Np[n.charCodeAt(r)];t|=(i&31)<<s,i&32?s+=5:(e.push(t),t=0,s=0)}return e},_=(n,e)=>{const t=Pp(n),s=e?t.length/2:t.length/3,r=new Uint32Array(s*3);let i=0,o=0;for(let a=0;a<s;a++)i+=t[o++],r[a*3]=i,i+=t[o++],r[a*3+1]=i,r[a*3+2]=e?1:t[o++];return r},Nw=n=>{const e=Pp(n),t=new Map;let s=0;for(let r=0;r<e.length;r+=2){s+=e[r];const i=e[r+1],o=i>>>1^-(i&1);t.set(s,s+o)}return t};var Ko=class{constructor(n){this.initializer=n,this.cache=new Map}has(n){return n in this.initializer}get(n){if(this.cache.has(n))return this.cache.get(n);const e=this.initializer[n],t=e?e():null;return this.cache.set(n,t),t}},Mn,yt=(Mn=class{static get CASE_ORBIT(){return this._CASE_ORBIT||(this._CASE_ORBIT=Nw("rCgCIgCY+rQI4QiCuuBLgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCCgCBgCBgCBgCBgCBgCBgCB+7OB-BB-BB-BB-BB-BBskQB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BC-BB-BB-BB-BB-BB-BB-BByHBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBxHBCBBBCBBBCBBB3SBmMBkNBCBBBCBBB8MBCBBB6MB6MBCBBC+EB0MB2MBCBBB6MB+MBiGBmNBiNBCBBBmKBikzCBmNBqNBkIBsNBCBBBCBBBCBBB0NBCBBB0NDCBBB0NBCBBByNByNBCBBBCBBB2NBCBBDCBBCwDFCBCBDBCBCBDBCBCBDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB9EBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBCBDBCBBBhGBvDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBjICCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBH2iVBCBBBlKBwiVB+jVB+jVBCBBBlMBqEBuEBCBBBCBBBCBBBCBBBCBBB+hVB4hVB8hVBjNB7MC5MB5MCzMC1MB+0yCE5MB20yCC9MBu2yCBwyyCBo0yCChNBlNBo0yCBu-UBi0yCDlNC6-UBpNDrNIu+UDzNCm0yCBzNE0yyCBzNBpEBxNBxNBtEG1NLqxyCBkxyCnFoFrBCBBBCBBDCBBEkIBkIBkICoHHsCCqCBqCBqCCgEC+DB+DBmkOBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCC+BBgCBgCBgCBgCBgCBgCBgCBgCBrCBpCBpCBpCBmjOB-BB8BB-BB-BBgEB-BB-BByBBqgOBsDB-BBtwBB-BB-BB-BBsBBgDBCB-BB-BB-BBeB-BB-BB61OB-BB-BB-DB9DB9DBQB7DBmCE9CBrDBPBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBrFB-EBOBnHB3FB-FCCBBBNBCBBCjIBjIBjIBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB8kMB-BB6kMB-BB-BB-BB-BB-BB-BB-BB-BB-BBokMB-BB-BBkkMBkkMB-BB-BB-BB-BB-BB-BB-BB4jMB-BB-BB-BB-BB-BB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EBCBBBCBoiMBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBJCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBeBCBBBCBBBCBBBCBBBCBBBCBBBCBBBdBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDL-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-C64CgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOCgmOGgmODg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FDg8FBg8FBg8FhVg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBQBQBQBQBQBQDPBPBPBPBPBPjkC7mMB5mMBnmMBjmMBCBlmMB3lMBpiMBk8kCBCBBG-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FD-7FB-7FB-7F6FoglCEsuHRwjlCyDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCB0DBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBG1DD97OCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPEQCQCQCQCPCPCPCPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPB0EB0EBsFBsFBsFBsFBoGBoGBgIBgIBgHBgHB8HB8HDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQCSFPBPBzEBzEBRCxnOFSFrFBrFBrFBrFBREQBQClkOFPBPBnGBnGFQBQCljOCODPBPB-GB-GBNHSF-HB-HB7HB7HBRqJ53OE9tQBrmQH4Bc3BSgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfECBByZ0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzB34BgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CBCBBBt-UBruHBt+UB1iVBviVBCBBBCBBBCBBB3hVB5-UB9hVB7hVCCBBCCBBI9jVB9jVBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBICBBBCBBECBBN-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOC-lOG-lOzoeCBBBCBBBCBBBCBBBCBBBCBl8kCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBTCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBnECBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBKCBBBCBBBnglCBCBBBCBBBCBBBCBBBCBBECBBBvyyCDCBBBCBBBgDCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBn0yCB90yCB10yCBh0yCBn0yCCjxyCBzyyCBpxyCBg6BBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB-CBl0yCBvjlCBCBBBCBBBt2yCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBhkzCZCBB9a-5Bd-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCm6TCBB7gBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCH-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BmlBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvChDwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCFvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvC1DuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCCuCBuCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCCtCBtCk2BgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEO-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-D+CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCL-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-B74CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhrVgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BD1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BtxekCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjC")),this._CASE_ORBIT}static get Print(){return this._Print||(this._Print=new m(_("hB9CBjBLBCpWBDFBFGBCCCBSBCsMBClBBDxBBDCBC2BBJaBFFBSVBC-FBCvBBD6BBDkDBP6BBDwBBDOBCbBDCCBJBGfBIqCBCgFBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYBDCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPBLCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGBCCBCHBDBBDVBCGBCBBCEBDIBDBBDCBICBFBBCEBDRBLBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBGMBCCBCWBCPBDIBCCBCDBIBBCCBCBBDDBDJBIVBCCBCWBCJBCEBDIBCCBCDBIBBGCBCDBDJBCCBNMBCCBCyBBCCBCFBFPBDZBCCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBN5BBFcBmBBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDBhBnCBCjBBFmBBCjBBCOBCMBmBlGBCGGD4LBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBH1CBDFBD-TBCbBE4CBIVBKXBKTBNMBCCBCBBN9CBDJBHJBHNBCKBH4CBIqBBGlCBLeBCLBFLBFEEBoBBDEBMrBBFZBHKBE9BBDgCBCcBDKBHJBHNBDtBBDLBVsCBClFBJ7BBEOBE9BBGqBBDKBJqBBG1QBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBSXBJuBBSBBDaBCMBEhBBPgBBQrEBF5UBXKBWz4BBD9LBGsBBCGGD3BBIBBPXBKGBCGBCGBCGBCGBCGBCGBCGBC9DBjBZBC4CBN1GBbPBC+BBC1CBDmDBGqBBC9CBC1CBKvBBCszcBE2BBK7KBV3FBJ8GBV7BBEJBH3BBJlCBJLBHzDBMdBEtCBCKBFgBBC2BBKNBDJBDmDBZbBLFBDFBDFBKGBCGBC7BBF9DBDJBHj9KBNWBFwBBloItLBDpDBnBGBNEBGZBCEBCCCBCCBCCBoUBhBpBBHyBBCSBCDBFEBCmEBF9FBEFBDFBDFBDCBEGBCGBOBBDLBCZBCSBCBBCOBDNBjB6DBGCBFsBBE3CBCMBEwBwBBsBBjEcBEwBBQbBFjBBKdBGqBBGdBCkBBFNBrB9EBDJBHjBBFjBBFnBBJzBBMLBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBCnCBJIBxBSBCBBGgBBEaBGaBnB3BBFTBDxBBCBBGHBCCBCcBDCBFJBIIBI-BBhBmBBFLBK1BBEcBDaBGZBIDBNGBxCoCB4ByBBOyBBItBBJJBHlBBEcBJBBxGeBCpBBCCBDBBRFBJIBiBtBBJpBBXZBnBbBVWBKtCBFjBBK9BBCEBOYBIJBH0BBCRBJmBBK-CBCTBMRBCuBB-BGBCCCBCBCOBCKBH6BBGJBHDBCHBDBBDVBCGBCBBCEBCJBDBBDCBDHHGGBDGBEEBMJBCDDClBBCJBCDDCDBCJBCBBJBBe7CBCEBfnCBJJBnF1BBDlBBjBkCBMJBHMBU5BBHJBHTBdaBDOBFWB6F7BBlDyCBNHBDDDBGBCBBCdBCBBDLBKJBnCHBDtBBDKBcnCBJyCBOoCBIJB3CHB5ChBBPJBHIBCsBBCNBLcBEfBDVBCNBqCGBCBBCrBBECCBCCBHBJJBHFBCBBCkBBCBBCFBIJBHrBBFJB3HYBIQBCoBBEcB2CQQBwBBO6cBnDuDBCEBMjGBtyCiDBOvhBBRVBL68DBGmSB61G5BBn2B4RBIeBCJBFwCBCJBHdBDFBLlCBLJBCGBCUBGSBxN5BBnG6CBGYBDYBtBqCBF4BBIQBhCEBMGBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBDDBh7D8HBEzNBHWBQQBQtBBDWBKzDB9B1HBLmBBDpCBJvDBWlCB7DTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBD9VBQEBCOBxiBeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBENBDJBFBBhKeBS5BBGxOxOBoBB3GqBBFhGhGBdBCVBJBBhHGBCDBCBBCOBCkGBDPBqBrCBFJBFBByYjCBtC8BBjGDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBBvIrBBFjDBNOBDOBCOBCkBBLtFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBmgB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIBnkzVvHB",!1))),this._Print}static get Upper(){return this.CATEGORIES.get("Lu")}},U(Mn,"_CASE_ORBIT",null),U(Mn,"_Print",null),U(Mn,"CATEGORIES",new Ko({C:()=>new m(_("AfBgDgBBOrWrWBHHBCBICCVuMuMnBBBzBBBE4B4BBGBcDBHQBXhGhGxBBB8BBBmDNB8BBByBBBQddBCCMEBhBGBsCiFiFJBBDBBXIICCBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBPMMBEB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKMMBDBbEByBPBDBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCB-FCBHBBHBBHBBECBIIIBLBDBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIB-BGGBLBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMBxhBPBXJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBF-6DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBrCHBxDUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIlkzVBxHvw-FB",!1)),Cc:()=>new m(_("AfgDgB",!0)),Cf:()=>new m(_("tFzqBzqBBEBXhGhGyBhMhMBxCxCs5D9-B9-BBDBbEByBEBCJBw03B6H6HBBBimEQQj7IPBhjiBDBwmFHBn0rYffB+CB",!1)),Cn:()=>new m(_("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBDBvzIBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-BB---BBB---BBB",!1)),Co:()=>new m(_("gg4B-nGh4hc9--BD9--B",!0)),Cs:()=>new m(_("gg2B--B",!0)),L:()=>new m(_("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICCiEEBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoCaBFDBuBqBBkBBBCiDBCQQBIIBLLBBBDRRCdBe4CBMZZBfBKBBFGGBUBFKKEYYBXBIKBGXBCGBRpBB7B1BBETTIJBQPBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNGB7BBBCCCBDBCXBCCCBIBCBBKDDBDBCWWBCBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNSSBkBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBkBFFkC4CBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBzC+C+CBtBBSHB3BdBOBBLrBBbjBBqBCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBhC1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBF1B1BB8zC8zCBjHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBxC2O2OBrBrBBDBGBBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBReBDlCByBIBDmDBDxCBVQBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBdRRBDBCJBLEBCoBBYCBCHBVWBEEEBwBBCEEBDDBDBDCCZCBDKBICBNFBDFBDFBKGBCGBCqBBCNBHyDBej9KBNWBFwBBloItLBDpDBnBGBNEBGCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBxB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOjBBnBbBKWB7HpBBHBBRFB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB1D-BBgBHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBqBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBGjCjCBLBhCBBCPPBNNB0mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBn7F0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFBmI9BBzEsBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCCBCBBCGBDEBKBBhHGBCDBCBBCOBCkGB8BjCBI1lB1lBBCBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),LC:()=>new m(_("hCZBHZB7BLLBVBCeBCiGBCDBFvGBDZBhGDBDBBECBCHHCCBCCCBSBCyCBCqEBJlFBClBBKoBB44ClBBCGGDqBBDCBhV1CBDFBjkCKBGqBBDCBhCrBBgCMBChBBmD1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGBmIFFDJBCEEBDBHGCBCBCFBFDDBCBGEBF1B1BB8zC8zCB6DBDmDBHDBEBBNlBBCGGzoetBBTbBnEtCBCWBEDBCsCBZBBE2Z2ZBpBBGIBIvCBh6TGBNEBqgBZBHZBmlBvCBhDjBBFjBB1DKBCOBCGBCBBCKBCOBCGBCBBk2ByBBOyBB+CVBLVB74C-BBhrV-BBhBYBDYBtpZ0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BJBCTBHFB2uCjCB",!1)),Ll:()=>new m(_("hDZB7BqBqBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDZBiGCCEEEBBBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBDCB5XFBjkCIBC2D2DBqBBgCMBChBBnD0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBBzIEEBEEcKFDBBJDBF2B2Bs1CvBBCEEBGCFCCBCCBEBGiDCBIICFFNlBBCGG0oesBCUaCoEMCBBBC+BCBGBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCbEE2ZqBBGIBIvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFB4vChBB",!1)),Lm:()=>new m(_("wVRBFLBPEBICCmEGG-OnHnHlFBBuIBBFgBgBKEEhFoFoF1mBgEgE2R72B72BsDkTkTxOFBvF+BBOjBjBBjBByVOORMBg-CBByHgGgG2OsBsBBDBGiDiDB+C+CBBB34bjnBjnBBEBvIzDzDdBB6DIBxCYYpDDBEBB2OXXqEtDtDWBBoDDBKngVngVuBBBh-BFBCpBBCIB0sBhBhB2K04D04DnrTDB9PCBpBBBnRMBhCBBCPPB9-P9-PBCBCGBCBByhM9BBqGGBud0Q0QsSAB",!1)),Lo:()=>new m(_("qFQQhIFFBCBxGBB7ZaBFDBuBfBCJBkBBBCiDBCZZBLLBBBDRRCdBe4CBMZZBfBWVBrBYBIKBGXBCGBRoBB8B1BBETTIJBROBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNFB8BBBCCCBDBCXBCCCBIBCBBKDDBDBYDBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNyDyDBnKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPByDrTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBpBkCkCBhBBC0BBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBxFuBBSHB3BdBOBBLrBBbjBBqBCBLdByDDBCFBCBBE7hB7hBBCB4-C3BBZWBKGBCGBCGBCGBCGBCGBCGBCGBoR2B2BF1CBJCCB4CBFGGBpBBC9CBSfBxBPBhQ-tGBhC0wUBC2jBBkCnBBJrIBFPBLBBjCyByBBkCBqFoDoDEGBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBuBEBDIBLEBCoBBYCBCHBVPBCFBEEEBwBBCEEBDDBDBDCCZBBEKBIPPBEBDFBDFBKGBCGByEiBBej9KBNWBFwBBloItLBDpDBkCCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBqDJBCsBBDeBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBhEtCBjDnBBJzBB9CzBBN2JBKVBLHB5EFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4FjBBnBDBCxJxJBoBBHBBRCBCBB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB0GHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBnBBCBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBB0BUBGSB0NnBB2MqCBGwFwFB0mHBqBfBiDyDBuwIiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBxzI2P2PBrBBiBiKiKBcBTrBBlPaBmHdBDwGwGBdBCCBCBBCGBDEBKiHiHBFBCDBCBBCOBCkGB8pBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Lt:()=>new m(_("lOGDnB2sH2sHBGBJHBJHBNQQwBAB",!1)),Lu:()=>new m(_("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBG+B+B9zCvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBB",!1)),M:()=>new m(_("gYvDB0IGBoIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCgBB3BCBCRBCGBLBBeCB5BCCBFBDBBDCBKLLBbbDCB5BCCBDBFBBDCBEffBEEMCB5BCCBGBCCBCCBVBBXFBCCB5BCCBFBDBBDCBICBLBBf8B8BBDBECBCDBKpBpBBDB4BCCBFBCCBCDBIBBMBBeCB5BCCBFBCCBCDBIBBMBBQNNBCB4BBBCGBCCBCDBKLLBeeBBBnCFFBEBCCCBGBTBB+BDDBFBNHBjDDDBHBMGBqCBBcECFBByBTBCBBGKBCjBBKlDlDBSBYDBFCBCCBDGBEDBOLBCLLBCBgWCBzdDBdCBeBBfBBhCfBKuBuBBBBC2D2DBjBjB3DLBFLB8GEB6BJBCcBDxBxBBsBBDLBVEBwBQBnBIBNCBfMB5BNBxBTB5ECBCUBFHHDCBnG-BBxWgBB--CCBuEhDhDBeBrRFBqDBB1udDBCJBhBBBxCBBxIEEFYYBDBF0C0CBzBzBBQBbRBOnBnBBGBaMBtBDBwBNBlBkCkCBMBNJJBuBuBBBBzBCCBBBDBBGBBCqBqBBDBGBBtHHBCBBx5TiXiXBOBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB7DCB2BOBqBDDBLLBCBuBKBI+B+BBBBlBNBRBBtBNNBBBxBNBJDBCBB9CLBHDD+ELBWDB4BBBCGBDBBDCBKLLBDDBFBEEBkCIBCDDCDBCEBCPPBzCzCBQBYyCyCBSBsHGBDIBcBBzCQBrDMBmDOBhIOB2HFBCBBDDBCCCBuEuEBFBDGBEddBIBpBGBCDBJKKBJBvBPBnGHBoGHBCHBzCVBCNB7DFBECCBCCBFBCjCjCBDBCBBCEB8KDBKBBCxBxBBFBEEBYmnFmnFHOBpmLRBhuCEB8BGB5gBCCB1BBIDByCMMBslTslTBizEizEBsBBDWB-QEBEFBJHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),Mc:()=>new m(_("joC4B4BDCBJDBCBBzBBB7BCBHBBDBBLsBsB7BCBjC7B7BBBBJCCB2B2BB7B7BCHHBDDBLLnDBBCBBECBCCBLqBqBBBB+BDB+BBB7BCCBDBDBBCBBKBBdPPB7B7BBBBGCBCCBLrBrBBsCsCBBBHHBTBBrKBBgCsFsFBFFHDDBaaBLLBBBDGBWBBDFBDLLBBB5zBffiEIIBGBCBB7KDBDCBFBBCFBhHBB7BCCKCCBJJBEByExBxBGCCBDBCBB+BffFBBD9B9BDCBCEEBxBxBBGBJBBsFWW35EBB0-dBBD5C5CBzBzBBOBvEBBwBxBxBBFFBDDBBBvDBBDBBZuBuBCuDuDDBBGuHuHBCCBCCBCC0gZCCgEuBuBBBBFBB0DZZB8B8BxBCBKBBO+C+CBBBEBBCrFrFBBBgBBB7BBBCDBDBBDCBKLLB1C1CBBBIDDCDBCBBCmDmDBBBJBBErDrDBBBHCCBCBDuHuHBBBHDBDyDyDBBBJBBCuDuDCBBHoDoDCBBFmImIBBBK4H4HBEBCBBFDDCvEvEBBBJDBF1C1CeBB-BqGqGECCoGPPrDIID2G2GBDBFBBC-K-KBNNxBBBJBBCpvQpvQBBBlxD2BBpDBB0rYBBHFB",!1)),Me:()=>new m(_("okBBB1xF-wB-wBBCBCCBsshBCB",!1)),Mn:()=>new m(_("gYvDB0IEBqIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCfB4BCCFHBFEEBFBLBBe7B7BFDBJVVBbbDBB6BFFBFFBDDBBBEffBEEMBB6BFFBDBCBBFVVBXXBEBC7B7BDCCBCBJIIBMMBff+BNNzBEE4BCCBBBGCBCDBIBBMBBe7B7BDHHGBBVBBdBB6BBBFDBJVVBeepCIIBBBC7C7CDGBNHBjDDDBHBMGBqCBBcEC4BNBCEBCBBGKBCjBBKnDnDBCBCFBCBBDBBaBBFCBRDBODDBHHQgWgWBBBzdCBeBBfBBfBBhCBBCGBJDDBJBKuBuBBBBC2D2DBjBjB3DCBFBBKHHBBB8GBBD7B7BCGBCCCDHBHJBDxBxBBMBCeBDLBVDBxBCCBDBCGGpBIBNBBhBDBDBBCCB5BCCBEECCB7BHBDBB5ECBCMBCGBFHHEBBnG-BBxWMBFEEBKB--CCBuEhDhDBeBrRDBsDBB1udFFBIBhBBBxCBBxIEEFaaBGG4EBBbRBOnBnBBGBaKBvBCBxBDDBCBDBBoBkCkCBEBDBBDBBNJJwB0B0BCCBDBBGBBCrBrBBJJvHDDFx5Tx5TiXPBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB8D3B3BBNBqBDDBLLBBByBDBDBBI+B+BBBBlBEBCHB-BNNB1B1BBHBLDBDgDgDBBBDCCBHHD+E+EEHBWBB6BBBEmBmBBFBEEBnCFBOECPBB2CHBDCBCYY1CFBCFFBCCBvHvHBCBHBBCBBcBB2CHBDCCBrDrDCDDBEBCmDmDCDDBCBCEBkIIBCBBhIBBCFFxEDBDBBFhBhBBIBpBFBDDBJKKBEBDCBvBMBCBBnGCCBBBCqGqGBFBCFBCzCzCBUBDGBCBBCBB7DFBECCBCCBFBCpCpCBEEC8K8KBMMB1B1BBDBGCCYmnFmnFHOBpmLLBECBhuCEB8BGB5gBgCgCBCByC5lT5lTBizEizEBsBBDWBhRCBSHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),N:()=>new m(_("wBJB5DBBGDDBBBitBJBnEJBnGJB9MJB3DJBFFBtDJB3DJB3DJBDFBvDMB0DJBJGBoDJBpDGBISBuDJBhDJB3DJBnCTBtIJBnCJBwWTBybCBwHJBHJBXJBtJJBhEKBmFJBHJB3FJB3CJBnEJBHJB3gBEEBEBHJBnGyBBDEB3W7BBvCVB3TdBqrBqYqYaIBPCB4KDBrEJBfHBCOBhBJBoBOBh7cJB9FJBhKFB7EJBnBJBnGJBXJB3CJB3MJB34UJBuPsBBN4BBSBB2KaBlBDBeJJnEEBrGJBvdHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBxBJBHJB3IeB-EJBrBDBxDGBnEdBhEJB9BJBxEJBITB8HJB3KJB3DJB3LJBnDJBHTBtCLBlNSB+CJB3UJB3CcBkHJBnCJB3BJBnLJBnDUBshBuDBimPJBnpCJB3CJBnEJBCGBvQJBnIWB+KCB6nXJBnuBTBNTBtDYB2iBxBBhqCJBnNJB3PJB4HJBtWIBhEJB4Y6BBCCBCDBtCsBBCOBjeMBk3CJB",!1)),Nd:()=>new m(_("wBJnxBJnEJnGJ9MJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJhDJ3DJnCJ3IJnCJn6BJnBJtJJhEJnFJHJ3FJ3CJnEJHJnuiBJnVJnBJnGJXJ3CJ3MJ34UJnsBJnkCJHJ9YJhEJ9BJxEJ3IJ3KJ3DJ3LJnDJHTtCJnNJnDJ3UJ3CJ3HJnCJ3BJnLJ3uQJnpCJ3CJnEJ3QJ37XJ12CxBhqCJnNJ3PJ4HJ2aJ30EJ",!0)),Nl:()=>new m(_("u3FCBwzCiBBDDB-zDaaBHBPCBs1dJBxyW0BBtOJJnEEBrhIuDBm8SCB",!1)),No:()=>new m(_("yFBBGDDBBB2pCFB5LFB5DCBmEGB6GGBSIByNJB2hBTB0jBJBhP20B20BEFBHJBnGPBqB3W3WB6BBvCVB3TdBqrB1kB1kBBCBrEJBfHBCOBhBJBoBOBxrdFBymWsBBiCDBSBB2KaBlBDB1pBHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBhLeB-EJBrBDBxDGBnETB8LTBmqBBBvNIBobSB0aUBn8SGB-YWBqhZTBNTBtDYBvqFIBid6BBCCBCDBtCsBBCOBjeMB",!1)),P:()=>new m(_("hBCBCFBCDBLBBEBBbCBCccCkBkBGEELBBEEE-VJJzOFBqBBB0BCCDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCmBmBBCBoCrCrCBDBFBBwDFBsFlTlTBHB4EuTuTtBBBvCCBoCBB+ECBCCBmBKB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBM9Z9ZBWBJTBCMBCLBfBBPBB6TDBeBB+hBNBwCBBgBJB0MVBgCDBhBBB8XDBCBBxDwEwEBtBBCfBDLBkNCBFJBDLBRNNjD7C7CjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HzqUzqUBxGxGBIBXiBBCNBCFFCBB2ECBCFBCDBLBBEBBbCBCccCCCBFB7MCB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDByO-J-JjBlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Pc:()=>new m(_("-Cg-Hg-HBUU-u3BBBZCBwHAB",!1)),Pd:()=>new m(_("tB9qB9qB0BiyDiyDmgBqgCqgCBEBiwDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Pe:()=>new m(_("pB0B0BgB+1D+1DC-6B-6BqtC4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECtBGCtNICEGCDBB-ozB6G6GeOCESSCCCrF0B0BgBGD",!1)),Pf:()=>new m(_("7F+6H+6HEddpuDCCFDDQEE",!1)),Pi:()=>new m(_("rFt7Ht7HDBBDaapuDCCFDDQEE",!1)),Po:()=>new m(_("hBCBCCBDECBLLBEEBcclCGGPBBI-V-VJzOzOBEBqB3B3BDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCxDxDrCEBFBBwDFBsFlTlTBHBmY9D9DBBBoCBB+ECBCCBmBFBCDB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBMjajaBJJBGBJIBDDBDCBEKBCCCBIB7kDDBCBBxDwEwEBFFBBBDDDBHBCBBCDDBLLBDBCJBDDBCCCBLBDCBtNCB6B+F+FjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HlxUlxUBFBDXXVBBDDBECBCDBICBHCCB2E2EBBBCCBDECBLLBEEBcclBDDB7M7MBBB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDB0ZlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Ps:()=>new m(_("oBzBzBgB-1D-1DC-6B-6B-rCEEnB4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECaTTCECtNICEGCDipzBipzB4GeeCMCESSCCCrFzBzBgBEEDAB",!1)),S:()=>new m(_("kBHHRCBgBCCcCCkBEBCBBDCCBCBDEEfgBgBrODBNNBGGBCCCBPB2DPPBxDxDsErIrIBBB3DCBDDDBvGvGLUUB4H4HIBBpEqLqLBHHB2H2H-DjEjEBGBlEwGwGqBmGmGiGCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WuLuLlL+E+EBgBBiLJBKIBhiBCCBBBMCBOCBOCBOBBmCOOoBCBOCBUhBB-BBBCDBCBBLCCBBBGFBCECFMMBFFBDBGDBC7B7BBFFB2LBFcBD+HBXKByCtCBXnTBtBwBBDeBLyMBX+BBFfBD1LBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBB8CBB0HBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BB6RWBKBBoDBB+EDBLDB+RCBiHPPB+9T+9TpEgBBuLPBhCBB3BHBtBDBjDCCBBBD7E7EHRRBBBgBCCcCCiEGBCGBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSmWmWBiKiKBGBnjC2kC2kCBbBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQQBgDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBrbaagBaagBaagBaagBaa9B-PB4BDBzBHBCNBCBBp2BwNwNttCEE+DiOiOBvIvIBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Sc:()=>new m(_("kB+D+DBCBqnB8D8DzPBBzPBBI2H2HoImSmS8sClmClmCBgBB37hBkuVkuVtD7E7E8GBBEBB3-HDB-4wBxtCxtC",!1)),Sk:()=>new m(_("+CCCoCHHFEEqQDBNNBGGBCCCBPB2DPPBjoBjoB15FCCBBBMCBOCBOCBOBB9kEBBkzdWBKBBoDBBxePPBniUniUBPB8bCCjF4g9B4g9BBDB",!1)),Sm:()=>new m(_("rBRRBBB+BCCuBFFmBgBgB-XwQwQBBB8xGOOoBCBOCBsEoBoBBDBHlClCBDBGBBFGDIgBgBBDDCgBgBBqIBhBBB7CffBXBpBFB2OKK3BHBwDxKxKBDBDeBLPBhIiEBX+BBFfBDhIBxBUBDFB9+zB5Z5ZCCBlFRRBBB+BCCkEHHBCBitDBBhrwBx+Bx+BagBgBagBgBagBgBagBgBat5Ft5FB-uC-uCBHB",!1)),So:()=>new m(_("mFDDFCCyerIrIBgEgEBvGvGLUUB4H4HkQ2L2LjEFBClElEwGqBqBoMCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WzWzW+EhBBiLJBKIBksBBBCDBCBBLCCBHHBEBCECFMMBPPCBBC7B7BBKKBDBDDBCBBCBBCGBCeBDBBCCCBdBtIHBFTBDGBDwCBCdBanBBHnCBXKByCtCBX2FBCIBC1BBJuDBC3HBtBrBBhC-HBhQvBBWBBHmBBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBBxKBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BBibDBLBBC+R+RBBBqqUPBuLPBhCBB3BHBuBCBlPEEFBBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSpgBpgBBGBnjC2kC2kCBGBFQBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQPBhDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBqlB-PB4BDBzBHBCNBCBBp2B96C96CiEyWyWBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E6HBG4WBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBB-B3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Z:()=>new m(_("gBgEgEgvFgsCgsCBJBeBBGwBwBh9DAB",!1)),Zl:()=>new m(_("ohIA",!0)),Zp:()=>new m(_("phIA",!0)),Zs:()=>new m(_("gBgEgEgvFgsCgsCBJBlBwBwBh9DAB",!1)),ASCII_Hex_Digit:()=>new m(_("wBJIFbF",!0)),Alphabetic:()=>new m(_("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICC3CeeBQBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoBNBCCCBCCBCCJaBFDBeKBG3BBCGBPlDBCHBFHBFCBLCBDRRBuBBOkDBZgBBKBBFGGBWBDSBUYBIKBGXBCGBIJJBoBBLLBEGBHrCBCPBCCBFOBOSBCHBDBBDVBCGBCEEBCBEHBDBBDBBCJJFBBCEBNBBLFFBBBCFBFBBDVBCGBCBBCBBCBBFEBFBBDBBFIIBCBCSSBEBMCBCIBCCBCVBCGBCBBCEBEIBCCBCBBEQQBCBWDBFCBCHBDBBDVBCGBCBBCEBEHBDBBDBBKBBFBBCEBORRBCCBEBECBCDBEBBCCCBEEBEEBBBELBFEBECBCCBEHHpBMBCCBCWBCPBEHBCCBCCBJBBCCBCBBDDBdDBCHBCCBCWBCJBCEBEHBCCBCCBJBBGCBCDBOCBNMBCCBCoBBDHBCCBCCBCGGBCBIEBXFBCCBCRBEXBCIBCDDBFBJFBCCCBGBTBBO5BBGGBH0B0BBECBDBCXBCCCBRBCCBDEBCHHPDBhBgCgCBGBCjBBFSBFPBCjBBkC2BBCDDBDBR-BBLDBDlBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBEKBITBMUBNTBNMBCCBCBBNzBBDSBPFFkC4CBIqBBGlCBLeBCLBFIBYdBDEBMrBBFZB3BbBF+BBDTBzBYYBMMBBByBzBBCOBCHB0BpBBDDBLrBBCKBP2BBXCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBUhBBM1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBFSSBnBBuZzBB34BkHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBCfBwB2O2OBBBaIBIEBDEBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBGHBEwDBoBIBDmDBDxCBVUBCgBBZzBBNjCBCtBtBBEBECCBBBLgBBGiBBOcBEyBBCLBQRRBOBLEBC2BBKNBTWBEkCBCCCZCBDPBDDBMFBDFBDFBKGBCGBCqBBCNBH6DBWj9KBNWBFwBBloItLBDpDBnBGBNEBGLBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmC0BBsIcBEwBBwBfBOdBGqBBGdBDjBBFHBCEBrB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCDBCBBGHBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOnBBjBbBEGGBVB7HpBBCBBEBBRFBzBCBEcBLJJBUBrBRBvBUBcWBKlCBsBEBL4BBKOOBXBYyBBSDBJiBBEKKB+BBCDBKBBLCCkBRBChBBDHHBCB-BGBCCCBCBCOBCJBI4BBYDBCHBDBBDVBCGBCBBCEBEHBDBBDBBEHHGGBdJBCDDClBBCJBCDDCDBCBBECCtBhCBCCBCDBVCBfhCBDBBC5F5FB0BBDGBaFBjB+BBCEE8B1BBDoCoCBZBDNBWGB6F4BBoD-BBgBHBDDDBGBCBBCdBCBBDBBDDB+CHBDtBBDFBCCCBccBxBBDJBSnCBGTTBnCBoDHB5CgBBgBIBCsBBCGBCyByBBcBDVBCNBqCGBCBBCrBBECCBCCBBBCDDBZZBEBCBBCkBBCBBCDBCYYBqBBlIWBKQBCoBBECBwDwCwCB4cBnDuDBSjGBtyCgDBQvhBBSFBa68DBGmSB61GuBBy2B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBF4BBIQBhCBBCNNBFBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBFi7Fi7FBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCVBJBBhHGBCDBCBBCOBCkGB8BjCBEEE1lBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1TZBHZBHZB3zD-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Dash:()=>new m(_("tB9qB9qB0BiyDiyDmgBqgCqgCBEB+BoBoBQnMnMlgDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Emoji:()=>new m(_("jBHHGJBwDFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDrGrGhFBBNBBPDDBIBsCZBCBBYVVDIBWBBvFhBBDvDBDBBCCBDyCBDCBCmIBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDDBEJBECCBEEDJBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Emoji_Component:()=>new m(_("jBHHGJB0+H2G2Gsp3B3+8B3+8BBYB8PEBxtBDBtzhY-CB",!1)),Emoji_Modifier:()=>new m(_("7-8DE",!0)),Emoji_Modifier_Base:()=>new m(_("9wJ8G8GRDB4jzD9B9BBBBDDDBBB2DBBDKBWSBEFFBBBCCBICCZqGqGBFFWFFBvFvFBBBEEB0CRRBBBKMMgSDDJHBHKKBIBDCB5B+B+BBCCBCCSCBCMBmHCBrBIB",!1)),Emoji_Presentation:()=>new m(_("64IBBuGDBEDDqQBBWBBzBLBsBUUOJJBSSBGGBJJGWWIBBCFFDIIFBBdkBkBCFFBBBC+B+BBBBZPP8aBB0BFFvlxDrGrG-FDDBIBsCZBCZZVDDBDBCCBWBBvFgBBNIBClCBCVBNqBBFEBNQBEEEBlCBCCCB5FBD+BBODBCXBTbbBOO3C0CBxBlCBHEEBBBDDBEDBMBBIIBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Extended_Pictographic:()=>new m(_("pFFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDoBoBBCBlDLBQBBQPPBmBmBBIBxDBBNBBPDDBIBU3BBcOBLVVDIBCDBKWBH7FBDvDBDBBCCBDyCBDCBCDBG9HBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDQBECCBEBDMB7GlBBNDB5BHBLFBpBHBfBBNDBDNBKmBBNuBBCJBC4FB5CHBPxEBhI9fB",!1)),Hex_Digit:()=>new m(_("wBJIFbFq1-BJIFbF",!0)),Lowercase:()=>new m(_("hDZBwBLLFlBlBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDiBBIBBfEBhDsBsBCEEDDBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBCDB5XFBjkCIBC2D2DB+FBiC0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBB6DOORMBuDEEBEEcKFDBBJDBFiBiBBOBFsasaBYBn6BvBBCEEBGCFCCBCCBGBEiDCBIICFFNlBBCGG0oesBCUaCBBBmEMCBBBC8BCBIBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCWDBCCCBBB2ZqBBCNBHvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBkODDBBBCpBBCIBmoByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFBmI9BB1lChBB",!1)),Math:()=>new m(_("rBRRBBBgBeeCuBuBFmBmBgB5W5WBBBDbbBDDBBBwQCBuwGccBBBMEEOPPBCBWEBMEBiCMBFEEBFFBDBTFFDJBCDDBEBHEEBDDBCCBBBCFBENBClClCBWBCFBCBBFBBFfBCHHBPPBqIBJDBVBB7CffBZBCZZMGB+NBBNJBFFBFBBDBBEEBPCCDFBMHBGBB6BCCeDBKCBxK-BBhI-PBxBUBDFB9+zB4Z4ZBEBCjFjFRCBeCCeCCkEHHBCBitDBBhrwBwoBwoBBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBBhwFDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB-uCIB",!1)),Quotation_Mark:()=>new m(_("iBFFkEQQ96HHBaBBowDqOqOBCBOCBixzBDB+FFF7CBB",!1)),Terminal_Punctuation:()=>new m(_("hBLLCMMBEE-ZJJiQ6B6BpCPPCCB1FsBsBBJBCsHsHB3B3BBEBCHBgBmImIB1nB1nBBtFtFFFB4JBB2YHBmY9D9DBBBoCBB+ECBEoBoBBCBDBB7JBBjLDBjFBBLBBCCBeCB8FEB-BBBldYYBKKBBBwlDCBzJOOFLLCBBEBBtNBB8ndBBuICBkHEB-LBB3CBBgD4E4EBBB0ECBgERRB6H6HnxUDDB6B6BBBBCDBqFLLCMMBEEiCDD7hBxBxBnkBoGoG3JBB5EFBlCFB6CDB5dEBtBDB+FGBxDDBgECBiEBBHRRB5C5CBDBtDrJrJB2D2DBBBNBBnLDBEOBqDBB6HCBmQCC8HBB4CBBFBB-MCBuBmUmUBrCrCBspBspBBDB6vRBBmEiCiCBBBLqRqRBoJoJBnwTnwTovHDB",!1)),Uppercase:()=>new m(_("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBGbbBOBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBBvgCZBHZBHZB",!1)),White_Space:()=>new m(_("JEBTlDlDbgvFgvFgsCKBeBBGwBwBh9DAB",!1))})),U(Mn,"SCRIPTS",new Ko({Adlam:()=>new m(_("go6DrCFJFB",!0)),Ahom:()=>new m(_("g4lCaDOFW",!0)),Anatolian_Hieroglyphs:()=>new m(_("ggxCmS",!0)),Arabic:()=>new m(_("gwBEBCFBCNBCCBCfBCJBMZBCrDBChBBxCvBBxHhBBGqCBCcBxy8BtPBDvEBhBPBxDEBCmEBk7DeBkCFBJIBiBFBh43BDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB",!1)),Armenian:()=>new m(_("xpBlBDxBDCks9BE",!0)),Avestan:()=>new m(_("g4iC1BEG",!0)),Balinese:()=>new m(_("g4GsCCxB",!0)),Bamum:()=>new m(_("g1pB3CpowB4R",!0)),Bassa_Vah:()=>new m(_("w26CdDF",!0)),Batak:()=>new m(_("g+GzBJD",!0)),Bengali:()=>new m(_("gsCDBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYB",!1)),Beria_Erfe:()=>new m(_("g17CYDY",!0)),Bhaiksuki:()=>new m(_("ggnCICsBCNLc",!0)),Bopomofo:()=>new m(_("qXB6wLqBxDf",!0)),Brahmi:()=>new m(_("ggkCtCFjBKA",!0)),Braille:()=>new m(_("ggK-H",!0)),Buginese:()=>new m(_("gwGbDB",!0)),Buhid:()=>new m(_("g6FT",!0)),Canadian_Aboriginal:()=>new m(_("ggF-TxRlC7tgCP",!0)),Carian:()=>new m(_("g1gCwB",!0)),Caucasian_Albanian:()=>new m(_("wphCzBMA",!0)),Chakma:()=>new m(_("gokC0BCR",!0)),Cham:()=>new m(_("gwqB2BKNDJDD",!0)),Cherokee:()=>new m(_("g9E1CDFz7lBvC",!0)),Chorasmian:()=>new m(_("w9jCb",!0)),Common:()=>new m(_("AgCBbFBbuBBCOBCEBYgBgBiOmBBGEBDTB1DKKHCC+THHPEEhB9E9ElQiEiEB6mB6mB2MDBjJwvBwvBBBBoCBBsGBBCumBumBOIIBCBCFBCCBDmYmYBKBD2CBCKBEKBCOBShBB-BlBBCCBDFBCaBCQBqBCBF5UBXKBW-cBhIzTBDpEBhQ9CBzMUBCCCBXBQHBFDB8CBBE7C7CB0E0EBOBhBlBBKxBxBB+BBgBwCBwB5C5CBmFBhuG-BBhoWhBBnDCBmFJB1HhFhFsMPPBzuUzuUBxGxGBIBXiBBCSBCDB0ECCBeBbFBbKBLuBuBBhChCBFBCGBLEBjICBFsBBEIBxCMB0BsBBlHaBltuBDB96D8HBEzNBHWBQQBgDzDB9B1HBLmBBD9BBEQBJBBIdBF8BB2GTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBByjFjCBtC8BBjWrBBFjDBNOBDOBCOBCkBBLtFB5BZBCBBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBnghYffB+CB",!1)),Coptic:()=>new m(_("ifNxkKzDGG",!0)),Cuneiform:()=>new m(_("ggoC5cnDuDCEMjG",!0)),Cypriot:()=>new m(_("ggiCFBDCCBqBBCBBEDD",!1)),Cypro_Minoan:()=>new m(_("w8rCiD",!0)),Cyrillic:()=>new m(_("ggBkEBDoFBx6FKBhFtCtCojEfBhie-CBv8VBBhw4B9BBiBAB",!1)),Deseret:()=>new m(_("gghCvC",!0)),Devanagari:()=>new m(_("goCwCFODZh7nBfhwcJ",!0)),Dives_Akuru:()=>new m(_("gomCGBDDDBGBCBBCdBCBBDLBKJB",!1)),Dogra:()=>new m(_("ggmC7B",!0)),Duployan:()=>new m(_("ggvDqDGMEIIJDD",!0)),Egyptian_Hieroglyphs:()=>new m(_("ggsC1iBL68D",!0)),Elbasan:()=>new m(_("gohCnB",!0)),Elymaic:()=>new m(_("g-jCW",!0)),Ethiopic:()=>new m(_("gwEoCBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBnvGWBKGBCGBCGBCGBCGBCGBCGBCGBjpfFBDFBDFBKGBCGBylvCGBCDBCBBCOB",!1)),Garay:()=>new m(_("gqjClBEcJB",!0)),Georgian:()=>new m(_("glElBBCGGDqBBCDBx8CqBBDCBhiElBBCGG",!1)),Glagolitic:()=>new m(_("ggL-Ch9sDGCQDGCBCE",!0)),Gothic:()=>new m(_("w5gCa",!0)),Grantha:()=>new m(_("g4kCDBCHBDBBDVBCGBCBBCEBDIBDBBDCBDHHGGBDGBEEB",!1)),Greek:()=>new m(_("wbDBCCBDDBCFFCCCBBBCCCBSBC+BBPPBnpGEBzBEBFEB1ChKhKBUBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBoJ-xiB-xiB7uVuCBSgj0Bgj0BBkCB",!1)),Gujarati:()=>new m(_("h0CCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGB",!1)),Gunjala_Gondi:()=>new m(_("grnCFCBCkBCBCFIJ",!0)),Gurmukhi:()=>new m(_("hwCCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPB",!1)),Gurung_Khema:()=>new m(_("go4C5B",!0)),Han:()=>new m(_("g0LZBC4CBN1GBwBCCaIBPDBle-tGBhC-vUBhoWtLBDpDBpodBBNGBqgkB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Hangul:()=>new m(_("goE-HvxHBiI9CyDeiCei3dckUj9KNWFwBl9JeEFDFDFDC",!0)),Hanifi_Rohingya:()=>new m(_("gojCnBJJ",!0)),Hanunoo:()=>new m(_("g5FU",!0)),Hatran:()=>new m(_("gniCSCBGE",!0)),Hebrew:()=>new m(_("xsB2BBJaBFFBpp9BZBCEBCCCBCCBCCBIB",!1)),Hiragana:()=>new m(_("hiM1CBHCBi7-C+IBTeeBBBulQAB",!1)),Imperial_Aramaic:()=>new m(_("giiCVCI",!0)),Inherited:()=>new m(_("gYvDB2IBBlOKBbhXhXBCB8qEtBBDLBlPCBCMBCGBFHHEBBnG-BBtQBBjGgBB65DDBsDBBmrzBPBRNBwejHjH7iEl+uBl+uBBsBBDWBhRCBSHBDGBfDBz6rYvHB",!1)),Inscriptional_Pahlavi:()=>new m(_("g7iCSGH",!0)),Inscriptional_Parthian:()=>new m(_("g6iCVDH",!0)),Javanese:()=>new m(_("gsqBtCDJFB",!0)),Kaithi:()=>new m(_("gkkCiCLA",!0)),Kannada:()=>new m(_("gkDMCCCWCJCEDICCCDIBGCCDDJCC",!0)),Katakana:()=>new m(_("hlM5CBDCBxHPBxGuBBC3CBvgzBJBCsBBzisBDBCGBCBBCgJgJBBBzBPPBCB",!1)),Kawi:()=>new m(_("g4nCQCoBEc",!0)),Kayah_Li:()=>new m(_("goqBtBCA",!0)),Kharoshthi:()=>new m(_("gwiCDCBGHCCCcDCFJII",!0)),Khitan_Small_Script:()=>new m(_("k-7C84G84GB0OBqBAB",!1)),Khmer:()=>new m(_("g8F9CDJHJnPf",!0)),Khojki:()=>new m(_("gwkCRCuB",!0)),Khudawadi:()=>new m(_("w1kC6BGJ",!0)),Kirat_Rai:()=>new m(_("gq7C5B",!0)),Lao:()=>new m(_("h0DBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDB",!1)),Latin:()=>new m(_("hCZBHZBwBQQGWBCeBCgOBoBEB8wGlBBHwBBGDBGMBClCBiC-HByLOORMBuEBBHccSoBB42CfBj1elDBExCBVOBxZqBBCIBCDB38TGB7gBZBHZBmhCFBCpBBCIBm61BeBHFB",!1)),Lepcha:()=>new m(_("ggH3BEOEC",!0)),Limbu:()=>new m(_("goGeBCLBFLBFEEBKB",!1)),Linear_A:()=>new m(_("gwhC2JKVLH",!0)),Linear_B:()=>new m(_("gggCLCZCSCBCODNjB6D",!0)),Lisu:()=>new m(_("wmpBvBx1eA",!0)),Lycian:()=>new m(_("g0gCc",!0)),Lydian:()=>new m(_("gpiCZGA",!0)),Mahajani:()=>new m(_("wqkCmB",!0)),Makasar:()=>new m(_("g3nCY",!0)),Malayalam:()=>new m(_("goDMCCCyBCCCFFPDZ",!0)),Mandaic:()=>new m(_("giCbDA",!0)),Manichaean:()=>new m(_("g2iCmBFL",!0)),Marchen:()=>new m(_("wjnCfDVCN",!0)),Masaram_Gondi:()=>new m(_("gonCGBCBBCrBBECCBCCBHBJJB",!1)),Medefaidrin:()=>new m(_("gy7C6C",!0)),Meetei_Mayek:()=>new m(_("g3qBWqGtBDJ",!0)),Mende_Kikakui:()=>new m(_("gg6DkGDP",!0)),Meroitic_Cursive:()=>new m(_("gtiCXFTDtB",!0)),Meroitic_Hieroglyphs:()=>new m(_("gsiCf",!0)),Miao:()=>new m(_("g47CqCF4BIQ",!0)),Modi:()=>new m(_("gwlCkCMJ",!0)),Mongolian:()=>new m(_("ggGBBDCCBSBH4CBIqBB2t-BMB",!1)),Mro:()=>new m(_("gy6CeCJFB",!0)),Multani:()=>new m(_("g0kCGBCCCBCBCOBCKB",!1)),Myanmar:()=>new m(_("ggE-EhqmBeiDfxibT",!0)),Nabataean:()=>new m(_("gkiCeJI",!0)),Nag_Mundari:()=>new m(_("wm5DpB",!0)),Nandinagari:()=>new m(_("gtmCHDtBDK",!0)),New_Tai_Lue:()=>new m(_("gsGrBFZHKEB",!0)),Newa:()=>new m(_("gglC7CCE",!0)),Nko:()=>new m(_("g+B6BDC",!0)),Nushu:()=>new m(_("h-7CvsQvsQBqMB",!1)),Nyiakeng_Puachue_Hmong:()=>new m(_("go4DsBENDJFB",!0)),Ogham:()=>new m(_("g0Fc",!0)),Ol_Chiki:()=>new m(_("wiHvB",!0)),Ol_Onal:()=>new m(_("wu5DqBFA",!0)),Old_Hungarian:()=>new m(_("gkjCyBOyBIF",!0)),Old_Italic:()=>new m(_("g4gCjBKC",!0)),Old_North_Arabian:()=>new m(_("g0iCf",!0)),Old_Permic:()=>new m(_("w6gCqB",!0)),Old_Persian:()=>new m(_("g9gCjBFN",!0)),Old_Sogdian:()=>new m(_("g4jCnB",!0)),Old_South_Arabian:()=>new m(_("gziCf",!0)),Old_Turkic:()=>new m(_("ggjCoC",!0)),Old_Uyghur:()=>new m(_("w7jCZ",!0)),Oriya:()=>new m(_("h4CCCHDBDVCGCBCEDIDBDCICFBCEDR",!0)),Osage:()=>new m(_("wlhCjBFjB",!0)),Osmanya:()=>new m(_("gkhCdDJ",!0)),Pahawh_Hmong:()=>new m(_("g46ClCLJCGCUGS",!0)),Palmyrene:()=>new m(_("gjiCf",!0)),Pau_Cin_Hau:()=>new m(_("g2mC4B",!0)),Phags_Pa:()=>new m(_("giqB3B",!0)),Phoenician:()=>new m(_("goiCbEA",!0)),Psalter_Pahlavi:()=>new m(_("g8iCRIDNG",!0)),Rejang:()=>new m(_("wpqBjBMA",!0)),Runic:()=>new m(_("g1FqCEK",!0)),Samaritan:()=>new m(_("ggCtBDO",!0)),Saurashtra:()=>new m(_("gkqBlCJL",!0)),Sharada:()=>new m(_("gskC-ChsCH",!0)),Shavian:()=>new m(_("wihCvB",!0)),Siddham:()=>new m(_("gslC1BDlB",!0)),Sidetic:()=>new m(_("gqiCZ",!0)),SignWriting:()=>new m(_("gg2DrUQECO",!0)),Sinhala:()=>new m(_("hsDCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBt-gCTB",!1)),Sogdian:()=>new m(_("w5jCpB",!0)),Sora_Sompeng:()=>new m(_("wmkCYIJ",!0)),Soyombo:()=>new m(_("wymCyC",!0)),Sundanese:()=>new m(_("g8G-BhIH",!0)),Sunuwar:()=>new m(_("g+mChBPJ",!0)),Syloti_Nagri:()=>new m(_("ggqBsB",!0)),Syriac:()=>new m(_("g4BNC7BDCxIK",!0)),Tagalog:()=>new m(_("g4FVKA",!0)),Tagbanwa:()=>new m(_("g7FMCCCB",!0)),Tai_Le:()=>new m(_("wqGdDE",!0)),Tai_Tham:()=>new m(_("gxG+BCcDKHJHN",!0)),Tai_Viet:()=>new m(_("g0qBiCZE",!0)),Tai_Yo:()=>new m(_("g25DeCVJB",!0)),Takri:()=>new m(_("g0lC5BHJ",!0)),Tamil:()=>new m(_("i8CBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBm+kCxBBOAB",!1)),Tangsa:()=>new m(_("wz6CuCCJ",!0)),Tangut:()=>new m(_("g-7CgBgBB+3GBhQeBiDyDB",!1)),Telugu:()=>new m(_("ggDMCCCWCPDICCCDIBCCCBDDDJII",!0)),Thaana:()=>new m(_("g8BxB",!0)),Thai:()=>new m(_("hwD5BGb",!0)),Tibetan:()=>new m(_("g4DnCCjBFmBCjBCOCGFB",!0)),Tifinagh:()=>new m(_("wpL3BIBPA",!0)),Tirhuta:()=>new m(_("gklCnCJJ",!0)),Todhri:()=>new m(_("guhCzB",!0)),Tolong_Siki:()=>new m(_("wtnCrBFJ",!0)),Toto:()=>new m(_("w04De",!0)),Tulu_Tigalari:()=>new m(_("g8kCJBCDDClBBCJBCDDCDBCJBCBBJBB",!1)),Ugaritic:()=>new m(_("g8gCdCA",!0)),Unknown:()=>new m(_("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-FB",!1)),Vai:()=>new m(_("gopBrJ",!0)),Vithkuqi:()=>new m(_("wrhCKCOCGCBCKCOCGCB",!0)),Wancho:()=>new m(_("g24D5BGA",!0)),Warang_Citi:()=>new m(_("glmCyCNA",!0)),Yezidi:()=>new m(_("g0jCpBCCDB",!0)),Yi:()=>new m(_("ggoBskBE2B",!0)),Zanabazar_Square:()=>new m(_("gwmCnC",!0))})),U(Mn,"FOLD_CATEGORIES",new Ko({L:()=>new m(_("laA",!0)),LC:()=>new m(_("laA",!0)),Ll:()=>new m(_("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGC3HrBrBCEEJHHCCBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHxC9zC9zCBuBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Lt:()=>new m(_("kOCCBCCBCClBCCtsHHBJHBJHBMQQwBAB",!1)),Lu:()=>new m(_("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpL2B2Bs1CvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1)),M:()=>new m(_("5cgBgBlgHAB",!1)),Mn:()=>new m(_("5cgBgBlgHAB",!1)),Emoji:()=>new m(_("8mJA",!0)),Extended_Pictographic:()=>new m(_("8mJA",!0)),Lowercase:()=>new m(_("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHuBPBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Math:()=>new m(_("ycGDCHHFMMDDDCHHFAB",!1)),Uppercase:()=>new m(_("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpLiBiBBOBFsasaBYBn6BvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1))})),U(Mn,"FOLD_SCRIPT",new Ko({Common:()=>new m(_("8cgBgB",!1)),Greek:()=>new m(_("1FwUwU",!1)),Inherited:()=>new m(_("5cgBgBlgHAB",!1))})),Mn),Te,z=(Te=class{static is32(e,t){let s=0,r=e.length;for(;s<r;){const i=s+Math.floor((r-s)/2),o=e.getLo(i),a=e.getHi(i);if(o<=t&&t<=a){const B=e.getStride(i);return(t-o)%B===0}t<o?r=i:s=i+1}return!1}static is(e,t){if(t<=Te.MAX_LATIN1){for(let s=0;s<e.length;s++){if(t>e.getHi(s))continue;const r=e.getLo(s);if(t<r)return!1;const i=e.getStride(s);return(t-r)%i===0}return!1}return e.length>0&&t>=e.getLo(0)&&Te.is32(e,t)}static isUpper(e){if(e<=Te.MAX_LATIN1){const t=String.fromCodePoint(e);return t.toUpperCase()===t&&t.toLowerCase()!==t}return Te.is(yt.Upper,e)}static isPrint(e){return e<=Te.MAX_LATIN1?e>=32&&e<Te.MAX_ASCII||e>=161&&e!==173:Te.is(yt.Print,e)}static simpleFold(e){if(yt.CASE_ORBIT.has(e))return yt.CASE_ORBIT.get(e);const t=L.toLowerCase(e);return t!==e?t:L.toUpperCase(e)}static equalsIgnoreCase(e,t){if(e===t)return!0;if(e<0||t<0)return!1;if(e<=Te.MAX_ASCII&&t<=Te.MAX_ASCII)return 65<=e&&e<=90&&(e|=32),65<=t&&t<=90&&(t|=32),e===t;for(let s=Te.simpleFold(e);s!==e;s=Te.simpleFold(s))if(s===t)return!0;return!1}},U(Te,"MAX_RUNE",1114111),U(Te,"MAX_ASCII",127),U(Te,"MAX_LATIN1",255),U(Te,"MAX_BMP",65535),U(Te,"MIN_FOLD",65),U(Te,"MAX_FOLD",125251),U(Te,"MIN_HIGH_SURROGATE",55296),U(Te,"MAX_HIGH_SURROGATE",56319),U(Te,"MIN_LOW_SURROGATE",56320),U(Te,"MAX_LOW_SURROGATE",57343),U(Te,"MIN_SUPPLEMENTARY_CODE_POINT",65536),Te);const Ac=256,Fp=new Uint8Array(Ac);for(let n=0;n<Ac;n++)Fp[n]=97<=n&&n<=122||65<=n&&n<=90||48<=n&&n<=57||n===95?1:0;let cB=null,uB=null;var Ne,Y=(Ne=class{static emptyInts(){return[]}static isByteArray(e){return Array.isArray(e)||e instanceof Uint8Array}static isalnum(e){return L.CODES.get("0")<=e&&e<=L.CODES.get("9")||L.CODES.get("a")<=e&&e<=L.CODES.get("z")||L.CODES.get("A")<=e&&e<=L.CODES.get("Z")}static unhex(e){return L.CODES.get("0")<=e&&e<=L.CODES.get("9")?e-L.CODES.get("0"):L.CODES.get("a")<=e&&e<=L.CODES.get("f")?e-L.CODES.get("a")+10:L.CODES.get("A")<=e&&e<=L.CODES.get("F")?e-L.CODES.get("A")+10:-1}static escapeRune(e){let t="";if(z.isPrint(e))Ne.METACHARACTERS.indexOf(String.fromCodePoint(e))>=0&&(t+="\\"),t+=String.fromCodePoint(e);else switch(e){case L.CODES.get('"'):t+='\\"';break;case L.CODES.get("\\"):t+="\\\\";break;case L.CODES.get("	"):t+="\\t";break;case L.CODES.get(`
`):t+="\\n";break;case L.CODES.get("\r"):t+="\\r";break;case L.CODES.get("\b"):t+="\\b";break;case L.CODES.get("\f"):t+="\\f";break;default:{let s=e.toString(16);e<256?(t+="\\x",s.length===1&&(t+="0"),t+=s):t+=`\\x{${s}}`;break}}return t}static stringToRunes(e){const t=String(e),s=[];let r=0;for(;r<t.length;){const i=t.codePointAt(r);s.push(i),r+=i>z.MAX_BMP?2:1}return s}static runeToString(e){return String.fromCodePoint(e)}static isWordRune(e){return e<Ac?Fp[e]===1:!1}static emptyOpContext(e,t){let s=0;return e<0&&(s|=Ne.EMPTY_BEGIN_TEXT|Ne.EMPTY_BEGIN_LINE),e===10&&(s|=Ne.EMPTY_BEGIN_LINE),t<0&&(s|=Ne.EMPTY_END_TEXT|Ne.EMPTY_END_LINE),t===10&&(s|=Ne.EMPTY_END_LINE),Ne.isWordRune(e)!==Ne.isWordRune(t)?s|=Ne.EMPTY_WORD_BOUNDARY:s|=Ne.EMPTY_NO_WORD_BOUNDARY,s}static quoteMeta(e){return e.split("").map(t=>Ne.METACHARACTERS.indexOf(t)>=0?`\\${t}`:t).join("")}static charCount(e){return e>z.MAX_BMP?2:1}static toArray(e){const t=e.length,s=new Array(t);for(let r=0;r<t;r++)s[r]=e[r];return s}static stringToUtf8ByteArray(e){if(globalThis.TextEncoder)return cB||(cB=new TextEncoder),cB.encode(e);{let t=[],s=0;for(let r=0;r<e.length;r++){let i=e.charCodeAt(r);i<128?t[s++]=i:i<2048?(t[s++]=i>>6|192,t[s++]=i&63|128):(i&64512)===z.MIN_HIGH_SURROGATE&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===z.MIN_LOW_SURROGATE?(i=z.MIN_SUPPLEMENTARY_CODE_POINT+((i&1023)<<10)+(e.charCodeAt(++r)&1023),t[s++]=i>>18|240,t[s++]=i>>12&63|128,t[s++]=i>>6&63|128,t[s++]=i&63|128):(t[s++]=i>>12|224,t[s++]=i>>6&63|128,t[s++]=i&63|128)}return t}}static utf8ByteArrayToString(e){if(globalThis.TextDecoder){uB||(uB=new TextDecoder("utf-8"));const t=e instanceof Uint8Array?e:new Uint8Array(e);return uB.decode(t)}else{let t=[],s=0,r=0;for(;s<e.length;){let i=e[s++];if(i<128)t[r++]=String.fromCharCode(i);else if(i>191&&i<224){let o=e[s++];t[r++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){let o=e[s++],a=e[s++],B=e[s++],c=((i&7)<<18|(o&63)<<12|(a&63)<<6|B&63)-z.MIN_SUPPLEMENTARY_CODE_POINT;t[r++]=String.fromCharCode(z.MIN_HIGH_SURROGATE+(c>>10)),t[r++]=String.fromCharCode(z.MIN_LOW_SURROGATE+(c&1023))}else{let o=e[s++],a=e[s++];t[r++]=String.fromCharCode((i&15)<<12|(o&63)<<6|a&63)}}return t.join("")}}},U(Ne,"METACHARACTERS","\\.+*?()|[]{}^$"),U(Ne,"EMPTY_BEGIN_LINE",1),U(Ne,"EMPTY_END_LINE",2),U(Ne,"EMPTY_BEGIN_TEXT",4),U(Ne,"EMPTY_END_TEXT",8),U(Ne,"EMPTY_WORD_BOUNDARY",16),U(Ne,"EMPTY_NO_WORD_BOUNDARY",32),U(Ne,"EMPTY_ALL",-1),Ne);const Op=(n=[],e=0)=>{const t=Object.create(null);for(let s=0;s<n.length;s++){const r=n[s],i=e+s;t[r]=i,t[i]=r}return Object.freeze(t)};var Jn,Gs=(Jn=class{getEncoding(){throw Error("not implemented")}asCharSequence(){throw Error("not implemented")}asBytes(){throw Error("not implemented")}length(){throw Error("not implemented")}isUTF8Encoding(){return this.getEncoding()===Jn.Encoding.UTF_8}isUTF16Encoding(){return this.getEncoding()===Jn.Encoding.UTF_16}},U(Jn,"Encoding",Op(["UTF_16","UTF_8"])),Jn),xf=class extends Gs{constructor(n=null){super(),this.bytes=n}getEncoding(){return Gs.Encoding.UTF_8}asCharSequence(){return Y.utf8ByteArrayToString(this.bytes)}asBytes(){return this.bytes}length(){return this.bytes.length}},Pw=class extends Gs{constructor(n=null){super(),this.charSequence=n}getEncoding(){return Gs.Encoding.UTF_16}asCharSequence(){return this.charSequence}asBytes(){return Y.stringToUtf8ByteArray(this.charSequence.toString())}length(){return this.charSequence.length}},Ss=class{static utf16(n){return new Pw(n)}static utf8(n){return Y.isByteArray(n)?new xf(n):new xf(Y.stringToUtf8ByteArray(n))}},gt=class{static EOF(){return-8}constructor(){this.end=0}canCheckPrefix(){return!0}endPos(){return this.end}hasString(){return!1}hasAnyString(){return!1}prefixLength(){return 0}},Fw=class extends gt{constructor(n,e=0,t=n.length){super(),this.bytes=n,this.start=e,this.end=t}hasString(n,e){const t=n.bytes;if(t.length===0)return!0;const s=this.indexOf(this.bytes,t,this.start+e);return s!==-1&&s<=this.end-t.length}hasAnyString(n,e){return n.ac8?n.ac8.searchUTF8(this.bytes,this.start+e,this.end):!1}step(n){if(n+=this.start,n>=this.end)return gt.EOF();const e=this.bytes[n]&255;if(e<128)return e<<3|1;if(e>=194&&e<=223&&n+1<this.end){const t=this.bytes[n+1]&255;return(t&192)!==128?e<<3|1:((e&31)<<6|t&63)<<3|2}else if(e>=224&&e<=239&&n+2<this.end){const t=this.bytes[n+1]&255;if((t&192)!==128)return e<<3|1;const s=this.bytes[n+2]&255;return(s&192)!==128?e<<3|1:((e&15)<<12|(t&63)<<6|s&63)<<3|3}else if(e>=240&&e<=244&&n+3<this.end){const t=this.bytes[n+1]&255;if((t&192)!==128)return e<<3|1;const s=this.bytes[n+2]&255;if((s&192)!==128)return e<<3|1;const r=this.bytes[n+3]&255;return(r&192)!==128?e<<3|1:((e&7)<<18|(t&63)<<12|(s&63)<<6|r&63)<<3|4}else return e<<3|1}index(n,e){e+=this.start;const t=this.indexOf(this.bytes,n.prefixUTF8,e);return t<0?t:t-e}context(n){n+=this.start;let e=-1;if(n>this.start&&n<=this.end){let s=n-1;if(e=this.bytes[s--],e>=128){let r=n-4;for(r<this.start&&(r=this.start);s>=r&&(this.bytes[s]&192)===128;)s--;s<this.start&&(s=this.start),e=this.step(s-this.start)>>3}}const t=n<this.end?this.step(n-this.start)>>3:-1;return Y.emptyOpContext(e,t)}indexOf(n,e,t=0){let s=e.length;if(s===0)return t<=this.end?t:-1;const r=e[0];let i=this.end-s;const o=typeof n.indexOf=="function";let a=t;for(;a<=i;){if(o){if(a=n.indexOf(r,a),a===-1||a>i)return-1}else{for(;a<=i&&n[a]!==r;)a++;if(a>i)return-1}let B=!0;for(let c=1;c<s;c++)if(n[a+c]!==e[c]){B=!1;break}if(B)return a;a++}return-1}prefixLength(n){return n.prefixUTF8.length}},Ow=class extends gt{constructor(n,e=0,t=n.length){super(),this.charSequence=n,this.start=e,this.end=t}hasString(n,e){const t=this.charSequence.indexOf(n.str,this.start+e);return t!==-1&&t<=this.end-n.str.length}hasAnyString(n,e){return n.ac16?n.ac16.searchUTF16(this.charSequence,this.start+e,this.end):!1}step(n){if(n+=this.start,n>=this.end)return gt.EOF();const e=this.charSequence.charCodeAt(n);if(e<z.MIN_HIGH_SURROGATE||e>z.MAX_HIGH_SURROGATE||n+1>=this.end)return e<<3|1;const t=this.charSequence.charCodeAt(n+1);return t>=z.MIN_LOW_SURROGATE&&t<=z.MAX_LOW_SURROGATE?(e-z.MIN_HIGH_SURROGATE)*1024+(t-z.MIN_LOW_SURROGATE)+z.MIN_SUPPLEMENTARY_CODE_POINT<<3|2:e<<3|1}index(n,e){e+=this.start;const t=this.charSequence.indexOf(n.prefix,e);return t<0||t>this.end-n.prefix.length?-1:t-e}context(n){n+=this.start;const e=n>this.start&&n<=this.end?this.charSequence.charCodeAt(n-1):-1,t=n<this.end?this.charSequence.charCodeAt(n):-1;return Y.emptyOpContext(e,t)}prefixLength(n){return n.prefix.length}},be=class{static fromUTF8(n,e=0,t=n.length){return new Fw(n,e,t)}static fromUTF16(n,e=0,t=n.length){return new Ow(n,e,t)}},io=class extends Error{constructor(n){super(n),this.name="RE2JSException"}},Ae=class extends io{constructor(n,e=null){let t=`error parsing regexp: ${n}`;e&&(t+=`: \`${e}\``),super(t),this.name="RE2JSSyntaxException",this.message=t,this.error=n,this.input=e}getDescription(){return this.error}getPattern(){return this.input}},Lw=class extends io{constructor(n){super(n),this.name="RE2JSCompileException"}},Dt=class extends io{constructor(n){super(n),this.name="RE2JSGroupException"}},xw=class extends io{constructor(n){super(n),this.name="RE2JSFlagsException"}},gi=class extends io{constructor(n){super(n),this.name="RE2JSInternalException"}},Ps,kf=(Ps=class{static quoteReplacement(e,t=!1){return t?e.indexOf("\\")<0&&e.indexOf("$")<0?e:e.split("").map(s=>{const r=s.codePointAt(0);return r===L.CODES.get("\\")||r===L.CODES.get("$")?`\\${s}`:s}).join(""):e.indexOf("$")<0?e:e.split("").map(s=>s.codePointAt(0)===L.CODES.get("$")?"$$":s).join("")}constructor(e,t){if(e===null)throw new Error("pattern is null");this.patternInput=e;const s=this.patternInput.re2();this.patternGroupCount=s.numberOfCapturingGroups(),this.groups=[],this.namedGroups=s.namedGroups,this.numberOfInstructions=s.numberOfInstructions(),t instanceof Gs?this.resetMatcherInput(t):Y.isByteArray(t)?this.resetMatcherInput(Ss.utf8(t)):this.resetMatcherInput(Ss.utf16(t))}pattern(){return this.patternInput}reset(){return this.matcherInputLength=this.matcherInput.length(),this.appendPos=0,this.hasMatch=!1,this.hasGroups=!1,this.anchorFlag=0,this}resetMatcherInput(e){if(e===null)throw new Error("input is null");return e instanceof Gs||(Y.isByteArray(e)?e=Ss.utf8(e):e=Ss.utf16(e)),this.matcherInput=e,this.reset(),this}start(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new Dt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e]}end(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new Dt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e+1]}programSize(){return this.numberOfInstructions}group(e=0){if(typeof e=="string"){const r=this.namedGroups[e];if(!Number.isFinite(r))throw new Dt(`group '${e}' not found`);e=r}const t=this.start(e),s=this.end(e);return t<0&&s<0?null:this.substring(t,s)}getNamedGroups(){if(!this.hasMatch)throw new Dt("perhaps no match attempted");const e=Object.create(null);for(const t of Object.keys(this.namedGroups))e[t]=this.group(t);return e}groupCount(){return this.patternGroupCount}loadGroup(e){if(e<0||e>this.patternGroupCount)throw new Dt(`Group index out of bounds: ${e}`);if(!this.hasMatch)throw new Dt("perhaps no match attempted");if(e===0||this.hasGroups)return;const t=this.matcherInputLength,s=this.patternInput.re2().matchMachineInput(this.matcherInput,this.groups[0],t,this.anchorFlag,1+this.patternGroupCount);if(!s[0])throw new Dt("inconsistency in matching group data");this.groups=s[1],this.hasGroups=!0}matches(){return this.genMatch(0,V.ANCHOR_BOTH)}lookingAt(){return this.genMatch(0,V.ANCHOR_START)}find(e=null){if(e!==null){if(e<0||e>this.matcherInputLength)throw new Dt(`start index out of bounds: ${e}`);return this.reset(),this.genMatch(e,0)}if(e=0,this.hasMatch&&(e=this.groups[1],this.groups[0]===this.groups[1])){const t=(this.matcherInput.isUTF16Encoding()?be.fromUTF16(this.matcherInput.asCharSequence(),0,this.matcherInputLength):be.fromUTF8(this.matcherInput.asBytes(),0,this.matcherInputLength)).step(e);t<0?e++:e+=t&7}return this.genMatch(e,V.UNANCHORED)}genMatch(e,t){const s=this.patternInput.re2().matchMachineInput(this.matcherInput,e,this.matcherInputLength,t,1);return s[0]?(this.groups=s[1],this.hasMatch=!0,this.hasGroups=this.patternGroupCount===0,this.anchorFlag=t,!0):(this.hasMatch=!1,!1)}substring(e,t){return this.matcherInput.isUTF8Encoding()?Y.utf8ByteArrayToString(this.matcherInput.asBytes().slice(e,t)):this.matcherInput.asCharSequence().substring(e,t).toString()}inputLength(){return this.matcherInputLength}appendReplacement(e,t=!1){let s="";const r=this.start(),i=this.end();return this.appendPos<r&&(s+=this.substring(this.appendPos,r)),this.appendPos=i,s+=t?this.appendReplacementInternalJava(e):this.appendReplacementInternalJs(e),s}appendReplacementInternalJava(e){let t="",s=0;const r=e.length;let i=0;for(;i<r;){const o=e.codePointAt(i);if(o===L.CODES.get("\\")){if(s<i&&(t+=e.substring(s,i)),i++,i>=r)throw new Dt("character to be escaped is missing");s=i,i++;continue}if(o===L.CODES.get("$")){if(s<i&&(t+=e.substring(s,i)),i+1>=r)throw new Dt("Illegal group reference: group index is missing");const a=e.codePointAt(i+1);if(L.CODES.get("0")<=a&&a<=L.CODES.get("9")){let B=a-L.CODES.get("0"),c=i+2;for(;c<r;c++){const f=e.codePointAt(c);if(f<L.CODES.get("0")||f>L.CODES.get("9")||B*10+f-L.CODES.get("0")>this.patternGroupCount)break;B=B*10+f-L.CODES.get("0")}if(B>this.patternGroupCount)throw new Dt(`n > number of groups: ${B}`);const u=this.group(B);u!==null&&(t+=u),i=c,s=i}else if(a===L.CODES.get("{")){let B=i+2;for(;B<r&&e.codePointAt(B)!==L.CODES.get("}");)B++;if(B>=r)throw new Dt("named capture group is missing trailing '}'");const c=e.substring(i+2,B),u=this.group(c);u!==null&&(t+=u),i=B+1,s=i}else throw new Dt("Illegal group reference");continue}i++}return s<r&&(t+=e.substring(s,r)),t}appendReplacementInternalJs(e){let t="",s=0;const r=e.length;for(let i=0;i<r-1;i++)if(e.codePointAt(i)===L.CODES.get("$")){let o=e.codePointAt(i+1);if(L.CODES.get("$")===o){s<i&&(t+=e.substring(s,i)),t+="$",i++,s=i+1;continue}else if(L.CODES.get("&")===o){s<i&&(t+=e.substring(s,i));const a=this.group(0);a!==null?t+=a:t+="$&",i++,s=i+1;continue}else if(L.CODES.get("`")===o){s<i&&(t+=e.substring(s,i)),t+=this.substring(0,this.start(0)),i++,s=i+1;continue}else if(L.CODES.get("'")===o){s<i&&(t+=e.substring(s,i)),t+=this.substring(this.end(0),this.matcherInputLength),i++,s=i+1;continue}else if(L.CODES.get("1")<=o&&o<=L.CODES.get("9")){let a=o-L.CODES.get("0");for(s<i&&(t+=e.substring(s,i)),i+=2;i<r&&(o=e.codePointAt(i),!(o<L.CODES.get("0")||o>L.CODES.get("9")||a*10+o-L.CODES.get("0")>this.patternGroupCount));i++)a=a*10+o-L.CODES.get("0");if(a>this.patternGroupCount){t+=`$${a}`,s=i,i--;continue}const B=this.group(a);B!==null&&(t+=B),s=i,i--;continue}else if(o===L.CODES.get("<")){s<i&&(t+=e.substring(s,i)),i++;let a=i+1;for(;a<e.length&&e.codePointAt(a)!==L.CODES.get(">")&&e.codePointAt(a)!==L.CODES.get(" ");)a++;if(a===e.length||e.codePointAt(a)!==L.CODES.get(">")){t+=e.substring(i-1,a+1),s=a+1,i=a;continue}const B=e.substring(i+1,a);if(Object.prototype.hasOwnProperty.call(this.namedGroups,B)){const c=this.group(B);c!==null&&(t+=c)}else t+=`$<${B}>`;s=a+1,i=a;continue}}return s<r&&(t+=e.substring(s,r)),t}appendTail(){return this.substring(this.appendPos,this.matcherInputLength)}replaceAll(e,t=!1){return this.replace(e,!0,t)}replaceFirst(e,t=!1){return this.replace(e,!1,t)}replace(e,t=!0,s=!1){let r="";this.reset();const i=typeof e=="function",o=Object.keys(this.namedGroups).length>0;let a=null;if(i){if(this.groupCount()>=Ps.MAX_REPLACER_ARGS)throw new Dt("Too many capture groups to safely invoke replacer function");a=this.matcherInput.isUTF8Encoding()?this.matcherInput.asBytes():this.matcherInput.asCharSequence()}for(;this.find()&&(r+=i?this.appendReplacementFunc(e,o,a):this.appendReplacement(e,s),!!t););return r+=this.appendTail(),r}appendReplacementFunc(e,t,s){let r="";const i=this.start(),o=this.end();this.appendPos<i&&(r+=this.substring(this.appendPos,i)),this.appendPos=o;const a=this.buildReplacerArgs(i,t,s);return r+=String(e(...a)),r}buildReplacerArgs(e,t,s){const r=[this.group(0)],i=this.groupCount();for(let o=1;o<=i;o++){const a=this.start(o);a<0?r.push(void 0):r.push(this.substring(a,this.end(o)))}if(r.push(e),r.push(s),t){const o=this.getNamedGroups();for(const a in o)o[a]===null&&(o[a]=void 0);r.push(o)}return r}},U(Ps,"MAX_REPLACER_ARGS",65535),Ps),fe,x=(fe=class{static isRuneOp(e){return fe.RUNE<=e&&e<=fe.RUNE_ANY_NOT_NL}static escapeRunes(e){let t='"';for(let s of e)t+=Y.escapeRune(s);return t+='"',t}constructor(e){this.op=e,this.out=0,this.arg=0,this.runes=[],this.next=null}matchRune(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&V.FOLD_CASE?z.equalsIgnoreCase(o,e):e===o}const t=this.runes.length;if(t===0)return!1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return!1;if(e<=this.runes[o+1])return!0}return!1}let s=0,r=t>>1;for(;r>1;){const o=r>>1;s+=this.runes[s+o<<1]<=e?o:0,r-=o}s+=this.runes[s<<1]<=e?1:0;const i=s-1;return i>=0&&e<=this.runes[i<<1|1]}matchRunePos(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&V.FOLD_CASE?z.equalsIgnoreCase(o,e)?0:-1:e===o?0:-1}const t=this.runes.length;if(t===0)return-1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return-1;if(e<=this.runes[o+1])return Math.floor(o/2)}return-1}let s=0,r=t>>1;for(;r>1;){const o=r>>1;s+=this.runes[s+o<<1]<=e?o:0,r-=o}s+=this.runes[s<<1]<=e?1:0;const i=s-1;return i>=0&&e<=this.runes[i<<1|1]?i:-1}toString(){switch(this.op){case fe.ALT:return`alt -> ${this.out}, ${this.arg}`;case fe.ALT_MATCH:return`altmatch -> ${this.out}, ${this.arg}`;case fe.CAPTURE:return`cap ${this.arg} -> ${this.out}`;case fe.EMPTY_WIDTH:return`empty ${this.arg} -> ${this.out}`;case fe.MATCH:return`match${this.arg!==0?` ${this.arg}`:""}`;case fe.FAIL:return"fail";case fe.NOP:return`nop -> ${this.out}`;case fe.LB_WRITE:return`lbwrite ${this.arg} -> ${this.out}`;case fe.LB_CHECK:return`lbcheck ${this.arg} -> ${this.out}`;case fe.RUNE:return this.runes===null?"rune <null>":["rune ",fe.escapeRunes(this.runes),this.arg&V.FOLD_CASE?"/i":""," -> ",this.out].join("");case fe.RUNE1:return`rune1 ${fe.escapeRunes(this.runes)} -> ${this.out}`;case fe.RUNE_ANY:return`any -> ${this.out}`;case fe.RUNE_ANY_NOT_NL:return`anynotnl -> ${this.out}`;default:throw new Error("unhandled case in Inst.toString")}}},U(fe,"ALT",1),U(fe,"ALT_MATCH",2),U(fe,"CAPTURE",3),U(fe,"EMPTY_WIDTH",4),U(fe,"FAIL",5),U(fe,"MATCH",6),U(fe,"NOP",7),U(fe,"RUNE",8),U(fe,"RUNE1",9),U(fe,"RUNE_ANY",10),U(fe,"RUNE_ANY_NOT_NL",11),U(fe,"LB_WRITE",12),U(fe,"LB_CHECK",13),fe),Mf=class{constructor(n){this.sparse=new Int32Array(n),this.densePcs=new Int32Array(n),this.denseCaps=null,this.size=0,this.ncap=0}init(n){this.ncap=n;const e=this.densePcs.length*n;(!this.denseCaps||this.denseCaps.length<e)&&(this.denseCaps=new Int32Array(e))}contains(n){const e=this.sparse[n];return e<this.size&&this.densePcs[e]===n}isEmpty(){return this.size===0}add(n){const e=this.size++;return this.sparse[n]=e,this.densePcs[e]=n,e}clear(){this.size=0}toString(){let n="{";for(let e=0;e<this.size;e++)e!==0&&(n+=", "),n+=this.densePcs[e];return n+="}",n}},kw=class kB{static fromRE2(e){const t=new kB;return t.prog=e.prog,t.re2=e,t.q0=new Mf(t.prog.numInst()),t.q1=new Mf(t.prog.numInst()),t.matched=!1,t.matchcap=new Int32Array(t.prog.numCap<2?2:t.prog.numCap),t.ncap=0,t}static fromMachine(e){return kB.fromRE2(e.re2)}constructor(){this.prog=null,this.re2=null,this.q0=null,this.q1=null,this.matched=!1,this.matchcap=null,this.ncap=0,this.lbTable=null}init(e){this.ncap=e,e>this.matchcap.length?this.matchcap=new Int32Array(e).fill(-1):this.matchcap.fill(-1),this.q0.init(e),this.q1.init(e),this.prog.numLb>0&&((!this.lbTable||this.lbTable.length<this.prog.numLb+1)&&(this.lbTable=new Int32Array(this.prog.numLb+1)),this.lbTable.fill(-1))}submatches(){return this.ncap===0?Y.emptyInts():Y.toArray(this.matchcap.subarray(0,this.ncap))}match(e,t,s){const r=this.re2.cond;if(r===Y.EMPTY_ALL||(s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&t!==0)return!1;this.matched=!1,this.matchcap.fill(-1);let i=this.prog.numLb>0?0:t,o=t,a=this.q0,B=this.q1,c=e.step(i),u=c>>3,f=c&7,C=-1,g=0;c!==gt.EOF()&&(c=e.step(i+f),C=c>>3,g=c&7);let E;for(i===0?E=Y.emptyOpContext(-1,u):E=e.context(i);;){if(a.isEmpty()){if(r&Y.EMPTY_BEGIN_TEXT&&i!==0||(s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&i!==0||this.matched)break;if(this.prog.numLb===0&&this.re2.prefix.length!==0&&C!==this.re2.prefixRune&&e.canCheckPrefix()){const j=e.index(this.re2,i);if(j<0)break;i+=j,c=e.step(i),u=c>>3,f=c&7,c=e.step(i+f),C=c>>3,g=c&7,E=e.context(i)}}if(i===0&&this.prog.numLb>0)for(let j=0;j<this.prog.lbStarts.length;j++)this.add(a,this.prog.lbStarts[j],i,this.matchcap,0,E);!this.matched&&(i===0||s===V.UNANCHORED)&&i>=o&&(this.ncap>0&&(this.matchcap[0]=i),this.add(a,this.prog.start,i,this.matchcap,0,E));const b=i+f;if(E=e.context(b),this.step(a,B,i,b,u,E,s,i===e.endPos()),f===0||this.ncap===0&&this.matched)break;i+=f,u=C,f=g,u!==-1&&(c=e.step(i+f),C=c>>3,g=c&7);const F=a;a=B,B=F}return B.clear(),this.matched}matchSet(e,t,s){const r=this.re2.cond;if(r===Y.EMPTY_ALL)return[];if((s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&t!==0)return[];let i=this.prog.numLb>0?0:t,o=t,a=this.q0,B=this.q1,c=e.step(i),u=c>>3,f=c&7,C=-1,g=0;c!==gt.EOF()&&(c=e.step(i+f),C=c>>3,g=c&7);let E=i===0?Y.emptyOpContext(-1,u):e.context(i);const b=new Set;for(;!(a.isEmpty()&&(r&Y.EMPTY_BEGIN_TEXT&&i!==0||(s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&i!==0));){if(i===0&&this.prog.numLb>0)for(let te=0;te<this.prog.lbStarts.length;te++)this.add(a,this.prog.lbStarts[te],i,this.matchcap,0,E);(i===0||s===V.UNANCHORED)&&i>=o&&this.add(a,this.prog.start,i,this.matchcap,0,E);const F=i+f;E=e.context(F);for(let te=0;te<a.size;te++){const ie=a.densePcs[te],me=this.prog.inst[ie],Me=te*this.ncap;let Le=!1;switch(me.op){case x.MATCH:if(s===V.ANCHOR_BOTH&&i!==e.endPos())break;b.add(me.arg);break;case x.RUNE:Le=me.matchRune(u);break;case x.RUNE1:Le=u===me.runes[0];break;case x.RUNE_ANY:Le=!0;break;case x.RUNE_ANY_NOT_NL:Le=u!==10;break;default:continue}Le&&this.add(B,me.out,F,a.denseCaps,Me,E)}if(a.clear(),f===0)break;i+=f,u=C,f=g,u!==-1&&(c=e.step(i+f),C=c>>3,g=c&7);const j=a;a=B,B=j}return B.clear(),Array.from(b).sort((F,j)=>F-j)}step(e,t,s,r,i,o,a,B){const c=this.re2.longest;for(let u=0;u<e.size;u++){const f=e.densePcs[u],C=u*this.ncap;if(c&&this.matched&&this.ncap>0&&this.matchcap[0]<e.denseCaps[C])continue;const g=this.prog.inst[f];let E=!1;switch(g.op){case x.MATCH:if(a===V.ANCHOR_BOTH&&!B)break;if(this.ncap>0&&(!c||!this.matched||this.matchcap[1]<s)){e.denseCaps[C+1]=s;for(let b=0;b<this.ncap;b++)this.matchcap[b]=e.denseCaps[C+b]}c||(e.size=0),this.matched=!0;break;case x.RUNE:E=g.matchRune(i);break;case x.RUNE1:E=i===g.runes[0];break;case x.RUNE_ANY:E=!0;break;case x.RUNE_ANY_NOT_NL:E=i!==10;break;default:continue}E&&this.add(t,g.out,r,e.denseCaps,C,o)}e.clear()}add(e,t,s,r,i,o){for(;;){if(t===0||e.contains(t))return;const a=e.add(t),B=this.prog.inst[t];switch(B.op){case x.FAIL:return;case x.ALT:case x.ALT_MATCH:this.add(e,B.out,s,r,i,o),t=B.arg;continue;case x.EMPTY_WIDTH:if(!(B.arg&~o)){t=B.out;continue}return;case x.NOP:t=B.out;continue;case x.CAPTURE:if(B.arg<this.ncap){const c=r[i+B.arg];r[i+B.arg]=s,this.add(e,B.out,s,r,i,o),r[i+B.arg]=c;return}else{t=B.out;continue}case x.LB_WRITE:this.lbTable[Math.abs(B.arg)]=s,t=B.out;continue;case x.LB_CHECK:if(B.arg>0){if(this.lbTable[B.arg]===s){t=B.out;continue}}else if(this.lbTable[-B.arg]!==s){t=B.out;continue}return;case x.MATCH:case x.RUNE:case x.RUNE1:case x.RUNE_ANY:case x.RUNE_ANY_NOT_NL:if(this.ncap>0){const c=a*this.ncap;for(let u=0;u<this.ncap;u++)e.denseCaps[c+u]=r[i+u]}return;default:throw new gi("unhandled")}}}};const Vf=n=>{let e=-2128831035;for(let t=0;t<n.length;t++)e^=n[t],e=Math.imul(e,16777619);return e},Mw=(n,e)=>{if(n.length!==e.length)return!1;for(let t=0;t<n.length;t++)if(n[t]!==e[t])return!1;return!0};var Vw=class{constructor(n,e,t=[]){this.nfaStates=n,this.isMatch=e,this.matchIDs=t,this.nextLatin1=new Array(z.MAX_LATIN1+1).fill(null),this.nextLatin1Anchored=new Array(z.MAX_LATIN1+1).fill(null),this.transKeys=[],this.transVals=[],this.lastSeen=0}},pn,Gw=(pn=class{constructor(e,t=8388608){this.prog=e,this.stateCache=new Map,this.stateCount=0,this.startState=null,this.stateLimit=Math.max(1,Math.floor(t/pn.STATE_MEMORY_ESTIMATE)),this.cacheClears=0,this.failed=!1,this.clock=0}computeClosure(e){const t=new Set,s=[...e];let r=!1;const i=[];for(;s.length>0;){const a=s.pop();if(t.has(a))continue;t.add(a);const B=this.prog.getInst(a);switch(B.op){case x.MATCH:r=!0,i.includes(B.arg)||i.push(B.arg);break;case x.ALT:case x.ALT_MATCH:s.push(B.out),s.push(B.arg);break;case x.NOP:case x.CAPTURE:s.push(B.out);break;case x.EMPTY_WIDTH:case x.LB_WRITE:case x.LB_CHECK:return null}}const o=Int32Array.from(t).sort();return i.sort((a,B)=>a-B),{pcs:o,isMatch:r,matchIDs:i}}getState(e){const t=this.computeClosure(e);if(!t)return null;const s=t.pcs,r=Vf(s);let i=this.stateCache.get(r);if(i)for(let a=0;a<i.length;a++){const B=i[a];if(Mw(B.nfaStates,s))return B.lastSeen=++this.clock,B}else i=[],this.stateCache.set(r,i);if(this.failed)return null;if(this.stateCount>=this.stateLimit){if(this.cacheClears++,this.cacheClears>=pn.MAX_CACHE_CLEARS)return this.failed=!0,this.stateCache.clear(),this.stateCount=0,this.startState=null,null;this.evictCache(),i=this.stateCache.get(r),i||(i=[],this.stateCache.set(r,i))}const o=new Vw(s,t.isMatch,t.matchIDs);return o.lastSeen=++this.clock,i.push(o),this.stateCount++,o}evictCache(){const e=[];for(const o of this.stateCache.values())for(let a=0;a<o.length;a++)e.push(o[a]);e.sort((o,a)=>o.lastSeen-a.lastSeen);const t=Math.max(1,Math.floor(this.stateLimit/2)),s=e.length-t,r=e.slice(s),i=new Set(r);this.stateCache.clear(),this.stateCount=0;for(let o=0;o<r.length;o++){const a=r[o];a.nextLatin1.fill(null),a.nextLatin1Anchored.fill(null),a.transKeys.length=0,a.transVals.length=0;const B=Vf(a.nfaStates);let c=this.stateCache.get(B);c||(c=[],this.stateCache.set(B,c)),c.push(a),this.stateCount++}this.startState&&!i.has(this.startState)&&(this.startState=null)}step(e,t,s){if(t<=z.MAX_LATIN1)if(s===V.UNANCHORED){const o=e.nextLatin1[t];if(o!==null)return o}else{const o=e.nextLatin1Anchored[t];if(o!==null)return o}else{const o=t+(s===V.UNANCHORED?0:z.MAX_RUNE+1),a=e.transKeys,B=a.length;for(let c=0;c<B;c++)if(a[c]===o)return e.transVals[c]}const r=[];for(let o=0;o<e.nfaStates.length;o++){const a=e.nfaStates[o],B=this.prog.getInst(a);x.isRuneOp(B.op)&&B.matchRune(t)&&r.push(B.out)}s===V.UNANCHORED&&r.push(this.prog.start);const i=this.getState(r);if(t<=z.MAX_LATIN1)s===V.UNANCHORED?e.nextLatin1[t]=i:e.nextLatin1Anchored[t]=i;else{const o=t+(s===V.UNANCHORED?0:z.MAX_RUNE+1);e.transKeys.push(o),e.transVals.push(i)}return i}match(e,t,s){if((s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&t!==0)return!1;if(!this.startState&&(this.startState=this.getState([this.prog.start]),!this.startState))return null;let r=e.endPos(),i=this.startState;if(i.isMatch)if(s===V.ANCHOR_BOTH){if(t===r)return!0}else return!0;let o=t;for(;o<r;){const a=e.step(o),B=a>>3,c=a&7;if(c===0)break;if(i=s===V.UNANCHORED&&B<=z.MAX_LATIN1&&i.nextLatin1[B]||this.step(i,B,s),i===null)return null;if(i.lastSeen=++this.clock,i.isMatch)if(s===V.ANCHOR_BOTH){if(o+c===r)return!0}else return!0;if(i.nfaStates.length===0&&s!==V.UNANCHORED)return!1;o+=c}return!1}matchSet(e,t,s){if((s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&t!==0)return[];if(!this.startState&&(this.startState=this.getState([this.prog.start]),!this.startState))return null;let r=e.endPos(),i=this.startState;const o=new Set,a=(c,u)=>{c.isMatch&&(s===V.ANCHOR_BOTH?u===r&&c.matchIDs.forEach(f=>o.add(f)):c.matchIDs.forEach(f=>o.add(f)))};a(i,t);let B=t;for(;B<r;){const c=e.step(B),u=c>>3,f=c&7;if(f===0)break;if(i=s===V.UNANCHORED&&u<=z.MAX_LATIN1&&i.nextLatin1[u]||this.step(i,u,s),i===null)return null;if(i.lastSeen=++this.clock,B+=f,a(i,B),i.nfaStates.length===0&&s!==V.UNANCHORED)break}return Array.from(o).sort((c,u)=>c-u)}},U(pn,"MAX_CACHE_CLEARS",5),U(pn,"STATE_MEMORY_ESTIMATE",838),pn);const Hw=32,Uw=500,hB=256,qw=256*1024;var Jw=class{constructor(){this.end=0,this.cap=new Int32Array(0),this.matchcap=new Int32Array(0),this.ncap=0,this.jobPc=new Int32Array(hB),this.jobArg=new Uint8Array(hB),this.jobPos=new Int32Array(hB),this.jobLen=0,this.visited=new Uint32Array(0)}reset(n,e,t){this.end=e,this.jobLen=0,this.ncap=t;const s=n.numInst()*(e+1)+Hw-1>>>5;this.visited.length<s?this.visited=new Uint32Array(s):this.visited.fill(0,0,s),this.cap.length<t?this.cap=new Int32Array(t).fill(-1):this.cap.fill(-1,0,t),this.matchcap.length<t?this.matchcap=new Int32Array(t).fill(-1):this.matchcap.fill(-1,0,t)}shouldVisit(n,e){const t=n*(this.end+1)+e,s=t>>>5,r=1<<(t&31);return this.visited[s]&r?!1:(this.visited[s]|=r,!0)}push(n,e,t,s){if(n.prog.getInst(e).op!==x.FAIL&&(s||this.shouldVisit(e,t))){if(this.jobLen>=this.jobPc.length){const r=this.jobPc.length*2,i=new Int32Array(r);i.set(this.jobPc),this.jobPc=i;const o=new Uint8Array(r);o.set(this.jobArg),this.jobArg=o;const a=new Int32Array(r);a.set(this.jobPos),this.jobPos=a}this.jobPc[this.jobLen]=e,this.jobArg[this.jobLen]=s?1:0,this.jobPos[this.jobLen]=t,this.jobLen++}}tryBacktrack(n,e,t,s,r){const i=n.longest;for(this.push(n,t,s,!1);this.jobLen>0;){this.jobLen--;let o=this.jobPc[this.jobLen],a=this.jobArg[this.jobLen]===1,B=this.jobPos[this.jobLen],c=!0;for(;!(!c&&!this.shouldVisit(o,B));){c=!1;const u=n.prog.getInst(o);switch(u.op){case x.FAIL:throw new gi("unexpected InstFail");case x.ALT:if(a){a=!1,o=u.arg;continue}else{this.push(n,o,B,!0),o=u.out;continue}case x.ALT_MATCH:{const f=n.prog.getInst(u.out);if(x.isRuneOp(f.op)){this.push(n,u.arg,B,!1),o=u.arg,B=this.end;continue}this.push(n,u.out,this.end,!1),o=u.out;continue}case x.RUNE:{const f=e.step(B);if(f===gt.EOF()||!u.matchRune(f>>3))break;B+=f&7,o=u.out;continue}case x.RUNE1:{const f=e.step(B);if(f===gt.EOF()||f>>3!==u.runes[0])break;B+=f&7,o=u.out;continue}case x.RUNE_ANY_NOT_NL:{const f=e.step(B);if(f===gt.EOF()||f>>3===10)break;B+=f&7,o=u.out;continue}case x.RUNE_ANY:{const f=e.step(B);if(f===gt.EOF())break;B+=f&7,o=u.out;continue}case x.CAPTURE:if(a){this.cap[u.arg]=B;break}else{u.arg<this.ncap&&(this.push(n,o,this.cap[u.arg],!0),this.cap[u.arg]=B),o=u.out;continue}case x.EMPTY_WIDTH:{const f=e.context(B);if(u.arg&~f)break;o=u.out;continue}case x.NOP:o=u.out;continue;case x.MATCH:{if(r===V.ANCHOR_BOTH&&B!==this.end)break;if(this.ncap===0)return!0;this.ncap>1&&(this.cap[1]=B);const f=this.matchcap[1];if((f===-1||i&&B>0&&B>f)&&this.matchcap.set(this.cap),!i||B===this.end)return!0;break}case x.LB_WRITE:case x.LB_CHECK:throw new gi("Backtracker cannot evaluate Lookbehind instructions");default:throw new gi("bad inst")}break}}return i&&this.matchcap.length>1&&this.matchcap[1]>=0}};const Qo=[];var zo=class Lp{static shouldBacktrack(e){return e.numInst()<=Uw}static maxBitStateLen(e){return Lp.shouldBacktrack(e)?Math.floor(qw/e.numInst()):0}static execute(e,t,s,r,i){const o=e.cond;if(o===Y.EMPTY_ALL||(r===V.ANCHOR_START||r===V.ANCHOR_BOTH)&&s!==0||o&Y.EMPTY_BEGIN_TEXT&&s!==0)return null;const a=Qo.length>0?Qo.pop():new Jw,B=t.endPos();a.reset(e.prog,B,i);let c=!1;if(o&Y.EMPTY_BEGIN_TEXT||r===V.ANCHOR_START||r===V.ANCHOR_BOTH)a.ncap>0&&(a.cap[0]=s),a.tryBacktrack(e,t,e.prog.start,s,r)&&(c=!0);else{let f=-1;for(;s<=B&&f!==0;s+=f){if(e.prefix.length>0){const g=t.index(e,s);if(g<0)break;s+=g}if(a.ncap>0&&(a.cap[0]=s),a.tryBacktrack(e,t,e.prog.start,s,r)){c=!0;break}const C=t.step(s);f=C===gt.EOF()?0:C&7}}if(!c)return Qo.push(a),null;const u=i===0?[]:Y.toArray(a.matchcap.subarray(0,i));return Qo.push(a),u}},Gf=class{constructor(n){this.sparse=new Uint32Array(n),this.dense=new Uint32Array(n),this.size=0,this.nextIndex=0}empty(){return this.nextIndex>=this.size}next(){return this.dense[this.nextIndex++]}clear(){this.size=0,this.nextIndex=0}contains(n){return n<this.sparse.length&&this.sparse[n]<this.size&&this.dense[this.sparse[n]]===n}insert(n){this.contains(n)||this.insertNew(n)}insertNew(n){n>=this.sparse.length||(this.sparse[n]=this.size,this.dense[this.size]=n,this.size++)}};const jw=(n,e,t,s)=>{const r=n.length,i=e.length;let o=0,a=0;const B=[],c=[];let u=!0,f=-1;const C=g=>{const E=g?n:e,b=g?o:a,F=g?t:s;return f>0&&E[b]<=B[f]?!1:(B.push(E[b],E[b+1]),g?o+=2:a+=2,f+=2,c.push(F),!0)};for(;o<r||a<i;)if(a>=i?u=C(!0):o>=r||e[a]<n[o]?u=C(!1):u=C(!0),!u)return null;return{merged:B,next:c}};var Kw=class{constructor(n){this.start=n.start,this.numCap=n.numCap,this.inst=new Array(n.inst.length);for(let e=0;e<n.inst.length;e++){const t=n.inst[e],s=new x(t.op);s.out=t.out,s.arg=t.arg,s.runes=t.runes?t.runes.slice():[],s.next=null,this.inst[e]=s}}};const Qw=n=>{const e=new Kw(n);for(let t=0;t<e.inst.length;t++){const s=e.inst[t];if(s.op!==x.ALT&&s.op!==x.ALT_MATCH)continue;let r="out",i="arg",o=e.inst[s[i]];if(o.op!==x.ALT&&o.op!==x.ALT_MATCH&&(r="arg",i="out",o=e.inst[s[i]],o.op!==x.ALT&&o.op!==x.ALT_MATCH))continue;const a=e.inst[s[r]];if(a.op===x.ALT||a.op===x.ALT_MATCH)continue;let B="out",c="arg",u=!1;o.out===t?u=!0:o.arg===t&&(u=!0,B="arg",c="out"),u&&(o[B]=s[r]),s[r]===o[B]&&(s[i]=o[c])}return e},zw=n=>{if(n.inst.length>=1e3)return null;const e=new Gf(n.inst.length),t=new Gf(n.inst.length),s=new Array(n.inst.length),r=new Array(n.inst.length).fill(!1),i=o=>{let a=!0;const B=n.inst[o];if(t.contains(o))return!0;switch(t.insert(o),B.op){case x.ALT:case x.ALT_MATCH:{a=i(B.out)&&i(B.arg);let c=r[B.out],u=r[B.arg];if(c&&u)return!1;if(u){const E=B.out;B.out=B.arg,B.arg=E;const b=c;c=u,u=b}c&&(r[o]=!0,B.op=x.ALT_MATCH);const f=s[B.out]||[],C=s[B.arg]||[],g=jw(f,C,B.out,B.arg);if(!g)return!1;s[o]=g.merged,B.next=new Uint32Array(g.next);break}case x.CAPTURE:case x.EMPTY_WIDTH:case x.NOP:a=i(B.out),r[o]=r[B.out],s[o]=s[B.out]?s[B.out].slice():[],B.next=new Uint32Array(Math.floor(s[o].length/2)+1).fill(B.out);break;case x.MATCH:case x.FAIL:r[o]=B.op===x.MATCH;break;case x.RUNE:{if(r[o]=!1,B.next&&B.next.length>0)break;if(e.insert(B.out),!B.runes||B.runes.length===0){s[o]=[],B.next=new Uint32Array([B.out]);break}let c=[];if(B.runes.length===1&&B.arg&V.FOLD_CASE){const u=B.runes[0];c.push(u,u);for(let f=z.simpleFold(u);f!==u;f=z.simpleFold(f))c.push(f,f);c.sort((f,C)=>f-C)}else for(let u=0;u<B.runes.length;u++)c.push(B.runes[u]);s[o]=c,B.next=new Uint32Array(Math.floor(c.length/2)+1).fill(B.out),B.op=x.RUNE;break}case x.RUNE1:{if(r[o]=!1,B.next&&B.next.length>0)break;e.insert(B.out);let c=[];if(B.arg&V.FOLD_CASE){const u=B.runes[0];c.push(u,u);for(let f=z.simpleFold(u);f!==u;f=z.simpleFold(f))c.push(f,f);c.sort((f,C)=>f-C)}else c.push(B.runes[0],B.runes[0]);s[o]=c,B.next=new Uint32Array(Math.floor(c.length/2)+1).fill(B.out),B.op=x.RUNE;break}case x.RUNE_ANY:if(r[o]=!1,B.next&&B.next.length>0)break;e.insert(B.out),s[o]=[0,z.MAX_RUNE],B.next=new Uint32Array([B.out]);break;case x.RUNE_ANY_NOT_NL:if(r[o]=!1,B.next&&B.next.length>0)break;e.insert(B.out),s[o]=[0,9,11,z.MAX_RUNE],B.next=new Uint32Array(Math.floor(s[o].length/2)+1).fill(B.out);break}return a};for(e.clear(),e.insert(n.start);!e.empty();)if(t.clear(),!i(e.next()))return null;for(let o=0;o<n.inst.length;o++)s[o]&&(n.inst[o].runes=s[o]);return n},Ww=(n,e)=>{for(let t=0;t<e.inst.length;t++){const s=e.inst[t];switch(s.op){case x.ALT:case x.ALT_MATCH:case x.RUNE:break;case x.CAPTURE:case x.EMPTY_WIDTH:case x.NOP:case x.MATCH:case x.FAIL:n.inst[t].next=null;break;case x.RUNE1:case x.RUNE_ANY:case x.RUNE_ANY_NOT_NL:n.inst[t].next=null,n.inst[t].op=s.op,n.inst[t].runes=s.runes?s.runes.slice():[];break}}};var Hf=class xp{static compile(e){if(e.start===0||e.numLb>0)return null;const t=e.inst[e.start];if(t.op!==x.EMPTY_WIDTH||!(t.arg&Y.EMPTY_BEGIN_TEXT))return null;let s=!1;for(let i=0;i<e.inst.length;i++)if(e.inst[i].op===x.ALT||e.inst[i].op===x.ALT_MATCH){s=!0;break}for(let i=0;i<e.inst.length;i++){const o=e.inst[i],a=e.inst[o.out].op;switch(o.op){case x.ALT:case x.ALT_MATCH:if(a===x.MATCH||e.inst[o.arg].op===x.MATCH)return null;break;case x.EMPTY_WIDTH:if(a===x.MATCH){if((o.arg&Y.EMPTY_END_TEXT)===Y.EMPTY_END_TEXT)continue;return null}break;default:if(a===x.MATCH&&s)return null;break}}let r=Qw(e);return r=zw(r),r!==null&&Ww(r,e),r}static next(e,t){const s=e.matchRunePos(t);return s>=0?e.next[s]:e.op===x.ALT_MATCH?e.out:0}static execute(e,t,s,r,i){const o=e.onepass;if(!o)return null;const a=new Int32Array(i).fill(-1);let B=!1,c=t.step(s),u=c>>3,f=c&7,C=gt.EOF(),g=-1,E=0;c!==gt.EOF()&&(C=t.step(s+f),C!==gt.EOF()&&(g=C>>3,E=C&7));let b=s===0?Y.emptyOpContext(-1,u):t.context(s),F=o.start,j;for(;;){switch(j=o.inst[F],F=j.out,j.op){case x.MATCH:return r===V.ANCHOR_BOTH&&s!==t.endPos()?null:(B=!0,a.length>0&&(a[0]=0,a[1]=s),i===0?[]:Y.toArray(a));case x.RUNE:if(!j.matchRune(u))return null;break;case x.RUNE1:if(u!==j.runes[0])return null;break;case x.RUNE_ANY:break;case x.RUNE_ANY_NOT_NL:if(u===10)return null;break;case x.ALT:case x.ALT_MATCH:F=xp.next(j,u);continue;case x.FAIL:return null;case x.NOP:continue;case x.EMPTY_WIDTH:if(j.arg&~b)return null;continue;case x.CAPTURE:j.arg<a.length&&(a[j.arg]=s);continue;default:throw new gi("bad inst")}if(f===0)break;b=Y.emptyOpContext(u,g),s+=f,u=g,f=E,u!==-1&&(C=t.step(s+f),C!==gt.EOF()?(g=C>>3,E=C&7):(g=-1,E=0))}return B?i===0?[]:Y.toArray(a):null}},Z,I=(Z=class{static isPseudoOp(e){return e>=Z.Op.LEFT_PAREN}static emptySubs(){return[]}static quoteIfHyphen(e){return e===L.CODES.get("-")?"\\":""}static fromRegexp(e){const t=new Z(e.op);return t.flags=e.flags,t.subs=e.subs,t.runes=e.runes,t.cap=e.cap,t.min=e.min,t.max=e.max,t.name=e.name,t.namedGroups=e.namedGroups,t.lb=e.lb,t}constructor(e){this.op=e,this.flags=0,this.subs=Z.emptySubs(),this.runes=[],this.min=0,this.max=0,this.cap=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}reinit(){this.flags=0,this.subs=Z.emptySubs(),this.runes=[],this.cap=0,this.min=0,this.max=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}toString(){return this.appendTo()}appendTo(){let e="";switch(this.op){case Z.Op.NO_MATCH:e+="[^\\x00-\\x{10FFFF}]";break;case Z.Op.EMPTY_MATCH:e+="(?:)";break;case Z.Op.STAR:case Z.Op.PLUS:case Z.Op.QUEST:case Z.Op.REPEAT:{const t=this.subs[0];switch(t.op>Z.Op.CAPTURE||t.op===Z.Op.LITERAL&&t.runes.length>1?e+=`(?:${t.appendTo()})`:e+=t.appendTo(),this.op){case Z.Op.STAR:e+="*";break;case Z.Op.PLUS:e+="+";break;case Z.Op.QUEST:e+="?";break;case Z.Op.REPEAT:e+=`{${this.min}`,this.min!==this.max&&(e+=",",this.max>=0&&(e+=this.max)),e+="}";break}this.flags&V.NON_GREEDY&&(e+="?");break}case Z.Op.CONCAT:for(let t of this.subs)t.op===Z.Op.ALTERNATE?e+=`(?:${t.appendTo()})`:e+=t.appendTo();break;case Z.Op.ALTERNATE:{let t="";for(let s of this.subs)e+=t,t="|",e+=s.appendTo();break}case Z.Op.LITERAL:this.flags&V.FOLD_CASE&&(e+="(?i:");for(let t of this.runes)e+=Y.escapeRune(t);this.flags&V.FOLD_CASE&&(e+=")");break;case Z.Op.ANY_CHAR_NOT_NL:e+="(?-s:.)";break;case Z.Op.ANY_CHAR:e+="(?s:.)";break;case Z.Op.PLB:e+=`(?<=${this.subs[0].appendTo()})`;break;case Z.Op.NLB:e+=`(?<!${this.subs[0].appendTo()})`;break;case Z.Op.CAPTURE:this.name===null||this.name.length===0?e+="(":e+=`(?P<${this.name}>`,this.subs[0].op!==Z.Op.EMPTY_MATCH&&(e+=this.subs[0].appendTo()),e+=")";break;case Z.Op.BEGIN_TEXT:e+="\\A";break;case Z.Op.END_TEXT:this.flags&V.WAS_DOLLAR?e+="(?-m:$)":e+="\\z";break;case Z.Op.BEGIN_LINE:e+="^";break;case Z.Op.END_LINE:e+="$";break;case Z.Op.WORD_BOUNDARY:e+="\\b";break;case Z.Op.NO_WORD_BOUNDARY:e+="\\B";break;case Z.Op.CHAR_CLASS:if(this.runes.length%2!==0){e+="[invalid char class]";break}if(e+="[",this.runes.length===0)e+="^\\x00-\\x{10FFFF}";else if(this.runes[0]===0&&this.runes[this.runes.length-1]===z.MAX_RUNE){e+="^";for(let t=1;t<this.runes.length-1;t+=2){const s=this.runes[t]+1,r=this.runes[t+1]-1;e+=Z.quoteIfHyphen(s),e+=Y.escapeRune(s),s!==r&&(e+="-",e+=Z.quoteIfHyphen(r),e+=Y.escapeRune(r))}}else for(let t=0;t<this.runes.length;t+=2){const s=this.runes[t],r=this.runes[t+1];e+=Z.quoteIfHyphen(s),e+=Y.escapeRune(s),s!==r&&(e+="-",e+=Z.quoteIfHyphen(r),e+=Y.escapeRune(r))}e+="]";break;default:e+=this.op;break}return e}maxCap(){let e=0;if(this.op===Z.Op.CAPTURE&&(e=this.cap),this.subs!==null)for(let t of this.subs){const s=t.maxCap();e<s&&(e=s)}return e}equals(e){if(!(e!==null&&e instanceof Z)||this.op!==e.op)return!1;switch(this.op){case Z.Op.END_TEXT:if((this.flags&V.WAS_DOLLAR)!==(e.flags&V.WAS_DOLLAR))return!1;break;case Z.Op.LITERAL:case Z.Op.CHAR_CLASS:if(this.runes===null&&e.runes===null)break;if(this.runes===null||e.runes===null||this.runes.length!==e.runes.length)return!1;for(let t=0;t<this.runes.length;t++)if(this.runes[t]!==e.runes[t])return!1;break;case Z.Op.ALTERNATE:case Z.Op.CONCAT:if(this.subs.length!==e.subs.length)return!1;for(let t=0;t<this.subs.length;++t)if(!this.subs[t].equals(e.subs[t]))return!1;break;case Z.Op.STAR:case Z.Op.PLUS:case Z.Op.QUEST:if((this.flags&V.NON_GREEDY)!==(e.flags&V.NON_GREEDY)||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.REPEAT:if((this.flags&V.NON_GREEDY)!==(e.flags&V.NON_GREEDY)||this.min!==e.min||this.max!==e.max||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.CAPTURE:if(this.cap!==e.cap||(this.name===null?e.name!==null:this.name!==e.name)||!this.subs[0].equals(e.subs[0]))return!1;break;case Z.Op.PLB:case Z.Op.NLB:if(this.lb!==e.lb||!this.subs[0].equals(e.subs[0]))return!1;break}return!0}},U(Z,"Op",Op(["NO_MATCH","EMPTY_MATCH","LITERAL","CHAR_CLASS","ANY_CHAR_NOT_NL","ANY_CHAR","BEGIN_LINE","END_LINE","BEGIN_TEXT","END_TEXT","WORD_BOUNDARY","NO_WORD_BOUNDARY","CAPTURE","STAR","PLUS","QUEST","REPEAT","CONCAT","ALTERNATE","PLB","NLB","LEFT_PAREN","VERTICAL_BAR"])),Z),Uf=class{constructor(n){this.next=[Object.create(null)],this.fail=[0],this.match=[!1];for(const t of n){let s=0;for(let r=0;r<t.length;r++){const i=t[r];i in this.next[s]||(this.next.push(Object.create(null)),this.fail.push(0),this.match.push(!1),this.next[s][i]=this.next.length-1),s=this.next[s][i]}this.match[s]=!0}const e=[];for(const t in this.next[0])if(Object.prototype.hasOwnProperty.call(this.next[0],t)){const s=this.next[0][t];this.fail[s]=0,e.push(s)}for(;e.length>0;){const t=e.shift();for(const s in this.next[t])if(Object.prototype.hasOwnProperty.call(this.next[t],s)){const r=this.next[t][s];let i=this.fail[t];for(;i!==0&&!(s in this.next[i]);)i=this.fail[i];s in this.next[i]?this.fail[r]=this.next[i][s]:this.fail[r]=0,this.match[r]=this.match[r]||this.match[this.fail[r]],e.push(r)}}}searchUTF16(n,e,t){let s=0;for(let r=e;r<t;r++){const i=n.charCodeAt(r);for(;s!==0&&!(i in this.next[s]);)s=this.fail[s];if(i in this.next[s]&&(s=this.next[s][i]),this.match[s])return!0}return!1}searchUTF8(n,e,t){let s=0;for(let r=e;r<t;r++){const i=n[r];for(;s!==0&&!(i in this.next[s]);)s=this.fail[s];if(i in this.next[s]&&(s=this.next[s][i]),this.match[s])return!0}return!1}},rn,ge=(rn=class{constructor(e){this.type=e,this.subs=[],this.str="",this.bytes=null,this.ac16=null,this.ac8=null}eval(e,t){switch(this.type){case rn.Type.NONE:return!0;case rn.Type.EXACT:return e.hasString(this,t);case rn.Type.AND:for(let s=0;s<this.subs.length;s++)if(!this.subs[s].eval(e,t))return!1;return!0;case rn.Type.OR:if(this.ac16&&this.ac8)return e.hasAnyString(this,t);for(let s=0;s<this.subs.length;s++)if(this.subs[s].eval(e,t))return!0;return!1;default:return!0}}},U(rn,"Type",{NONE:0,EXACT:1,AND:2,OR:3}),rn),$w=class dn{static build(e){const t=dn.fromRegexp(e);return dn.simplify(t)}static fromRegexp(e){if(!e)return new ge(ge.Type.NONE);switch(e.op){case I.Op.PLB:case I.Op.NLB:case I.Op.NO_MATCH:case I.Op.EMPTY_MATCH:case I.Op.BEGIN_LINE:case I.Op.END_LINE:case I.Op.BEGIN_TEXT:case I.Op.END_TEXT:case I.Op.WORD_BOUNDARY:case I.Op.NO_WORD_BOUNDARY:case I.Op.CHAR_CLASS:case I.Op.ANY_CHAR_NOT_NL:case I.Op.ANY_CHAR:return new ge(ge.Type.NONE);case I.Op.LITERAL:{if(e.runes.length===0||e.flags&V.FOLD_CASE)return new ge(ge.Type.NONE);const t=new ge(ge.Type.EXACT);let s="";for(let r=0;r<e.runes.length;r++)s+=String.fromCodePoint(e.runes[r]);return t.str=s,t.bytes=Y.stringToUtf8ByteArray(t.str),t}case I.Op.CAPTURE:case I.Op.PLUS:return dn.fromRegexp(e.subs[0]);case I.Op.REPEAT:return e.min>=1?dn.fromRegexp(e.subs[0]):new ge(ge.Type.NONE);case I.Op.CONCAT:{const t=new ge(ge.Type.AND);for(const s of e.subs)t.subs.push(dn.fromRegexp(s));return t}case I.Op.ALTERNATE:{const t=new ge(ge.Type.OR);for(const s of e.subs)t.subs.push(dn.fromRegexp(s));return t}default:return new ge(ge.Type.NONE)}}static simplify(e){if(e.type===ge.Type.EXACT||e.type===ge.Type.NONE)return e;if(e.type===ge.Type.AND){const t=[];for(const s of e.subs){const r=dn.simplify(s);if(r.type!==ge.Type.NONE)if(r.type===ge.Type.AND)for(let i=0;i<r.subs.length;i++)t.push(r.subs[i]);else t.push(r)}return t.length===0?new ge(ge.Type.NONE):t.length===1?t[0]:(e.subs=t,e)}if(e.type===ge.Type.OR){const t=[];for(const o of e.subs){const a=dn.simplify(o);if(a.type===ge.Type.NONE)return new ge(ge.Type.NONE);if(a.type===ge.Type.OR)for(let B=0;B<a.subs.length;B++)t.push(a.subs[B]);else t.push(a)}if(t.length===0)return new ge(ge.Type.NONE);if(t.length===1)return t[0];const s=new Set,r=[];for(const o of t)o.type===ge.Type.EXACT?s.has(o.str)||(s.add(o.str),r.push(o)):r.push(o);e.subs=r;let i=!0;for(const o of r)if(o.type!==ge.Type.EXACT){i=!1;break}return i&&r.length>1&&(e.ac16=new Uf(r.map(o=>{const a=[];for(let B=0;B<o.str.length;B++)a.push(o.str.charCodeAt(B));return a})),e.ac8=new Uf(r.map(o=>o.bytes))),e}return e}},Vt=class{constructor(n=0,e=0){this.head=n,this.tail=e}},Yw=class{constructor(){this.inst=[],this.start=0,this.numCap=2,this.lbStarts=[],this.numLb=0}getInst(n){return this.inst[n]}numInst(){return this.inst.length}addInst(n){this.inst.push(new x(n))}skipNop(n){let e=this.inst[n];for(;e.op===x.NOP||e.op===x.CAPTURE;)e=this.inst[n],n=e.out;return e}prefix(){let n="",e=this.skipNop(this.start);if(!x.isRuneOp(e.op)||e.runes.length!==1)return[e.op===x.MATCH,n];for(;x.isRuneOp(e.op)&&e.runes.length===1&&!(e.arg&V.FOLD_CASE);)n+=String.fromCodePoint(e.runes[0]),e=this.skipNop(e.out);return[e.op===x.MATCH,n]}startCond(){let n=0,e=this.start;e:for(;;){const t=this.inst[e];switch(t.op){case x.EMPTY_WIDTH:n|=t.arg;break;case x.FAIL:return-1;case x.CAPTURE:case x.NOP:break;default:break e}e=t.out}return n}patch(n,e){let t=n.head;for(;t!==0;){const s=this.inst[t>>1];t&1?(t=s.arg,s.arg=e):(t=s.out,s.out=e)}}append(n,e){if(n.head===0)return e;if(e.head===0)return n;const t=this.inst[n.tail>>1];return n.tail&1?t.arg=e.head:t.out=e.head,new Vt(n.head,e.tail)}toString(){let n="";for(let e=0;e<this.inst.length;e++){const t=n.length;n+=e,e===this.start&&(n+="*"),n+="        ".substring(n.length-t),n+=this.inst[e],n+=`
`}return n}},Wo=class{constructor(n=0,e=new Vt,t=!1){this.i=n,this.out=e,this.nullable=t}},Xw=class sr{static ANY_RUNE_NOT_NL(){return[0,L.CODES.get(`
`)-1,L.CODES.get(`
`)+1,z.MAX_RUNE]}static ANY_RUNE(){return[0,z.MAX_RUNE]}static compileRegexp(e){const t=new sr,s=t.compile(e);return t.prog.patch(s.out,t.newInst(x.MATCH).i),t.prog.start=s.i,t.prog}static compileSet(e){const t=new sr;if(e.length===0)return t.prog.start=t.newInst(x.FAIL).i,t.prog;let s=[];for(let i=0;i<e.length;i++){const o=t.compile(e[i]),a=t.newInst(x.MATCH);t.prog.getInst(a.i).arg=i,t.prog.patch(o.out,a.i),s.push(o.i)}let r=s[0];for(let i=1;i<s.length;i++){const o=t.newInst(x.ALT),a=t.prog.getInst(o.i);a.out=r,a.arg=s[i],r=o.i}return t.prog.start=r,t.prog}constructor(){this.prog=new Yw,this.newInst(x.FAIL)}newInst(e){return this.prog.addInst(e),new Wo(this.prog.numInst()-1,new Vt,!0)}nop(){const e=this.newInst(x.NOP);return e.out=new Vt(e.i<<1,e.i<<1),e}fail(){return new Wo}cap(e){const t=this.newInst(x.CAPTURE);return t.out=new Vt(t.i<<1,t.i<<1),this.prog.getInst(t.i).arg=e,this.prog.numCap<e+1&&(this.prog.numCap=e+1),t}cat(e,t){return e.i===0||t.i===0?this.fail():(this.prog.patch(e.out,t.i),new Wo(e.i,t.out,e.nullable&&t.nullable))}alt(e,t){if(e.i===0)return t;if(t.i===0)return e;const s=this.newInst(x.ALT),r=this.prog.getInst(s.i);return r.out=e.i,r.arg=t.i,s.out=this.prog.append(e.out,t.out),s.nullable=e.nullable||t.nullable,s}loop(e,t){const s=this.newInst(x.ALT),r=this.prog.getInst(s.i);return t?(r.arg=e.i,s.out=new Vt(s.i<<1,s.i<<1)):(r.out=e.i,s.out=new Vt(s.i<<1|1,s.i<<1|1)),this.prog.patch(e.out,s.i),s}quest(e,t){const s=this.newInst(x.ALT),r=this.prog.getInst(s.i);return t?(r.arg=e.i,s.out=new Vt(s.i<<1,s.i<<1)):(r.out=e.i,s.out=new Vt(s.i<<1|1,s.i<<1|1)),s.out=this.prog.append(s.out,e.out),s}star(e,t){return e.nullable?this.quest(this.plus(e,t),t):this.loop(e,t)}plus(e,t){return new Wo(e.i,this.loop(e,t).out,e.nullable)}empty(e){const t=this.newInst(x.EMPTY_WIDTH);return this.prog.getInst(t.i).arg=e,t.out=new Vt(t.i<<1,t.i<<1),t}rune(e,t){const s=this.newInst(x.RUNE);s.nullable=!1;const r=this.prog.getInst(s.i);return r.runes=e,t&=V.FOLD_CASE,(e.length!==1||z.simpleFold(e[0])===e[0])&&(t&=-2),r.arg=t,s.out=new Vt(s.i<<1,s.i<<1),!(t&V.FOLD_CASE)&&e.length===1||e.length===2&&e[0]===e[1]?r.op=x.RUNE1:e.length===2&&e[0]===0&&e[1]===z.MAX_RUNE?r.op=x.RUNE_ANY:e.length===4&&e[0]===0&&e[1]===L.CODES.get(`
`)-1&&e[2]===L.CODES.get(`
`)+1&&e[3]===z.MAX_RUNE&&(r.op=x.RUNE_ANY_NOT_NL),s}lookBehind(e,t){const s=this.newInst(x.LB_WRITE);this.prog.getInst(s.i).arg=t;const r=this.rune(sr.ANY_RUNE(),0),i=this.star(r,!0),o=this.cat(i,e);this.prog.patch(o.out,s.i);const a=this.newInst(x.LB_CHECK);return this.prog.getInst(a.i).arg=t,this.prog.lbStarts.push(o.i),Math.abs(t)>this.prog.numLb&&(this.prog.numLb=Math.abs(t)),a.out=new Vt(a.i<<1,a.i<<1),a}compile(e){switch(e.op){case I.Op.NO_MATCH:return this.fail();case I.Op.EMPTY_MATCH:return this.nop();case I.Op.LITERAL:if(e.runes.length===0)return this.nop();{let t=null;for(let s of e.runes){const r=this.rune([s],e.flags);t=t===null?r:this.cat(t,r)}return t}case I.Op.CHAR_CLASS:return this.rune(e.runes,e.flags);case I.Op.ANY_CHAR_NOT_NL:return this.rune(sr.ANY_RUNE_NOT_NL(),0);case I.Op.ANY_CHAR:return this.rune(sr.ANY_RUNE(),0);case I.Op.BEGIN_LINE:return this.empty(Y.EMPTY_BEGIN_LINE);case I.Op.END_LINE:return this.empty(Y.EMPTY_END_LINE);case I.Op.BEGIN_TEXT:return this.empty(Y.EMPTY_BEGIN_TEXT);case I.Op.END_TEXT:return this.empty(Y.EMPTY_END_TEXT);case I.Op.WORD_BOUNDARY:return this.empty(Y.EMPTY_WORD_BOUNDARY);case I.Op.NO_WORD_BOUNDARY:return this.empty(Y.EMPTY_NO_WORD_BOUNDARY);case I.Op.PLB:case I.Op.NLB:return this.lookBehind(this.compile(e.subs[0]),e.lb);case I.Op.CAPTURE:{const t=this.cap(e.cap<<1),s=this.compile(e.subs[0]),r=this.cap(e.cap<<1|1);return this.cat(this.cat(t,s),r)}case I.Op.STAR:return this.star(this.compile(e.subs[0]),(e.flags&V.NON_GREEDY)!==0);case I.Op.PLUS:return this.plus(this.compile(e.subs[0]),(e.flags&V.NON_GREEDY)!==0);case I.Op.QUEST:return this.quest(this.compile(e.subs[0]),(e.flags&V.NON_GREEDY)!==0);case I.Op.CONCAT:if(e.subs.length===0)return this.nop();{let t=null;for(let s of e.subs){const r=this.compile(s);t=t===null?r:this.cat(t,r)}return t}case I.Op.ALTERNATE:if(e.subs.length===0)return this.nop();{let t=null;for(let s of e.subs){const r=this.compile(s);t=t===null?r:this.alt(t,r)}return t}default:throw new Lw("regexp: unhandled case in compile")}}},Zw=class Nt{static simplify(e){if(e===null)return null;switch(e.op){case I.Op.PLB:case I.Op.NLB:case I.Op.CAPTURE:{const t=Nt.simplify(e.subs[0]);if(t!==e.subs[0]){const s=I.fromRegexp(e);return s.runes=[],s.subs=[t],s}return e}case I.Op.CONCAT:case I.Op.ALTERNATE:{const t=[];let s=!1;for(let r=0;r<e.subs.length;r++){const i=e.subs[r],o=Nt.simplify(i);if(o!==i&&(s=!0),e.op===I.Op.CONCAT){if(o.op===I.Op.NO_MATCH)return new I(I.Op.NO_MATCH);if(o.op===I.Op.EMPTY_MATCH){s=!0;continue}if(o.op===I.Op.CONCAT){s=!0;for(let a=0;a<o.subs.length;a++)t.push(o.subs[a]);continue}}else if(e.op===I.Op.ALTERNATE){if(o.op===I.Op.NO_MATCH){s=!0;continue}if(o.op===I.Op.ALTERNATE){s=!0;for(let a=0;a<o.subs.length;a++)t.push(o.subs[a]);continue}}t.push(o)}if(s){if(t.length===0)return new I(e.op===I.Op.CONCAT?I.Op.EMPTY_MATCH:I.Op.NO_MATCH);if(t.length===1)return t[0];const r=I.fromRegexp(e);return r.runes=[],r.subs=t,r}return e}case I.Op.CHAR_CLASS:return e.runes===null?e:e.runes.length===0?new I(I.Op.NO_MATCH):e.runes.length===2&&e.runes[0]===0&&e.runes[1]===z.MAX_RUNE?new I(I.Op.ANY_CHAR):e.runes.length===4&&e.runes[0]===0&&e.runes[1]===L.CODES.get(`
`)-1&&e.runes[2]===L.CODES.get(`
`)+1&&e.runes[3]===z.MAX_RUNE?new I(I.Op.ANY_CHAR_NOT_NL):e;case I.Op.STAR:case I.Op.PLUS:case I.Op.QUEST:{const t=Nt.simplify(e.subs[0]);return Nt.simplify1(e.op,e.flags,t,e)}case I.Op.REPEAT:{if(e.min===0&&e.max===0)return new I(I.Op.EMPTY_MATCH);const t=Nt.simplify(e.subs[0]);if(e.max===-1){if(e.min===0)return Nt.simplify1(I.Op.STAR,e.flags,t,null);if(e.min===1)return Nt.simplify1(I.Op.PLUS,e.flags,t,null);const r=new I(I.Op.CONCAT),i=[];for(let o=0;o<e.min-1;o++)i.push(t);return i.push(Nt.simplify1(I.Op.PLUS,e.flags,t,null)),r.subs=i.slice(0),Nt.simplify(r)}if(e.min===1&&e.max===1)return t;let s=null;if(e.min>0){s=[];for(let r=0;r<e.min;r++)s.push(t)}if(e.max>e.min){let r=Nt.simplify1(I.Op.QUEST,e.flags,t,null);for(let i=e.min+1;i<e.max;i++){const o=new I(I.Op.CONCAT);o.subs=[t,r],r=Nt.simplify1(I.Op.QUEST,e.flags,o,null)}if(s===null)return r;s.push(r)}if(s!==null){const r=new I(I.Op.CONCAT);return r.subs=s.slice(0),Nt.simplify(r)}return new I(I.Op.NO_MATCH)}}return e}static simplify1(e,t,s,r){if(s.op===I.Op.EMPTY_MATCH)return s;if(s.op===I.Op.NO_MATCH)return e===I.Op.PLUS?s:new I(I.Op.EMPTY_MATCH);if(e===s.op&&(t&V.NON_GREEDY)===(s.flags&V.NON_GREEDY))return s;if(r!==null&&r.op===e&&(r.flags&V.NON_GREEDY)===(t&V.NON_GREEDY)&&s===r.subs[0])return r;const i=new I(e);return i.flags=t,i.subs=[s],i}},Ce=class{constructor(n,e){this.sign=n,this.cls=e}};const qf=[48,57],Jf=[9,10,12,13,32,32],jf=[48,57,65,90,95,95,97,122],Kf=new Map([["\\d",new Ce(1,qf)],["\\D",new Ce(-1,qf)],["\\s",new Ce(1,Jf)],["\\S",new Ce(-1,Jf)],["\\w",new Ce(1,jf)],["\\W",new Ce(-1,jf)]]),Qf=[48,57,65,90,97,122],zf=[65,90,97,122],Wf=[0,127],$f=[9,9,32,32],Yf=[0,31,127,127],Xf=[48,57],Zf=[33,126],ed=[97,122],td=[32,126],nd=[33,47,58,64,91,96,123,126],sd=[9,13,32,32],rd=[65,90],id=[48,57,65,90,95,95,97,122],od=[48,57,65,70,97,102],ad=new Map([["[:alnum:]",new Ce(1,Qf)],["[:^alnum:]",new Ce(-1,Qf)],["[:alpha:]",new Ce(1,zf)],["[:^alpha:]",new Ce(-1,zf)],["[:ascii:]",new Ce(1,Wf)],["[:^ascii:]",new Ce(-1,Wf)],["[:blank:]",new Ce(1,$f)],["[:^blank:]",new Ce(-1,$f)],["[:cntrl:]",new Ce(1,Yf)],["[:^cntrl:]",new Ce(-1,Yf)],["[:digit:]",new Ce(1,Xf)],["[:^digit:]",new Ce(-1,Xf)],["[:graph:]",new Ce(1,Zf)],["[:^graph:]",new Ce(-1,Zf)],["[:lower:]",new Ce(1,ed)],["[:^lower:]",new Ce(-1,ed)],["[:print:]",new Ce(1,td)],["[:^print:]",new Ce(-1,td)],["[:punct:]",new Ce(1,nd)],["[:^punct:]",new Ce(-1,nd)],["[:space:]",new Ce(1,sd)],["[:^space:]",new Ce(-1,sd)],["[:upper:]",new Ce(1,rd)],["[:^upper:]",new Ce(-1,rd)],["[:word:]",new Ce(1,id)],["[:^word:]",new Ce(-1,id)],["[:xdigit:]",new Ce(1,od)],["[:^xdigit:]",new Ce(-1,od)]]);var kn=class Gn{static charClassToString(e,t){let s="[";for(let r=0;r<t;r+=2){r>0&&(s+=" ");const i=e[r],o=e[r+1];i===o?s+=`0x${i.toString(16)}`:s+=`0x${i.toString(16)}-0x${o.toString(16)}`}return s+="]",s}static cmp(e,t,s,r){const i=e[t]-s;return i!==0?i:r-e[t+1]}static qsortIntPair(e,t,s){const r=((t+s)/2|0)&-2,i=e[r],o=e[r+1];let a=t,B=s;for(;a<=B;){for(;a<s&&Gn.cmp(e,a,i,o)<0;)a+=2;for(;B>t&&Gn.cmp(e,B,i,o)>0;)B-=2;if(a<=B){if(a!==B){let c=e[a];e[a]=e[B],e[B]=c,c=e[a+1],e[a+1]=e[B+1],e[B+1]=c}a+=2,B-=2}}t<B&&Gn.qsortIntPair(e,t,B),a<s&&Gn.qsortIntPair(e,a,s)}constructor(e=Y.emptyInts()){this.r=e,this.len=e.length}toArray(){return this.len===this.r.length?this.r:this.r.slice(0,this.len)}cleanClass(){if(this.len<4)return this;Gn.qsortIntPair(this.r,0,this.len-2);let e=2;for(let t=2;t<this.len;t+=2){const s=this.r[t],r=this.r[t+1];if(s<=this.r[e-1]+1){r>this.r[e-1]&&(this.r[e-1]=r);continue}this.r[e]=s,this.r[e+1]=r,e+=2}return this.len=e,this}appendLiteral(e,t){return t&V.FOLD_CASE?this.appendFoldedRange(e,e):this.appendRange(e,e)}appendRange(e,t){if(this.len>0){for(let s=2;s<=4;s+=2)if(this.len>=s){const r=this.r[this.len-s],i=this.r[this.len-s+1];if(e<=i+1&&r<=t+1)return e<r&&(this.r[this.len-s]=e),t>i&&(this.r[this.len-s+1]=t),this}}return this.r[this.len++]=e,this.r[this.len++]=t,this}appendFoldedRange(e,t){if(e<=z.MIN_FOLD&&t>=z.MAX_FOLD)return this.appendRange(e,t);if(t<z.MIN_FOLD||e>z.MAX_FOLD)return this.appendRange(e,t);e<z.MIN_FOLD&&(this.appendRange(e,z.MIN_FOLD-1),e=z.MIN_FOLD),t>z.MAX_FOLD&&(this.appendRange(z.MAX_FOLD+1,t),t=z.MAX_FOLD);for(let s=e;s<=t;s++){this.appendRange(s,s);for(let r=z.simpleFold(s);r!==s;r=z.simpleFold(r))this.appendRange(r,r)}return this}appendClass(e){for(let t=0;t<e.length;t+=2)this.appendRange(e[t],e[t+1]);return this}appendFoldedClass(e){for(let t=0;t<e.length;t+=2)this.appendFoldedRange(e[t],e[t+1]);return this}appendNegatedClass(e){let t=0;for(let s=0;s<e.length;s+=2){const r=e[s],i=e[s+1];t<=r-1&&this.appendRange(t,r-1),t=i+1}return t<=z.MAX_RUNE&&this.appendRange(t,z.MAX_RUNE),this}appendTable(e){for(let t=0;t<e.length;++t){const s=e.getLo(t),r=e.getHi(t),i=e.getStride(t);if(i===1){this.appendRange(s,r);continue}for(let o=s;o<=r;o+=i)this.appendRange(o,o)}return this}appendNegatedTable(e){let t=0;for(let s=0;s<e.length;++s){const r=e.getLo(s),i=e.getHi(s),o=e.getStride(s);if(o===1){t<=r-1&&this.appendRange(t,r-1),t=i+1;continue}for(let a=r;a<=i;a+=o)t<=a-1&&this.appendRange(t,a-1),t=a+1}return t<=z.MAX_RUNE&&this.appendRange(t,z.MAX_RUNE),this}appendTableWithSign(e,t){return t<0?this.appendNegatedTable(e):this.appendTable(e)}negateClass(){let e=0,t=0;for(let s=0;s<this.len;s+=2){const r=this.r[s],i=this.r[s+1];e<=r-1&&(this.r[t]=e,this.r[t+1]=r-1,t+=2),e=i+1}return this.len=t,e<=z.MAX_RUNE&&(this.r[this.len++]=e,this.r[this.len++]=z.MAX_RUNE),this}appendClassWithSign(e,t){return t<0?this.appendNegatedClass(e):this.appendClass(e)}appendGroup(e,t){let s=e.cls;return t&&(s=new Gn().appendFoldedClass(s).cleanClass().toArray()),this.appendClassWithSign(s,e.sign)}toString(){return Gn.charClassToString(this.r,this.len)}},eT=class{constructor(n){this.str=n,this.position=0}pos(){return this.position}rewindTo(n){this.position=n}more(){return this.position<this.str.length}peek(){return this.str.codePointAt(this.position)}skip(n){this.position+=n}skipString(n){this.position+=n.length}pop(){const n=this.str.codePointAt(this.position);return this.position+=Y.charCount(n),n}lookingAt(n){return this.str.startsWith(n,this.position)}rest(){return this.str.substring(this.position)}from(n){return this.str.substring(n,this.position)}toString(){return this.rest()}},q,tT=(q=class{static unicodeTable(e){return e==="Any"?{tab:q.ANY_TABLE,fold:q.ANY_TABLE,sign:1}:e==="Ascii"?{tab:q.ASCII_TABLE,fold:q.ASCII_FOLD_TABLE,sign:1}:e==="Assigned"?{tab:yt.CATEGORIES.get("Cn"),fold:yt.CATEGORIES.get("Cn"),sign:-1}:e==="Lc"?{tab:yt.CATEGORIES.get("LC"),fold:yt.FOLD_CATEGORIES.get("LC"),sign:1}:yt.CATEGORIES.has(e)?{tab:yt.CATEGORIES.get(e),fold:yt.FOLD_CATEGORIES.get(e),sign:1}:yt.SCRIPTS.has(e)?{tab:yt.SCRIPTS.get(e),fold:yt.FOLD_SCRIPT.get(e),sign:1}:null}static minFoldRune(e){if(e<z.MIN_FOLD||e>z.MAX_FOLD)return e;let t=e;const s=e;for(e=z.simpleFold(e);e!==s;e=z.simpleFold(e))t>e&&(t=e);return t}static leadingRegexp(e){if(e.op===I.Op.EMPTY_MATCH)return null;if(e.op===I.Op.CONCAT&&e.subs.length>0){const t=e.subs[0];return t.op===I.Op.EMPTY_MATCH?null:t}return e}static literalRegexp(e,t){const s=new I(I.Op.LITERAL);return s.flags=t,s.runes=Y.stringToRunes(e),s}static parse(e,t){return new q(e,t).parseInternal()}static parseRepeat(e){const t=e.pos();if(!e.more()||!e.lookingAt("{"))return-1;e.skip(1);const s=q.parseInt(e);if(s===-1||!e.more())return-1;let r;if(!e.lookingAt(","))r=s;else{if(e.skip(1),!e.more())return-1;if(e.lookingAt("}"))r=-1;else if((r=q.parseInt(e))===-1)return-1}if(!e.more()||!e.lookingAt("}"))return-1;if(e.skip(1),s<0||s>1e3||r===-2||r>1e3||r>=0&&s>r)throw new Ae(q.ERR_INVALID_REPEAT_SIZE,e.from(t));return s<<16|r&z.MAX_BMP}static isValidCaptureName(e){if(e.length===0)return!1;for(let t=0;t<e.length;t++){const s=e.codePointAt(t);if(s!==L.CODES.get("_")&&!Y.isalnum(s))return!1}return!0}static parseInt(e){const t=e.pos();for(;e.more()&&e.peek()>=L.CODES.get("0")&&e.peek()<=L.CODES.get("9");)e.skip(1);const s=e.from(t);return s.length===0||s.length>1&&s.codePointAt(0)===L.CODES.get("0")?-1:s.length>8?-2:parseInt(s,10)}static isCharClass(e){return e.op===I.Op.LITERAL&&e.runes.length===1||e.op===I.Op.CHAR_CLASS||e.op===I.Op.ANY_CHAR_NOT_NL||e.op===I.Op.ANY_CHAR}static matchRune(e,t){switch(e.op){case I.Op.LITERAL:return e.runes.length===1&&e.runes[0]===t;case I.Op.CHAR_CLASS:for(let s=0;s<e.runes.length;s+=2)if(e.runes[s]<=t&&t<=e.runes[s+1])return!0;return!1;case I.Op.ANY_CHAR_NOT_NL:return t!==L.CODES.get(`
`);case I.Op.ANY_CHAR:return!0}return!1}static mergeCharClass(e,t){switch(e.op){case I.Op.ANY_CHAR:break;case I.Op.ANY_CHAR_NOT_NL:q.matchRune(t,L.CODES.get(`
`))&&(e.op=I.Op.ANY_CHAR);break;case I.Op.CHAR_CLASS:t.op===I.Op.LITERAL?e.runes=new kn(e.runes).appendLiteral(t.runes[0],t.flags).toArray():e.runes=new kn(e.runes).appendClass(t.runes).toArray();break;case I.Op.LITERAL:if(t.runes[0]===e.runes[0]&&t.flags===e.flags)break;e.op=I.Op.CHAR_CLASS,e.runes=new kn().appendLiteral(e.runes[0],e.flags).appendLiteral(t.runes[0],t.flags).toArray();break}}static parseEscape(e){const t=e.pos();if(e.skip(1),!e.more())throw new Ae(q.ERR_TRAILING_BACKSLASH);let s=e.pop();e:switch(s){case L.CODES.get("1"):case L.CODES.get("2"):case L.CODES.get("3"):case L.CODES.get("4"):case L.CODES.get("5"):case L.CODES.get("6"):case L.CODES.get("7"):if(!e.more()||e.peek()<L.CODES.get("0")||e.peek()>L.CODES.get("7"))break;case L.CODES.get("0"):{let r=s-L.CODES.get("0");for(let i=1;i<3&&!(!e.more()||e.peek()<L.CODES.get("0")||e.peek()>L.CODES.get("7"));i++)r=r*8+e.peek()-L.CODES.get("0"),e.skip(1);return r}case L.CODES.get("x"):{if(!e.more())break;if(s=e.pop(),s===L.CODES.get("{")){let o=0,a=0;for(;;){if(!e.more())break e;if(s=e.pop(),s===L.CODES.get("}"))break;const B=Y.unhex(s);if(B<0||(a=a*16+B,a>z.MAX_RUNE))break e;o++}if(o===0)break e;return a}const r=Y.unhex(s);if(!e.more())break;s=e.pop();const i=Y.unhex(s);if(r<0||i<0)break;return r*16+i}case L.CODES.get("a"):return L.CODES.get("\x07");case L.CODES.get("f"):return L.CODES.get("\f");case L.CODES.get("n"):return L.CODES.get(`
`);case L.CODES.get("r"):return L.CODES.get("\r");case L.CODES.get("t"):return L.CODES.get("	");case L.CODES.get("v"):return L.CODES.get("\v");default:if(s<=z.MAX_ASCII&&!Y.isalnum(s))return s;break}throw new Ae(q.ERR_INVALID_ESCAPE,e.from(t))}static parseClassChar(e,t){if(!e.more())throw new Ae(q.ERR_MISSING_BRACKET,e.from(t));return e.lookingAt("\\")?q.parseEscape(e):e.pop()}static concatRunes(e,t){for(let s=0;s<t.length;s++)e.push(t[s]);return e}static hasCapture(e){if(e===null)return!1;if(e.op===I.Op.CAPTURE)return!0;if(e.subs){for(let t of e.subs)if(q.hasCapture(t))return!0}return!1}constructor(e,t=0){this.wholeRegexp=e,this.flags=t,this.numCap=0,this.namedGroups=Object.create(null),this.stack=[],this.free=null,this.numRegexp=0,this.numRunes=0,this.repeats=0,this.height=null,this.size=null,this.nlb=0}newRegexp(e){let t=this.free;return t!==null&&t.subs!==null&&t.subs.length>0?(this.free=t.subs[0],t.reinit(),t.op=e):(t=new I(e),this.numRegexp+=1),t}reuse(e){this.height!==null&&this.height.has(e)&&this.height.delete(e),e.subs!==null&&e.subs.length>0&&(e.subs[0]=this.free),this.free=e}checkLimits(e){if(this.numRunes>q.MAX_RUNES)throw new Ae(q.ERR_LARGE);this.checkSize(e),this.checkHeight(e)}checkSize(e){if(this.size===null){if(this.repeats===0&&(this.repeats=1),e.op===I.Op.REPEAT){let t=e.max;t===-1&&(t=e.min),t<=0&&(t=1),t>Math.floor(q.MAX_SIZE/this.repeats)?this.repeats=q.MAX_SIZE:this.repeats*=t}if(this.numRegexp<Math.floor(q.MAX_SIZE/this.repeats))return;this.size=new Map;for(let t of this.stack)this.checkSize(t)}if(this.calcSize(e,!0)>q.MAX_SIZE)throw new Ae(q.ERR_LARGE)}calcSize(e,t=!1){if(!t&&this.size!==null&&this.size.has(e))return this.size.get(e);let s=0;switch(e.op){case I.Op.LITERAL:s=e.runes.length;break;case I.Op.PLB:case I.Op.NLB:case I.Op.CAPTURE:case I.Op.STAR:s=2+this.calcSize(e.subs[0]);break;case I.Op.PLUS:case I.Op.QUEST:s=1+this.calcSize(e.subs[0]);break;case I.Op.CONCAT:for(let r of e.subs)s=s+this.calcSize(r);break;case I.Op.ALTERNATE:for(let r of e.subs)s=s+this.calcSize(r);e.subs.length>1&&(s=s+e.subs.length-1);break;case I.Op.REPEAT:{let r=this.calcSize(e.subs[0]);if(e.max===-1){e.min===0?s=2+r:s=1+e.min*r;break}s=e.max*r+(e.max-e.min);break}}return s=Math.max(1,s),this.size===null&&(this.size=new Map),this.size.set(e,s),s}checkHeight(e){if(!(this.numRegexp<q.MAX_HEIGHT)){if(this.height===null){this.height=new Map;for(let t of this.stack)this.checkHeight(t)}if(this.calcHeight(e,!0)>q.MAX_HEIGHT)throw new Ae(q.ERR_NESTING_DEPTH)}}calcHeight(e,t=!1){if(!t&&this.height!==null&&this.height.has(e))return this.height.get(e);let s=1;for(let r of e.subs){const i=this.calcHeight(r);s<1+i&&(s=1+i)}return this.height===null&&(this.height=new Map),this.height.set(e,s),s}pop(){return this.stack.pop()}popToPseudo(){const e=this.stack.length;let t=e;for(;t>0&&!I.isPseudoOp(this.stack[t-1].op);)t--;const s=this.stack.slice(t,e);return this.stack=this.stack.slice(0,t),s}push(e){if(this.numRunes+=e.runes.length,e.op===I.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]===e.runes[1]){if(this.maybeConcat(e.runes[0],this.flags&-2))return null;e.op=I.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags&-2}else if(e.op===I.Op.CHAR_CLASS&&e.runes.length===4&&e.runes[0]===e.runes[1]&&e.runes[2]===e.runes[3]&&z.simpleFold(e.runes[0])===e.runes[2]&&z.simpleFold(e.runes[2])===e.runes[0]||e.op===I.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]+1===e.runes[1]&&z.simpleFold(e.runes[0])===e.runes[1]&&z.simpleFold(e.runes[1])===e.runes[0]){if(this.maybeConcat(e.runes[0],this.flags|V.FOLD_CASE))return null;e.op=I.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags|V.FOLD_CASE}else this.maybeConcat(-1,0);return this.stack.push(e),this.checkLimits(e),e}maybeConcat(e,t){const s=this.stack.length;if(s<2)return!1;const r=this.stack[s-1],i=this.stack[s-2];return r.op!==I.Op.LITERAL||i.op!==I.Op.LITERAL||(r.flags&V.FOLD_CASE)!==(i.flags&V.FOLD_CASE)?!1:(i.runes=q.concatRunes(i.runes,r.runes),e>=0?(r.runes=[e],r.flags=t,!0):(this.pop(),this.reuse(r),!1))}newLiteral(e,t){const s=this.newRegexp(I.Op.LITERAL);return s.flags=t,t&V.FOLD_CASE&&(e=q.minFoldRune(e)),s.runes=[e],s}literal(e){this.push(this.newLiteral(e,this.flags))}op(e){const t=this.newRegexp(e);return t.flags=this.flags,this.push(t)}repeat(e,t,s,r,i,o){let a=this.flags;if(a&V.PERL_X&&(i.more()&&i.lookingAt("?")&&(i.skip(1),a^=V.NON_GREEDY),o!==-1))throw new Ae(q.ERR_INVALID_REPEAT_OP,i.from(o));const B=this.stack.length;if(B===0)throw new Ae(q.ERR_MISSING_REPEAT_ARGUMENT,i.from(r));const c=this.stack[B-1];if(I.isPseudoOp(c.op))throw new Ae(q.ERR_MISSING_REPEAT_ARGUMENT,i.from(r));const u=this.newRegexp(e);if(u.min=t,u.max=s,u.flags=a,u.subs=[c],this.stack[B-1]=u,this.checkLimits(u),e===I.Op.REPEAT&&(t>=2||s>=2)&&!this.repeatIsValid(u,1e3))throw new Ae(q.ERR_INVALID_REPEAT_SIZE,i.from(r))}repeatIsValid(e,t){if(e.op===I.Op.REPEAT){let s=e.max;if(s===0)return!0;if(s<0&&(s=e.min),s>t)return!1;s>0&&(t=Math.trunc(t/s))}for(let s of e.subs)if(!this.repeatIsValid(s,t))return!1;return!0}concat(){this.maybeConcat(-1,0);const e=this.popToPseudo();return e.length===0?this.push(this.newRegexp(I.Op.EMPTY_MATCH)):this.push(this.collapse(e,I.Op.CONCAT))}alternate(){const e=this.popToPseudo();return e.length>0&&this.cleanAlt(e[e.length-1]),e.length===0?this.push(this.newRegexp(I.Op.NO_MATCH)):this.push(this.collapse(e,I.Op.ALTERNATE))}cleanAlt(e){e.op===I.Op.CHAR_CLASS&&(e.runes=new kn(e.runes).cleanClass().toArray(),e.runes.length===2&&e.runes[0]===0&&e.runes[1]===z.MAX_RUNE?(e.runes=[],e.op=I.Op.ANY_CHAR):e.runes.length===4&&e.runes[0]===0&&e.runes[1]===L.CODES.get(`
`)-1&&e.runes[2]===L.CODES.get(`
`)+1&&e.runes[3]===z.MAX_RUNE&&(e.runes=[],e.op=I.Op.ANY_CHAR_NOT_NL))}collapse(e,t){if(e.length===1)return e[0];let s=0;for(let a of e)s+=a.op===t?a.subs.length:1;let r=new Array(s).fill(null),i=0;for(let a of e)if(a.op===t){for(let B=0;B<a.subs.length;B++)r[i++]=a.subs[B];this.reuse(a)}else r[i++]=a;let o=this.newRegexp(t);if(o.subs=r,t===I.Op.ALTERNATE&&(o.subs=this.factor(o.subs),o.subs.length===1)){const a=o;o=o.subs[0],this.reuse(a)}return o}factor(e){if(e.length<2)return e;let t=0,s=e.length,r=0,i=null,o=0,a=0,B=0;for(let u=0;u<=s;u++){let f=null,C=0,g=0;if(u<s){let E=e[t+u];if(E.op===I.Op.CONCAT&&E.subs.length>0&&(E=E.subs[0]),E.op===I.Op.LITERAL&&(f=E.runes,C=E.runes.length,g=E.flags&V.FOLD_CASE),g===a){let b=0;for(;b<o&&b<C&&i[b]===f[b];)b++;if(b>0){o=b;continue}}}if(u!==B)if(u===B+1)e[r++]=e[t+B];else{const E=this.newRegexp(I.Op.LITERAL);E.flags=a,E.runes=i.slice(0,o);for(let j=B;j<u;j++)e[t+j]=this.removeLeadingString(e[t+j],o),this.checkLimits(e[t+j]);const b=this.collapse(e.slice(t+B,t+u),I.Op.ALTERNATE),F=this.newRegexp(I.Op.CONCAT);F.subs=[E,b],e[r++]=F}B=u,i=f,o=C,a=g}s=r,t=0,B=0,r=0;let c=null;for(let u=0;u<=s;u++){let f=null;if(!(u<s&&(f=q.leadingRegexp(e[t+u]),c!==null&&c.equals(f)&&(q.isCharClass(c)||c.op===I.Op.REPEAT&&c.min===c.max&&q.isCharClass(c.subs[0]))))){if(u!==B)if(u===B+1)e[r++]=e[t+B];else{const C=c;for(let b=B;b<u;b++){const F=b!==B;e[t+b]=this.removeLeadingRegexp(e[t+b],F),this.checkLimits(e[t+b])}const g=this.collapse(e.slice(t+B,t+u),I.Op.ALTERNATE),E=this.newRegexp(I.Op.CONCAT);E.subs=[C,g],e[r++]=E}B=u,c=f}}s=r,t=0,B=0,r=0;for(let u=0;u<=s;u++)if(!(u<s&&q.isCharClass(e[t+u]))){if(u!==B)if(u===B+1)e[r++]=e[t+B];else{let f=B;for(let g=B+1;g<u;g++){const E=e[t+f],b=e[t+g];(E.op<b.op||E.op===b.op&&(E.runes!==null?E.runes.length:0)<(b.runes!==null?b.runes.length:0))&&(f=g)}const C=e[t+B];e[t+B]=e[t+f],e[t+f]=C;for(let g=B+1;g<u;g++)q.mergeCharClass(e[t+B],e[t+g]),this.reuse(e[t+g]);this.cleanAlt(e[t+B]),e[r++]=e[t+B]}u<s&&(e[r++]=e[t+u]),B=u+1}s=r,t=0,B=0,r=0;for(let u=0;u<s;++u)u+1<s&&e[t+u].op===I.Op.EMPTY_MATCH&&e[t+u+1].op===I.Op.EMPTY_MATCH||(e[r++]=e[t+u]);return s=r,t=0,e.slice(t,s)}removeLeadingString(e,t){if(e.op===I.Op.CONCAT&&e.subs.length>0){const s=this.removeLeadingString(e.subs[0],t);if(e.subs[0]=s,s.op===I.Op.EMPTY_MATCH)switch(this.reuse(s),e.subs.length){case 0:case 1:e.op=I.Op.EMPTY_MATCH,e.subs=I.emptySubs();break;case 2:{const r=e;e=e.subs[1],this.reuse(r);break}default:e.subs=e.subs.slice(1,e.subs.length);break}return e}return e.op===I.Op.LITERAL&&(e.runes=e.runes.slice(t,e.runes.length),e.runes.length===0&&(e.op=I.Op.EMPTY_MATCH)),e}removeLeadingRegexp(e,t){if(e.op===I.Op.CONCAT&&e.subs.length>0){switch(t&&this.reuse(e.subs[0]),e.subs=e.subs.slice(1,e.subs.length),e.subs.length){case 0:e.op=I.Op.EMPTY_MATCH,e.subs=I.emptySubs();break;case 1:{const s=e;e=e.subs[0],this.reuse(s);break}}return e}return t&&this.reuse(e),this.newRegexp(I.Op.EMPTY_MATCH)}parseInternal(){if(this.flags&V.LITERAL)return q.literalRegexp(this.wholeRegexp,this.flags);let e=-1,t=-1,s=-1;const r=new eT(this.wholeRegexp);for(;r.more();){let i=-1;e:switch(r.peek()){case L.CODES.get("("):if(this.flags&V.LOOKBEHIND){if(r.lookingAt("(?<=")){this.parsePosLookBehind(),r.skip(4);break}if(r.lookingAt("(?<!")){this.parseNegLookBehind(),r.skip(4);break}}if(this.flags&V.PERL_X&&r.lookingAt("(?")){this.parsePerlFlags(r);break}this.op(I.Op.LEFT_PAREN).cap=++this.numCap,r.skip(1);break;case L.CODES.get("|"):this.parseVerticalBar(),r.skip(1);break;case L.CODES.get(")"):this.parseRightParen(),r.skip(1);break;case L.CODES.get("^"):this.flags&V.ONE_LINE?this.op(I.Op.BEGIN_TEXT):this.op(I.Op.BEGIN_LINE),r.skip(1);break;case L.CODES.get("$"):this.flags&V.ONE_LINE?this.op(I.Op.END_TEXT).flags|=V.WAS_DOLLAR:this.op(I.Op.END_LINE),r.skip(1);break;case L.CODES.get("."):this.flags&V.DOT_NL?this.op(I.Op.ANY_CHAR):this.op(I.Op.ANY_CHAR_NOT_NL),r.skip(1);break;case L.CODES.get("["):this.parseClass(r);break;case L.CODES.get("*"):case L.CODES.get("+"):case L.CODES.get("?"):{i=r.pos();let o=null;switch(r.pop()){case L.CODES.get("*"):o=I.Op.STAR;break;case L.CODES.get("+"):o=I.Op.PLUS;break;case L.CODES.get("?"):o=I.Op.QUEST;break}this.repeat(o,t,s,i,r,e);break}case L.CODES.get("{"):{i=r.pos();const o=q.parseRepeat(r);if(o<0){r.rewindTo(i),this.literal(r.pop());break}t=o>>16,s=(o&z.MAX_BMP)<<16>>16,this.repeat(I.Op.REPEAT,t,s,i,r,e);break}case L.CODES.get("\\"):{const o=r.pos();if(r.skip(1),this.flags&V.PERL_X&&r.more())switch(r.pop()){case L.CODES.get("A"):this.op(I.Op.BEGIN_TEXT);break e;case L.CODES.get("b"):this.op(I.Op.WORD_BOUNDARY);break e;case L.CODES.get("B"):this.op(I.Op.NO_WORD_BOUNDARY);break e;case L.CODES.get("C"):throw new Ae(q.ERR_INVALID_ESCAPE,"\\C");case L.CODES.get("Q"):{let c=r.rest();const u=c.indexOf("\\E");u>=0?(c=c.substring(0,u),r.skipString(c),r.skipString("\\E")):r.skipString(c);let f=0;for(;f<c.length;){const C=c.codePointAt(f);this.literal(C),f+=Y.charCount(C)}break e}case L.CODES.get("z"):this.op(I.Op.END_TEXT);break e;default:r.rewindTo(o);break}else r.rewindTo(o);const a=this.newRegexp(I.Op.CHAR_CLASS);if(a.flags=this.flags,r.lookingAt("\\p")||r.lookingAt("\\P")){const c=new kn;if(this.parseUnicodeClass(r,c)){a.runes=c.toArray(),this.push(a);break e}}const B=new kn;if(this.parsePerlClassEscape(r,B)){a.runes=B.toArray(),this.push(a);break e}r.rewindTo(o),this.reuse(a),this.literal(q.parseEscape(r));break}default:this.literal(r.pop());break}e=i}if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length!==1)throw new Ae(q.ERR_MISSING_PAREN,this.wholeRegexp);return this.stack[0].namedGroups=this.namedGroups,this.stack[0]}parsePerlFlags(e){const t=e.pos(),s=e.rest();if(s.startsWith("(?P<")||s.startsWith("(?<")){const a=s.charAt(2)==="P"?4:3,B=s.indexOf(">");if(B<0)throw new Ae(q.ERR_INVALID_NAMED_CAPTURE,s);const c=s.substring(a,B);if(e.skipString(c),e.skip(a+1),!q.isValidCaptureName(c))throw new Ae(q.ERR_INVALID_NAMED_CAPTURE,s.substring(0,B+1));const u=this.op(I.Op.LEFT_PAREN);if(u.cap=++this.numCap,this.namedGroups[c])throw new Ae(q.ERR_DUPLICATE_NAMED_CAPTURE,c);this.namedGroups[c]=this.numCap,u.name=c;return}e.skip(2);let r=this.flags,i=1,o=!1;e:for(;e.more();){const a=e.pop();switch(a){case L.CODES.get("i"):r|=V.FOLD_CASE,o=!0;break;case L.CODES.get("m"):r&=-17,o=!0;break;case L.CODES.get("s"):r|=V.DOT_NL,o=!0;break;case L.CODES.get("U"):r|=V.NON_GREEDY,o=!0;break;case L.CODES.get("-"):if(i<0)break e;i=-1,r=~r,o=!1;break;case L.CODES.get(":"):case L.CODES.get(")"):if(i<0){if(!o)break e;r=~r}a===L.CODES.get(":")&&this.op(I.Op.LEFT_PAREN),this.flags=r;return;default:break e}}throw new Ae(q.ERR_INVALID_PERL_OP,e.from(t))}parsePosLookBehind(){const e=this.newRegexp(I.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=++this.nlb,this.push(e)}parseNegLookBehind(){const e=this.newRegexp(I.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=-++this.nlb,this.push(e)}parseVerticalBar(){this.concat(),this.swapVerticalBar()||this.op(I.Op.VERTICAL_BAR)}swapVerticalBar(){const e=this.stack.length;if(e>=3&&this.stack[e-2].op===I.Op.VERTICAL_BAR&&q.isCharClass(this.stack[e-1])&&q.isCharClass(this.stack[e-3])){let t=this.stack[e-1],s=this.stack[e-3];if(t.op>s.op){const r=s;s=t,t=r,this.stack[e-3]=s}return q.mergeCharClass(s,t),this.reuse(t),this.pop(),!0}if(e>=2){const t=this.stack[e-1],s=this.stack[e-2];if(s.op===I.Op.VERTICAL_BAR)return e>=3&&this.cleanAlt(this.stack[e-3]),this.stack[e-2]=t,this.stack[e-1]=s,!0}return!1}parseRightParen(){if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length<2)throw new Ae(q.ERR_UNEXPECTED_PAREN,this.wholeRegexp);const e=this.pop(),t=this.pop();if(t.op!==I.Op.LEFT_PAREN)throw new Ae(q.ERR_UNEXPECTED_PAREN,this.wholeRegexp);if(this.flags=t.flags,t.lb!==0){if(q.hasCapture(e))throw new Ae(q.ERR_INVALID_CAPTURE_IN_LOOKBEHIND,this.wholeRegexp);t.lb>0?t.op=I.Op.PLB:t.op=I.Op.NLB,t.subs=[e],this.push(t);return}t.cap===0?this.push(e):(t.op=I.Op.CAPTURE,t.subs=[e],this.push(t))}parsePerlClassEscape(e,t){const s=e.pos();if(!(this.flags&V.PERL_X)||!e.more()||e.pop()!==L.CODES.get("\\")||!e.more())return!1;e.pop();const r=e.from(s),i=Kf.has(r)?Kf.get(r):null;return i===null?!1:(t.appendGroup(i,(this.flags&V.FOLD_CASE)!==0),!0)}parseNamedClass(e,t){const s=e.rest(),r=s.indexOf(":]");if(r<0)return!1;const i=s.substring(0,r+2);e.skipString(i);const o=ad.has(i)?ad.get(i):null;if(o===null)throw new Ae(q.ERR_INVALID_CHAR_RANGE,i);return t.appendGroup(o,(this.flags&V.FOLD_CASE)!==0),!0}parseUnicodeClass(e,t){const s=e.pos();if(!(this.flags&V.UNICODE_GROUPS)||!e.lookingAt("\\p")&&!e.lookingAt("\\P"))return!1;e.skip(1);let r=1,i=e.pop();if(i===L.CODES.get("P")&&(r=-1),!e.more())throw e.rewindTo(s),new Ae(q.ERR_INVALID_CHAR_RANGE,e.rest());i=e.pop();let o;if(i!==L.CODES.get("{"))o=Y.runeToString(i);else{const u=e.rest(),f=u.indexOf("}");if(f<0)throw e.rewindTo(s),new Ae(q.ERR_INVALID_CHAR_RANGE,e.rest());o=u.substring(0,f),e.skipString(o),e.skip(1)}o.length!==0&&o.codePointAt(0)===L.CODES.get("^")&&(r=0-r,o=o.substring(1));const a=q.unicodeTable(o);if(a===null)throw new Ae(q.ERR_INVALID_CHAR_RANGE,e.from(s));a.sign<0&&(r=0-r);const B=a.tab,c=a.fold;if(!(this.flags&V.FOLD_CASE)||c===null)t.appendTableWithSign(B,r);else{const u=new kn().appendTable(B).appendTable(c).cleanClass().toArray();t.appendClassWithSign(u,r)}return!0}parseClass(e){const t=e.pos();e.skip(1);const s=this.newRegexp(I.Op.CHAR_CLASS);s.flags=this.flags;const r=new kn;let i=1;e.more()&&e.lookingAt("^")&&(i=-1,e.skip(1),this.flags&V.CLASS_NL||r.appendRange(L.CODES.get(`
`),L.CODES.get(`
`)));let o=!0;for(;!e.more()||e.peek()!==L.CODES.get("]")||o;){if(e.more()&&e.lookingAt("-")&&!(this.flags&V.PERL_X)&&!o){const u=e.rest();if(u==="-"||!u.startsWith("-]"))throw e.rewindTo(t),new Ae(q.ERR_INVALID_CHAR_RANGE,e.rest())}o=!1;const a=e.pos();if(e.lookingAt("[:")){if(this.parseNamedClass(e,r))continue;e.rewindTo(a)}if(this.parseUnicodeClass(e,r)||this.parsePerlClassEscape(e,r))continue;e.rewindTo(a);const B=q.parseClassChar(e,t);let c=B;if(e.more()&&e.lookingAt("-")){if(e.skip(1),e.more()&&e.lookingAt("]"))e.skip(-1);else if(c=q.parseClassChar(e,t),c<B)throw new Ae(q.ERR_INVALID_CHAR_RANGE,e.from(a))}this.flags&V.FOLD_CASE?r.appendFoldedRange(B,c):r.appendRange(B,c)}e.skip(1),r.cleanClass(),i<0&&r.negateClass(),s.runes=r.toArray(),this.push(s)}},U(q,"ERR_INTERNAL_ERROR","regexp/syntax: internal error"),U(q,"ERR_INVALID_CHAR_RANGE","invalid character class range"),U(q,"ERR_INVALID_ESCAPE","invalid escape sequence"),U(q,"ERR_INVALID_NAMED_CAPTURE","invalid named capture"),U(q,"ERR_INVALID_PERL_OP","invalid or unsupported Perl syntax"),U(q,"ERR_INVALID_REPEAT_OP","invalid nested repetition operator"),U(q,"ERR_INVALID_REPEAT_SIZE","invalid repeat count"),U(q,"ERR_MISSING_BRACKET","missing closing ]"),U(q,"ERR_MISSING_PAREN","missing closing )"),U(q,"ERR_MISSING_REPEAT_ARGUMENT","missing argument to repetition operator"),U(q,"ERR_TRAILING_BACKSLASH","trailing backslash at end of expression"),U(q,"ERR_DUPLICATE_NAMED_CAPTURE","duplicate capture group name"),U(q,"ERR_UNEXPECTED_PAREN","unexpected )"),U(q,"ERR_NESTING_DEPTH","expression nests too deeply"),U(q,"ERR_LARGE","expression too large"),U(q,"ERR_INVALID_CAPTURE_IN_LOOKBEHIND","invalid capture in lookbehind"),U(q,"MAX_HEIGHT",1e3),U(q,"MAX_SIZE",3355443),U(q,"MAX_RUNES",33554432),U(q,"ANY_TABLE",new m(new Uint32Array([0,z.MAX_RUNE,1]))),U(q,"ASCII_TABLE",new m(new Uint32Array([0,127,1]))),U(q,"ASCII_FOLD_TABLE",new m(new Uint32Array([0,127,1,383,383,1,8490,8490,1]))),q),nT=class Is{static initTest(e){const t=Is.compile(e),s=new Is(t.expr,t.prog,t.numSubexp,t.longest);return s.cond=t.cond,s.prefix=t.prefix,s.prefixUTF8=t.prefixUTF8,s.prefixComplete=t.prefixComplete,s.prefixRune=t.prefixRune,s.prefilter=t.prefilter,s}static compile(e){return Is.compileImpl(e,V.PERL,!1)}static compilePOSIX(e){return Is.compileImpl(e,V.POSIX,!0)}static compileImpl(e,t,s){let r=tT.parse(e,t);const i=r.maxCap();r=Zw.simplify(r);const o=$w.build(r),a=Xw.compileRegexp(r),B=new Is(e,a,i,s);B.prefilter=o.type===ge.Type.NONE?null:o;const[c,u]=a.prefix();return B.prefixComplete=c,B.prefix=u,B.prefixUTF8=Y.stringToUtf8ByteArray(B.prefix),B.prefix.length>0&&(B.prefixRune=B.prefix.codePointAt(0)),B.namedGroups=r.namedGroups,B}static match(e,t){return Is.compile(e).match(t)}constructor(e,t,s=0,r=0){this.expr=e,this.prog=t,this.numSubexp=s,this.longest=r,this.cond=t.startCond(),this.prefix=null,this.prefixUTF8=null,this.prefixComplete=!1,this.prefixRune=0,this.machinePool=[],this.dfa=new Gw(this.prog),this.onepass=Hf.compile(this.prog),this.prefilter=null}matchPrefixComplete(e,t,s,r){if((s===V.ANCHOR_START||s===V.ANCHOR_BOTH)&&t!==0)return null;let i=-1,o=-1;const a=e.prefixLength(this);if(s===V.UNANCHORED){const B=e.index(this,t);if(B<0)return null;i=t+B,o=i+a}else if(s===V.ANCHOR_BOTH){if(e.endPos()!==a||e.index(this,0)!==0)return null;i=0,o=a}else if(s===V.ANCHOR_START){if(e.index(this,0)!==0)return null;i=0,o=a}if(i<0)return null;if(r>0){const B=new Int32Array(r).fill(-1);return B[0]=i,B[1]=o,Array.from(B)}return[]}executeEngine(e,t,s,r){if(this.prefixComplete&&(r===0||this.numSubexp===0))return this.matchPrefixComplete(e,t,s,r);if(this.prefilter!==null&&s===V.UNANCHORED&&!this.prefilter.eval(e,t))return null;if(this.onepass!==null)return Hf.execute(this,e,t,s,r);if(r>0)return this.prog.numLb===0&&e.endPos()<=zo.maxBitStateLen(this.prog)?zo.execute(this,e,t,s,r):this.doExecuteNFA(e,t,s,r);if(this.prog.numLb===0){const i=this.dfa.match(e,t,s);if(i!==null)return i?[]:null;if(e.endPos()<=zo.maxBitStateLen(this.prog))return zo.execute(this,e,t,s,r)}return this.doExecuteNFA(e,t,s,r)}numberOfCapturingGroups(){return this.numSubexp}numberOfInstructions(){return this.prog.numInst()}get(){return this.machinePool.length>0?this.machinePool.pop():null}reset(){this.machinePool.length=0}put(e){this.machinePool.push(e)}toString(){return this.expr}doExecuteNFA(e,t,s,r){let i=this.get();i||(i=kw.fromRE2(this)),i.init(r);const o=i.match(e,t,s)?i.submatches():null;return this.put(i),o}match(e){return this.executeEngine(be.fromUTF16(e),0,V.UNANCHORED,0)!==null}matchWithGroup(e,t,s,r,i){return e instanceof Gs||(Y.isByteArray(e)?e=Ss.utf8(e):e=Ss.utf16(e)),this.matchMachineInput(e,t,s,r,i)}matchMachineInput(e,t,s,r,i){if(t>s)return[!1,null];const o=e.isUTF16Encoding()?be.fromUTF16(e.asCharSequence(),0,s):be.fromUTF8(e.asBytes(),0,s),a=this.executeEngine(o,t,r,2*i);return a===null?[!1,null]:[!0,a]}matchUTF8(e){return this.executeEngine(be.fromUTF8(e),0,V.UNANCHORED,0)!==null}replaceAll(e,t){return this.replaceAllFunc(e,()=>t,2*e.length+1)}replaceFirst(e,t){return this.replaceAllFunc(e,()=>t,1)}replaceAllFunc(e,t,s){let r=0,i=0,o="";const a=be.fromUTF16(e);let B=0;for(;i<=e.length;){const c=this.executeEngine(a,i,V.UNANCHORED,2);if(c===null||c.length===0)break;o+=e.substring(r,c[0]),(c[1]>r||c[0]===0)&&(o+=t(e.substring(c[0],c[1])),B++),r=c[1];const u=a.step(i)&7;if(i+u>c[1]?i+=u:i+1>c[1]?i++:i=c[1],B>=s)break}return o+=e.substring(r),o}pad(e){if(e===null)return null;let t=(1+this.numSubexp)*2;if(e.length<t){let s=new Array(t).fill(-1);for(let r=0;r<e.length;r++)s[r]=e[r];e=s}return e}allMatches(e,t,s=r=>r){let r=[];const i=e.endPos();t<0&&(t=i+1);let o=0,a=0,B=-1;for(;a<t&&o<=i;){const c=this.executeEngine(e,o,V.UNANCHORED,this.prog.numCap);if(c===null||c.length===0)break;let u=!0;if(c[1]===o){c[0]===B&&(u=!1);const f=e.step(o);f<0?o=i+1:o+=f&7}else o=c[1];B=c[1],u&&(r.push(s(this.pad(c))),a++)}return r}findUTF8(e){const t=this.executeEngine(be.fromUTF8(e),0,V.UNANCHORED,2);return t===null?null:e.slice(t[0],t[1])}findUTF8Index(e){const t=this.executeEngine(be.fromUTF8(e),0,V.UNANCHORED,2);return t===null?null:t.slice(0,2)}find(e){const t=this.executeEngine(be.fromUTF16(e),0,V.UNANCHORED,2);return t===null?"":e.substring(t[0],t[1])}findIndex(e){return this.executeEngine(be.fromUTF16(e),0,V.UNANCHORED,2)}findUTF8Submatch(e){const t=this.executeEngine(be.fromUTF8(e),0,V.UNANCHORED,this.prog.numCap);if(t===null)return null;const s=new Array(1+this.numSubexp).fill(null);for(let r=0;r<s.length;r++)2*r<t.length&&t[2*r]>=0&&(s[r]=e.slice(t[2*r],t[2*r+1]));return s}findUTF8SubmatchIndex(e){return this.pad(this.executeEngine(be.fromUTF8(e),0,V.UNANCHORED,this.prog.numCap))}findSubmatch(e){const t=this.executeEngine(be.fromUTF16(e),0,V.UNANCHORED,this.prog.numCap);if(t===null)return null;const s=new Array(1+this.numSubexp).fill(null);for(let r=0;r<s.length;r++)2*r<t.length&&t[2*r]>=0&&(s[r]=e.substring(t[2*r],t[2*r+1]));return s}findSubmatchIndex(e){return this.pad(this.executeEngine(be.fromUTF16(e),0,V.UNANCHORED,this.prog.numCap))}findAllUTF8(e,t){const s=this.allMatches(be.fromUTF8(e),t,r=>e.slice(r[0],r[1]));return s.length===0?null:s}findAllUTF8Index(e,t){const s=this.allMatches(be.fromUTF8(e),t,r=>r.slice(0,2));return s.length===0?null:s}findAll(e,t){const s=this.allMatches(be.fromUTF16(e),t,r=>e.substring(r[0],r[1]));return s.length===0?null:s}findAllIndex(e,t){const s=this.allMatches(be.fromUTF16(e),t,r=>r.slice(0,2));return s.length===0?null:s}findAllUTF8Submatch(e,t){const s=this.allMatches(be.fromUTF8(e),t,r=>{let i=new Array(r.length/2|0).fill(null);for(let o=0;o<i.length;o++)r[2*o]>=0&&(i[o]=e.slice(r[2*o],r[2*o+1]));return i});return s.length===0?null:s}findAllUTF8SubmatchIndex(e,t){const s=this.allMatches(be.fromUTF8(e),t);return s.length===0?null:s}findAllSubmatch(e,t){const s=this.allMatches(be.fromUTF16(e),t,r=>{let i=new Array(r.length/2|0).fill(null);for(let o=0;o<i.length;o++)r[2*o]>=0&&(i[o]=e.substring(r[2*o],r[2*o+1]));return i});return s.length===0?null:s}findAllSubmatchIndex(e,t){const s=this.allMatches(be.fromUTF16(e),t);return s.length===0?null:s}},sT=class rr{static isHexadecimal(e){return"0"<=e&&e<="9"||"A"<=e&&e<="F"||"a"<=e&&e<="f"}static translate(e){let t="";if(e instanceof RegExp&&(e.ignoreCase&&(t+="i"),e.multiline&&(t+="m"),e.dotAll&&(t+="s"),e=e.source),typeof e!="string")return e;let s="",r=!1,i=e.length;i===0&&(s="(?:)",r=!0);let o=!1,a=0;for(;a<i;){let c=e[a];if(c==="\\"){if(a+1<i)switch(c=e[a+1],c){case"\\":s+="\\\\",a+=2;continue;case"c":if(a+2<i){let C=e[a+2].charCodeAt(0);if(C>=65&&C<=90||C>=97&&C<=122){let g=C%32;s+="\\x",s+=(g>>4).toString(16).toUpperCase(),s+=(g&15).toString(16).toUpperCase(),a+=3,r=!0;continue}}s+="c",a+=2,r=!0;continue;case"u":if(a+2<i){if(e[a+2]==="{"){let C=a+3,g=!1,E=!1;for(;C<i;){const b=e[C];if(b==="}"){E=!0;break}if(!rr.isHexadecimal(b))break;g=!0,C++}if(E&&g){s+="\\x",a+=2,r=!0;continue}}else if(a+5<i){let C=!0;for(let g=0;g<4;g++)if(!rr.isHexadecimal(e[a+2+g])){C=!1;break}if(C){s+="\\x{"+e.substring(a+2,a+6)+"}",a+=6,r=!0;continue}}}s+="u",a+=2,r=!0;continue;case"x":{let C=!1;if(a+2<i&&e[a+2]==="{"){let g=a+3,E=!1,b=!1;for(;g<i;){const F=e[g];if(F==="}"){b=!0;break}if(!rr.isHexadecimal(F))break;E=!0,g++}b&&E&&(C=!0)}else a+3<i&&rr.isHexadecimal(e[a+2])&&rr.isHexadecimal(e[a+3])&&(C=!0);C?(s+="\\x",a+=2):(s+="x",a+=2,r=!0);continue}case"n":case"r":case"t":case"a":case"f":case"v":case"d":case"D":case"s":case"S":case"w":case"W":case"b":case"B":case"p":case"P":case"A":case"z":case"Q":case"E":case"0":case"1":case"2":case"3":case"4":case"5":case"6":case"7":s+="\\"+c,a+=2;continue;default:{let C=e.codePointAt(a+1);if(C>=48&&C<=57||C>=65&&C<=90||C>=97&&C<=122){let g=Y.charCount(C);s+=e.substring(a+1,a+1+g),a+=g+1,r=!0}else{s+="\\";let g=Y.charCount(C);s+=e.substring(a+1,a+1+g),a+=g+1}continue}}}else if(c==="/"){s+="\\/",a+=1,r=!0;continue}else if(c==="[")o=!0;else if(c==="]")o=!1;else if(!o&&c==="("&&a+2<i&&e[a+1]==="?"&&e[a+2]==="<"&&a+3<i&&!"=!>)".includes(e[a+3])){s+="(?P<",a+=3,r=!0;continue}let u=e.codePointAt(a),f=Y.charCount(u);s+=e.substring(a,a+f),a+=f}const B=r?s:e;return t.length>0?`(?${t})${B}`:B}},Ue,vc=(Ue=class{static quote(e){return Y.quoteMeta(e)}static quoteReplacement(e,t=!1){return kf.quoteReplacement(e,t)}static translateRegExp(e){return sT.translate(e)}static compile(e,t=0){let s=e;if(t&Ue.CASE_INSENSITIVE&&(s=`(?i)${s}`),t&Ue.DOTALL&&(s=`(?s)${s}`),t&Ue.MULTILINE&&(s=`(?m)${s}`),t&-544)throw new xw("Flags should only be a combination of MULTILINE, DOTALL, CASE_INSENSITIVE, DISABLE_UNICODE_GROUPS, LONGEST_MATCH, LOOKBEHINDS");let r=V.PERL;t&Ue.DISABLE_UNICODE_GROUPS&&(r&=-129),t&Ue.LOOKBEHINDS&&(r|=V.LOOKBEHIND);const i=new Ue(e,t);return i.re2Input=nT.compileImpl(s,r,(t&Ue.LONGEST_MATCH)!==0),i}static matches(e,t){return Ue.compile(e).testExact(t)}static initTest(e,t,s){if(e==null)throw new Error("pattern is null");if(s==null)throw new Error("re2 is null");const r=new Ue(e,t);return r.re2Input=s,r}constructor(e,t){this.patternInput=e,this.flagsInput=t,this.re2Input=null}reset(){this.re2Input.reset()}flags(){return this.flagsInput}pattern(){return this.patternInput}re2(){return this.re2Input}matches(e){return this.testExact(e)}matcher(e){return Y.isByteArray(e)&&(e=Ss.utf8(e)),new kf(this,e)}test(e){return Y.isByteArray(e)?this.re2Input.matchUTF8(e):this.re2Input.match(e)}testExact(e){const t=Y.isByteArray(e)?be.fromUTF8(e):be.fromUTF16(e);return this.re2Input.executeEngine(t,0,V.ANCHOR_BOTH,0)!==null}exec(e){const t=this.matcher(e);if(!t.find())return null;const s=[t.group(0)];for(let i=1;i<=t.groupCount();i++){const o=t.group(i);s.push(o===null?void 0:o)}s.index=t.start(0),s.input=e;const r=this.namedGroups();if(Object.keys(r).length>0){const i=t.getNamedGroups();for(const o in i)i[o]===null&&(i[o]=void 0);s.groups=i}else s.groups=void 0;return s}split(e,t=0){const s=this.matcher(e),r=[];let i=0,o=0;for(;s.find();){if(o===0&&s.end()===0){o=s.end();continue}if(t>0&&r.length===t-1)break;if(o===s.start()){if(t===0){i+=1,o=s.end();continue}}else for(;i>0;)r.push(""),i-=1;r.push(s.substring(o,s.start())),o=s.end()}if(t===0&&o!==s.inputLength()){for(;i>0;)r.push(""),i-=1;r.push(s.substring(o,s.inputLength()))}return(t!==0||r.length===0&&!(o===s.inputLength()&&o>0))&&r.push(s.substring(o,s.inputLength())),r}*matchAll(e){const t=this.matcher(e);for(;t.find();){const s=[t.group(0)];for(let i=1;i<=t.groupCount();i++){const o=t.group(i);s.push(o===null?void 0:o)}s.index=t.start(0),s.input=e;const r=this.namedGroups();if(Object.keys(r).length>0){const i=t.getNamedGroups();for(const o in i)i[o]===null&&(i[o]=void 0);s.groups=i}else s.groups=void 0;yield s}}toString(){return this.patternInput}programSize(){return this.re2Input.numberOfInstructions()}groupCount(){return this.re2Input.numberOfCapturingGroups()}namedGroups(){return this.re2Input.namedGroups}equals(e){return this===e?!0:e===null||this.constructor!==e.constructor?!1:this.flagsInput===e.flagsInput&&this.patternInput===e.patternInput}},U(Ue,"CASE_INSENSITIVE",tr.CASE_INSENSITIVE),U(Ue,"DOTALL",tr.DOTALL),U(Ue,"MULTILINE",tr.MULTILINE),U(Ue,"DISABLE_UNICODE_GROUPS",tr.DISABLE_UNICODE_GROUPS),U(Ue,"LONGEST_MATCH",tr.LONGEST_MATCH),U(Ue,"LOOKBEHINDS",tr.LOOKBEHINDS),Ue);/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rT{constructor(e,t,s){this.alias=e,this.aggregateType=t,this.fieldPath=s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Nr="12.19.0";function iT(n){Nr=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hs=new Qa("@firebase/firestore");function ir(){return Hs.logLevel}function Q(n,...e){if(Hs.logLevel<=he.DEBUG){const t=e.map(Rc);Hs.debug(`Firestore (${Nr}): ${n}`,...t)}}function In(n,...e){if(Hs.logLevel<=he.ERROR){const t=e.map(Rc);Hs.error(`Firestore (${Nr}): ${n}`,...t)}}function Wt(n,...e){if(Hs.logLevel<=he.WARN){const t=e.map(Rc);Hs.warn(`Firestore (${Nr}): ${n}`,...t)}}function Rc(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function X(n,e,t){let s="Unexpected state";typeof e=="string"?s=e:t=e,kp(n,s,t)}function kp(n,e,t){let s=`FIRESTORE (${Nr}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{s+=" CONTEXT: "+JSON.stringify(t)}catch{s+=" CONTEXT: "+t}throw In(s),new Error(s)}function W(n,e,t,s){let r="Unexpected state";typeof t=="string"?r=t:s=t,n||kp(e,r,s)}function re(n,e){return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oT(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let s=0;s<n;s++)t[s]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sc{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let s="";for(;s.length<20;){const r=oT(40);for(let i=0;i<r.length;++i)s.length<20&&r[i]<t&&(s+=e.charAt(r[i]%62))}return s}}function ue(n,e){return n<e?-1:n>e?1:0}function MB(n,e){const t=Math.min(n.length,e.length);for(let s=0;s<t;s++){const r=n.charAt(s),i=e.charAt(s);if(r!==i)return fB(r)===fB(i)?ue(r,i):fB(r)?1:-1}return ue(n.length,e.length)}const aT=55296,lT=57343;function fB(n){const e=n.charCodeAt(0);return e>=aT&&e<=lT}function Cr(n,e,t){return n.length===e.length&&n.every((s,r)=>t(s,e[r]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ge=class VB{constructor(e,t){this.comparator=e,this.root=t||Qn.EMPTY}insert(e,t){return new VB(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,Qn.BLACK,null,null))}remove(e){return new VB(this.comparator,this.root.remove(e,this.comparator).copy(null,null,Qn.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const s=this.comparator(e,t.key);if(s===0)return t.value;s<0?t=t.left:s>0&&(t=t.right)}return null}indexOf(e){let t=0,s=this.root;for(;!s.isEmpty();){const r=this.comparator(e,s.key);if(r===0)return t+s.left.size;r<0?s=s.left:(t+=s.left.size+1,s=s.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,s)=>(e(t,s),!1))}toString(){const e=[];return this.inorderTraversal((t,s)=>(e.push(`${t}:${s}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new $o(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new $o(this.root,e,this.comparator,!1)}getReverseIterator(){return new $o(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new $o(this.root,e,this.comparator,!0)}},$o=class{constructor(e,t,s,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?s(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}},Qn=class Cn{constructor(e,t,s,r,i){this.key=e,this.value=t,this.color=s??Cn.RED,this.left=r??Cn.EMPTY,this.right=i??Cn.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,s,r,i){return new Cn(e??this.key,t??this.value,s??this.color,r??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let r=this;const i=s(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,s),null):i===0?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,s)),r.fixUp()}removeMin(){if(this.left.isEmpty())return Cn.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let s,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),t(e,r.key)===0){if(r.right.isEmpty())return Cn.EMPTY;s=r.right.min(),r=r.copy(s.key,s.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,Cn.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,Cn.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw X(43730,{key:this.key,value:this.value});if(this.right.isRed())throw X(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw X(27949);return e+(this.isRed()?0:1)}};Qn.EMPTY=null,Qn.RED=!0,Qn.BLACK=!1;Qn.EMPTY=new class{constructor(){this.size=0}get key(){throw X(57766)}get value(){throw X(16141)}get color(){throw X(16727)}get left(){throw X(29726)}get right(){throw X(36894)}copy(e,t,s,r,i){return this}insert(e,t,s){return new Qn(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class je{constructor(e){this.comparator=e,this.data=new Ge(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,s)=>(e(t),!1))}forEachInRange(e,t){const s=this.data.getIteratorFrom(e[0]);for(;s.hasNext();){const r=s.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let s;for(s=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();s.hasNext();)if(!e(s.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new ld(this.data.getIterator())}getIteratorFrom(e){return new ld(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(s=>{t=t.add(s)}),t}isEqual(e){if(!(e instanceof je)||this.size!==e.size)return!1;const t=this.data.getIterator(),s=e.data.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=s.getNext().key;if(this.comparator(r,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new je(this.comparator);return t.data=e,t}}class ld{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const O={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class G extends bn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nn="__name__";class tn{constructor(e,t,s){t===void 0?t=0:t>e.length&&X(637,{offset:t,range:e.length}),s===void 0?s=e.length-t:s>e.length-t&&X(1746,{length:s,range:e.length-t}),this.segments=e,this.offset=t,this.len=s}get length(){return this.len}isEqual(e){return tn.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof tn?e.forEach(s=>{t.push(s)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,s=this.limit();t<s;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const s=Math.min(e.length,t.length);for(let r=0;r<s;r++){const i=tn.compareSegments(e.get(r),t.get(r));if(i!==0)return i}return ue(e.length,t.length)}static compareSegments(e,t){const s=tn.isNumericId(e),r=tn.isNumericId(t);return s&&!r?-1:!s&&r?1:s&&r?tn.extractNumericId(e).compare(tn.extractNumericId(t)):MB(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Kn.fromString(e.substring(4,e.length-2))}}class pe extends tn{construct(e,t,s){return new pe(e,t,s)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const s of e){if(s.indexOf("//")>=0)throw new G(O.INVALID_ARGUMENT,`Invalid segment (${s}). Paths must not contain // in them.`);t.push(...s.split("/").filter(r=>r.length>0))}return new pe(t)}static emptyPath(){return new pe([])}}const BT=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let xt=class or extends tn{construct(e,t,s){return new or(e,t,s)}static isValidIdentifier(e){return BT.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),or.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===nn}static keyField(){return new or([nn])}static fromServerFormat(e){const t=[];let s="",r=0;const i=()=>{if(s.length===0)throw new G(O.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(s),s=""};let o=!1;for(;r<e.length;){const a=e[r];if(a==="\\"){if(r+1===e.length)throw new G(O.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const B=e[r+1];if(B!=="\\"&&B!=="."&&B!=="`")throw new G(O.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);s+=B,r+=2}else a==="`"?(o=!o,r++):a!=="."||o?(s+=a,r++):(i(),r++)}if(i(),o)throw new G(O.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new or(t)}static emptyPath(){return new or([])}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ot{constructor(e){this.fields=e,e.sort(xt.comparator)}static empty(){return new Ot([])}unionWith(e){let t=new je(xt.comparator);for(const s of this.fields)t=t.add(s);for(const s of e)t=t.add(s);return new Ot(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Cr(this.fields,e.fields,(t,s)=>t.isEqual(s))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pa(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function Cs(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function Mp(n,e){const t=[];for(const s in n)Object.prototype.hasOwnProperty.call(n,s)&&t.push(e(n[s],s,n));return t}function Vp(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ${constructor(e){this.path=e}static fromPath(e){return new $(pe.fromString(e))}static fromName(e){return new $(pe.fromString(e).popFirst(5))}static empty(){return new $(pe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&pe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return pe.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new $(new pe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gp(n,e,t){if(!t)throw new G(O.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function cT(n,e,t,s){if(e===!0&&s===!0)throw new G(O.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Bd(n){if(!$.isDocumentKey(n))throw new G(O.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function cd(n){if($.isDocumentKey(n))throw new G(O.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function oo(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function $a(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(s){return s.constructor?s.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":X(12329,{type:typeof n})}function ht(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new G(O.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=$a(n);throw new G(O.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function uT(n,e){if(e<=0)throw new G(O.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Je(n,e){const t={typeString:n};return e&&(t.value=e),t}function ao(n,e){if(!oo(n))throw new G(O.INVALID_ARGUMENT,"JSON must be an object");let t;for(const s in e)if(e[s]){const r=e[s].typeString,i="value"in e[s]?{value:e[s].value}:void 0;if(!(s in n)){t=`JSON missing required field: '${s}'`;break}const o=n[s];if(r&&typeof o!==r){t=`JSON field '${s}' must be a ${r}.`;break}if(i!==void 0&&o!==i.value){t=`Expected '${s}' field to equal '${i.value}'`;break}}if(t)throw new G(O.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ud=-62135596800,hd=1e6;class Ee{static now(){return Ee.fromMillis(Date.now())}static fromDate(e){return Ee.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),s=Math.floor((e-1e3*t)*hd);return new Ee(t,s)}static fromInstant(e){if(!e||typeof e.t!="bigint")throw new G(O.INVALID_ARGUMENT,"Invalid Temporal.Instant object provided.");return Ee._fromEpochNanoseconds(e.t)}static _fromEpochNanoseconds(e){let t,s;if(e>=0n)t=Number(e/1000000000n),s=Number(e%1000000000n);else{const r=e%1000000000n;r===0n?(t=Number(e/1000000000n),s=0):(t=Number(e/1000000000n-1n),s=Number(r+1000000000n))}return new Ee(t,s)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new G(O.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new G(O.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<ud)throw new G(O.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new G(O.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/hd}toInstant(){if(typeof Temporal>"u"||!Temporal.Instant)throw new G(O.FAILED_PRECONDITION,"The Temporal object is not available in the current environment.");const e=1000000000n*BigInt(this.seconds)+BigInt(this.nanoseconds);return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(e)}_compareTo(e){return this.seconds===e.seconds?ue(this.nanoseconds,e.nanoseconds):ue(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Ee._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(ao(e,Ee._jsonSchema))return new Ee(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-ud;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Ee._jsonSchemaVersion="firestore/timestamp/1.0",Ee._jsonSchema={type:Je("string",Ee._jsonSchemaVersion),seconds:Je("number"),nanoseconds:Je("number")};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hp extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ke{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new Hp("Invalid base64 string: "+i):i}}(e);return new Ke(t)}static fromUint8Array(e){const t=function(r){let i="";for(let o=0;o<r.length;++o)i+=String.fromCharCode(r[o]);return i}(e);return new Ke(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const s=new Uint8Array(t.length);for(let r=0;r<t.length;r++)s[r]=t.charCodeAt(r);return s}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ue(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}Ke.EMPTY_BYTE_STRING=new Ke("");const hT=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function ts(n){if(W(!!n,39018),typeof n=="string"){let e=0;const t=hT.exec(n);if(W(!!t,46558,{timestamp:n}),t[1]){let r=t[1];r=(r+"000000000").substr(0,9),e=Number(r)}const s=new Date(n);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:Fe(n.seconds),nanos:Fe(n.nanos)}}function Fe(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function ns(n){return typeof n=="string"?Ke.fromBase64String(n):Ke.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Up="server_timestamp",qp="__type__",Jp="__previous_value__",jp="__local_write_time__";function lo(n){var t,s;return((s=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[qp])==null?void 0:s.stringValue)===Up}function Bo(n){const e=n.mapValue.fields[Jp];return lo(e)?Bo(e):e}function pr(n){const e=ts(n.mapValue.fields[jp].timestampValue);return new Ee(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fT{constructor(e,t,s,r,i,o,a,B,c,u,f,C,g){this.databaseId=e,this.appId=t,this.persistenceKey=s,this.host=r,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.longPollingOptions=B,this.useFetchStreams=c,this.isUsingEmulator=u,this.apiKey=f,this._customHeaders=C,this.grpcFlowControlWindow=g}}const ga="(default)";class Oi{constructor(e,t){this.projectId=e,this.database=t||ga}static empty(){return new Oi("","")}get isDefaultDatabase(){return this.database===ga}isEqual(e){return e instanceof Oi&&e.projectId===this.projectId&&e.database===this.database}}function dT(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new G(O.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Oi(n.options.projectId,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bc=-1;function co(n){return n==null}function Li(n){return n===0&&1/n==-1/0}function CT(n){return typeof n=="number"&&Number.isInteger(n)&&!Li(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}function pT(n){return typeof n=="string"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kp="__type__",gT="__max__",Yo={mapValue:{}},Qp="__vector__",xi="value",gr={nullValue:"NULL_VALUE"},vt={booleanValue:!0},st={booleanValue:!1};function Qe(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?lo(n)?4:mT(n)?9007199254740991:_a(n)?10:11:X(28295,{value:n})}function Ut(n,e,t){if(n===e)return!0;const s=Qe(n);if(s!==Qe(e))return!1;switch(s){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return pr(n).isEqual(pr(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const a=ts(i.timestampValue),B=ts(o.timestampValue);return a.seconds===B.seconds&&a.nanos===B.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,o){return ns(i.bytesValue).isEqual(ns(o.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,o){return Fe(i.geoPointValue.latitude)===Fe(o.geoPointValue.latitude)&&Fe(i.geoPointValue.longitude)===Fe(o.geoPointValue.longitude)}(n,e);case 2:return function(i,o,a){if("integerValue"in i&&"integerValue"in o)return Fe(i.integerValue)===Fe(o.integerValue);let B,c;if("doubleValue"in i&&"doubleValue"in o)B=Fe(i.doubleValue),c=Fe(o.doubleValue);else{if(!(a!=null&&a.i))return!1;B=Fe(i.integerValue??i.doubleValue),c=Fe(o.integerValue??o.doubleValue)}return B===c?!!(a!=null&&a.o)||Li(B)===Li(c):!!(a===void 0||a.u)&&isNaN(B)&&isNaN(c)}(n,e,t);case 9:return Cr(n.arrayValue.values||[],e.arrayValue.values||[],(r,i)=>Ut(r,i,t));case 10:case 11:return function(i,o,a){const B=i.mapValue.fields||{},c=o.mapValue.fields||{};if(pa(B)!==pa(c))return!1;for(const u in B)if(B.hasOwnProperty(u)&&(c[u]===void 0||!Ut(B[u],c[u],a)))return!1;return!0}(n,e,t);default:return X(52216,{left:n})}}function ki(n,e){return(n.values||[]).find(t=>Ut(t,e))!==void 0}function Rt(n,e){if(n===e)return 0;const t=Qe(n),s=Qe(e);if(t!==s)return ue(t,s);switch(t){case 0:case 9007199254740991:return 0;case 1:return ue(n.booleanValue,e.booleanValue);case 2:return function(i,o){const a=Fe(i.integerValue||i.doubleValue),B=Fe(o.integerValue||o.doubleValue);return a<B?-1:a>B?1:a===B?0:isNaN(a)?isNaN(B)?0:-1:1}(n,e);case 3:return fd(n.timestampValue,e.timestampValue);case 4:return fd(pr(n),pr(e));case 5:return MB(n.stringValue,e.stringValue);case 6:return function(i,o){const a=ns(i),B=ns(o);return a.compareTo(B)}(n.bytesValue,e.bytesValue);case 7:return function(i,o){const a=i.split("/"),B=o.split("/");for(let c=0;c<a.length&&c<B.length;c++){const u=ue(a[c],B[c]);if(u!==0)return u}return ue(a.length,B.length)}(n.referenceValue,e.referenceValue);case 8:return function(i,o){const a=ue(Fe(i.latitude),Fe(o.latitude));return a!==0?a:ue(Fe(i.longitude),Fe(o.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return dd(n.arrayValue,e.arrayValue);case 10:return function(i,o){var C,g,E,b;const a=i.fields||{},B=o.fields||{},c=(C=a[xi])==null?void 0:C.arrayValue,u=(g=B[xi])==null?void 0:g.arrayValue,f=ue(((E=c==null?void 0:c.values)==null?void 0:E.length)||0,((b=u==null?void 0:u.values)==null?void 0:b.length)||0);return f!==0?f:dd(c,u)}(n.mapValue,e.mapValue);case 11:return function(i,o){if(i===Yo.mapValue&&o===Yo.mapValue)return 0;if(i===Yo.mapValue)return 1;if(o===Yo.mapValue)return-1;const a=i.fields||{},B=Object.keys(a),c=o.fields||{},u=Object.keys(c);B.sort(),u.sort();for(let f=0;f<B.length&&f<u.length;++f){const C=MB(B[f],u[f]);if(C!==0)return C;const g=Rt(a[B[f]],c[u[f]]);if(g!==0)return g}return ue(B.length,u.length)}(n.mapValue,e.mapValue);default:throw X(23264,{l:t})}}function fd(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return ue(n,e);const t=ts(n),s=ts(e),r=ue(t.seconds,s.seconds);return r!==0?r:ue(t.nanos,s.nanos)}function dd(n,e){const t=n.values||[],s=e.values||[];for(let r=0;r<t.length&&r<s.length;++r){const i=Rt(t[r],s[r]);if(i!==void 0&&i!==0)return i}return ue(t.length,s.length)}function mr(n){return GB(n)}function GB(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const s=ts(t);return`time(${s.seconds},${s.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return ns(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return $.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let s="[",r=!0;for(const i of t.values||[])r?r=!1:s+=",",s+=GB(i);return s+"]"}(n.arrayValue):"mapValue"in n?function(t){const s=Object.keys(t.fields||{}).sort();let r="{",i=!0;for(const o of s)i?i=!1:r+=",",r+=`${o}:${GB(t.fields[o])}`;return r+"}"}(n.mapValue):X(61005,{value:n})}function ia(n){switch(Qe(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Bo(n);return e?16+ia(e):16;case 5:return 2*n.stringValue.length;case 6:return ns(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(s){return(s.values||[]).reduce((r,i)=>r+ia(i),0)}(n.arrayValue);case 10:case 11:return function(s){let r=0;return Cs(s.fields,(i,o)=>{r+=i.length+ia(o)}),r}(n.mapValue);default:throw X(13486,{value:n})}}function ma(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function sn(n){return!!n&&"integerValue"in n}function bs(n){return!!n&&"doubleValue"in n}function ss(n){return sn(n)||bs(n)}function _r(n){return!!n&&"arrayValue"in n}function Lt(n){return!!n&&"nullValue"in n}function St(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function Fs(n){return!!n&&"mapValue"in n}function _a(n){var t,s;return((s=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[Kp])==null?void 0:s.stringValue)===Qp}function HB(n){var e,t;return(t=(((e=n==null?void 0:n.mapValue)==null?void 0:e.fields)||{})[xi])==null?void 0:t.arrayValue}function mi(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return Cs(n.mapValue.fields,(t,s)=>e.mapValue.fields[t]=mi(s)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=mi(n.arrayValue.values[t]);return e}return{...n}}function mT(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===gT}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class it{constructor(e){this.value=e}static empty(){return new it({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let s=0;s<e.length-1;++s)if(t=(t.mapValue.fields||{})[e.get(s)],!Fs(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=mi(t)}setAll(e){let t=xt.emptyPath(),s={},r=[];e.forEach((o,a)=>{if(!t.isImmediateParentOf(a)){const B=this.getFieldsMap(t);this.applyChanges(B,s,r),s={},r=[],t=a.popLast()}o?s[a.lastSegment()]=mi(o):r.push(a.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,s,r)}delete(e){const t=this.field(e.popLast());Fs(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Ut(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let s=0;s<e.length;++s){let r=t.mapValue.fields[e.get(s)];Fs(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(s)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,s){Cs(t,(r,i)=>e[r]=i);for(const r of s)delete e[r]}clone(){return new it(mi(this.value))}}function zp(n){const e=[];return Cs(n.fields,(t,s)=>{const r=new xt([t]);if(Fs(s)){const i=zp(s.mapValue).fields;if(i.length===0)e.push(r);else for(const o of i)e.push(r.child(o))}else e.push(r)}),new Ot(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ya(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Li(e)?"-0":e}}function Nc(n){return{integerValue:""+n}}function Xa(n,e,t){return CT(e)?Nc(e):Ya(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Za{constructor(){this._=void 0}}function _T(n,e,t){return n instanceof Mi?function(r,i){const o={fields:{[qp]:{stringValue:Up},[jp]:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&lo(i)&&(i=Bo(i)),i&&(o.fields[Jp]=i),{mapValue:o}}(t,e):n instanceof Er?$p(n,e):n instanceof Vi?Yp(n,e):n instanceof Dr?function(r,i){const o=Wp(r,i),a=ya(o)+ya(r.h);return sn(o)&&sn(r.h)?Nc(a):Ya(r.serializer,a)}(n,e):n instanceof Ea?function(r,i){return Cd(r,i,Math.min)}(n,e):n instanceof Da?function(r,i){return Cd(r,i,Math.max)}(n,e):void 0}function ET(n,e,t){return n instanceof Er?$p(n,e):n instanceof Vi?Yp(n,e):t}function Wp(n,e){return n instanceof Dr?ss(e)?e:{integerValue:0}:null}class Mi extends Za{}class Er extends Za{constructor(e){super(),this.elements=e}}function $p(n,e){const t=Xp(e);for(const s of n.elements)t.some(r=>Ut(r,s))||t.push(s);return{arrayValue:{values:t}}}class Vi extends Za{constructor(e){super(),this.elements=e}}function Yp(n,e){let t=Xp(e);for(const s of n.elements)t=t.filter(r=>!Ut(r,s));return{arrayValue:{values:t}}}class Pc extends Za{constructor(e,t){super(),this.serializer=e,this.h=t}}class Dr extends Pc{}class Ea extends Pc{}class Da extends Pc{}function Cd(n,e,t){if(!ss(e))return n.h;const s=t(ya(e),ya(n.h));return sn(e)&&sn(n.h)?Nc(s):Ya(n.serializer,s)}function ya(n){return Fe(n.integerValue||n.doubleValue)}function Xp(n){return _r(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc{constructor(e,t){this.field=e,this.transform=t}}function DT(n,e){return n.field.isEqual(e.field)&&function(s,r){return s instanceof Er&&r instanceof Er||s instanceof Vi&&r instanceof Vi?Cr(s.elements,r.elements,Ut):s instanceof Dr&&r instanceof Dr||s instanceof Ea&&r instanceof Ea||s instanceof Da&&r instanceof Da?Ut(s.h,r.h):s instanceof Mi&&r instanceof Mi}(n.transform,e.transform)}class yT{constructor(e,t){this.version=e,this.transformResults=t}}class ot{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new ot}static exists(e){return new ot(void 0,e)}static updateTime(e){return new ot(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function oa(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class el{}function Zp(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new tl(n.key,ot.none()):new uo(n.key,n.data,ot.none());{const t=n.data,s=it.empty();let r=new je(xt.comparator);for(let i of e.fields)if(!r.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?s.delete(i):s.set(i,o),r=r.add(i)}return new ps(n.key,s,new Ot(r.toArray()),ot.none())}}function wT(n,e,t){n instanceof uo?function(r,i,o){const a=r.value.clone(),B=gd(r.fieldTransforms,i,o.transformResults);a.setAll(B),i.convertToFoundDocument(o.version,a).setHasCommittedMutations()}(n,e,t):n instanceof ps?function(r,i,o){if(!oa(r.precondition,i))return void i.convertToUnknownDocument(o.version);const a=gd(r.fieldTransforms,i,o.transformResults),B=i.data;B.setAll(eg(r)),B.setAll(a),i.convertToFoundDocument(o.version,B).setHasCommittedMutations()}(n,e,t):function(r,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function _i(n,e,t,s){return n instanceof uo?function(i,o,a,B){if(!oa(i.precondition,o))return a;const c=i.value.clone(),u=md(i.fieldTransforms,B,o);return c.setAll(u),o.convertToFoundDocument(o.version,c).setHasLocalMutations(),null}(n,e,t,s):n instanceof ps?function(i,o,a,B){if(!oa(i.precondition,o))return a;const c=md(i.fieldTransforms,B,o),u=o.data;return u.setAll(eg(i)),u.setAll(c),o.convertToFoundDocument(o.version,u).setHasLocalMutations(),a===null?null:a.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(f=>f.field))}(n,e,t,s):function(i,o,a){return oa(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a}(n,e,t)}function TT(n,e){let t=null;for(const s of n.fieldTransforms){const r=e.data.field(s.field),i=Wp(s.transform,r||null);i!=null&&(t===null&&(t=it.empty()),t.set(s.field,i))}return t||null}function pd(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(s,r){return s===void 0&&r===void 0||!(!s||!r)&&Cr(s,r,(i,o)=>DT(i,o))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class uo extends el{constructor(e,t,s,r=[]){super(),this.key=e,this.value=t,this.precondition=s,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class ps extends el{constructor(e,t,s,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=s,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function eg(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const s=n.data.field(t);e.set(t,s)}}),e}function gd(n,e,t){const s=new Map;W(n.length===t.length,32656,{T:t.length,P:n.length});for(let r=0;r<t.length;r++){const i=n[r],o=i.transform,a=e.data.field(i.field);s.set(i.field,ET(o,a,t[r]))}return s}function md(n,e,t){const s=new Map;for(const r of n){const i=r.transform,o=t.data.field(r.field);s.set(r.field,_T(i,o,e))}return s}class tl extends el{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class tg extends el{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yr{constructor(e,t){this.position=e,this.inclusive=t}}function _d(n,e,t){let s=0;for(let r=0;r<n.position.length;r++){const i=e[r],o=n.position[r];if(i.field.isKeyField()?s=$.comparator($.fromName(o.referenceValue),t.key):s=Rt(o,t.data.field(i.field)),i.dir==="desc"&&(s*=-1),s!==0)break}return s}function Ed(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Ut(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ng{}class qe extends ng{constructor(e,t,s){super(),this.field=e,this.op=t,this.value=s}static create(e,t,s){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,s):new AT(e,t,s):t==="array-contains"?new ST(e,s):t==="in"?new bT(e,s):t==="not-in"?new NT(e,s):t==="array-contains-any"?new PT(e,s):new qe(e,t,s)}static createKeyFieldInFilter(e,t,s){return t==="in"?new vT(e,s):new RT(e,s)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(Rt(t,this.value)):t!==null&&Qe(this.value)===Qe(t)&&this.matchesComparison(Rt(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return X(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class $t extends ng{constructor(e,t){super(),this.filters=e,this.op=t,this.I=null}static create(e,t){return new $t(e,t)}matches(e){return sg(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.I!==null||(this.I=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.I}getFilters(){return Object.assign([],this.filters)}}function sg(n){return n.op==="and"}function rg(n){return IT(n)&&sg(n)}function IT(n){for(const e of n.filters)if(e instanceof $t)return!1;return!0}function UB(n){if(n instanceof qe)return n.field.canonicalString()+n.op.toString()+mr(n.value);if(rg(n))return n.filters.map(e=>UB(e)).join(",");{const e=n.filters.map(t=>UB(t)).join(",");return`${n.op}(${e})`}}function ig(n,e){return n instanceof qe?function(s,r){return r instanceof qe&&s.op===r.op&&s.field.isEqual(r.field)&&Ut(s.value,r.value)}(n,e):n instanceof $t?function(s,r){return r instanceof $t&&s.op===r.op&&s.filters.length===r.filters.length?s.filters.reduce((i,o,a)=>i&&ig(o,r.filters[a]),!0):!1}(n,e):void X(19439)}function og(n){return n instanceof qe?function(t){return`${t.field.canonicalString()} ${t.op} ${mr(t.value)}`}(n):n instanceof $t?function(t){return t.op.toString()+" {"+t.getFilters().map(og).join(" ,")+"}"}(n):"Filter"}class AT extends qe{constructor(e,t,s){super(e,t,s),this.key=$.fromName(s.referenceValue)}matches(e){const t=$.comparator(e.key,this.key);return this.matchesComparison(t)}}class vT extends qe{constructor(e,t){super(e,"in",t),this.keys=ag("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class RT extends qe{constructor(e,t){super(e,"not-in",t),this.keys=ag("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function ag(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(s=>$.fromName(s.referenceValue))}class ST extends qe{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return _r(t)&&ki(t.arrayValue,this.value)}}class bT extends qe{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&ki(this.value.arrayValue,t)}}class NT extends qe{constructor(e,t){super(e,"not-in",t)}matches(e){if(ki(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!ki(this.value.arrayValue,t)}}class PT extends qe{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!_r(t)||!t.arrayValue.values)&&t.arrayValue.values.some(s=>ki(this.value.arrayValue,s))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gi{constructor(e,t="asc"){this.field=e,this.dir=t}}function FT(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ne{static fromTimestamp(e){return new ne(e)}static min(){return new ne(new Ee(0,0))}static max(){return new ne(new Ee(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nt{constructor(e,t,s,r,i,o,a){this.key=e,this.documentType=t,this.version=s,this.readTime=r,this.createTime=i,this.data=o,this.documentState=a}static newInvalidDocument(e){return new nt(e,0,ne.min(),ne.min(),ne.min(),it.empty(),0)}static newFoundDocument(e,t,s,r){return new nt(e,1,t,ne.min(),s,r,0)}static newNoDocument(e,t){return new nt(e,2,t,ne.min(),ne.min(),it.empty(),0)}static newUnknownDocument(e,t){return new nt(e,3,t,ne.min(),ne.min(),it.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ne.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=it.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=it.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ne.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof nt&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new nt(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hi=-1;function OT(n,e){const t=n.toTimestamp().seconds,s=n.toTimestamp().nanoseconds+1,r=ne.fromTimestamp(s===1e9?new Ee(t+1,0):new Ee(t,s));return new rs(r,$.empty(),e)}function LT(n){return new rs(n.readTime,n.key,Hi)}class rs{constructor(e,t,s){this.readTime=e,this.documentKey=t,this.largestBatchId=s}static min(){return new rs(ne.min(),$.empty(),Hi)}static max(){return new rs(ne.max(),$.empty(),Hi)}}function xT(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=$.comparator(n.documentKey,e.documentKey),t!==0?t:ue(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kT{constructor(e,t=null,s=[],r=[],i=null,o=null,a=null){this.path=e,this.collectionGroup=t,this.orderBy=s,this.filters=r,this.limit=i,this.startAt=o,this.endAt=a,this.R=null}}function Dd(n,e=null,t=[],s=[],r=null,i=null,o=null){return new kT(n,e,t,s,r,i,o)}function lg(n){const e=re(n);if(e.R===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(s=>UB(s)).join(","),t+="|ob:",t+=e.orderBy.map(s=>function(i){return i.field.canonicalString()+i.dir}(s)).join(","),co(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(s=>mr(s)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(s=>mr(s)).join(",")),e.R=t}return e.R}function Bg(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!FT(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!ig(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Ed(n.startAt,e.startAt)&&Ed(n.endAt,e.endAt)}function vs(n){return!!n.isCorePipeline}function cg(n){return!!n.path&&$.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gs{constructor(e,t=null,s=[],r=[],i=null,o="F",a=null,B=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=s,this.filters=r,this.limit=i,this.limitType=o,this.startAt=a,this.endAt=B,this.A=null,this.V=null,this.m=null,this.startAt,this.endAt}}function MT(n,e,t,s,r,i,o,a){return new gs(n,e,t,s,r,i,o,a)}function nl(n){return new gs(n)}function yd(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function VT(n){return $.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Oc(n){return n.collectionGroup!==null}function ur(n){const e=re(n);if(e.A===null){e.A=[];const t=new Set;for(const i of e.explicitOrderBy)e.A.push(i),t.add(i.field.canonicalString());const s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new je(xt.comparator);return o.filters.forEach(B=>{B.getFlattenedFilters().forEach(c=>{c.isInequality()&&(a=a.add(c.field))})}),a})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.A.push(new Gi(i,s))}),t.has(xt.keyField().canonicalString())||e.A.push(new Gi(xt.keyField(),s))}return e.A}function on(n){const e=re(n);return e.V||(e.V=ug(e,ur(n))),e.V}function GT(n){const e=re(n);return e.m||(e.m=ug(e,n.explicitOrderBy)),e.m}function ug(n,e){if(n.limitType==="F")return Dd(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(r=>{const i=r.dir==="desc"?"asc":"desc";return new Gi(r.field,i)});const t=n.endAt?new yr(n.endAt.position,n.endAt.inclusive):null,s=n.startAt?new yr(n.startAt.position,n.startAt.inclusive):null;return Dd(n.path,n.collectionGroup,e,n.filters,n.limit,t,s)}}function qB(n,e){const t=n.filters.concat([e]);return new gs(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function HT(n,e){const t=n.explicitOrderBy.concat([e]);return new gs(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function wa(n,e,t){return new gs(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function UT(n,e){return new gs(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),n.limit,n.limitType,e,n.endAt)}function qT(n,e){return new gs(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),n.limit,n.limitType,n.startAt,e)}function JT(n,e){return Bg(on(n),on(e))&&n.limitType===e.limitType}function Ei(n){return`Query(target=${function(t){let s=t.path.canonicalString();return t.collectionGroup!==null&&(s+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(s+=`, filters: [${t.filters.map(r=>og(r)).join(", ")}]`),co(t.limit)||(s+=", limit: "+t.limit),t.orderBy.length>0&&(s+=`, orderBy: [${t.orderBy.map(r=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(r)).join(", ")}]`),t.startAt&&(s+=", startAt: ",s+=t.startAt.inclusive?"b:":"a:",s+=t.startAt.position.map(r=>mr(r)).join(",")),t.endAt&&(s+=", endAt: ",s+=t.endAt.inclusive?"a:":"b:",s+=t.endAt.position.map(r=>mr(r)).join(",")),`Target(${s})`}(on(n))}; limitType=${n.limitType})`}function sl(n,e){return e.isFoundDocument()&&function(s,r){const i=r.key.path;return s.collectionGroup!==null?r.key.hasCollectionId(s.collectionGroup)&&s.path.isPrefixOf(i):$.isDocumentKey(s.path)?s.path.isEqual(i):s.path.isImmediateParentOf(i)}(n,e)&&function(s,r){for(const i of ur(s))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0}(n,e)&&function(s,r){for(const i of s.filters)if(!i.matches(r))return!1;return!0}(n,e)&&function(s,r){return!(s.startAt&&!function(o,a,B){const c=_d(o,a,B);return o.inclusive?c<=0:c<0}(s.startAt,ur(s),r)||s.endAt&&!function(o,a,B){const c=_d(o,a,B);return o.inclusive?c>=0:c>0}(s.endAt,ur(s),r))}(n,e)}function Lc(n){return(e,t)=>{let s=!1;for(const r of ur(n)){const i=jT(r,e,t);if(i!==0)return i;s=s||r.field.isKeyField()}return 0}}function jT(n,e,t){const s=n.field.isKeyField()?$.comparator(e.key,t.key):function(i,o,a){const B=o.data.field(i),c=a.data.field(i);return B!==null&&c!==null?Rt(B,c):X(42886)}(n.field,e,t);switch(n.dir){case"asc":return s;case"desc":return-1*s;default:return X(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KT{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var He,de;function hg(n){switch(n){case O.OK:return X(64938);case O.CANCELLED:case O.UNKNOWN:case O.DEADLINE_EXCEEDED:case O.RESOURCE_EXHAUSTED:case O.INTERNAL:case O.UNAVAILABLE:case O.UNAUTHENTICATED:return!1;case O.INVALID_ARGUMENT:case O.NOT_FOUND:case O.ALREADY_EXISTS:case O.PERMISSION_DENIED:case O.FAILED_PRECONDITION:case O.ABORTED:case O.OUT_OF_RANGE:case O.UNIMPLEMENTED:case O.DATA_LOSS:return!0;default:return X(15467,{code:n})}}function fg(n){if(n===void 0)return In("GRPC error has no .code"),O.UNKNOWN;switch(n){case He.OK:return O.OK;case He.CANCELLED:return O.CANCELLED;case He.UNKNOWN:return O.UNKNOWN;case He.DEADLINE_EXCEEDED:return O.DEADLINE_EXCEEDED;case He.RESOURCE_EXHAUSTED:return O.RESOURCE_EXHAUSTED;case He.INTERNAL:return O.INTERNAL;case He.UNAVAILABLE:return O.UNAVAILABLE;case He.UNAUTHENTICATED:return O.UNAUTHENTICATED;case He.INVALID_ARGUMENT:return O.INVALID_ARGUMENT;case He.NOT_FOUND:return O.NOT_FOUND;case He.ALREADY_EXISTS:return O.ALREADY_EXISTS;case He.PERMISSION_DENIED:return O.PERMISSION_DENIED;case He.FAILED_PRECONDITION:return O.FAILED_PRECONDITION;case He.ABORTED:return O.ABORTED;case He.OUT_OF_RANGE:return O.OUT_OF_RANGE;case He.UNIMPLEMENTED:return O.UNIMPLEMENTED;case He.DATA_LOSS:return O.DATA_LOSS;default:return X(39323,{code:n})}}(de=He||(He={}))[de.OK=0]="OK",de[de.CANCELLED=1]="CANCELLED",de[de.UNKNOWN=2]="UNKNOWN",de[de.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",de[de.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",de[de.NOT_FOUND=5]="NOT_FOUND",de[de.ALREADY_EXISTS=6]="ALREADY_EXISTS",de[de.PERMISSION_DENIED=7]="PERMISSION_DENIED",de[de.UNAUTHENTICATED=16]="UNAUTHENTICATED",de[de.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",de[de.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",de[de.ABORTED=10]="ABORTED",de[de.OUT_OF_RANGE=11]="OUT_OF_RANGE",de[de.UNIMPLEMENTED=12]="UNIMPLEMENTED",de[de.INTERNAL=13]="INTERNAL",de[de.UNAVAILABLE=14]="UNAVAILABLE",de[de.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class js{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s!==void 0){for(const[r,i]of s)if(this.equalsFn(r,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const s=this.mapKeyFn(e),r=this.inner[s];if(r===void 0)return this.inner[s]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),s=this.inner[t];if(s===void 0)return!1;for(let r=0;r<s.length;r++)if(this.equalsFn(s[r][0],e))return s.length===1?delete this.inner[t]:s.splice(r,1),this.innerSize--,!0;return!1}forEach(e){Cs(this.inner,(t,s)=>{for(const[r,i]of s)e(r,i)})}isEmpty(){return Vp(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const QT=new Ge($.comparator);function Tt(){return QT}const dg=new Ge($.comparator);function ar(...n){let e=dg;for(const t of n)e=e.insert(t.key,t);return e}function Cg(n){let e=dg;return n.forEach((t,s)=>e=e.insert(t,s.overlayedDocument)),e}function Hn(){return Di()}function pg(){return Di()}function Di(){return new js(n=>n.toString(),(n,e)=>n.isEqual(e))}const zT=new Ge($.comparator),WT=new je($.comparator);function Be(...n){let e=WT;for(const t of n)e=e.add(t);return e}const $T=new je(ue);function YT(){return $T}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function XT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ZT=new Kn([4294967295,4294967295],0);function wd(n){const e=XT().encode(n),t=new Ip;return t.update(e),new Uint8Array(t.digest())}function Td(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),s=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new Kn([t,s],0),new Kn([r,i],0)]}class xc{constructor(e,t,s){if(this.bitmap=e,this.padding=t,this.hashCount=s,t<0||t>=8)throw new di(`Invalid padding: ${t}`);if(s<0)throw new di(`Invalid hash count: ${s}`);if(e.length>0&&this.hashCount===0)throw new di(`Invalid hash count: ${s}`);if(e.length===0&&t!==0)throw new di(`Invalid padding when bitmap length is 0: ${t}`);this.p=8*e.length-t,this.S=Kn.fromNumber(this.p)}v(e,t,s){let r=e.add(t.multiply(Kn.fromNumber(s)));return r.compare(ZT)===1&&(r=new Kn([r.getBits(0),r.getBits(1)],0)),r.modulo(this.S).toNumber()}D(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.p===0)return!1;const t=wd(e),[s,r]=Td(t);for(let i=0;i<this.hashCount;i++){const o=this.v(s,r,i);if(!this.D(o))return!1}return!0}static create(e,t,s){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new xc(i,r,t);return s.forEach(a=>o.insert(a)),o}insert(e){if(this.p===0)return;const t=wd(e),[s,r]=Td(t);for(let i=0;i<this.hashCount;i++){const o=this.v(s,r,i);this.C(o)}}C(e){const t=Math.floor(e/8),s=e%8;this.bitmap[t]|=1<<s}}class di extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ho{constructor(e,t,s,r,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=s,this.documentUpdates=r,this.augmentedDocumentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,s){const r=new Map;return r.set(e,fo.createSynthesizedTargetChangeForCurrentChange(e,t,s)),new ho(ne.min(),r,new Ge(ue),Tt(),Tt(),Be())}}class fo{constructor(e,t,s,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=s,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,s){return new fo(s,t,Be(),Be(),Be())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aa{constructor(e,t,s,r){this.F=e,this.removedTargetIds=t,this.key=s,this.O=r}}class gg{constructor(e,t){this.targetId=e,this.M=t}}class mg{constructor(e,t,s=Ke.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=s,this.cause=r}}class Id{constructor(e){this.targetId=e,this.N=0,this.L=Ad(),this.B=Ke.EMPTY_BYTE_STRING,this.U=!1,this.k=!0}get current(){return this.U}get resumeToken(){return this.B}get q(){return this.N!==0}get $(){return this.k}K(e){e.approximateByteSize()>0&&(this.k=!0,this.B=e)}W(){let e=Be(),t=Be(),s=Be();return this.L.forEach((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:s=s.add(r);break;default:X(38017,{changeType:i})}}),new fo(this.B,this.U,e,t,s)}G(){this.k=!1,this.L=Ad()}j(e,t){this.k=!0,this.L=this.L.insert(e,t)}H(e){this.k=!0,this.L=this.L.remove(e)}J(){this.N+=1}Y(){this.N-=1,W(this.N>=0,3241,{N:this.N,targetId:this.targetId})}Z(){this.k=!0,this.U=!0}}const ai="WatchChangeAggregator";class eI{constructor(e){this.X=e,this.ee=new Map,this.te=Tt(),this.ne=Xo(),this.re=Tt(),this.ie=Xo(),this.se=new Ge(ue)}_e(e){for(const t of e.F)e.O&&e.O.isFoundDocument()?this.oe(t,e.O):this.ae(t,e.key,e.O);for(const t of e.removedTargetIds)this.ae(t,e.key,e.O)}ue(e){this.forEachTarget(e,t=>{const s=this.ee.get(t);if(s)switch(e.state){case 0:this.ce(t)&&s.K(e.resumeToken);break;case 1:s.Y(),s.q||s.G(),s.K(e.resumeToken);break;case 2:s.Y(),s.q||this.removeTarget(t);break;case 3:this.ce(t)&&(s.Z(),s.K(e.resumeToken));break;case 4:this.ce(t)&&(this.le(t),s.K(e.resumeToken));break;default:X(56790,{state:e.state})}else Q(ai,`handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`)})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ee.forEach((s,r)=>{this.ce(r)&&t(r)})}Ee(e){var t;return vs(e)?e.getPipelineSourceType()==="documents"&&((t=e.getPipelineDocuments())==null?void 0:t.length)===1:cg(e)}he(e){const t=e.targetId,s=e.M.count,r=this.Te(t);if(r){const i=r.target;if(this.Ee(i))if(s===0){const o=new $(vs(i)?pe.fromString(i.getPipelineDocuments()[0]):i.path);this.ae(t,o,nt.newNoDocument(o,ne.min()))}else W(s===1,20013,"Single document existence filter with count: "+s);else{const o=this.Pe(t);if(o!==s){const a=this.Ie(e),B=a?this.Re(a,e,o):1;if(B!==0){this.le(t);const c=B===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.se=this.se.insert(t,c)}}}}}Ie(e){const t=e.M.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:s="",padding:r=0},hashCount:i=0}=t;let o,a;try{o=ns(s).toUint8Array()}catch(B){if(B instanceof Hp)return Wt("Decoding the base64 bloom filter in existence filter failed ("+B.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw B}try{a=new xc(o,r,i)}catch(B){return Wt(B instanceof di?"BloomFilter error: ":"Applying bloom filter failed: ",B),null}return a.p===0?null:a}Re(e,t,s){return t.M.count===s-this.de(e,t.targetId)?0:2}de(e,t){const s=this.X.getRemoteKeysForTarget(t);let r=0;return s.forEach(i=>{const o=this.X.Ve(),a=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(a)||(this.ae(t,i,null),r++)}),r}fe(e){const t=new Map;this.ee.forEach((i,o)=>{const a=this.Te(o);if(a){if(i.current&&this.Ee(a.target)){const B=vs(a.target)?pe.fromString(a.target.getPipelineDocuments()[0]):a.target.path,c=new $(B);this.me(c).has(o)||this.pe(o,c)||this.ae(o,c,nt.newNoDocument(c,e))}i.$&&(t.set(o,i.W()),i.G())}});let s=Be();this.ie.forEach((i,o)=>{let a=!0;o.forEachWhile(B=>{const c=this.Te(B);return!c||c.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(s=s.add(i))}),this.te.forEach((i,o)=>o.setReadTime(e)),this.re.forEach((i,o)=>o.setReadTime(e));const r=new ho(e,t,this.se,this.te,this.re,s);return this.te=Tt(),this.ne=Xo(),this.re=Tt(),this.ie=Xo(),this.se=new Ge(ue),r}oe(e,t){const s=this.ee.get(e);if(!s||!this.ce(e))return void Q(ai,`addDocumentToTarget received document for unknown inactive target (${e})`);const r=this.pe(e,t.key)?2:0;s.j(t.key,r),vs(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t.key,t):this.te=this.te.insert(t.key,t),this.ne=this.ne.insert(t.key,this.me(t.key).add(e)),this.ie=this.ie.insert(t.key,this.ge(t.key).add(e))}ae(e,t,s){const r=this.ee.get(e);r&&this.ce(e)?(this.pe(e,t)?r.j(t,1):r.H(t),this.ie=this.ie.insert(t,this.ge(t).delete(e)),this.ie=this.ie.insert(t,this.ge(t).add(e)),s&&(vs(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t,s):this.te=this.te.insert(t,s))):Q(ai,`removeDocumentFromTarget received document for unknown or inactive target (${e})`)}removeTarget(e){this.ee.delete(e)}Pe(e){const t=this.ee.get(e);if(!t)return 0;const s=t.W();return this.X.getRemoteKeysForTarget(e).size+s.addedDocuments.size-s.removedDocuments.size}J(e){let t=this.ee.get(e);t||(Q(ai,`recordPendingTargetRequest set up tracking for target ID ${e}`),t=new Id(e),this.ee.set(e,t)),t.J()}ge(e){let t=this.ie.get(e);return t||(t=new je(ue),this.ie=this.ie.insert(e,t)),t}me(e){let t=this.ne.get(e);return t||(t=new je(ue),this.ne=this.ne.insert(e,t)),t}ce(e){const t=this.Te(e)!==null;return t||Q(ai,"Detected inactive target",e),t}Te(e){const t=this.ee.get(e);return t===void 0||t.q?null:this.X.ye(e)}le(e){this.ee.set(e,new Id(e)),this.X.getRemoteKeysForTarget(e).forEach(t=>{this.ae(e,t,null)})}pe(e,t){return this.X.getRemoteKeysForTarget(e).has(t)}}function Xo(){return new Ge($.comparator)}function Ad(){return new Ge($.comparator)}const tI={asc:"ASCENDING",desc:"DESCENDING"},nI={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},sI={and:"AND",or:"OR"};class rI{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function JB(n,e){return n.useProto3Json||co(e)?e:{value:e}}function yi(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function kc(n){const e=ts(n);return new Ee(e.seconds,e.nanos)}function _g(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function la(n,e){return yi(n,e.toTimestamp())}function kt(n){return W(!!n,49232),ne.fromTimestamp(kc(n))}function Mc(n,e){return jB(n,e).canonicalString()}function jB(n,e){const t=function(r){return new pe(["projects",r.projectId,"databases",r.database])}(n).child("documents");return e===void 0?t:t.child(e)}function Eg(n){const e=pe.fromString(n);return W(vg(e),10190,{key:e.toString()}),e}function Ui(n,e){return Mc(n.databaseId,e.path)}function wi(n,e){const t=Eg(e);if(t.get(1)!==n.databaseId.projectId)throw new G(O.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new G(O.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new $(yg(t))}function Dg(n,e){return Mc(n.databaseId,e)}function iI(n){const e=Eg(n);return e.length===4?pe.emptyPath():yg(e)}function KB(n){return new pe(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function yg(n){return W(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function vd(n,e,t){return{name:Ui(n,e),fields:t.value.mapValue.fields}}function oI(n,e){return"found"in e?function(s,r){W(!!r.found,43571),r.found.name,r.found.updateTime;const i=wi(s,r.found.name),o=kt(r.found.updateTime),a=r.found.createTime?kt(r.found.createTime):ne.min(),B=new it({mapValue:{fields:r.found.fields}});return nt.newFoundDocument(i,o,a,B)}(n,e):"missing"in e?function(s,r){W(!!r.missing,3894),W(!!r.readTime,22933);const i=wi(s,r.missing),o=kt(r.readTime);return nt.newNoDocument(i,o)}(n,e):X(7234,{result:e})}function aI(n,e){let t;if("targetChange"in e){e.targetChange;const s=function(c){return c==="NO_CHANGE"?0:c==="ADD"?1:c==="REMOVE"?2:c==="CURRENT"?3:c==="RESET"?4:X(39313,{state:c})}(e.targetChange.targetChangeType||"NO_CHANGE"),r=e.targetChange.targetIds||[],i=function(c,u){return c.useProto3Json?(W(u===void 0||typeof u=="string",58123),Ke.fromBase64String(u||"")):(W(u===void 0||u instanceof Buffer||u instanceof Uint8Array,16193),Ke.fromUint8Array(u||new Uint8Array))}(n,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(c){const u=c.code===void 0?O.UNKNOWN:fg(c.code);return new G(u,c.message||"")}(o);t=new mg(s,r,i,a||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const r=wi(n,s.document.name),i=kt(s.document.updateTime),o=s.document.createTime?kt(s.document.createTime):ne.min(),a=new it({mapValue:{fields:s.document.fields}}),B=nt.newFoundDocument(r,i,o,a),c=s.targetIds||[],u=s.removedTargetIds||[];t=new aa(c,u,B.key,B)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const r=wi(n,s.document),i=s.readTime?kt(s.readTime):ne.min(),o=nt.newNoDocument(r,i),a=s.removedTargetIds||[];t=new aa([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const r=wi(n,s.document),i=s.removedTargetIds||[];t=new aa([],i,r,null)}else{if(!("filter"in e))return X(11601,{we:e});{e.filter;const s=e.filter;s.targetId;const{count:r=0,unchangedNames:i}=s,o=new KT(r,i),a=s.targetId;t=new gg(a,o)}}return t}function wg(n,e){let t;if(e instanceof uo)t={update:vd(n,e.key,e.value)};else if(e instanceof tl)t={delete:Ui(n,e.key)};else if(e instanceof ps)t={update:vd(n,e.key,e.data),updateMask:gI(e.fieldMask)};else{if(!(e instanceof tg))return X(16599,{be:e.type});t={verify:Ui(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(s=>function(i,o){const a=o.transform;if(a instanceof Mi)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof Er)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof Vi)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof Dr)return{fieldPath:o.field.canonicalString(),increment:a.h};if(a instanceof Ea)return{fieldPath:o.field.canonicalString(),minimum:a.h};if(a instanceof Da)return{fieldPath:o.field.canonicalString(),maximum:a.h};throw X(20930,{transform:o.transform})}(0,s))),e.precondition.isNone||(t.currentDocument=function(r,i){return i.updateTime!==void 0?{updateTime:la(r,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:X(27497)}(n,e.precondition)),t}function lI(n,e){return n&&n.length>0?(W(e!==void 0,14353),n.map(t=>function(r,i){let o=r.updateTime?kt(r.updateTime):kt(i);return o.isEqual(ne.min())&&(o=kt(i)),new yT(o,r.transformResults||[])}(t,e))):[]}function BI(n,e){return{documents:[Dg(n,e.path)]}}function Tg(n,e){const t={structuredQuery:{}},s=e.path;let r;e.collectionGroup!==null?(r=s,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=s.popLast(),t.structuredQuery.from=[{collectionId:s.lastSegment()}]),t.parent=Dg(n,r);const i=function(c){if(c.length!==0)return Ag($t.create(c,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const o=function(c){if(c.length!==0)return c.map(u=>function(C){return{field:Un(C.field),direction:dI(C.dir)}}(u))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const a=JB(n,e.limit);return a!==null&&(t.structuredQuery.limit=a),e.startAt&&(t.structuredQuery.startAt=function(c){return{before:c.inclusive,values:c.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(c){return{before:!c.inclusive,values:c.position}}(e.endAt)),{Se:t,parent:r}}function cI(n,e,t,s){const{Se:r,parent:i}=Tg(n,e),o={},a=[];let B=0;return t.forEach(c=>{const u="aggregate_"+B++;o[u]=c.alias,c.aggregateType==="count"?a.push({alias:u,count:{}}):c.aggregateType==="avg"?a.push({alias:u,avg:{field:Un(c.fieldPath)}}):c.aggregateType==="sum"&&a.push({alias:u,sum:{field:Un(c.fieldPath)}})}),{request:{structuredAggregationQuery:{aggregations:a,structuredQuery:r.structuredQuery},parent:r.parent},ve:o,parent:i}}function uI(n){let e=iI(n.parent);const t=n.structuredQuery,s=t.from?t.from.length:0;let r=null;if(s>0){W(s===1,65062);const u=t.from[0];u.allDescendants?r=u.collectionId:e=e.child(u.collectionId)}let i=[];t.where&&(i=function(f){const C=Ig(f);return C instanceof $t&&rg(C)?C.getFilters():[C]}(t.where));let o=[];t.orderBy&&(o=function(f){return f.map(C=>function(E){return new Gi(lr(E.field),function(F){switch(F){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(E.direction))}(C))}(t.orderBy));let a=null;t.limit&&(a=function(f){let C;return C=typeof f=="object"?f.value:f,co(C)?null:C}(t.limit));let B=null;t.startAt&&(B=function(f){const C=!!f.before,g=f.values||[];return new yr(g,C)}(t.startAt));let c=null;return t.endAt&&(c=function(f){const C=!f.before,g=f.values||[];return new yr(g,C)}(t.endAt)),MT(e,r,o,i,a,"F",B,c)}function hI(n,e){const t=function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return X(28987,{purpose:r})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function fI(n,e){return{structuredPipeline:{pipeline:{stages:e.stages.map(t=>t._toProto(n))}}}}function Ig(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const s=lr(t.unaryFilter.field);return qe.create(s,"==",{doubleValue:NaN});case"IS_NULL":const r=lr(t.unaryFilter.field);return qe.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=lr(t.unaryFilter.field);return qe.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=lr(t.unaryFilter.field);return qe.create(o,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return X(61313);default:return X(60726)}}(n):n.fieldFilter!==void 0?function(t){return qe.create(lr(t.fieldFilter.field),function(r){switch(r){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return X(58110);default:return X(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return $t.create(t.compositeFilter.filters.map(s=>Ig(s)),function(r){switch(r){case"AND":return"and";case"OR":return"or";default:return X(1026)}}(t.compositeFilter.op))}(n):X(30097,{filter:n})}function dI(n){return tI[n]}function CI(n){return nI[n]}function pI(n){return sI[n]}function Un(n){return{fieldPath:n.canonicalString()}}function lr(n){return xt.fromServerFormat(n.fieldPath)}function Ag(n){return n instanceof qe?function(t){if(t.op==="=="){if(St(t.value))return{unaryFilter:{field:Un(t.field),op:"IS_NAN"}};if(Lt(t.value))return{unaryFilter:{field:Un(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(St(t.value))return{unaryFilter:{field:Un(t.field),op:"IS_NOT_NAN"}};if(Lt(t.value))return{unaryFilter:{field:Un(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Un(t.field),op:CI(t.op),value:t.value}}}(n):n instanceof $t?function(t){const s=t.getFilters().map(r=>Ag(r));return s.length===1?s[0]:{compositeFilter:{op:pI(t.op),filters:s}}}(n):X(54877,{filter:n})}function gI(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function vg(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function Rg(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}function qi(n,e){const t={fields:{}};return e.forEach((s,r)=>{if(typeof r!="string")throw new Error(`Cannot encode map with non-string key: ${r}`);t.fields[r]=s._toProto(n)}),{mapValue:t}}function Sg(n){return{stringValue:n}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rl(n){return new rI(n,!0)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ft{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Ft(Ke.fromBase64String(e))}catch(t){throw new G(O.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Ft(Ke.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:Ft._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(ao(e,Ft._jsonSchema))return Ft.fromBase64String(e.bytes)}}Ft._jsonSchemaVersion="firestore/bytes/1.0",Ft._jsonSchema={type:Je("string",Ft._jsonSchemaVersion),bytes:Je("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Co{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new G(O.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new xt(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}function mI(){return new Co(nn)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pr{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class an{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new G(O.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new G(O.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return ue(this._lat,e._lat)||ue(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:an._jsonSchemaVersion}}static fromJSON(e){if(ao(e,an._jsonSchema))return new an(e.latitude,e.longitude)}}an._jsonSchemaVersion="firestore/geoPoint/1.0",an._jsonSchema={type:Je("string",an._jsonSchemaVersion),latitude:Je("number"),longitude:Je("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ut.UNAUTHENTICATED=new ut(null),ut.GOOGLE_CREDENTIALS=new ut("google-credentials-uid"),ut.FIRST_PARTY=new ut("first-party-uid"),ut.MOCK_USER=new ut("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qt{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bg{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class _I{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(ut.UNAUTHENTICATED))}shutdown(){}}class EI{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class DI{constructor(e){this.De=e,this.currentUser=ut.UNAUTHENTICATED,this.xe=0,this.forceRefresh=!1,this.auth=null}start(e,t){W(this.Ce===void 0,42304);let s=this.xe;const r=B=>this.xe!==s?(s=this.xe,t(B)):Promise.resolve();let i=new Qt;this.Ce=()=>{this.xe++,this.currentUser=this.Fe(),i.resolve(),i=new Qt,e.enqueueRetryable(()=>r(this.currentUser))};const o=()=>{const B=i;e.enqueueRetryable(async()=>{await B.promise,await r(this.currentUser)})},a=B=>{Q("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=B,this.Ce&&(this.auth.addAuthTokenListener(this.Ce),o())};this.De.onInit(B=>a(B)),setTimeout(()=>{if(!this.auth){const B=this.De.getImmediate({optional:!0});B?a(B):(Q("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new Qt)}},0),o()}getToken(){const e=this.xe,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(s=>this.xe!==e?(Q("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):s?(W(typeof s.accessToken=="string",31837,{Oe:s}),new bg(s.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.Ce&&this.auth.removeAuthTokenListener(this.Ce),this.Ce=void 0}Fe(){const e=this.auth&&this.auth.getUid();return W(e===null||typeof e=="string",2055,{Me:e}),new ut(e)}}class yI{constructor(e,t,s){this.Ne=e,this.Le=t,this.Be=s,this.type="FirstParty",this.user=ut.FIRST_PARTY,this.Ue=new Map}ke(){return this.Be?this.Be():null}get headers(){this.Ue.set("X-Goog-AuthUser",this.Ne);const e=this.ke();return e&&this.Ue.set("Authorization",e),this.Le&&this.Ue.set("X-Goog-Iam-Authorization-Token",this.Le),this.Ue}}class wI{constructor(e,t,s){this.Ne=e,this.Le=t,this.Be=s}getToken(){return Promise.resolve(new yI(this.Ne,this.Le,this.Be))}start(e,t){e.enqueueRetryable(()=>t(ut.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Rd{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class TI{constructor(e,t){this.qe=t,this.forceRefresh=!1,this.appCheck=null,this.$e=null,this.Ke=null,ZC(e)&&e.settings.appCheckToken&&(this.Ke=e.settings.appCheckToken)}start(e,t){W(this.Ce===void 0,3512);const s=i=>{i.error!=null&&Q("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.$e;return this.$e=i.token,Q("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.Ce=i=>{e.enqueueRetryable(()=>s(i))};const r=i=>{Q("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.Ce&&this.appCheck.addTokenListener(this.Ce)};this.qe.onInit(i=>r(i)),setTimeout(()=>{if(!this.appCheck){const i=this.qe.getImmediate({optional:!0});i?r(i):Q("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.Ke)return Promise.resolve(new Rd(this.Ke));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(W(typeof t.token=="string",44558,{tokenResult:t}),this.$e=t.token,new Rd(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.Ce&&this.appCheck.removeTokenListener(this.Ce),this.Ce=void 0}}function Ng(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class II{Qe(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sd="ConnectivityMonitor";class bd{constructor(){this.We=()=>this.Ge(),this.ze=()=>this.je(),this.He=[],this.Je()}Qe(e){this.He.push(e)}shutdown(){window.removeEventListener("online",this.We),window.removeEventListener("offline",this.ze)}Je(){window.addEventListener("online",this.We),window.addEventListener("offline",this.ze)}Ge(){Q(Sd,"Network connectivity changed: AVAILABLE");for(const e of this.He)e(0)}je(){Q(Sd,"Network connectivity changed: UNAVAILABLE");for(const e of this.He)e(1)}static Ye(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Zo=null;function QB(){return Zo===null?Zo=function(){return 268435456+Math.round(2147483648*Math.random())}():Zo++,"0x"+Zo.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dB="RestConnection",AI={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class vI{get Ze(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",s=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.Xe=t+"://"+e.host,this.et=`projects/${s}/databases/${r}`,this.tt=this.databaseId.database===ga?`project_id=${s}`:`project_id=${s}&database_id=${r}`}nt(e,t,s,r,i){const o=QB(),a=this.rt(e,t.toUriEncodedString());Q(dB,`Sending RPC '${e}' ${o}:`,a,s);const B={"google-cloud-resource-prefix":this.et,"x-goog-request-params":this.tt};this.it(B,r,i);const{host:c}=new URL(a),u=Ka(c);return this.st(e,a,B,s,u).then(f=>(Q(dB,`Received RPC '${e}' ${o}: `,f),f),f=>{throw Wt(dB,`RPC '${e}' ${o} failed with error: `,f,"url: ",a,"request:",s),f})}_t(e,t,s,r,i,o){return this.nt(e,t,s,r,i)}it(e,t,s){if(e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Nr}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((r,i)=>e[i]=r),s&&s.headers.forEach((r,i)=>e[i]=r),this.databaseInfo._customHeaders)for(const r of Object.keys(this.databaseInfo._customHeaders))e[r]=this.databaseInfo._customHeaders[r]}rt(e,t){const s=AI[e];let r=`${this.Xe}/v1/${t}:${s}`;return this.databaseInfo.apiKey&&(r=`${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),r}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RI{constructor(e){this.ot=e.ot,this.ut=e.ut}ct(e){this.lt=e}Et(e){this.ht=e}Tt(e){this.Pt=e}onMessage(e){this.It=e}close(){this.ut()}send(e){this.ot(e)}Rt(){this.lt()}At(){this.ht()}Vt(e){this.Pt(e)}dt(e){this.It(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ct="WebChannelConnection",li=(n,e,t)=>{n.listen(e,s=>{try{t(s)}catch(r){setTimeout(()=>{throw r},0)}})};class hr extends vI{constructor(e){super(e),this.ft=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static gt(){if(!hr.yt){const e=Sp();li(e,Rp.STAT_EVENT,t=>{t.stat===OB.PROXY?Q(ct,"STAT_EVENT: detected buffering proxy"):t.stat===OB.NOPROXY&&Q(ct,"STAT_EVENT: detected no buffering proxy")}),hr.yt=!0}}st(e,t,s,r,i){const o=QB();return new Promise((a,B)=>{const c=new Ap;c.setWithCredentials(!0),c.listenOnce(vp.COMPLETE,()=>{try{switch(c.getLastErrorCode()){case ra.NO_ERROR:const f=c.getResponseJson();Q(ct,`XHR for RPC '${e}' ${o} received:`,JSON.stringify(f)),a(f);break;case ra.TIMEOUT:Q(ct,`RPC '${e}' ${o} timed out`),B(new G(O.DEADLINE_EXCEEDED,"Request time out"));break;case ra.HTTP_ERROR:const C=c.getStatus();if(Q(ct,`RPC '${e}' ${o} failed with status:`,C,"response text:",c.getResponseText()),C>0){let g=c.getResponseJson();Array.isArray(g)&&(g=g[0]);const E=g==null?void 0:g.error;if(E&&E.status&&E.message){const b=function(j){const te=j.toLowerCase().replace(/_/g,"-");return Object.values(O).indexOf(te)>=0?te:O.UNKNOWN}(E.status);B(new G(b,E.message))}else B(new G(O.UNKNOWN,"Server responded with status "+c.getStatus()))}else B(new G(O.UNAVAILABLE,"Connection failed."));break;default:X(9055,{wt:e,streamId:o,bt:c.getLastErrorCode(),St:c.getLastError()})}}finally{Q(ct,`RPC '${e}' ${o} completed.`)}});const u=JSON.stringify(r);Q(ct,`RPC '${e}' ${o} sending request:`,r),c.send(t,"POST",u,s,15)})}vt(e,t,s){const r=QB(),i=[this.Xe,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=this.createWebChannelTransport(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},B=this.longPollingOptions.timeoutSeconds;B!==void 0&&(a.longPollingTimeout=Math.round(1e3*B)),this.useFetchStreams&&(a.useFetchStreams=!0),this.it(a.initMessageHeaders,t,s),a.encodeInitMessageHeaders=!0;const c=i.join("");Q(ct,`Creating RPC '${e}' stream ${r}: ${c}`,a);const u=o.createWebChannel(c,a);this.Dt(u);let f=!1,C=!1;const g=new RI({ot:E=>{C?Q(ct,`Not sending because RPC '${e}' stream ${r} is closed:`,E):(f||(Q(ct,`Opening RPC '${e}' stream ${r} transport.`),u.open(),f=!0),Q(ct,`RPC '${e}' stream ${r} sending:`,E),u.send(E))},ut:()=>u.close()});return li(u,fi.EventType.OPEN,()=>{C||(Q(ct,`RPC '${e}' stream ${r} transport opened.`),g.Rt())}),li(u,fi.EventType.CLOSE,()=>{C||(C=!0,Q(ct,`RPC '${e}' stream ${r} transport closed`),g.Vt(),this.xt(u))}),li(u,fi.EventType.ERROR,E=>{C||(C=!0,Wt(ct,`RPC '${e}' stream ${r} transport errored. Name:`,E.name,"Message:",E.message),g.Vt(new G(O.UNAVAILABLE,"The operation could not be completed")))}),li(u,fi.EventType.MESSAGE,E=>{var b;if(!C){const F=E.data[0];W(!!F,16349);const j=F,te=(j==null?void 0:j.error)||((b=j[0])==null?void 0:b.error);if(te){Q(ct,`RPC '${e}' stream ${r} received error:`,te);const ie=te.status;let me=function(v){const D=He[v];if(D!==void 0)return fg(D)}(ie),Me=te.message;ie==="NOT_FOUND"&&Me.includes("database")&&Me.includes("does not exist")&&Me.includes(this.databaseId.database)&&Wt(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),me===void 0&&(me=O.INTERNAL,Me="Unknown error status: "+ie+" with message "+te.message),C=!0,g.Vt(new G(me,Me)),u.close()}else Q(ct,`RPC '${e}' stream ${r} received:`,F),g.dt(F)}}),hr.gt(),setTimeout(()=>{g.At()},0),g}terminate(){this.ft.forEach(e=>e.close()),this.ft=[]}Dt(e){this.ft.push(e)}xt(e){this.ft=this.ft.filter(t=>t===e)}it(e,t,s){super.it(e,t,s),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return bp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function SI(n){return new hr(n)}hr.yt=!1;class Vc{constructor(e,t,s=1e3,r=1.5,i=6e4){this.Ct=e,this.timerId=t,this.Ft=s,this.Ot=r,this.Mt=i,this.Nt=0,this.Lt=null,this.Bt=Date.now(),this.reset()}reset(){this.Nt=0}Ut(){this.Nt=this.Mt}kt(e){this.cancel();const t=Math.floor(this.Nt+this.qt()),s=Math.max(0,Date.now()-this.Bt),r=Math.max(0,t-s);r>0&&Q("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.Nt} ms, delay with jitter: ${t} ms, last attempt: ${s} ms ago)`),this.Lt=this.Ct.enqueueAfterDelay(this.timerId,r,()=>(this.Bt=Date.now(),e())),this.Nt*=this.Ot,this.Nt<this.Ft&&(this.Nt=this.Ft),this.Nt>this.Mt&&(this.Nt=this.Mt)}$t(){this.Lt!==null&&(this.Lt.skipDelay(),this.Lt=null)}cancel(){this.Lt!==null&&(this.Lt.cancel(),this.Lt=null)}qt(){return(Math.random()-.5)*this.Nt}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nd="PersistentStream";class Pg{constructor(e,t,s,r,i,o,a,B){this.Ct=e,this.Kt=s,this.Qt=r,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=B,this.state=0,this.Wt=0,this.Gt=null,this.zt=null,this.stream=null,this.jt=0,this.Ht=new Vc(e,t)}Jt(){return this.state===1||this.state===5||this.Yt()}Yt(){return this.state===2||this.state===3}start(){this.jt=0,this.state!==4?this.auth():this.Zt()}async stop(){this.Jt()&&await this.close(0)}Xt(){this.state=0,this.Ht.reset()}en(){this.Yt()&&this.Gt===null&&(this.Gt=this.Ct.enqueueAfterDelay(this.Kt,6e4,()=>this.tn()))}nn(e){this.rn(),this.stream.send(e)}async tn(){if(this.Yt())return this.close(0)}rn(){this.Gt&&(this.Gt.cancel(),this.Gt=null)}sn(){this.zt&&(this.zt.cancel(),this.zt=null)}async close(e,t){this.rn(),this.sn(),this.Ht.cancel(),this.Wt++,e!==4?this.Ht.reset():t&&t.code===O.RESOURCE_EXHAUSTED?(In(t.toString()),In("Using maximum backoff delay to prevent overloading the backend."),this.Ht.Ut()):t&&t.code===O.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this._n(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Tt(t)}_n(){}auth(){this.state=1;const e=this.an(this.Wt),t=this.Wt;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([s,r])=>{this.Wt===t&&this.un(s,r)},s=>{e(()=>{const r=new G(O.UNKNOWN,"Fetching auth token failed: "+s.message);return this.cn(r)})})}un(e,t){const s=this.an(this.Wt);this.stream=this.En(e,t),this.stream.ct(()=>{s(()=>this.listener.ct())}),this.stream.Et(()=>{s(()=>(this.state=2,this.zt=this.Ct.enqueueAfterDelay(this.Qt,1e4,()=>(this.Yt()&&(this.state=3),Promise.resolve())),this.listener.Et()))}),this.stream.Tt(r=>{s(()=>this.cn(r))}),this.stream.onMessage(r=>{s(()=>++this.jt==1?this.hn(r):this.onNext(r))})}Zt(){this.state=5,this.Ht.kt(async()=>{this.state=0,this.start()})}cn(e){return Q(Nd,`close with error: ${e}`),this.stream=null,this.close(4,e)}an(e){return t=>{this.Ct.enqueueAndForget(()=>this.Wt===e?t():(Q(Nd,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class bI extends Pg{constructor(e,t,s,r,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,s,r,o),this.serializer=i}En(e,t){return this.connection.vt("Listen",e,t)}hn(e){return this.onNext(e)}onNext(e){this.Ht.reset();const t=aI(this.serializer,e),s=function(i){if(!("targetChange"in i))return ne.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?ne.min():o.readTime?kt(o.readTime):ne.min()}(e);return this.listener.Tn(t,s)}Pn(e){const t={};t.database=KB(this.serializer),t.addTarget=function(i,o){let a;const B=o.target;if(a=vs(B)?{pipelineQuery:fI(i,B)}:cg(B)?{documents:BI(i,B)}:{query:Tg(i,B).Se},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=_g(i,o.resumeToken);const c=JB(i,o.expectedCount);c!==null&&(a.expectedCount=c)}else if(o.snapshotVersion.compareTo(ne.min())>0){a.readTime=yi(i,o.snapshotVersion.toTimestamp());const c=JB(i,o.expectedCount);c!==null&&(a.expectedCount=c)}return a}(this.serializer,e);const s=hI(this.serializer,e);s&&(t.labels=s),this.nn(t)}In(e){const t={};t.database=KB(this.serializer),t.removeTarget=e,this.nn(t)}}class NI extends Pg{constructor(e,t,s,r,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,s,r,o),this.serializer=i}get Rn(){return this.jt>0}start(){this.lastStreamToken=void 0,super.start()}_n(){this.Rn&&this.An([])}En(e,t){return this.connection.vt("Write",e,t)}hn(e){return W(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,W(!e.writeResults||e.writeResults.length===0,55816),this.listener.Vn()}onNext(e){W(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.Ht.reset();const t=lI(e.writeResults,e.commitTime),s=kt(e.commitTime);return this.listener.dn(s,t)}fn(){const e={};e.database=KB(this.serializer),this.nn(e)}An(e){const t={streamToken:this.lastStreamToken,writes:e.map(s=>wg(this.serializer,s))};this.nn(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PI{}class FI extends PI{constructor(e,t,s,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=s,this.serializer=r,this.mn=!1}pn(){if(this.mn)throw new G(O.FAILED_PRECONDITION,"The client has already been terminated.")}nt(e,t,s,r){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.nt(e,jB(t,s),r,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===O.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new G(O.UNKNOWN,i.toString())})}_t(e,t,s,r,i){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection._t(e,jB(t,s),r,o,a,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===O.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new G(O.UNKNOWN,o.toString())})}terminate(){this.mn=!0,this.connection.terminate()}}function OI(n,e,t,s){return new FI(n,e,t,s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const LI="ComponentProvider",Pd=new Map;function xI(n,e,t,s,r){return new fT(n,e,t,r.host,r.ssl,r.experimentalForceLongPolling,r.experimentalAutoDetectLongPolling,Ng(r.experimentalLongPollingOptions),r.useFetchStreams,r.isUsingEmulator,s,r._customHeaders,r.grpcFlowControlWindow)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fd={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Fg=41943040;class wt{static withCacheSize(e){return new wt(e,wt.DEFAULT_COLLECTION_PERCENTILE,wt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,s){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=s}}wt.DEFAULT_COLLECTION_PERCENTILE=10,wt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,wt.DEFAULT=new wt(Fg,wt.DEFAULT_COLLECTION_PERCENTILE,wt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),wt.DISABLED=new wt(-1,0,0);/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class il{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=s=>this.gn(s),this.yn=s=>t.writeSequenceNumber(s))}gn(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.yn&&this.yn(e),e}}il.wn=-1;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kI="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class MI{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fr(n){if(n.code!==O.FAILED_PRECONDITION||n.message!==kI)throw n;Q("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&X(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new M((s,r)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(s,r)},this.catchCallback=i=>{this.wrapFailure(t,i).next(s,r)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof M?t:M.resolve(t)}catch(t){return M.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):M.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):M.reject(t)}static resolve(e){return new M((t,s)=>{t(e)})}static reject(e){return new M((t,s)=>{s(e)})}static waitFor(e){return new M((t,s)=>{let r=0,i=0,o=!1;e.forEach(a=>{++r,a.next(()=>{++i,o&&i===r&&t()},B=>s(B))}),o=!0,i===r&&t()})}static or(e){let t=M.resolve(!1);for(const s of e)t=t.next(r=>r?M.resolve(r):s());return t}static forEach(e,t){const s=[];return e.forEach((r,i)=>{s.push(t.call(this,r,i))}),this.waitFor(s)}static mapArray(e,t){return new M((s,r)=>{const i=e.length,o=new Array(i);let a=0;for(let B=0;B<i;B++){const c=B;t(e[c]).next(u=>{o[c]=u,++a,a===i&&s(o)},u=>r(u))}})}static doWhile(e,t){return new M((s,r)=>{const i=()=>{e()===!0?t().next(()=>{i()},r):s()};i()})}}function VI(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function Or(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Od="LruGarbageCollector",GI=1048576;function Ld([n,e],[t,s]){const r=ue(n,t);return r===0?ue(e,s):r}class HI{constructor(e){this.Yn=e,this.buffer=new je(Ld),this.Zn=0}Xn(){return++this.Zn}er(e){const t=[e,this.Xn()];if(this.buffer.size<this.Yn)this.buffer=this.buffer.add(t);else{const s=this.buffer.last();Ld(t,s)<0&&(this.buffer=this.buffer.delete(s).add(t))}}get maxValue(){return this.buffer.last()[0]}}class UI{constructor(e,t,s){this.garbageCollector=e,this.asyncQueue=t,this.localStore=s,this.tr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.nr(6e4)}stop(){this.tr&&(this.tr.cancel(),this.tr=null)}get started(){return this.tr!==null}nr(e){Q(Od,`Garbage collection scheduled in ${e}ms`),this.tr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.tr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Or(t)?Q(Od,"Ignoring IndexedDB error during garbage collection: ",t):await Fr(t)}await this.nr(3e5)})}}class qI{constructor(e,t){this.rr=e,this.params=t}calculateTargetCount(e,t){return this.rr.ir(e).next(s=>Math.floor(t/100*s))}nthSequenceNumber(e,t){if(t===0)return M.resolve(il.wn);const s=new HI(t);return this.rr.forEachTarget(e,r=>s.er(r.sequenceNumber)).next(()=>this.rr.sr(e,r=>s.er(r))).next(()=>s.maxValue)}removeTargets(e,t,s){return this.rr.removeTargets(e,t,s)}removeOrphanedDocuments(e,t){return this.rr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(Q("LruGarbageCollector","Garbage collection skipped; disabled"),M.resolve(Fd)):this.getCacheSize(e).next(s=>s<this.params.cacheSizeCollectionThreshold?(Q("LruGarbageCollector",`Garbage collection skipped; Cache size ${s} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Fd):this._r(e,t))}getCacheSize(e){return this.rr.getCacheSize(e)}_r(e,t){let s,r,i,o,a,B,c;const u=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(f=>(f>this.params.maximumSequenceNumbersToCollect?(Q("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${f}`),r=this.params.maximumSequenceNumbersToCollect):r=f,o=Date.now(),this.nthSequenceNumber(e,r))).next(f=>(s=f,a=Date.now(),this.removeTargets(e,s,t))).next(f=>(i=f,B=Date.now(),this.removeOrphanedDocuments(e,s))).next(f=>(c=Date.now(),ir()<=he.DEBUG&&Q("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-u}ms
	Determined least recently used ${r} in `+(a-o)+`ms
	Removed ${i} targets in `+(B-a)+`ms
	Removed ${f} documents in `+(c-B)+`ms
Total Duration: ${c-u}ms`),M.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:f})))}}function JI(n,e){return new qI(n,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Og="firestore.googleapis.com",xd=!0;class kd{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new G(O.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Og,this.ssl=xd}else this.host=e.host,this.ssl=e.ssl??xd;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e._customHeaders&&(this._customHeaders={...e._customHeaders}),e.cacheSizeBytes===void 0)this.cacheSizeBytes=Fg;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<GI)throw new G(O.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}if(cT("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Ng(e.experimentalLongPollingOptions??{}),function(s){if(s.timeoutSeconds!==void 0){if(isNaN(s.timeoutSeconds))throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (must not be NaN)`);if(s.timeoutSeconds<5)throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (minimum allowed value is 5)`);if(s.timeoutSeconds>30)throw new G(O.INVALID_ARGUMENT,`invalid long polling timeout: ${s.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams,e.grpcFlowControlWindow!==void 0){if(typeof e.grpcFlowControlWindow!="number"||e.grpcFlowControlWindow<=0||e.grpcFlowControlWindow>2147483647||!Number.isInteger(e.grpcFlowControlWindow))throw new G(O.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=e.grpcFlowControlWindow}}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(s,r){return s.timeoutSeconds===r.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams&&this.grpcFlowControlWindow===e.grpcFlowControlWindow&&function(s,r){if(s===r)return!0;if(!s||!r)return!1;const i=Object.keys(s),o=Object.keys(r);if(i.length!==o.length)return!1;for(const a of i)if(s[a]!==r[a])return!1;return!0}(this._customHeaders,e._customHeaders)}}let ol=class{constructor(e,t,s,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=s,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new kd({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new G(O.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new G(O.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new kd(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(s){if(!s)return new _I;switch(s.type){case"firstParty":return new wI(s.sessionIndex||"0",s.iamToken||null,s.authTokenFactory||null);case"provider":return s.client;default:throw new G(O.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const s=Pd.get(t);s&&(Q(LI,"Removing Datastore"),Pd.delete(t),s.terminate())}(this),Promise.resolve()}};function jI(n,e,t,s={}){var c;n=ht(n,ol);const r=Ka(e),i=n._getSettings(),o={...i,emulatorOptions:n._getEmulatorOptions()},a=`${e}:${t}`;r&&WC(`https://${a}`),i.host!==Og&&i.host!==a&&Wt("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const B={...i,host:a,ssl:r,emulatorOptions:s};if(!ks(B,o)&&(n._setSettings(B),s.mockUserToken)){let u,f;if(typeof s.mockUserToken=="string")u=s.mockUserToken,f=ut.MOCK_USER;else{u=qC(s.mockUserToken,(c=n._app)==null?void 0:c.options.projectId);const C=s.mockUserToken.sub||s.mockUserToken.user_id;if(!C)throw new G(O.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");f=new ut(C)}n._authCredentials=new EI(new bg(u,f))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xt{constructor(e,t,s){this.converter=t,this._query=s,this.type="query",this.firestore=e}withConverter(e){return new Xt(this.firestore,e,this._query)}}class Pe{constructor(e,t,s){this.converter=t,this._key=s,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new zn(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Pe(this.firestore,e,this._key)}toJSON(){return{type:Pe._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,s){if(ao(t,Pe._jsonSchema))return new Pe(e,s||null,new $(pe.fromString(t.referencePath)))}}Pe._jsonSchemaVersion="firestore/documentReference/1.0",Pe._jsonSchema={type:Je("string",Pe._jsonSchemaVersion),referencePath:Je("string")};class zn extends Xt{constructor(e,t,s){super(e,t,nl(s)),this._path=s,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Pe(this.firestore,null,new $(e))}withConverter(e){return new zn(this.firestore,e,this._path)}}function FN(n,e,...t){if(n=Ie(n),Gp("collection","path",e),n instanceof ol){const s=pe.fromString(e,...t);return cd(s),new zn(n,null,s)}{if(!(n instanceof Pe||n instanceof zn))throw new G(O.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(pe.fromString(e,...t));return cd(s),new zn(n.firestore,null,s)}}function KI(n,e,...t){if(n=Ie(n),arguments.length===1&&(e=Sc.newId()),Gp("doc","path",e),n instanceof ol){const s=pe.fromString(e,...t);return Bd(s),new Pe(n,null,new $(s))}{if(!(n instanceof Pe||n instanceof zn))throw new G(O.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=n._path.child(pe.fromString(e,...t));return Bd(s),new Pe(n.firestore,n instanceof zn?n.converter:null,new $(s))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class At{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(s,r){if(s.length!==r.length)return!1;for(let i=0;i<s.length;++i)if(s[i]!==r[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:At._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(ao(e,At._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new At(e.vectorValues);throw new G(O.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}At._jsonSchemaVersion="firestore/vectorValue/1.0",At._jsonSchema={type:Je("string",At._jsonSchemaVersion),vectorValues:Je("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const QI=/^__.*__$/;class zI{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return this.fieldMask!==null?new ps(e,this.data,this.fieldMask,t,this.fieldTransforms):new uo(e,this.data,t,this.fieldTransforms)}}class Lg{constructor(e,t,s){this.data=e,this.fieldMask=t,this.fieldTransforms=s}toMutation(e,t){return new ps(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function xg(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw X(40011,{dataSource:n})}}class al{constructor(e,t,s,r,i,o){this.settings=e,this.databaseId=t,this.serializer=s,this.ignoreUndefinedProperties=r,i===void 0&&this.validatePath(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(e){return new al({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(e){var r;const t=(r=this.path)==null?void 0:r.child(e),s=this.contextWith({path:t,arrayElement:!1});return s.validatePathSegment(e),s}childContextForFieldPath(e){var r;const t=(r=this.path)==null?void 0:r.child(e),s=this.contextWith({path:t,arrayElement:!1});return s.validatePath(),s}childContextForArray(e){return this.contextWith({path:void 0,arrayElement:!0})}createError(e){return Ta(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}validatePath(){if(this.path)for(let e=0;e<this.path.length;e++)this.validatePathSegment(this.path.get(e))}validatePathSegment(e){if(e.length===0)throw this.createError("Document fields must not be empty");if(xg(this.dataSource)&&QI.test(e))throw this.createError('Document fields cannot begin and end with "__"')}}class WI{constructor(e,t,s){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=s||rl(e)}createContext(e,t,s,r=!1){return new al({dataSource:e,methodName:t,targetDoc:s,path:xt.emptyPath(),arrayElement:!1,hasConverter:r},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Lr(n){const e=n._freezeSettings(),t=rl(n._databaseId);return new WI(n._databaseId,!!e.ignoreUndefinedProperties,t)}function Gc(n,e,t,s,r,i={}){const o=n.createContext(i.merge||i.mergeFields?2:0,e,t,r);Jc("Data must be an object, but it was:",o,s);const a=Gg(s,o);let B,c;if(i.merge)B=new Ot(o.fieldMask),c=o.fieldTransforms;else if(i.mergeFields){const u=[];for(const f of i.mergeFields){const C=is(e,f,t);if(!o.contains(C))throw new G(O.INVALID_ARGUMENT,`Field '${C}' is specified in your field mask but missing from your input data.`);Jg(u,C)||u.push(C)}B=new Ot(u),c=o.fieldTransforms.filter(f=>B.covers(f.field))}else B=null,c=o.fieldTransforms;return new zI(new it(a),B,c)}class po extends Pr{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.createError(`${this._methodName}() can only appear at the top level of your update data`):e.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof po}}function $I(n,e,t){return new al({dataSource:3,targetDoc:e.settings.targetDoc,methodName:n._methodName,arrayElement:t},e.databaseId,e.serializer,e.ignoreUndefinedProperties)}class Hc extends Pr{_toFieldTransform(e){return new Fc(e.path,new Mi)}isEqual(e){return e instanceof Hc}}class Uc extends Pr{constructor(e,t){super(e),this.ar=t}_toFieldTransform(e){const t=$I(this,e,!0),s=this.ar.map(i=>An(i,t)),r=new Er(s);return new Fc(e.path,r)}isEqual(e){return e instanceof Uc&&ks(this.ar,e.ar)}}class qc extends Pr{constructor(e,t){super(e),this.ur=t}_toFieldTransform(e){const t=new Dr(e.serializer,Xa(e.serializer,this.ur));return new Fc(e.path,t)}isEqual(e){return e instanceof qc&&(this.ur===e.ur||Number.isNaN(this.ur)&&Number.isNaN(e.ur))}}function kg(n,e,t,s){const r=n.createContext(1,e,t);Jc("Data must be an object, but it was:",r,s);const i=[],o=it.empty();Cs(s,(B,c)=>{const u=qg(e,B,t);c=Ie(c);const f=r.childContextForFieldPath(u);if(c instanceof po)i.push(u);else{const C=An(c,f);C!=null&&(i.push(u),o.set(u,C))}});const a=new Ot(i);return new Lg(o,a,r.fieldTransforms)}function Mg(n,e,t,s,r,i){const o=n.createContext(1,e,t),a=[is(e,s,t)],B=[r];if(i.length%2!=0)throw new G(O.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let C=0;C<i.length;C+=2)a.push(is(e,i[C])),B.push(i[C+1]);const c=[],u=it.empty();for(let C=a.length-1;C>=0;--C)if(!Jg(c,a[C])){const g=a[C];let E=B[C];E=Ie(E);const b=o.childContextForFieldPath(g);if(E instanceof po)c.push(g);else{const F=An(E,b);F!=null&&(c.push(g),u.set(g,F))}}const f=new Ot(c);return new Lg(u,f,o.fieldTransforms)}function Vg(n,e,t,s=!1){return An(t,n.createContext(s?4:3,e))}function An(n,e,t){if(Ug(n=Ie(n)))return Jc("Unsupported field value:",e,n),Gg(n,e);if(n instanceof Pr)return function(r,i){if(!xg(i.dataSource))throw i.createError(`${r._methodName}() can only be used with update() and set()`);if(!i.path)throw i.createError(`${r._methodName}() is not currently supported inside arrays`);const o=r._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.createError("Nested arrays are not supported");return function(r,i){const o=[];let a=0;for(const B of r){let c=An(B,i.childContextForArray(a));c==null&&(c={nullValue:"NULL_VALUE"}),o.push(c),a++}return{arrayValue:{values:o}}}(n,e)}return function(r,i,o){if((r=Ie(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return Xa(i.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const a=Ee.fromDate(r);return{timestampValue:yi(i.serializer,a)}}if(r instanceof Ee){const a=new Ee(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:yi(i.serializer,a)}}if(Hg(r)){const a=Ee.fromInstant(r),B=new Ee(a.seconds,1e3*Math.floor(a.nanoseconds/1e3));return{timestampValue:yi(i.serializer,B)}}if(r instanceof an)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof Ft)return{bytesValue:_g(i.serializer,r._byteString)};if(r instanceof Pe){const a=i.databaseId,B=r.firestore._databaseId;if(!B.isEqual(a))throw i.createError(`Document reference is for database ${B.projectId}/${B.database} but should be for database ${a.projectId}/${a.database}`);return{referenceValue:Mc(r.firestore._databaseId||i.databaseId,r._key.path)}}if(r instanceof At)return function(B,c){const u=B instanceof At?B.toArray():B;return{mapValue:{fields:{[Kp]:{stringValue:Qp},[xi]:{arrayValue:{values:u.map(C=>{if(typeof C!="number")throw c.createError("VectorValues must only contain numeric values.");return Ya(c.serializer,C)})}}}}}}(r,i);if(Rg(r))return r._toProto(i.serializer);throw i.createError(`Unsupported field value: ${$a(r)}`)}(n,e)}function Gg(n,e){const t={};return Vp(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Cs(n,(s,r)=>{const i=An(r,e.childContextForField(s));i!=null&&(t[s]=i)}),{mapValue:{fields:t}}}function Hg(n){if(typeof n!="object"||n===null)return!1;if(typeof Temporal<"u"&&typeof Temporal.Instant=="function"&&n instanceof Temporal.Instant)return!0;const e=n;return e[Symbol.toStringTag]==="Temporal.Instant"&&typeof e.t=="bigint"}function Ug(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Ee||n instanceof an||n instanceof Ft||n instanceof Pe||n instanceof Pr||n instanceof At||Hg(n)||Rg(n))}function Jc(n,e,t){if(!Ug(t)||!oo(t)){const s=$a(t);throw s==="an object"?e.createError(n+" a custom object"):e.createError(n+" "+s)}}function is(n,e,t){if((e=Ie(e))instanceof Co)return e._internalPath;if(typeof e=="string")return qg(n,e);throw Ta("Field path arguments must be of type string or ",n,!1,void 0,t)}const YI=new RegExp("[~\\*/\\[\\]]");function qg(n,e,t){if(e.search(YI)>=0)throw Ta(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Co(...e.split("."))._internalPath}catch{throw Ta(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Ta(n,e,t,s,r){const i=s&&!s.isEmpty(),o=r!==void 0;let a=`Function ${e}() called with invalid data`;t&&(a+=" (via `toFirestore()`)"),a+=". ";let B="";return(i||o)&&(B+=" (found",i&&(B+=` in field ${s}`),o&&(B+=` in document ${r}`),B+=")"),new G(O.INVALID_ARGUMENT,a+n+B)}function Jg(n,e){return n.some(t=>t.isEqual(e))}function jg(n){return typeof n._readUserData=="function"}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ft{constructor(e){this.optionDefinitions=e}_getKnownOptions(e,t){const s=it.empty();for(const r in this.optionDefinitions)if(this.optionDefinitions.hasOwnProperty(r)){const i=this.optionDefinitions[r];if(r in e){const o=e[r];let a;i.nestedOptions&&oo(o)?a={mapValue:{fields:new ft(i.nestedOptions).getOptionsProto(t,o)}}:o&&(a=An(o,t)??void 0),a&&s.set(xt.fromServerFormat(i.serverName),a)}}return s}getOptionsProto(e,t,s){const r=this._getKnownOptions(t,e);if(s){const i=new Map(Mp(s,(o,a)=>[xt.fromServerFormat(a),o!==void 0?An(o,e):null]));r.setAll(i)}return r.value.mapValue.fields??{}}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function XI(n){return typeof n=="object"&&n!==null&&!!("nullValue"in n&&(n.nullValue===null||n.nullValue==="NULL_VALUE")||"booleanValue"in n&&(n.booleanValue===null||typeof n.booleanValue=="boolean")||"integerValue"in n&&(n.integerValue===null||typeof n.integerValue=="number"||typeof n.integerValue=="string")||"doubleValue"in n&&(n.doubleValue===null||typeof n.doubleValue=="number")||"timestampValue"in n&&(n.timestampValue===null||function(t){return typeof t=="object"&&t!==null&&"seconds"in t&&(t.seconds===null||typeof t.seconds=="number"||typeof t.seconds=="string")&&"nanos"in t&&(t.nanos===null||typeof t.nanos=="number")}(n.timestampValue))||"stringValue"in n&&(n.stringValue===null||typeof n.stringValue=="string")||"bytesValue"in n&&(n.bytesValue===null||n.bytesValue instanceof Uint8Array)||"referenceValue"in n&&(n.referenceValue===null||typeof n.referenceValue=="string")||"geoPointValue"in n&&(n.geoPointValue===null||function(t){return typeof t=="object"&&t!==null&&"latitude"in t&&(t.latitude===null||typeof t.latitude=="number")&&"longitude"in t&&(t.longitude===null||typeof t.longitude=="number")}(n.geoPointValue))||"arrayValue"in n&&(n.arrayValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("values"in t)||t.values!==null&&!Array.isArray(t.values))}(n.arrayValue))||"mapValue"in n&&(n.mapValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("fields"in t)||t.fields!==null&&!oo(t.fields))}(n.mapValue))||"fieldReferenceValue"in n&&(n.fieldReferenceValue===null||typeof n.fieldReferenceValue=="string")||"functionValue"in n&&(n.functionValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("name"in t)||t.name!==null&&typeof t.name!="string"||!("args"in t)||t.args!==null&&!Array.isArray(t.args))}(n.functionValue))||"pipelineValue"in n&&(n.pipelineValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("stages"in t)||t.stages!==null&&!Array.isArray(t.stages))}(n.pipelineValue)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ON(){return new po("deleteField")}function LN(){return new Hc("serverTimestamp")}function xN(...n){return new Uc("arrayUnion",n)}function kN(n){return new qc("increment",n)}function ZI(n){return new At(n)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function J(n){let e;return n instanceof Ks?n:(e=oo(n)?rA(n):n instanceof Array?iA(n):Kg(n,void 0),e)}function CB(n){if(n instanceof Ks)return n;if(n instanceof At)return Ji(n);if(Array.isArray(n))return Ji(ZI(n));throw new Error("Unsupported value: "+typeof n)}function jc(n){return pT(n)?Ba(n):J(n)}class Ks{constructor(){this._protoValueType="ProtoValue"}add(e){return new k("add",[this,J(e)],"add")}asBoolean(){if(this instanceof os)return this;if(this instanceof kr)return new zg(this);if(this instanceof xr)return new sA(this);if(this instanceof k)return new Qg(this);throw new G("invalid-argument",`Conversion of type ${typeof this} to BooleanExpression not supported.`)}subtract(e){return new k("subtract",[this,J(e)],"subtract")}multiply(e){return new k("multiply",[this,J(e)],"multiply")}divide(e){return new k("divide",[this,J(e)],"divide")}mod(e){return new k("mod",[this,J(e)],"mod")}equal(e){return new k("equal",[this,J(e)],"equal").asBoolean()}notEqual(e){return new k("not_equal",[this,J(e)],"notEqual").asBoolean()}lessThan(e){return new k("less_than",[this,J(e)],"lessThan").asBoolean()}lessThanOrEqual(e){return new k("less_than_or_equal",[this,J(e)],"lessThanOrEqual").asBoolean()}greaterThan(e){return new k("greater_than",[this,J(e)],"greaterThan").asBoolean()}greaterThanOrEqual(e){return new k("greater_than_or_equal",[this,J(e)],"greaterThanOrEqual").asBoolean()}arrayConcat(e,...t){const s=[e,...t].map(r=>J(r));return new k("array_concat",[this,...s],"arrayConcat")}arrayContains(e){return new k("array_contains",[this,J(e)],"arrayContains").asBoolean()}arrayContainsAll(e){const t=Array.isArray(e)?new Ci(e.map(J),"arrayContainsAll"):e;return new k("array_contains_all",[this,t],"arrayContainsAll").asBoolean()}arrayContainsAny(e){const t=Array.isArray(e)?new Ci(e.map(J),"arrayContainsAny"):e;return new k("array_contains_any",[this,t],"arrayContainsAny").asBoolean()}arrayReverse(){return new k("array_reverse",[this])}arrayLength(){return new k("array_length",[this],"arrayLength")}equalAny(e){const t=Array.isArray(e)?new Ci(e.map(J),"equalAny"):e;return new k("equal_any",[this,t],"equalAny").asBoolean()}notEqualAny(e){const t=Array.isArray(e)?new Ci(e.map(J),"notEqualAny"):e;return new k("not_equal_any",[this,t],"notEqualAny").asBoolean()}exists(){return new k("exists",[this],"exists").asBoolean()}charLength(){return new k("char_length",[this],"charLength")}like(e){return new k("like",[this,J(e)],"like").asBoolean()}regexContains(e){return new k("regex_contains",[this,J(e)],"regexContains").asBoolean()}regexFind(e){return new k("regex_find",[this,J(e)],"regexFind")}regexFindAll(e){return new k("regex_find_all",[this,J(e)],"regexFindAll")}regexMatch(e){return new k("regex_match",[this,J(e)],"regexMatch").asBoolean()}stringContains(e){return new k("string_contains",[this,J(e)],"stringContains").asBoolean()}startsWith(e){return new k("starts_with",[this,J(e)],"startsWith").asBoolean()}endsWith(e){return new k("ends_with",[this,J(e)],"endsWith").asBoolean()}toLower(){return new k("to_lower",[this],"toLower")}toUpper(){return new k("to_upper",[this],"toUpper")}trim(e){const t=[this];return e&&t.push(J(e)),new k("trim",t,"trim")}ltrim(e){const t=[this];return e&&t.push(J(e)),new k("ltrim",t,"ltrim")}rtrim(e){const t=[this];return e&&t.push(J(e)),new k("rtrim",t,"rtrim")}type(){return new k("type",[this])}isType(e){return new k("is_type",[this,Ji(e)],"isType").asBoolean()}stringConcat(e,...t){const s=[e,...t].map(J);return new k("string_concat",[this,...s],"stringConcat")}stringIndexOf(e){return new k("string_index_of",[this,J(e)],"stringIndexOf")}stringRepeat(e){return new k("string_repeat",[this,J(e)],"stringRepeat")}stringReplaceAll(e,t){return new k("string_replace_all",[this,J(e),J(t)],"stringReplaceAll")}stringReplaceOne(e,t){return new k("string_replace_one",[this,J(e),J(t)],"stringReplaceOne")}concat(e,...t){const s=[e,...t].map(J);return new k("concat",[this,...s],"concat")}reverse(){return new k("reverse",[this],"reverse")}arrayFilter(e,t){return new k("array_filter",[this,J(e),t],"arrayFilter")}arrayTransform(e,t){return new k("array_transform",[this,J(e),t],"arrayTransform")}arrayTransformWithIndex(e,t,s){return new k("array_transform",[this,J(e),J(t),s],"arrayTransformWithIndex")}arraySlice(e,t){const s=[this,J(e)];return t!==void 0&&s.push(J(t)),new k("array_slice",s,"arraySlice")}arrayFirst(){return new k("array_first",[this],"arrayFirst")}arrayFirstN(e){return new k("array_first_n",[this,J(e)],"arrayFirstN")}arrayLast(){return new k("array_last",[this],"arrayLast")}arrayLastN(e){return new k("array_last_n",[this,J(e)],"arrayLastN")}arrayMaximum(){return new k("maximum",[this],"arrayMaximum")}arrayMaximumN(e){return new k("maximum_n",[this,J(e)],"arrayMaximumN")}arrayMinimum(){return new k("minimum",[this],"arrayMinimum")}arrayMinimumN(e){return new k("minimum_n",[this,J(e)],"arrayMinimumN")}arrayIndexOf(e){return new k("array_index_of",[this,J(e),J("first")],"arrayIndexOf")}arrayLastIndexOf(e){return new k("array_index_of",[this,J(e),J("last")],"arrayLastIndexOf")}arrayIndexOfAll(e){return new k("array_index_of_all",[this,J(e)],"arrayIndexOfAll")}byteLength(){return new k("byte_length",[this],"byteLength")}ceil(){return new k("ceil",[this])}floor(){return new k("floor",[this])}abs(){return new k("abs",[this])}exp(){return new k("exp",[this])}mapGet(e){return new k("map_get",[this,Ji(e)],"mapGet")}mapSet(e,t,...s){const r=[this,J(e),J(t),...s.map(J)];return new k("map_set",r,"mapSet")}mapKeys(){return new k("map_keys",[this],"mapKeys")}mapValues(){return new k("map_values",[this],"mapValues")}mapEntries(){return new k("map_entries",[this],"mapEntries")}getField(e){return new k("get_field",[this,J(e)],"get_field")}count(){return Pt._create("count",[this],"count")}sum(){return Pt._create("sum",[this],"sum")}average(){return Pt._create("average",[this],"average")}minimum(){return Pt._create("minimum",[this],"minimum")}maximum(){return Pt._create("maximum",[this],"maximum")}first(){return Pt._create("first",[this],"first")}last(){return Pt._create("last",[this],"last")}arrayAgg(){return Pt._create("array_agg",[this],"arrayAgg")}arrayAggDistinct(){return Pt._create("array_agg_distinct",[this],"arrayAggDistinct")}countDistinct(){return Pt._create("count_distinct",[this],"countDistinct")}logicalMaximum(e,...t){const s=[e,...t];return new k("maximum",[this,...s.map(J)],"logicalMaximum")}logicalMinimum(e,...t){const s=[e,...t];return new k("minimum",[this,...s.map(J)],"minimum")}vectorLength(){return new k("vector_length",[this],"vectorLength")}cosineDistance(e){return new k("cosine_distance",[this,CB(e)],"cosineDistance")}dotProduct(e){return new k("dot_product",[this,CB(e)],"dotProduct")}euclideanDistance(e){return new k("euclidean_distance",[this,CB(e)],"euclideanDistance")}unixMicrosToTimestamp(){return new k("unix_micros_to_timestamp",[this],"unixMicrosToTimestamp")}timestampToUnixMicros(){return new k("timestamp_to_unix_micros",[this],"timestampToUnixMicros")}unixMillisToTimestamp(){return new k("unix_millis_to_timestamp",[this],"unixMillisToTimestamp")}timestampToUnixMillis(){return new k("timestamp_to_unix_millis",[this],"timestampToUnixMillis")}unixSecondsToTimestamp(){return new k("unix_seconds_to_timestamp",[this],"unixSecondsToTimestamp")}timestampToUnixSeconds(){return new k("timestamp_to_unix_seconds",[this],"timestampToUnixSeconds")}timestampAdd(e,t){return new k("timestamp_add",[this,J(e),J(t)],"timestampAdd")}timestampSubtract(e,t){return new k("timestamp_subtract",[this,J(e),J(t)],"timestampSubtract")}timestampDiff(e,t){return new k("timestamp_diff",[this,jc(e),J(t)],"timestampDiff")}timestampExtract(e,t){const s=[this,J(e)];return t&&s.push(J(t)),new k("timestamp_extract",s,"timestampExtract")}documentId(){return new k("document_id",[this],"documentId")}parent(){return new k("parent",[this],"parent")}substring(e,t){const s=J(e);return new k("substring",t===void 0?[this,s]:[this,s,J(t)],"substring")}arrayGet(e){return new k("array_get",[this,J(e)],"arrayGet")}isError(){return new k("is_error",[this],"isError").asBoolean()}ifError(e){const t=new k("if_error",[this,J(e)],"ifError");return e instanceof os?t.asBoolean():t}isAbsent(){return new k("is_absent",[this],"isAbsent").asBoolean()}mapRemove(e){return new k("map_remove",[this,J(e)],"mapRemove")}mapMerge(e,...t){const s=J(e),r=t.map(J);return new k("map_merge",[this,s,...r],"mapMerge")}pow(e){return new k("pow",[this,J(e)])}trunc(e){return e===void 0?new k("trunc",[this]):new k("trunc",[this,J(e)],"trunc")}round(e){return e===void 0?new k("round",[this]):new k("round",[this,J(e)],"round")}collectionId(){return new k("collection_id",[this])}length(){return new k("length",[this])}ln(){return new k("ln",[this])}sqrt(){return new k("sqrt",[this])}stringReverse(){return new k("string_reverse",[this])}ifAbsent(e){return new k("if_absent",[this,J(e)],"ifAbsent")}ifNull(e){return new k("if_null",[this,J(e)],"ifNull")}coalesce(e,...t){return new k("coalesce",[this,J(e),...t.map(J)],"coalesce")}join(e){return new k("join",[this,J(e)],"join")}log10(){return new k("log10",[this])}arraySum(){return new k("sum",[this])}split(e){return new k("split",[this,J(e)])}timestampTruncate(e,t){const s=[this,J(e)];return t&&s.push(J(t)),new k("timestamp_trunc",s)}ascending(){return oA(this)}descending(){return aA(this)}as(e){return new tA(this,e,"as")}}class Pt{constructor(e,t){this.name=e,this.params=t,this.exprType="AggregateFunction",this._protoValueType="ProtoValue"}static _create(e,t,s){const r=new Pt(e,t);return r._methodName=s,r}as(e){return new eA(this,e,"as")}_toProto(e){return{functionValue:{name:this.name,args:this.params.map(t=>t._toProto(e))}}}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e))}}class eA{constructor(e,t,s){this.aggregate=e,this.alias=t,this._methodName=s}_readUserData(e){this.aggregate._readUserData(e)}}class tA{constructor(e,t,s){this.expr=e,this.alias=t,this._methodName=s,this.exprType="AliasedExpression",this.selectable=!0}_readUserData(e){this.expr._readUserData(e)}}class Ci extends Ks{constructor(e,t){super(),this.cr=e,this._methodName=t,this.expressionType="ListOfExpressions"}_toProto(e){return{arrayValue:{values:this.cr.map(t=>t._toProto(e))}}}_readUserData(e){this.cr.forEach(t=>t._readUserData(e))}}class xr extends Ks{constructor(e,t){super(),this.fieldPath=e,this._methodName=t,this.expressionType="Field",this.selectable=!0}get _fieldPath(){return this.fieldPath}get fieldName(){return this.fieldPath.canonicalString()}get alias(){return this.fieldName}get expr(){return this}geoDistance(e){return new k("geo_distance",[this,J(e)],"geoDistance")}_toProto(e){return{fieldReferenceValue:this.fieldPath.canonicalString()}}_readUserData(e){}}function Ba(n){return nA(n,"field")}function nA(n,e){return new xr(typeof n=="string"?nn===n?mI()._internalPath:is("field",n):n._internalPath,e)}class kr extends Ks{constructor(e,t){super(),this.value=e,this._methodName=t,this.expressionType="Constant"}static _fromProto(e){const t=new kr(e,void 0);return t._protoValue=e,t}_toProto(e){return W(this._protoValue!==void 0,237),this._protoValue}_getValue(){return this._protoValue}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,XI(this._protoValue)||(this._protoValue=An(this.value,e))}}function Ji(n,e){return Kg(n,"constant")}function Kg(n,e){const t=new kr(n,e);return typeof n=="boolean"?new zg(t):t}class k extends Ks{constructor(e,t,s,r){super(),this.name=e,this.params=t,this.expressionType="Function",this._optionsProto=void 0,s!==void 0&&(this._methodName=s),r!==void 0&&(this._options=r)}get _optionsUtil(){return new ft({})}_toProto(e){const t={functionValue:{name:this.name,args:this.params.map(s=>s._toProto(e))}};return this._optionsProto&&(t.functionValue.options=this._optionsProto),t}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e)),this._options&&(this._optionsProto=this._optionsUtil.getOptionsProto(e,this._options))}}class os extends Ks{get _methodName(){return this._expr._methodName}countIf(){return Pt._create("count_if",[this],"countIf")}not(){return new k("not",[this],"not").asBoolean()}conditional(e,t){return new k("conditional",[this,e,t],"conditional")}ifError(e){const t=J(e),s=new k("if_error",[this,t],"ifError");return t instanceof os?s.asBoolean():s}_toProto(e){return this._expr._toProto(e)}_readUserData(e){this._expr._readUserData(e)}}class Qg extends os{constructor(e){super(),this._expr=e,this.expressionType="Function"}}class zg extends os{constructor(e){super(),this._expr=e,this.expressionType="Constant"}_getValue(){return this._expr._getValue()}}class sA extends os{constructor(e){super(),this._expr=e,this.expressionType="Field"}}function rA(n,e){const t=[];for(const s in n)if(Object.prototype.hasOwnProperty.call(n,s)){const r=n[s];t.push(Ji(s)),t.push(J(r))}return new k("map",t,"map")}function iA(n){return function(t,s){return new k("array",t.map(r=>J(r)),s)}(n,"array")}function oA(n){return new Wg(jc(n),"ascending","ascending")}function aA(n){return new Wg(jc(n),"descending","descending")}class Wg{constructor(e,t,s){this.expr=e,this.direction=t,this._methodName=s,this._protoValueType="ProtoValue"}_toProto(e){return{mapValue:{fields:{direction:Sg(this.direction),expression:this.expr._toProto(e)}}}}_readUserData(e){this.expr._readUserData(e)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mt{constructor(e){this.optionsProto=void 0,{rawOptions:this.rawOptions,...this.knownOptions}=e}_readUserData(e){this.optionsProto=this._optionsUtil.getOptionsProto(e,this.knownOptions,this.rawOptions)}_toProto(e){return{name:this._name,options:this.optionsProto}}}class $g extends Mt{get _name(){return"add_fields"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.fields=e}_toProto(e){return{...super._toProto(e),args:[qi(e,this.fields)]}}_readUserData(e){super._readUserData(e),as(this.fields,e)}}class Yg extends Mt{get _name(){return"aggregate"}get _optionsUtil(){return new ft({})}constructor(e,t,s){super(s),this.groups=e,this.accumulators=t}_toProto(e){return{...super._toProto(e),args:[qi(e,this.accumulators),qi(e,this.groups)]}}_readUserData(e){super._readUserData(e),as(this.groups,e),as(this.accumulators,e)}}class Xg extends Mt{get _name(){return"distinct"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.groups=e}_toProto(e){return{...super._toProto(e),args:[qi(e,this.groups)]}}_readUserData(e){super._readUserData(e),as(this.groups,e)}}class ll extends Mt{get _name(){return"collection"}get _optionsUtil(){return new ft({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.hr=e.startsWith("/")?e:"/"+e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:this.hr}]}}_readUserData(e){super._readUserData(e)}}class Bl extends Mt{get _name(){return"collection_group"}get _optionsUtil(){return new ft({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.collectionId=e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:""},{stringValue:this.collectionId}]}}_readUserData(e){super._readUserData(e)}}class Kc extends Mt{get _name(){return"database"}get _optionsUtil(){return new ft({})}_toProto(e){return{...super._toProto(e)}}_readUserData(e){super._readUserData(e)}}class Qc extends Mt{get _name(){return"documents"}get _optionsUtil(){return new ft({})}constructor(e,t){if(super(t),!e||e.length===0)throw new G(O.INVALID_ARGUMENT,"Empty document paths are not allowed in DocumentsSource");const s=e.map(i=>i.startsWith("/")?i:"/"+i),r=new Set(s);if(r.size!==s.length)throw new G(O.INVALID_ARGUMENT,"Duplicate document paths are not allowed in DocumentsSource");this.Tr=s,this.Pr=r}_toProto(e){return{...super._toProto(e),args:this.Tr.map(t=>({referenceValue:t}))}}_readUserData(e){super._readUserData(e)}}class cl extends Mt{get _name(){return"where"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.condition=e}_toProto(e){return{...super._toProto(e),args:[this.condition._toProto(e)]}}_readUserData(e){super._readUserData(e),as(this.condition,e)}}class Us extends Mt{get _name(){return"limit"}get _optionsUtil(){return new ft({})}constructor(e,t){W(!isNaN(e)&&e!==1/0&&e!==-1/0,34860),super(t),this.limit=e}_toProto(e){return{...super._toProto(e),args:[Xa(e,this.limit)]}}}class Md extends Mt{get _name(){return"offset"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.offset=e}_toProto(e){return{...super._toProto(e),args:[Xa(e,this.offset)]}}}class lA extends Mt{get _name(){return"select"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.selections=e}_toProto(e){return{...super._toProto(e),args:[qi(e,this.selections)]}}_readUserData(e){super._readUserData(e),as(this.selections,e)}}class mn extends Mt{get _name(){return"sort"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.orderings=e}_toProto(e){return{...super._toProto(e),args:this.orderings.map(t=>t._toProto(e))}}_readUserData(e){super._readUserData(e),as(this.orderings,e)}}class zc extends Mt{get _name(){return"replace_with"}get _optionsUtil(){return new ft({})}constructor(e,t){super(t),this.map=e}_toProto(e){return{...super._toProto(e),args:[this.map._toProto(e),Sg(zc.Ir)]}}_readUserData(e){super._readUserData(e),as(this.map,e)}}zc.Ir="full_replace";function as(n,e){return jg(n)?n._readUserData(e):Array.isArray(n)?n.forEach(t=>t._readUserData(e)):n instanceof Map?n.forEach(t=>t._readUserData(e)):Object.values(n).forEach(t=>t._readUserData(e)),n}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{constructor(e,t,s,r){this._db=e,this.userDataReader=t,this._userDataWriter=s,this.stages=r}Vr(e,t){const s=this.userDataReader.createContext(3,e);return jg(t)?t._readUserData(s):Array.isArray(t)?t.forEach(r=>r._readUserData(s)):t.forEach(r=>r._readUserData(s)),t}where(e){const t=this.stages.map(s=>s);return this.Vr("where",e),t.push(new cl(e,{})),new Ti(this._db,this.userDataReader,this._userDataWriter,t)}limit(e){const t=this.stages.map(s=>s);return t.push(new Us(e,{})),new Ti(this._db,this.userDataReader,this._userDataWriter,t)}sort(e,...t){const s=this.stages.map(r=>r);return"orderings"in e?s.push(new mn(this.Vr("sort",e.orderings),{})):s.push(new mn(this.Vr("sort",[e,...t]),{})),new Ti(this._db,this.userDataReader,this._userDataWriter,s)}dr(e){return{pipeline:{stages:this.stages.map(t=>t._toProto(e))}}}}// Copyright 2024 Google LLC* @license
class pt{constructor(e,t,s){this.serializer=e,this.stages=t,this.listenOptions=s,this.isCorePipeline=!0}getPipelineCollection(){return ul(this)}getPipelineCollectionGroup(){return Wc(this)}getPipelineCollectionId(){return BA(this)}getPipelineDocuments(){return zB(this)}getPipelineFlavor(){return function(t){let s="exact";return t.stages.forEach((r,i)=>{r._name!==Xg.name&&r._name!==Yg.name||(s="keyless"),r._name===lA.name&&s==="exact"&&(s="augmented"),r._name===$g.name&&i<t.stages.length-1&&s==="exact"&&(s="augmented")}),s}(this)}getPipelineSourceType(){return Wn(this)}}function Wn(n){const e=n.stages[0];return e instanceof ll||e instanceof Bl||e instanceof Kc||e instanceof Qc?e._name:"unknown"}function ul(n){if(Wn(n)==="collection")return n.stages[0].hr}function Wc(n){if(Wn(n)==="collection_group")return n.stages[0].collectionId}function BA(n){switch(Wn(n)){case"collection":return pe.fromString(ul(n)).lastSegment();case"collection_group":return Wc(n);default:return}}function zB(n){if(Wn(n)==="documents")return n.stages[0].Tr}class T{constructor(e,t){this.type=e,this.value=t}static mr(){return new T("ERROR",void 0)}static pr(){return new T("UNSET",void 0)}static gr(){return new T("NULL",gr)}static newValue(e){return Lt(e)?new T("NULL",gr):function(s){return!!s&&"booleanValue"in s}(e)?new T("BOOLEAN",e):sn(e)?new T("INT",e):bs(e)?new T("DOUBLE",e):function(s){return!!s&&"timestampValue"in s&&!!s.timestampValue}(e)?new T("TIMESTAMP",e):function(s){return!!s&&"stringValue"in s}(e)?new T("STRING",e):function(s){return!!s&&"bytesValue"in s}(e)?new T("BYTES",e):e.referenceValue?new T("REFERENCE",e):e.geoPointValue?new T("GEO_POINT",e):_r(e)?new T("ARRAY",e):_a(e)?new T("VECTOR",e):Fs(e)?new T("MAP",e):new T("ERROR",void 0)}yr(){return this.type==="ERROR"||this.type==="UNSET"}wr(){return this.type==="NULL"}}function Ii(n){if(!n.yr())return n.value}function Zg(n){return n instanceof os?n._expr:n}function ee(n){if((n=Zg(n))instanceof xr)return new cA(n);if(n instanceof kr)return new uA(n);if(n instanceof Ci)return new hA(n);if(n instanceof k){if(n.name==="add")return new CA(n);if(n.name==="subtract")return new pA(n);if(n.name==="multiply")return new gA(n);if(n.name==="divide")return new mA(n);if(n.name==="mod")return new _A(n);if(n.name==="and")return new EA(n);if(n.name==="equal")return new PA(n);if(n.name==="not_equal")return new FA(n);if(n.name==="less_than")return new OA(n);if(n.name==="less_than_or_equal")return new LA(n);if(n.name==="greater_than")return new xA(n);if(n.name==="greater_than_or_equal")return new kA(n);if(n.name==="array_concat")return new MA(n);if(n.name==="array_reverse")return new VA(n);if(n.name==="array_contains")return new GA(n);if(n.name==="array_contains_all")return new HA(n);if(n.name==="array_contains_any")return new UA(n);if(n.name==="array_length")return new qA(n);if(n.name==="array_element")return new JA(n);if(n.name==="equal_any")return new em(n);if(n.name==="not_equal_any")return new yA(n);if(n.name==="is_nan")return new wA(n);if(n.name==="is_not_nan")return new TA(n);if(n.name==="is_null")return new IA(n);if(n.name==="is_not_null")return new AA(n);if(n.name==="is_error")return new vA(n);if(n.name==="exists")return new RA(n);if(n.name==="not")return new hl(n);if(n.name==="or")return new DA(n);if(n.name==="xor")return new $c(n);if(n.name==="conditional")return new SA(n);if(n.name==="maximum")return new bA(n);if(n.name==="minimum")return new NA(n);if(n.name==="reverse")return new jA(n);if(n.name==="replace_first")return new KA(n);if(n.name==="replace_all")return new QA(n);if(n.name==="char_length")return new zA(n);if(n.name==="byte_length")return new WA(n);if(n.name==="like")return new $A(n);if(n.name==="regex_contains")return new YA(n);if(n.name==="regex_match")return new XA(n);if(n.name==="string_contains")return new ZA(n);if(n.name==="starts_with")return new ev(n);if(n.name==="ends_with")return new tv(n);if(n.name==="to_lower")return new nv(n);if(n.name==="to_upper")return new sv(n);if(n.name==="trim")return new rv(n);if(n.name==="string_concat")return new iv(n);if(n.name==="map_get")return new ov(n);if(n.name==="cosine_distance")return new av(n);if(n.name==="dot_product")return new lv(n);if(n.name==="euclidean_distance")return new Bv(n);if(n.name==="vector_length")return new cv(n);if(n.name==="unix_micros_to_timestamp")return new Cv(n);if(n.name==="timestamp_to_unix_micros")return new mv(n);if(n.name==="unix_millis_to_timestamp")return new pv(n);if(n.name==="timestamp_to_unix_millis")return new _v(n);if(n.name==="unix_seconds_to_timestamp")return new gv(n);if(n.name==="timestamp_to_unix_seconds")return new Ev(n);if(n.name==="timestamp_add")return new Dv(n);if(n.name==="timestamp_subtract")return new yv(n)}throw new Error(`Unknown Expr : ${n}`)}class cA{constructor(e){this.expr=e}evaluate(e,t){if(this.expr.fieldName===nn)return T.newValue({referenceValue:Ui(e.serializer,t.key)});if(this.expr.fieldName==="__update_time__")return T.newValue({timestampValue:la(e.serializer,t.version)});if(this.expr.fieldName==="__create_time__")return T.newValue({timestampValue:la(e.serializer,t.createTime)});const s=t.data.field(this.expr._fieldPath);return s?lo(s)?T.newValue(function(i,o){if(i.serverTimestampBehavior==="estimate")return{timestampValue:la(i.serializer,ne.fromTimestamp(pr(o)))};if(i.serverTimestampBehavior==="previous"){const a=Bo(o);if(a)return a}return{nullValue:"NULL_VALUE"}}(e,s)):T.newValue(s):T.pr()}}class uA{constructor(e){this.expr=e}evaluate(e,t){return T.newValue(this.expr._getValue())}}class hA{constructor(e){this.expr=e}evaluate(e,t){const s=this.expr.cr.map(r=>ee(r).evaluate(e,t));return s.some(r=>r.yr())?T.mr():T.newValue({arrayValue:{values:s.map(r=>r.value)}})}}function at(n){return bs(n)?Number(n.doubleValue):Number(n.integerValue)}function Bn(n){return BigInt(n.integerValue)}const fA=BigInt("0x7fffffffffffffff"),dA=-BigInt("0x8000000000000000");class go{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length>=2,24778);const s=ee(this.expr.params[0]).evaluate(e,t),r=ee(this.expr.params[1]).evaluate(e,t);let i=this.br(s,r);for(const o of this.expr.params.slice(2)){const a=ee(o).evaluate(e,t);i=this.br(i,a)}return i}br(e,t){if(e.yr()||t.yr())return T.mr();if(e.wr()||t.wr())return T.gr();const s=e.value,r=t.value;if(!bs(s)&&!sn(s)||!bs(r)&&!sn(r))return T.mr();if(bs(s)||bs(r)){const i=this.Sr(s,r);return i?T.newValue(i):T.mr()}if(sn(s)&&sn(r)){const i=this.vr(s,r);return i===void 0?T.mr():typeof i=="number"?T.newValue({doubleValue:i}):i<dA||i>fA?T.mr():T.newValue({integerValue:`${i}`})}return T.mr()}}function vn(n,e){return Qe(n)!==Qe(e)?"TYPE_MISMATCH":St(n)||St(e)?"NOT_EQ":Lt(n)&&Lt(e)?"EQ":Lt(n)||Lt(e)?"NULL":_r(n)&&_r(e)?function(s,r){var o,a,B;if(((o=s.values)==null?void 0:o.length)!==((a=r.values)==null?void 0:a.length))return"NOT_EQ";let i=!1;for(let c=0;c<(((B=s.values)==null?void 0:B.length)??0);c++){const u=s.values[c],f=r.values[c];switch(vn(u,f)){case"EQ":break;case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":i=!0;break;default:X(44609,{Dr:u,Cr:f})}}return i?"NULL":"EQ"}(n.arrayValue,e.arrayValue):_a(n)&&_a(e)||Fs(n)&&Fs(e)?function(s,r){const i=s.fields||{},o=r.fields||{};if(pa(i)!==pa(o))return"NOT_EQ";let a=!1;for(const B in i)if(i.hasOwnProperty(B)){if(o[B]===void 0)return"NOT_EQ";switch(vn(i[B],o[B])){case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":a=!0}}return a?"NULL":"EQ"}(n.mapValue,e.mapValue):function(s,r){return Ut(s,r,{u:!1,i:!0,o:!0})}(n,e)?"EQ":"NOT_EQ"}class CA extends go{vr(e,t){return Bn(e)+Bn(t)}Sr(e,t){return{doubleValue:at(e)+at(t)}}}class pA extends go{constructor(e){super(e),this.expr=e}vr(e,t){return Bn(e)-Bn(t)}Sr(e,t){return{doubleValue:at(e)-at(t)}}}class gA extends go{constructor(e){super(e),this.expr=e}vr(e,t){return Bn(e)*Bn(t)}Sr(e,t){return{doubleValue:at(e)*at(t)}}}class mA extends go{constructor(e){super(e),this.expr=e}vr(e,t){const s=Bn(t);if(s!==BigInt(0))return Bn(e)/s}Sr(e,t){const s=at(t);return s===0?{doubleValue:Li(s)?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY}:{doubleValue:at(e)/s}}}class _A extends go{constructor(e){super(e),this.expr=e}vr(e,t){const s=Bn(t);if(s!==BigInt(0))return Bn(e)%s}Sr(e,t){const s=at(t);if(s!==0)return{doubleValue:at(e)%s}}}class EA{constructor(e){this.expr=e}evaluate(e,t){var i;let s=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if(!((i=a.value)!=null&&i.booleanValue))return T.newValue(st);break;case"NULL":r=!0;break;default:s=!0}}return s?T.mr():r?T.gr():T.newValue(vt)}}class hl{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,9634);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"BOOLEAN":return T.newValue({booleanValue:!((r=s.value)!=null&&r.booleanValue)});case"NULL":return T.gr();default:return T.mr()}}}class DA{constructor(e){this.expr=e}evaluate(e,t){var i;let s=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if((i=a.value)!=null&&i.booleanValue)return T.newValue(vt);break;case"NULL":r=!0;break;default:s=!0}}return s?T.mr():r?T.gr():T.newValue(st)}}class $c{constructor(e){this.expr=e}evaluate(e,t){var i;let s=!1,r=!1;for(const o of this.expr.params){const a=ee(o).evaluate(e,t);switch(a.type){case"BOOLEAN":s=$c.xor(s,!!((i=a.value)!=null&&i.booleanValue));break;case"NULL":r=!0;break;default:return T.mr()}}return r?T.gr():T.newValue({booleanValue:s})}static xor(e,t){return(e||t)&&!(e&&t)}}class em{constructor(e){this.expr=e}evaluate(e,t){var o,a;W(this.expr.params.length===2,55094);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"NULL":s=!0;break;case"ERROR":case"UNSET":return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":s=!0;break;default:return T.mr()}if(s)return T.gr();for(const B of((a=(o=i.value)==null?void 0:o.arrayValue)==null?void 0:a.values)??[])switch(Lt(r.value)&&Lt(B)?"EQ":vn(r.value,B)){case"EQ":return T.newValue(vt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":s=!0;break;default:X(44608,{value:r.value,candidate:B})}return s?T.gr():T.newValue(st)}}class yA{constructor(e){this.expr=e}evaluate(e,t){return new hl(new k("not",[new k("equal_any",this.expr.params)])).evaluate(e,t)}}class wA{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,23322);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"INT":return T.newValue(st);case"DOUBLE":return T.newValue({booleanValue:isNaN(at(s.value))});case"NULL":return T.gr();default:return T.mr()}}}class TA{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,50406),new hl(new k("not",[new k("is_nan",this.expr.params)])).evaluate(e,t)}}class IA{constructor(e){this.expr=e}evaluate(e,t){switch(W(this.expr.params.length===1,23123),ee(this.expr.params[0]).evaluate(e,t).type){case"NULL":return T.newValue(vt);case"UNSET":case"ERROR":return T.mr();default:return T.newValue(st)}}}class AA{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,23167),new hl(new k("not",[new k("is_null",this.expr.params)])).evaluate(e,t)}}class vA{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===1,5228),ee(this.expr.params[0]).evaluate(e,t).type==="ERROR"?T.newValue(vt):T.newValue(st)}}class RA{constructor(e){this.expr=e}evaluate(e,t){switch(W(this.expr.params.length===1,6877),ee(this.expr.params[0]).evaluate(e,t).type){case"ERROR":return T.mr();case"UNSET":return T.newValue(st);default:return T.newValue(vt)}}}class SA{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===3,11706);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"BOOLEAN":return(r=s.value)!=null&&r.booleanValue?ee(this.expr.params[1]).evaluate(e,t):ee(this.expr.params[2]).evaluate(e,t);case"NULL":return ee(this.expr.params[2]).evaluate(e,t);default:return T.mr()}}}class bA{constructor(e){this.expr=e}evaluate(e,t){const s=this.expr.params.map(i=>ee(i).evaluate(e,t));let r;for(const i of s)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:r=r===void 0||Rt(i.value,r.value)>0?i:r}return r===void 0?T.gr():r}}class NA{constructor(e){this.expr=e}evaluate(e,t){const s=this.expr.params.map(i=>ee(i).evaluate(e,t));let r;for(const i of s)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:r=r===void 0||Rt(i.value,r.value)<0?i:r}return r===void 0?T.gr():r}}class Mr{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===2,31033,`${this.expr.name}() function should have exactly 2 params`);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"ERROR":case"UNSET":return T.mr()}const r=ee(this.expr.params[1]).evaluate(e,t);switch(r.type){case"ERROR":case"UNSET":return T.mr()}return this.Fr(s,r)}}class PA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){if(e.wr()&&t.wr())return T.newValue(vt);if(e.wr()||t.wr()||St(e.value)||St(t.value)||Qe(e.value)!==Qe(t.value))return T.newValue(st);switch(vn(e.value,t.value)){case"EQ":return T.newValue(vt);case"NOT_EQ":return T.newValue(st);case"NULL":return T.gr();default:X(44615,{left:e,right:t})}}}class FA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){switch(vn(e.value,t.value)){case"EQ":return T.newValue(st);case"NOT_EQ":case"TYPE_MISMATCH":return T.newValue(vt);case"NULL":return T.gr();default:X(44614,{left:e,right:t})}}}class OA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){return Qe(e.value)!==Qe(t.value)||St(e.value)||St(t.value)?T.newValue(st):T.newValue({booleanValue:Rt(e.value,t.value)<0})}}class LA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){return Qe(e.value)!==Qe(t.value)||St(e.value)||St(t.value)?T.newValue(st):vn(e.value,t.value)==="EQ"?T.newValue(vt):T.newValue({booleanValue:Rt(e.value,t.value)<0})}}class xA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){return Qe(e.value)!==Qe(t.value)||St(e.value)||St(t.value)?T.newValue(st):T.newValue({booleanValue:Rt(e.value,t.value)>0})}}class kA extends Mr{constructor(e){super(e),this.expr=e}Fr(e,t){return Qe(e.value)!==Qe(t.value)||St(e.value)||St(t.value)?T.newValue(st):vn(e.value,t.value)==="EQ"?T.newValue(vt):T.newValue({booleanValue:Rt(e.value,t.value)>0})}}class MA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class VA{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,216);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":return T.gr();case"ARRAY":{const i=((r=s.value.arrayValue)==null?void 0:r.values)??[];return T.newValue({arrayValue:{values:[...i].reverse()}})}default:return T.mr()}}}class GA{constructor(e){this.expr=e}evaluate(e,t){return W(this.expr.params.length===2,52884),new em(new k("eq_any",[this.expr.params[1],this.expr.params[0]])).evaluate(e,t)}}class HA{constructor(e){this.expr=e}evaluate(e,t){var B,c,u,f;W(this.expr.params.length===2,1392);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"ARRAY":break;case"NULL":s=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":s=!0;break;default:return T.mr()}if(s)return T.gr();const o=((c=(B=i.value)==null?void 0:B.arrayValue)==null?void 0:c.values)??[],a=((f=(u=r.value)==null?void 0:u.arrayValue)==null?void 0:f.values)??[];for(const C of o){let g=!1;s=!1;for(const E of a){switch(Lt(C)&&Lt(E)?"EQ":vn(C,E)){case"EQ":g=!0;break;case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":s=!0;break;default:X(44613,{value:E,search:C})}if(g)break}if(!g)return T.newValue(st)}return T.newValue(vt)}}class UA{constructor(e){this.expr=e}evaluate(e,t){var B,c,u,f;W(this.expr.params.length===2,2680);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"ARRAY":break;case"NULL":s=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":s=!0;break;default:return T.mr()}if(s)return T.gr();const o=((c=(B=i.value)==null?void 0:B.arrayValue)==null?void 0:c.values)??[],a=((f=(u=r.value)==null?void 0:u.arrayValue)==null?void 0:f.values)??[];for(const C of a)for(const g of o)switch(Lt(C)&&Lt(g)?"EQ":vn(C,g)){case"EQ":return T.newValue(vt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":s=!0;break;default:X(60403,{value:C,search:g})}return s?T.gr():T.newValue(st)}}class qA{constructor(e){this.expr=e}evaluate(e,t){var r,i,o;W(this.expr.params.length===1,38605);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":return T.gr();case"ARRAY":return T.newValue({integerValue:`${((o=(i=(r=s.value)==null?void 0:r.arrayValue)==null?void 0:i.values)==null?void 0:o.length)??0}`});default:return T.mr()}}}class JA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class jA{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,1508);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":return T.gr();case"BYTES":{const o=(r=s.value)==null?void 0:r.bytesValue;if(typeof o=="string"){const a=Ke.fromBase64String(o).toUint8Array();return a.reverse(),T.newValue({bytesValue:Ke.fromUint8Array(a).toBase64()})}return T.newValue({bytesValue:new Uint8Array(o).reverse()})}case"STRING":{const o=(i=s.value)==null?void 0:i.stringValue,a=new Intl.__PRIVATE_Segmenter(void 0,{granularity:"grapheme"}).segment(o),B=Array.from(a,c=>c.segment).reverse();return T.newValue({stringValue:B.join("")})}default:return T.mr()}}}class KA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class QA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class zA{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,19400);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":return T.gr();case"STRING":{const r=function(o){let a=0;for(let B=0;B<o.length;B++){const c=o.codePointAt(B);if(c===void 0)return;if(c<=65535)if(c>=55296&&c<=57343)if(c<=56319){const u=o.codePointAt(B+1);u!==void 0&&u>=56320&&u<=57343?(a+=1,B++):a+=1}else a+=1;else a+=1;else{if(!(c<=1114111))return;a+=1,B++}}return a}(s.value.stringValue);return r===void 0?T.mr():T.newValue({integerValue:r})}default:return T.mr()}}}class WA{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,8486);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"BYTES":{const o=(r=s.value)==null?void 0:r.bytesValue;return typeof o=="string"?T.newValue({integerValue:Ke.fromBase64String(o).toUint8Array().length}):T.newValue({integerValue:new Uint8Array(o).length})}case"STRING":{const o=function(B){let c=0;for(let u=0;u<B.length;u++){const f=B.codePointAt(u);if(f===void 0)return;if(f>=55296&&f<=57343){if(!(f<=56319))return;{const C=B.codePointAt(u+1);if(C===void 0||!(C>=56320&&C<=57343))return;c+=4,u++}}else if(f<=127)c+=1;else if(f<=2047)c+=2;else if(f<=65535)c+=3;else{if(!(f<=1114111))return;c+=4,u++}}return c}((i=s.value)==null?void 0:i.stringValue);return o===void 0?T.mr():T.newValue({integerValue:o})}case"NULL":return T.gr();default:return T.mr()}}}class Vr{constructor(e){this.expr=e}evaluate(e,t){var o,a;W(this.expr.params.length===2,39773,`${this.expr.name}() function should have exactly two parameters`);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"STRING":break;case"NULL":s=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"STRING":break;case"NULL":s=!0;break;default:return T.mr()}return s?T.gr():this.Or((o=r.value)==null?void 0:o.stringValue,(a=i.value)==null?void 0:a.stringValue)}}class $A extends Vr{Or(e,t){try{const s=function(o){let a="";for(let B=0;B<o.length;B++){const c=o.charAt(B);switch(c){case"_":a+=".";break;case"%":a+=".*";break;case"\\":case".":case"*":case"?":case"+":case"^":case"$":case"|":case"(":case")":case"[":case"]":case"{":case"}":a+="\\"+c;break;default:a+=c}}return"^"+a+"$"}(t),r=vc.compile(s);return T.newValue({booleanValue:r.matches(e)})}catch(s){return Wt(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${s}`),T.mr()}}}class YA extends Vr{Or(e,t){try{const s=vc.compile(t);return T.newValue({booleanValue:s.test(e)})}catch{return Wt(`Invalid regex pattern found in regex_contains: ${t}, returning error`),T.mr()}}}class XA extends Vr{Or(e,t){try{return T.newValue({booleanValue:vc.compile(t).matches(e)})}catch{return Wt(`Invalid regex pattern found in regex_match: ${t}, returning error`),T.mr()}}}class ZA extends Vr{Or(e,t){return T.newValue({booleanValue:e.includes(t)})}}class ev extends Vr{Or(e,t){return T.newValue({booleanValue:e.startsWith(t)})}}class tv extends Vr{Or(e,t){return T.newValue({booleanValue:e.endsWith(t)})}}class nv{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,29079);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"STRING":return T.newValue({stringValue:(i=(r=s.value)==null?void 0:r.stringValue)==null?void 0:i.toLowerCase()});case"NULL":return T.gr();default:return T.mr()}}}class sv{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,60487);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"STRING":return T.newValue({stringValue:(i=(r=s.value)==null?void 0:r.stringValue)==null?void 0:i.toUpperCase()});case"NULL":return T.gr();default:return T.mr()}}}class rv{constructor(e){this.expr=e}evaluate(e,t){var r,i;W(this.expr.params.length===1,28544);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"STRING":return T.newValue({stringValue:(i=(r=s.value)==null?void 0:r.stringValue)==null?void 0:i.trim()});case"NULL":return T.gr();default:return T.mr()}}}class iv{constructor(e){this.expr=e}evaluate(e,t){const s=this.expr.params.map(o=>ee(o).evaluate(e,t));let r="",i=!1;for(const o of s)switch(o.type){case"STRING":r+=o.value.stringValue;break;case"NULL":i=!0;break;default:return T.mr()}return i?T.gr():T.newValue({stringValue:r})}}class ov{constructor(e){this.expr=e}evaluate(e,t){var o,a,B,c;W(this.expr.params.length===2,4483);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"UNSET":return T.pr();case"MAP":break;default:return T.mr()}const r=ee(this.expr.params[1]).evaluate(e,t);if(r.type!=="STRING")return T.mr();const i=(c=(a=(o=s.value)==null?void 0:o.mapValue)==null?void 0:a.fields)==null?void 0:c[(B=r.value)==null?void 0:B.stringValue];return i===void 0?T.pr():T.newValue(i)}}class Yc{constructor(e){this.expr=e}evaluate(e,t){var c,u;W(this.expr.params.length===2,25231,`${this.expr.name}() function should have exactly 2 params`);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"VECTOR":break;case"NULL":s=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);switch(i.type){case"VECTOR":break;case"NULL":s=!0;break;default:return T.mr()}if(s)return T.gr();const o=HB(r.value),a=HB(i.value);if(o===void 0||a===void 0||((c=o.values)==null?void 0:c.length)!==((u=a.values)==null?void 0:u.length))return T.mr();const B=this.Mr(o,a);return B===void 0||isNaN(B)?T.mr():T.newValue({doubleValue:B})}}class av extends Yc{Mr(e,t){const s=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(s.length===0)return;let i=0,o=0,a=0;for(let c=0;c<s.length;c++){if(!ss(s[c])||!ss(r[c]))return;const u=at(s[c]),f=at(r[c]);i+=u*f,o+=u*u,a+=f*f}const B=Math.sqrt(o)*Math.sqrt(a);if(B!==0)return 1-Math.max(-1,Math.min(1,i/B))}}class lv extends Yc{Mr(e,t){const s=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(s.length===0)return 0;let i=0;for(let o=0;o<s.length;o++){if(!ss(s[o])||!ss(r[o]))return;i+=at(s[o])*at(r[o])}return i}}class Bv extends Yc{Mr(e,t){const s=(e==null?void 0:e.values)??[],r=(t==null?void 0:t.values)??[];if(s.length===0)return 0;let i=0;for(let o=0;o<s.length;o++){if(!ss(s[o])||!ss(r[o]))return;const a=at(s[o]),B=at(r[o]);i+=Math.pow(a-B,2)}return Math.sqrt(i)}}class cv{constructor(e){this.expr=e}evaluate(e,t){var r;W(this.expr.params.length===1,39044);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"VECTOR":{const i=HB(s.value);return T.newValue({integerValue:((r=i==null?void 0:i.values)==null?void 0:r.length)??0})}case"NULL":return T.gr();default:return T.mr()}}}const ji=BigInt(-62135596800),Ki=BigInt(253402300799),Ia=BigInt(1e3),$n=BigInt(1e6),uv=ji*Ia,hv=Ki*Ia+BigInt(999),fv=ji*$n,dv=Ki*$n+BigInt(999999);function Xc(n){return n>=fv&&n<=dv}function tm(n){return n>=ji&&n<=Ki}function Qi(n,e){const t=BigInt(n);return!(t<ji||t>Ki)&&!(e<0||e>=1e9)&&(t!==ji||e===0)&&!(t===Ki&&e>999999999)}function nm(n,e){return e<0?{seconds:n-1,nanos:e+1e9}:{seconds:n,nanos:e}}function Zc(n){return BigInt(n.seconds)*$n+BigInt(Math.trunc(n.nanoseconds/1e3))}class eu{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,49262,`${this.expr.name}() function should have exactly one parameter`);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"INT":return this.toTimestamp(BigInt(s.value.integerValue));case"NULL":return T.gr();default:return T.mr()}}}class Cv extends eu{toTimestamp(e){if(!Xc(e))return T.mr();let t=Number(e/$n),s=Number(e%$n*BigInt(1e3));const r=nm(t,s);return t=r.seconds,s=r.nanos,Qi(t,s)?T.newValue({timestampValue:{seconds:t,nanos:s}}):T.mr()}}class pv extends eu{toTimestamp(e){if(!function(o){return o>=uv&&o<=hv}(e))return T.mr();let t=Number(e/Ia),s=Number(e%Ia*BigInt(1e6));const r=nm(t,s);return t=r.seconds,s=r.nanos,Qi(t,s)?T.newValue({timestampValue:{seconds:t,nanos:s}}):T.mr()}}class gv extends eu{toTimestamp(e){if(!tm(e))return T.mr();const t=Number(e);return T.newValue({timestampValue:{seconds:t,nanos:0}})}}class tu{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===1,1265,`${this.expr.name}() function should have exactly one parameter`);const s=ee(this.expr.params[0]).evaluate(e,t);switch(s.type){case"TIMESTAMP":break;case"NULL":return T.gr();default:return T.mr()}const r=kc(s.value.timestampValue);return Qi(r.seconds,r.nanoseconds)?this.Nr(r):T.mr()}}class mv extends tu{Nr(e){const t=Zc(e);return Xc(t)?T.newValue({integerValue:`${t.toString()}`}):T.mr()}}class _v extends tu{Nr(e){const t=Zc(e),s=t/BigInt(1e3),r=t%BigInt(1e3);return s>BigInt(0)||r===BigInt(0)?T.newValue({integerValue:s.toString()}):T.newValue({integerValue:(s-BigInt(1)).toString()})}}class Ev extends tu{Nr(e){const t=BigInt(e.seconds);return tm(t)?T.newValue({integerValue:t.toString()}):T.mr()}}class sm{constructor(e){this.expr=e}evaluate(e,t){W(this.expr.params.length===3,2775,`${this.expr.name}() function should have exactly 3 parameters`);let s=!1;const r=ee(this.expr.params[0]).evaluate(e,t);switch(r.type){case"TIMESTAMP":break;case"NULL":s=!0;break;default:return T.mr()}const i=ee(this.expr.params[1]).evaluate(e,t);let o;switch(i.type){case"STRING":if(o=function(te){switch(te){case"microsecond":return"microsecond";case"millisecond":return"millisecond";case"second":return"second";case"minute":return"minute";case"hour":return"hour";case"day":return"day";default:return}}(i.value.stringValue),o===void 0)return T.mr();break;case"NULL":s=!0;break;default:return T.mr()}const a=ee(this.expr.params[2]).evaluate(e,t);switch(a.type){case"INT":break;case"NULL":s=!0;break;default:return T.mr()}if(s)return T.gr();const B=BigInt(a.value.integerValue);let c;try{switch(o){case"microsecond":c=B;break;case"millisecond":c=B*BigInt(1e3);break;case"second":c=B*BigInt(1e6);break;case"minute":c=B*BigInt(6e7);break;case"hour":c=B*BigInt(36e8);break;case"day":c=B*BigInt(864e8);break;default:return T.mr()}if(o!=="microsecond"&&B!==BigInt(0)&&c/B!==BigInt(this.Lr(o)))return T.mr()}catch(j){return Wt(`Error during timestamp arithmetic: ${j}`),T.mr()}const u=kc(r.value.timestampValue);if(!Qi(u.seconds,u.nanoseconds))return T.mr();const f=Zc(u),C=this.Br(f,c);if(!Xc(C))return T.mr();const g=Number(C/$n),E=C%$n,b=Number((E<0?E+$n:E)*BigInt(1e3)),F=E<0?g-1:g;return Qi(F,b)?T.newValue({timestampValue:{seconds:F,nanos:b}}):T.mr()}Lr(e){switch(e){case"millisecond":return 1e3;case"second":return 1e6;case"minute":return 6e7;case"hour":return 36e8;case"day":return 864e8;default:return 1}}}class Dv extends sm{Br(e,t){return e+t}}class yv extends sm{Br(e,t){return e-t}}function zi(n){if((n=Zg(n))instanceof xr)return`fld(${n.fieldName})`;if(n instanceof kr)return`cst(${function(t){return t===null?"null":typeof t=="number"?t.toString():typeof t=="string"?`"${t}"`:t instanceof Pe?`ref(${t.path})`:t instanceof At?`vec(${JSON.stringify(t)})`:JSON.stringify(t)}(n.value)})`;if(n instanceof k)return`fn(${n.name},[${n.params.map(zi).join(",")}])`;if(n.expressionType==="ListOfExpressions")return`list([${n.cr.map(zi).join(",")}])`;throw new Error(`Unrecognized expr ${JSON.stringify(n,null,2)}`)}function wv(n){if(n instanceof $g)return`${n._name}(${ea(n.fields)})`;if(n instanceof Yg){let e=`${n._name}(${ea(n.accumulators)})`;return n.groups.size>0&&(e+=`grouping(${ea(n.groups)})`),e}if(n instanceof Xg)return`${n._name}(${ea(n.groups)})`;if(n instanceof ll)return`${n._name}(${n.hr})`;if(n instanceof Bl)return`${n._name}(${n.collectionId})`;if(n instanceof Kc)return`${n._name}()`;if(n instanceof Qc)return`${n._name}(${n.Tr.sort()})`;if(n instanceof cl)return`${n._name}(${zi(n.condition)})`;if(n instanceof Us)return`${n._name}(${n.limit})`;if(n instanceof mn)return`${n._name}(${function(t){return t.map(s=>`${zi(s.expr)}${s.direction}`).join(",")}(n.orderings)})`;throw new Error(`Unrecognized stage ${n._name}`)}function ea(n){return`${Array.from(n.entries()).sort().map(([e,t])=>`${e}=${zi(t)}`).join(",")}`}function Dn(n){return n.stages.map(e=>wv(e)).join("|")}function rm(n,e){return Dn(n)===Dn(e)}function Ye(n){return n instanceof pt}function Vd(n){return Ye(n)?Dn(n):Ei(n)}function im(n){return Ye(n)?Dn(n):function(t){return`${lg(on(t))}|lt:${t.limitType}`}(n)}function fl(n,e){return n instanceof pt&&e instanceof pt?rm(n,e):!(n instanceof pt&&!(e instanceof pt)||!(n instanceof pt)&&e instanceof pt)&&JT(n,e)}function om(n){return vs(n)?Dn(n):lg(n)}function am(n,e){return n instanceof pt&&e instanceof pt?rm(n,e):!(n instanceof pt&&!(e instanceof pt)||!(n instanceof pt)&&e instanceof pt)&&Bg(n,e)}function Tv(n,e){const t=function(r){let i=!1;const o=[];for(const a of r)if(a instanceof mn)if(i=!0,a.orderings.some(B=>B.expr instanceof xr&&B.expr.fieldName===nn))o.push(a);else{const B=a.orderings.map(c=>c);B.push(Ba(nn).ascending()),o.push(new mn(B,{}))}else a instanceof Us&&(i||(o.push(new mn([Ba(nn).ascending()],{})),i=!0)),o.push(a);return i||o.push(new mn([Ba(nn).ascending()],{})),o}(n.stages);if(n.userDataReader){const s=n.userDataReader.createContext(3,"toCorePipeline");t.forEach(r=>r._readUserData(s))}return new pt(n.userDataReader.serializer,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iv{constructor(e,t,s,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=s,this.mutations=r}applyToRemoteDocument(e,t){const s=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const i=this.mutations[r];i.key.isEqual(e.key)&&wT(i,e,s[r])}}applyToLocalView(e,t){for(const s of this.baseMutations)s.key.isEqual(e.key)&&(t=_i(s,e,t,this.localWriteTime));for(const s of this.mutations)s.key.isEqual(e.key)&&(t=_i(s,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const s=pg();return this.mutations.forEach(r=>{const i=e.get(r.key),o=i.overlayedDocument;let a=this.applyToLocalView(o,i.mutatedFields);a=t.has(r.key)?null:a;const B=Zp(o,a);B!==null&&s.set(r.key,B),o.isValidDocument()||o.convertToNoDocument(ne.min())}),s}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),Be())}isEqual(e){return this.batchId===e.batchId&&Cr(this.mutations,e.mutations,(t,s)=>pd(t,s))&&Cr(this.baseMutations,e.baseMutations,(t,s)=>pd(t,s))}}class nu{constructor(e,t,s,r){this.batch=e,this.commitVersion=t,this.mutationResults=s,this.docVersions=r}static from(e,t,s){W(e.mutations.length===s.length,58842,{Ur:e.mutations.length,kr:s.length});let r=function(){return zT}();const i=e.mutations;for(let o=0;o<i.length;o++)r=r.insert(i[o].key,s[o].version);return new nu(e,t,s,r)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lm="";function Av(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Gd(e)),e=vv(n.get(t),e);return Gd(e)}function vv(n,e){let t=e;const s=n.length;for(let r=0;r<s;r++){const i=n.charAt(r);switch(i){case"\0":t+="";break;case lm:t+="";break;default:t+=i}}return t}function Gd(n){return n+lm+""}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rv{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(e,t,s,r,i=ne.min(),o=ne.min(),a=Ke.EMPTY_BYTE_STRING,B=null){this.target=e,this.targetId=t,this.purpose=s,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=B}withSequenceNumber(e){return new _n(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new _n(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new _n(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new _n(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sv{constructor(e){this.$r=e}}function bv(n){const e=uI({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?wa(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nv{constructor(){this.Zi=new Pv}addToCollectionParentIndex(e,t){return this.Zi.add(t),M.resolve()}getCollectionParents(e,t){return M.resolve(this.Zi.getEntries(t))}addFieldIndex(e,t){return M.resolve()}deleteFieldIndex(e,t){return M.resolve()}deleteAllFieldIndexes(e){return M.resolve()}createTargetIndexes(e,t){return M.resolve()}getDocumentsMatchingTarget(e,t){return M.resolve(null)}getIndexType(e,t){return M.resolve(0)}getFieldIndexes(e,t){return M.resolve([])}getNextCollectionGroupToUpdate(e){return M.resolve(null)}getMinOffset(e,t){return M.resolve(rs.min())}getMinOffsetFromCollectionGroup(e,t){return M.resolve(rs.min())}updateCollectionGroup(e,t,s){return M.resolve()}updateIndexEntries(e,t){return M.resolve()}}class Pv{constructor(){this.index={}}add(e){const t=e.lastSegment(),s=e.popLast(),r=this.index[t]||new je(pe.comparator),i=!r.has(s);return this.index[t]=r.add(s),i}has(e){const t=e.lastSegment(),s=e.popLast(),r=this.index[t];return r&&r.has(s)}getEntries(e){return(this.index[e]||new je(pe.comparator)).toArray()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ls{constructor(e){this.ys=e}next(){return this.ys+=2,this.ys}static ws(){return new ls(0)}static bs(){return new ls(-1)}}// Copyright 2024 Google LLC* @license
function Bm(n,e){var s;let t=e;for(const r of n.stages)t=Ov({serializer:n.serializer,serverTimestampBehavior:(s=n.listenOptions)==null?void 0:s.serverTimestampBehavior},r,t);return t}function dl(n,e){return Bm(n,[e]).length>0}function Fv(n,e){return Ye(n)?dl(n,e):sl(n,e)}function Ov(n,e,t){if(e instanceof ll)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&`/${a.key.getCollectionPath().canonicalString()}`===i.hr)}(0,e,t);if(e instanceof cl)return function(r,i,o){return o.filter(a=>{const B=Ii(ee(i.condition).evaluate(r,a));return B!==void 0&&Ut(B,vt)})}(n,e,t);if(e instanceof Bl)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&a.key.getCollectionPath().lastSegment()===i.collectionId)}(0,e,t);if(e instanceof Kc)return function(r,i,o){return o.filter(a=>a.isFoundDocument())}(0,0,t);if(e instanceof Qc)return function(r,i,o){return o.filter(a=>a.isFoundDocument()&&i.Pr.has(a.key.path.toStringWithLeadingSlash()))}(0,e,t);if(e instanceof Us)return function(r,i,o){return o.slice(0,i.limit)}(0,e,t);if(e instanceof mn)return function(r,i,o){const a=i.orderings.map(B=>({Ms:ee(B.expr),direction:B.direction}));return[...o].sort((B,c)=>{for(const{Ms:u,direction:f}of a){const C=Ii(u.evaluate(r,B)),g=Ii(u.evaluate(r,c)),E=Rt(C??gr,g??gr);if(E!==0)return f==="ascending"?E:-E}return 0})}(n,e,t);throw new Error(`Unknown stage: ${e._name}`)}function WB(n){const e=function(s){for(let r=s.stages.length-1;r>=0;r--){const i=s.stages[r];if(i instanceof mn)return i.orderings}throw new Error("Pipeline must contain at least one Sort stage")}(n);return(t,s)=>{for(const r of e){const i=Ii(ee(r.expr).evaluate({serializer:n.serializer},t)),o=Ii(ee(r.expr).evaluate({serializer:n.serializer},s)),a=Rt(i||gr,o||gr);if(a!==0)return r.direction==="ascending"?a:-a}return 0}}function pB(n){for(let e=n.stages.length-1;e>=0;e--){const t=n.stages[e];if(t instanceof Us)return{limit:t.limit}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lv{constructor(){this.changes=new js(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,nt.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const s=this.changes.get(t);return s!==void 0?M.resolve(s):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xv{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kv{constructor(e,t,s,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=s,this.indexManager=r}getDocument(e,t){let s=null;return this.documentOverlayCache.getOverlay(e,t).next(r=>(s=r,this.remoteDocumentCache.getEntry(e,t))).next(r=>(s!==null&&_i(s.mutation,r,Ot.empty(),Ee.now()),r))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.getLocalViewOfDocuments(e,s,Be()).next(()=>s))}getLocalViewOfDocuments(e,t,s=Be()){const r=Hn();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,s).next(i=>{let o=ar();return i.forEach((a,B)=>{o=o.insert(a,B.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const s=Hn();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,Be()))}populateOverlays(e,t,s){const r=[];return s.forEach(i=>{t.has(i)||r.push(i)}),this.documentOverlayCache.getOverlays(e,r).next(i=>{i.forEach((o,a)=>{t.set(o,a)})})}computeViews(e,t,s,r){let i=Tt();const o=Di(),a=function(){return Di()}();return t.forEach((B,c)=>{const u=s.get(c.key);r.has(c.key)&&(u===void 0||u.mutation instanceof ps)?i=i.insert(c.key,c):u!==void 0?(o.set(c.key,u.mutation.getFieldMask()),_i(u.mutation,c,u.mutation.getFieldMask(),Ee.now())):o.set(c.key,Ot.empty())}),this.recalculateAndSaveOverlays(e,i).next(B=>(B.forEach((c,u)=>o.set(c,u)),t.forEach((c,u)=>a.set(c,new xv(u,o.get(c)??null))),a))}recalculateAndSaveOverlays(e,t){const s=Di();let r=new Ge((o,a)=>o-a),i=Be();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const a of o)a.keys().forEach(B=>{const c=t.get(B);if(c===null)return;let u=s.get(B)||Ot.empty();u=a.applyToLocalView(c,u),s.set(B,u);const f=(r.get(a.batchId)||Be()).add(B);r=r.insert(a.batchId,f)})}).next(()=>{const o=[],a=r.getReverseIterator();for(;a.hasNext();){const B=a.getNext(),c=B.key,u=B.value,f=pg();u.forEach(C=>{if(!i.has(C)){const g=Zp(t.get(C),s.get(C));g!==null&&f.set(C,g),i=i.add(C)}}),o.push(this.documentOverlayCache.saveOverlays(e,c,f))}return M.waitFor(o)}).next(()=>s)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(s=>this.recalculateAndSaveOverlays(e,s))}getDocumentsMatchingQuery(e,t,s,r){return Ye(t)?this.getDocumentsMatchingPipeline(e,t,s,r):VT(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):Oc(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,s,r):this.getDocumentsMatchingCollectionQuery(e,t,s,r)}getNextDocuments(e,t,s,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,s,r).next(i=>{const o=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,s.largestBatchId,r-i.size):M.resolve(Hn());let a=Hi,B=i;return o.next(c=>M.forEach(c,(u,f)=>(a<f.largestBatchId&&(a=f.largestBatchId),i.get(u)?M.resolve():this.remoteDocumentCache.getEntry(e,u).next(C=>{B=B.insert(u,C)}))).next(()=>this.populateOverlays(e,c,i)).next(()=>this.computeViews(e,B,c,Be())).next(u=>({batchId:a,changes:Cg(u)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new $(t)).next(s=>{let r=ar();return s.isFoundDocument()&&(r=r.insert(s.key,s)),r})}getDocumentsMatchingCollectionGroupQuery(e,t,s,r){const i=t.collectionGroup;let o=ar();return this.indexManager.getCollectionParents(e,i).next(a=>M.forEach(a,B=>{const c=function(f,C){return new gs(C,null,f.explicitOrderBy.slice(),f.filters.slice(),f.limit,f.limitType,f.startAt,f.endAt)}(t,B.child(i));return this.getDocumentsMatchingCollectionQuery(e,c,s,r).next(u=>{u.forEach((f,C)=>{o=o.insert(f,C)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,s,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,s.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,i,r))).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>sl(t,a)))}getDocumentsMatchingPipeline(e,t,s,r){if(Wn(t)==="collection_group"){const i=Wc(t);let o=ar();return this.indexManager.getCollectionParents(e,i).next(a=>M.forEach(a,B=>{const c=function(f,C){const g=f.stages.map(E=>E instanceof Bl?new ll(C.canonicalString(),{}):E);return new pt(f.serializer,g)}(t,B.child(i));return this.getDocumentsMatchingPipeline(e,c,s,r).next(u=>{u.forEach((f,C)=>{o=o.insert(f,C)})})}).next(()=>o))}{let i;return this.getOverlaysForPipeline(e,t,s.largestBatchId).next(o=>{switch(i=o,Wn(t)){case"collection":return this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,s,i,r);case"documents":let a=Be();for(const B of zB(t))a=a.add($.fromPath(B));return this.remoteDocumentCache.getEntries(e,a);case"database":return this.remoteDocumentCache.getAllEntries(e);default:throw new G("invalid-argument",`Invalid pipeline source to execute offline: ${Dn(t)}`)}}).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>dl(t,a)))}}retrieveMatchingLocalDocuments(e,t,s){e.forEach((i,o)=>{const a=o.getKey();t.get(a)===null&&(t=t.insert(a,nt.newInvalidDocument(a)))});let r=ar();return t.forEach((i,o)=>{const a=e.get(i);a!==void 0&&_i(a.mutation,o,Ot.empty(),Ee.now()),s(o)&&(r=r.insert(i,o))}),r}getOverlaysForPipeline(e,t,s){switch(Wn(t)){case"collection":return this.documentOverlayCache.getOverlaysForCollection(e,pe.fromString(ul(t)),s);case"collection_group":throw new G("invalid-argument",`Unexpected collection group pipeline: ${Dn(t)}`);case"documents":return this.documentOverlayCache.getOverlays(e,zB(t).map(r=>$.fromPath(r)));case"database":return this.documentOverlayCache.getAllOverlays(e,s);default:throw new G("invalid-argument",`Failed to get overlays for pipeline: ${Dn(t)}`)}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mv{constructor(e){this.serializer=e,this.Qs=new Map,this.Ws=new Map}getBundleMetadata(e,t){return M.resolve(this.Qs.get(t))}saveBundleMetadata(e,t){return this.Qs.set(t.id,function(r){return{id:r.id,version:r.version,createTime:kt(r.createTime)}}(t)),M.resolve()}getNamedQuery(e,t){return M.resolve(this.Ws.get(t))}saveNamedQuery(e,t){return this.Ws.set(t.name,function(r){return{name:r.name,query:bv(r.bundledQuery),readTime:kt(r.readTime)}}(t)),M.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vv{constructor(){this.overlays=new Ge($.comparator),this.Gs=new Map}getOverlay(e,t){return M.resolve(this.overlays.get(t))}getOverlays(e,t){const s=Hn();return M.forEach(t,r=>this.getOverlay(e,r).next(i=>{i!==null&&s.set(r,i)})).next(()=>s)}getAllOverlays(e,t){const s=Hn();return this.overlays.forEach((r,i)=>{i.largestBatchId>t&&s.set(r,i)}),M.resolve(s)}saveOverlays(e,t,s){return s.forEach((r,i)=>{this.Zr(e,t,i)}),M.resolve()}removeOverlaysForBatchId(e,t,s){const r=this.Gs.get(s);return r!==void 0&&(r.forEach(i=>this.overlays=this.overlays.remove(i)),this.Gs.delete(s)),M.resolve()}getOverlaysForCollection(e,t,s){const r=Hn(),i=t.length+1,o=new $(t.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const B=a.getNext().value,c=B.getKey();if(!t.isPrefixOf(c.path))break;c.path.length===i&&B.largestBatchId>s&&r.set(B.getKey(),B)}return M.resolve(r)}getOverlaysForCollectionGroup(e,t,s,r){let i=new Ge((c,u)=>c-u);const o=this.overlays.getIterator();for(;o.hasNext();){const c=o.getNext().value;if(c.getKey().getCollectionGroup()===t&&c.largestBatchId>s){let u=i.get(c.largestBatchId);u===null&&(u=Hn(),i=i.insert(c.largestBatchId,u)),u.set(c.getKey(),c)}}const a=Hn(),B=i.getIterator();for(;B.hasNext()&&(B.getNext().value.forEach((c,u)=>a.set(c,u)),!(a.size()>=r)););return M.resolve(a)}Zr(e,t,s){const r=this.overlays.get(s.key);if(r!==null){const o=this.Gs.get(r.largestBatchId).delete(s.key);this.Gs.set(r.largestBatchId,o)}this.overlays=this.overlays.insert(s.key,new Rv(t,s));let i=this.Gs.get(t);i===void 0&&(i=Be(),this.Gs.set(t,i)),this.Gs.set(t,i.add(s.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gv{constructor(){this.sessionToken=Ke.EMPTY_BYTE_STRING}getSessionToken(e){return M.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,M.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class su{constructor(){this.zs=new je(et.js),this.Hs=new je(et.Js)}isEmpty(){return this.zs.isEmpty()}addReference(e,t){const s=new et(e,t);this.zs=this.zs.add(s),this.Hs=this.Hs.add(s)}Ys(e,t){e.forEach(s=>this.addReference(s,t))}removeReference(e,t){this.Zs(new et(e,t))}Xs(e,t){e.forEach(s=>this.removeReference(s,t))}e_(e){const t=new $(new pe([])),s=new et(t,e),r=new et(t,e+1),i=[];return this.Hs.forEachInRange([s,r],o=>{this.Zs(o),i.push(o.key)}),i}t_(){this.zs.forEach(e=>this.Zs(e))}Zs(e){this.zs=this.zs.delete(e),this.Hs=this.Hs.delete(e)}n_(e){const t=new $(new pe([])),s=new et(t,e),r=new et(t,e+1);let i=Be();return this.Hs.forEachInRange([s,r],o=>{i=i.add(o.key)}),i}containsKey(e){const t=new et(e,0),s=this.zs.firstAfterOrEqual(t);return s!==null&&e.isEqual(s.key)}}class et{constructor(e,t){this.key=e,this.r_=t}static js(e,t){return $.comparator(e.key,t.key)||ue(e.r_,t.r_)}static Js(e,t){return ue(e.r_,t.r_)||$.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hv{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Gr=1,this.i_=new je(et.js)}checkEmpty(e){return M.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,s,r){const i=this.Gr;this.Gr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new Iv(i,t,s,r);this.mutationQueue.push(o);for(const a of r)this.i_=this.i_.add(new et(a.key,i)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return M.resolve(o)}lookupMutationBatch(e,t){return M.resolve(this.s_(t))}getNextMutationBatchAfterBatchId(e,t){const s=t+1,r=this.__(s),i=r<0?0:r;return M.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return M.resolve(this.mutationQueue.length===0?bc:this.Gr-1)}getAllMutationBatches(e){return M.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const s=new et(t,0),r=new et(t,Number.POSITIVE_INFINITY),i=[];return this.i_.forEachInRange([s,r],o=>{const a=this.s_(o.r_);i.push(a)}),M.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let s=new je(ue);return t.forEach(r=>{const i=new et(r,0),o=new et(r,Number.POSITIVE_INFINITY);this.i_.forEachInRange([i,o],a=>{s=s.add(a.r_)})}),M.resolve(this.o_(s))}getAllMutationBatchesAffectingQuery(e,t){const s=t.path,r=s.length+1;let i=s;$.isDocumentKey(i)||(i=i.child(""));const o=new et(new $(i),0);let a=new je(ue);return this.i_.forEachWhile(B=>{const c=B.key.path;return!!s.isPrefixOf(c)&&(c.length===r&&(a=a.add(B.r_)),!0)},o),M.resolve(this.o_(a))}o_(e){const t=[];return e.forEach(s=>{const r=this.s_(s);r!==null&&t.push(r)}),t}removeMutationBatch(e,t){W(this.a_(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let s=this.i_;return M.forEach(t.mutations,r=>{const i=new et(r.key,t.batchId);return s=s.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)}).next(()=>{this.i_=s})}Hr(e){}containsKey(e,t){const s=new et(t,0),r=this.i_.firstAfterOrEqual(s);return M.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,M.resolve()}a_(e,t){return this.__(e)}__(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}s_(e){const t=this.__(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uv{constructor(e){this.u_=e,this.docs=function(){return new Ge($.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const s=t.key,r=this.docs.get(s),i=r?r.size:0,o=this.u_(t);return this.docs=this.docs.insert(s,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,s.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const s=this.docs.get(t);return M.resolve(s?s.document.mutableCopy():nt.newInvalidDocument(t))}getEntries(e,t){let s=Tt();return t.forEach(r=>{const i=this.docs.get(r);s=s.insert(r,i?i.document.mutableCopy():nt.newInvalidDocument(r))}),M.resolve(s)}getAllEntries(e){let t=Tt();return this.docs.forEach((s,r)=>{t=t.insert(s,r.document)}),M.resolve(t)}getDocumentsMatchingQuery(e,t,s,r){let i,o;Ye(t)?(i=pe.fromString(ul(t)),o=u=>dl(t,u)):(i=t.path,o=u=>sl(t,u));let a=Tt();const B=new $(i.child("__id-9223372036854775808__")),c=this.docs.getIteratorFrom(B);for(;c.hasNext();){const{key:u,value:{document:f}}=c.getNext();if(!i.isPrefixOf(u.path))break;u.path.length>i.length+1||xT(LT(f),s)<=0||(r.has(f.key)||o(f))&&(a=a.insert(f.key,f.mutableCopy()))}return M.resolve(a)}getAllFromCollectionGroup(e,t,s,r){X(9500)}c_(e,t){return M.forEach(this.docs,s=>t(s))}newChangeBuffer(e){return new qv(this)}getSize(e){return M.resolve(this.size)}}class qv extends Lv{constructor(e){super(),this.$s=e}applyChanges(e){const t=[];return this.changes.forEach((s,r)=>{r.isValidDocument()?t.push(this.$s.addEntry(e,r)):this.$s.removeEntry(s)}),M.waitFor(t)}getFromCache(e,t){return this.$s.getEntry(e,t)}getAllFromCache(e,t){return this.$s.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jv{constructor(e){this.persistence=e,this.l_=new js(t=>om(t),am),this.lastRemoteSnapshotVersion=ne.min(),this.highestTargetId=0,this.E_=0,this.h_=new su,this.targetCount=0,this.T_=ls.ws()}forEachTarget(e,t){return this.l_.forEach((s,r)=>t(r)),M.resolve()}getLastRemoteSnapshotVersion(e){return M.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return M.resolve(this.E_)}allocateTargetId(e){return this.highestTargetId=this.T_.next(),M.resolve(this.highestTargetId)}setTargetsMetadata(e,t,s){return s&&(this.lastRemoteSnapshotVersion=s),t>this.E_&&(this.E_=t),M.resolve()}Ds(e){this.l_.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.T_=new ls(t),this.highestTargetId=t),e.sequenceNumber>this.E_&&(this.E_=e.sequenceNumber)}addTargetData(e,t){return this.Ds(t),this.targetCount+=1,M.resolve()}updateTargetData(e,t){return this.Ds(t),M.resolve()}removeTargetData(e,t){return this.l_.delete(t.target),this.h_.e_(t.targetId),this.targetCount-=1,M.resolve()}removeTargets(e,t,s){let r=0;const i=[];return this.l_.forEach((o,a)=>{a.sequenceNumber<=t&&s.get(a.targetId)===null&&(this.l_.delete(o),i.push(this.removeMatchingKeysForTargetId(e,a.targetId)),r++)}),M.waitFor(i).next(()=>r)}getTargetCount(e){return M.resolve(this.targetCount)}getTargetData(e,t){const s=this.l_.get(t)||null;return M.resolve(s)}addMatchingKeys(e,t,s){return this.h_.Ys(t,s),M.resolve()}removeMatchingKeys(e,t,s){this.h_.Xs(t,s);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach(o=>{i.push(r.markPotentiallyOrphaned(e,o))}),M.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.h_.e_(t),M.resolve()}getMatchingKeysForTargetId(e,t){const s=this.h_.n_(t);return M.resolve(s)}containsKey(e,t){return M.resolve(this.h_.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cm{constructor(e,t){this.P_={},this.overlays={},this.I_=new il(0),this.R_=!1,this.R_=!0,this.A_=new Gv,this.referenceDelegate=e(this),this.V_=new Jv(this),this.indexManager=new Nv,this.remoteDocumentCache=function(r){return new Uv(r)}(s=>this.referenceDelegate.d_(s)),this.serializer=new Sv(t),this.f_=new Mv(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.R_=!1,Promise.resolve()}get started(){return this.R_}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new Vv,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let s=this.P_[e.toKey()];return s||(s=new Hv(t,this.referenceDelegate),this.P_[e.toKey()]=s),s}getGlobalsCache(){return this.A_}getTargetCache(){return this.V_}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.f_}runTransaction(e,t,s){Q("MemoryPersistence","Starting transaction:",e);const r=new jv(this.I_.next());return this.referenceDelegate.m_(),s(r).next(i=>this.referenceDelegate.p_(r).next(()=>i)).toPromise().then(i=>(r.raiseOnCommittedEvent(),i))}g_(e,t){return M.or(Object.values(this.P_).map(s=>()=>s.containsKey(e,t)))}}class jv extends MI{constructor(e){super(),this.currentSequenceNumber=e}}class ru{constructor(e){this.persistence=e,this.y_=new su,this.w_=null}static b_(e){return new ru(e)}get S_(){if(this.w_)return this.w_;throw X(60996)}addReference(e,t,s){return this.y_.addReference(s,t),this.S_.delete(s.toString()),M.resolve()}removeReference(e,t,s){return this.y_.removeReference(s,t),this.S_.add(s.toString()),M.resolve()}markPotentiallyOrphaned(e,t){return this.S_.add(t.toString()),M.resolve()}removeTarget(e,t){this.y_.e_(t.targetId).forEach(r=>this.S_.add(r.toString()));const s=this.persistence.getTargetCache();return s.getMatchingKeysForTargetId(e,t.targetId).next(r=>{r.forEach(i=>this.S_.add(i.toString()))}).next(()=>s.removeTargetData(e,t))}m_(){this.w_=new Set}p_(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return M.forEach(this.S_,s=>{const r=$.fromPath(s);return this.v_(e,r).next(i=>{i||t.removeEntry(r,ne.min())})}).next(()=>(this.w_=null,t.apply(e)))}updateLimboDocument(e,t){return this.v_(e,t).next(s=>{s?this.S_.delete(t.toString()):this.S_.add(t.toString())})}d_(e){return 0}v_(e,t){return M.or([()=>M.resolve(this.y_.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.g_(e,t)])}}class Aa{constructor(e,t){this.persistence=e,this.D_=new js(s=>Av(s.path),(s,r)=>s.isEqual(r)),this.garbageCollector=JI(this,t)}static b_(e,t){return new Aa(e,t)}m_(){}p_(e){return M.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}ir(e){const t=this.Cs(e);return this.persistence.getTargetCache().getTargetCount(e).next(s=>t.next(r=>s+r))}Cs(e){let t=0;return this.sr(e,s=>{t++}).next(()=>t)}sr(e,t){return M.forEach(this.D_,(s,r)=>this.Os(e,s,r).next(i=>i?M.resolve():t(r)))}removeTargets(e,t,s){return this.persistence.getTargetCache().removeTargets(e,t,s)}removeOrphanedDocuments(e,t){let s=0;const r=this.persistence.getRemoteDocumentCache(),i=r.newChangeBuffer();return r.c_(e,o=>this.Os(e,o,t).next(a=>{a||(s++,i.removeEntry(o,ne.min()))})).next(()=>i.apply(e)).next(()=>s)}markPotentiallyOrphaned(e,t){return this.D_.set(t,e.currentSequenceNumber),M.resolve()}removeTarget(e,t){const s=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,s)}addReference(e,t,s){return this.D_.set(s,e.currentSequenceNumber),M.resolve()}removeReference(e,t,s){return this.D_.set(s,e.currentSequenceNumber),M.resolve()}updateLimboDocument(e,t){return this.D_.set(t,e.currentSequenceNumber),M.resolve()}d_(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=ia(e.data.value)),t}Os(e,t,s){return M.or([()=>this.persistence.g_(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const r=this.D_.get(t);return M.resolve(r!==void 0&&r>s)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iu{constructor(e,t,s,r){this.targetId=e,this.fromCache=t,this.Vo=s,this.fo=r}static mo(e,t){let s=Be(),r=Be();for(const i of t.docChanges)switch(i.type){case 0:s=s.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new iu(e,t.fromCache,s,r)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kv(n,e){return $.comparator(n.key,e.key)}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qv{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zv{constructor(){this.po=!1,this.yo=!1,this.wo=100,this.bo=function(){return KE()?8:VI(JC())>0?6:4}()}initialize(e,t){this.So=e,this.indexManager=t,this.po=!0}getDocumentsMatchingQuery(e,t,s,r){const i={result:null};return this.vo(e,t).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.Do(e,t,r,s).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new Qv;return this.xo(e,t,o).next(a=>{if(i.result=a,this.yo)return this.Co(e,t,o,a.size)})}).next(()=>i.result)}Co(e,t,s,r){return Ye(t)?M.resolve():s.documentReadCount<this.wo?(ir()<=he.DEBUG&&Q("QueryEngine","SDK will not create cache indexes for query:",Ei(t),"since it only creates cache indexes for collection contains","more than or equal to",this.wo,"documents"),M.resolve()):(ir()<=he.DEBUG&&Q("QueryEngine","Query:",Ei(t),"scans",s.documentReadCount,"local documents and returns",r,"documents as results."),s.documentReadCount>this.bo*r?(ir()<=he.DEBUG&&Q("QueryEngine","The SDK decides to create cache indexes for query:",Ei(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,on(t))):M.resolve())}vo(e,t){if(Ye(t))return M.resolve(null);let s=t;if(yd(s))return M.resolve(null);let r=on(s);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(s.limit!==null&&i===1&&(s=wa(s,null,"F"),r=on(s)),this.indexManager.getDocumentsMatchingTarget(e,r).next(o=>{const a=Be(...o);return this.So.getDocuments(e,a).next(B=>this.indexManager.getMinOffset(e,r).next(c=>{const u=this.Fo(s,B);return this.Oo(s,u,a,c.readTime)?this.vo(e,wa(s,null,"F")):this.Mo(e,u,s,c)}))})))}Do(e,t,s,r){return(Ye(t)?function(o){for(const a of o.stages){if(a instanceof Us||a instanceof Md)return!1;if(a instanceof cl){if(a.condition instanceof Qg&&a.condition._expr.name==="exists"&&a.condition._expr.params[0]instanceof xr&&a.condition._expr.params[0].fieldName===nn)continue;return!1}}return!0}(t):yd(t))||r.isEqual(ne.min())?M.resolve(null):this.So.getDocuments(e,s).next(i=>{const o=this.Fo(t,i);return this.Oo(t,o,s,r)?M.resolve(null):(ir()<=he.DEBUG&&Q("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),Vd(t)),this.Mo(e,o,t,OT(r,Hi)).next(a=>a))})}Fo(e,t){let s,r;return Ye(e)?(s=new je(Kv),r=i=>dl(e,i)):(s=new je(Lc(e)),r=i=>sl(e,i)),t.forEach((i,o)=>{r(o)&&(s=s.add(o))}),s}Oo(e,t,s,r){if(Ye(e))return function(a){return a.stages.some(B=>B instanceof Us||B instanceof Md)}(e);if(e.limit===null)return!1;if(s.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}xo(e,t,s){return ir()<=he.DEBUG&&Q("QueryEngine","Using full collection scan to execute query:",Vd(t)),this.So.getDocumentsMatchingQuery(e,t,rs.min(),s)}Mo(e,t,s,r){return this.So.getDocumentsMatchingQuery(e,s,r).next(i=>(t.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ou="LocalStore",Wv=3e8;class $v{constructor(e,t,s,r){this.persistence=e,this.No=t,this.serializer=r,this.Lo=new Ge(ue),this.Bo=new js(i=>om(i),am),this.Uo=new Map,this.ko=e.getRemoteDocumentCache(),this.V_=e.getTargetCache(),this.f_=e.getBundleCache(),this.qo(s)}qo(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new kv(this.ko,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.ko.setIndexManager(this.indexManager),this.No.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.Lo))}}function Yv(n,e,t,s){return new $v(n,e,t,s)}async function um(n,e){const t=re(n);return await t.persistence.runTransaction("Handle user change","readonly",s=>{let r;return t.mutationQueue.getAllMutationBatches(s).next(i=>(r=i,t.qo(e),t.mutationQueue.getAllMutationBatches(s))).next(i=>{const o=[],a=[];let B=Be();for(const c of r){o.push(c.batchId);for(const u of c.mutations)B=B.add(u.key)}for(const c of i){a.push(c.batchId);for(const u of c.mutations)B=B.add(u.key)}return t.localDocuments.getDocuments(s,B).next(c=>({$o:c,removedBatchIds:o,addedBatchIds:a}))})})}function Xv(n,e){const t=re(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",s=>{const r=e.batch.keys(),i=t.ko.newChangeBuffer({trackRemovals:!0});return function(a,B,c,u){const f=c.batch,C=f.keys();let g=M.resolve();return C.forEach(E=>{g=g.next(()=>u.getEntry(B,E)).next(b=>{const F=c.docVersions.get(E);W(F!==null,48541),b.version.compareTo(F)<0&&(f.applyToRemoteDocument(b,c),b.isValidDocument()&&(b.setReadTime(c.commitVersion),u.addEntry(b)))})}),g.next(()=>a.mutationQueue.removeMutationBatch(B,f))}(t,s,e,i).next(()=>i.apply(s)).next(()=>t.mutationQueue.performConsistencyCheck(s)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(s,r,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(s,function(a){let B=Be();for(let c=0;c<a.mutationResults.length;++c)a.mutationResults[c].transformResults.length>0&&(B=B.add(a.batch.mutations[c].key));return B}(e))).next(()=>t.localDocuments.getDocuments(s,r))})}function hm(n){const e=re(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.V_.getLastRemoteSnapshotVersion(t))}function Zv(n,e){const t=re(n),s=e.snapshotVersion;let r=t.Lo;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=t.ko.newChangeBuffer({trackRemovals:!0});r=t.Lo;const a=[];e.targetChanges.forEach((u,f)=>{const C=r.get(f);if(!C)return;a.push(t.V_.removeMatchingKeys(i,u.removedDocuments,f).next(()=>t.V_.addMatchingKeys(i,u.addedDocuments,f)));let g=C.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(f)!==null?g=g.withResumeToken(Ke.EMPTY_BYTE_STRING,ne.min()).withLastLimboFreeSnapshotVersion(ne.min()):u.resumeToken.approximateByteSize()>0&&(g=g.withResumeToken(u.resumeToken,s)),r=r.insert(f,g),function(b,F,j){return b.resumeToken.approximateByteSize()===0||F.snapshotVersion.toMicroseconds()-b.snapshotVersion.toMicroseconds()>=Wv?!0:j.addedDocuments.size+j.modifiedDocuments.size+j.removedDocuments.size>0}(C,g,u)&&a.push(t.V_.updateTargetData(i,g))});let B=Tt(),c=Be();if(e.documentUpdates.forEach(u=>{e.resolvedLimboDocuments.has(u)&&a.push(t.persistence.referenceDelegate.updateLimboDocument(i,u))}),a.push(eR(i,o,e.documentUpdates).next(u=>{B=u.Ko,c=u.Qo})),!s.isEqual(ne.min())){const u=t.V_.getLastRemoteSnapshotVersion(i).next(f=>t.V_.setTargetsMetadata(i,i.currentSequenceNumber,s));a.push(u)}return M.waitFor(a).next(()=>o.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,B,c)).next(()=>B)}).then(i=>(t.Lo=r,i))}function eR(n,e,t){let s=Be(),r=Be();return t.forEach(i=>s=s.add(i)),e.getEntries(n,s).next(i=>{let o=Tt();return t.forEach((a,B)=>{const c=i.get(a);B.isFoundDocument()!==c.isFoundDocument()&&(r=r.add(a)),B.isNoDocument()&&B.version.isEqual(ne.min())?(e.removeEntry(a,B.readTime),o=o.insert(a,B)):!c.isValidDocument()||B.version.compareTo(c.version)>0||B.version.compareTo(c.version)===0&&c.hasPendingWrites?(e.addEntry(B),o=o.insert(a,B)):Q(ou,"Ignoring outdated watch update for ",a,". Current version:",c.version," Watch version:",B.version)}),{Ko:o,Qo:r}})}function tR(n,e){const t=re(n);return t.persistence.runTransaction("Get next mutation batch","readonly",s=>(e===void 0&&(e=bc),t.mutationQueue.getNextMutationBatchAfterBatchId(s,e)))}function nR(n,e){const t=re(n);return t.persistence.runTransaction("Allocate target","readwrite",s=>{let r;return t.V_.getTargetData(s,e).next(i=>i?(r=i,M.resolve(r)):t.V_.allocateTargetId(s).next(o=>(r=new _n(e,o,"TargetPurposeListen",s.currentSequenceNumber),t.V_.addTargetData(s,r).next(()=>r))))}).then(s=>{const r=t.Lo.get(s.targetId);return(r===null||s.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(t.Lo=t.Lo.insert(s.targetId,s),t.Bo.set(e,s.targetId)),s})}async function $B(n,e,t){const s=re(n),r=s.Lo.get(e),i=t?"readwrite":"readwrite-primary";try{t||await s.persistence.runTransaction("Release target",i,o=>s.persistence.referenceDelegate.removeTarget(o,r))}catch(o){if(!Or(o))throw o;Q(ou,`Failed to update sequence numbers for target ${e}: ${o}`)}s.Lo=s.Lo.remove(e),s.Bo.delete(r.target)}function Hd(n,e,t){const s=re(n);let r=ne.min(),i=Be();return s.persistence.runTransaction("Execute query","readwrite",o=>function(B,c,u){const f=re(B),C=f.Bo.get(u);return C!==void 0?M.resolve(f.Lo.get(C)):f.V_.getTargetData(c,u)}(s,o,Ye(e)?e:on(e)).next(a=>{if(a)return r=a.lastLimboFreeSnapshotVersion,s.V_.getMatchingKeysForTargetId(o,a.targetId).next(B=>{i=B})}).next(()=>s.No.getDocumentsMatchingQuery(o,e,t?r:ne.min(),t?i:Be())).next(a=>(sR(s,a),{documents:a,Wo:i})))}function sR(n,e){e.forEach((t,s)=>{const r=s.key.getCollectionGroup(),i=n.Uo.get(r)||ne.min();s.readTime.compareTo(i)>0&&n.Uo.set(r,s.readTime)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rR{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.Yo=0,this.Zo=null,this.Xo=!0}ea(){this.Yo===0&&(this.ta("Unknown"),this.Zo=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.Zo=null,this.na("Backend didn't respond within 10 seconds."),this.ta("Offline"),Promise.resolve())))}ra(e){this.state==="Online"?this.ta("Unknown"):(this.Yo++,this.Yo>=1&&(this.ia(),this.na(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ta("Offline")))}set(e){this.ia(),this.Yo=0,e==="Online"&&(this.Xo=!1),this.ta(e)}ta(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}na(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Xo?(In(t),this.Xo=!1):Q("OnlineStateTracker",t)}ia(){this.Zo!==null&&(this.Zo.cancel(),this.Zo=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cn="RemoteStore";class iR{constructor(e,t,s,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=s,this.remoteSyncer={},this.sa=[],this._a=new Map,this.oa=new Map,this.aa=new Map,this.ua=new ls(1e3),this.ca=new ls(1001),this.la=new Set,this.Ea=[],this.ha=i,this.ha.Qe(o=>{s.enqueueAndForget(async()=>{Qs(this)&&(Q(cn,"Restarting streams for network reachability change."),await async function(B){const c=re(B);c.la.add(4),await mo(c),c.Ta.set("Unknown"),c.la.delete(4),await Cl(c)}(this))})}),this.Ta=new rR(s,r)}}async function Cl(n){if(Qs(n))for(const e of n.Ea)await e(!0)}async function mo(n){for(const e of n.Ea)await e(!1)}function YB(n,e){return n.oa.get(e)||void 0}function fm(n,e){const t=re(n),s=YB(t,e.targetId);if(s!==void 0&&t._a.has(s))return;const r=function(a,B){const c=YB(a,B);c!==void 0&&a.aa.delete(c);const u=function(C,g){return g%2!=0?C.ca.next():C.ua.next()}(a,B);return a.oa.set(B,u),a.aa.set(u,B),u}(t,e.targetId);Q(cn,"remoteStoreListen mapping SDK target ID to remote",e.targetId,r);const i=new _n(e.target,r,e.purpose,e.sequenceNumber,e.snapshotVersion,e.lastLimboFreeSnapshotVersion,e.resumeToken);t._a.set(r,i),cu(t)?Bu(t):Gr(t).Yt()&&lu(t,i)}function au(n,e){const t=re(n),s=Gr(t),r=YB(t,e);Q(cn,"remoteStoreUnlisten removing mapping of SDK target ID to remote",e,r),t._a.delete(r),t.oa.delete(e),t.aa.delete(r),s.Yt()&&dm(t,r),t._a.size===0&&(s.Yt()?s.en():Qs(t)&&t.Ta.set("Unknown"))}function lu(n,e){if(n.Pa.J(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ne.min())>0){const t=n.aa.get(e.targetId);if(t===void 0)return void Q(cn,"SDK target ID not found for remote ID: "+e.targetId);const s=n.remoteSyncer.getRemoteKeysForTarget(t).size;e=e.withExpectedCount(s)}Gr(n).Pn(e)}function dm(n,e){n.Pa.J(e),Gr(n).In(e)}function Bu(n){n.Pa=new eI({getRemoteKeysForTarget:e=>{const t=n.aa.get(e);return t!==void 0?n.remoteSyncer.getRemoteKeysForTarget(t):Be()},ye:e=>n._a.get(e)||null,Ve:()=>n.datastore.serializer.databaseId}),Gr(n).start(),n.Ta.ea()}function cu(n){return Qs(n)&&!Gr(n).Jt()&&n._a.size>0}function Qs(n){return re(n).la.size===0}function Cm(n){n.Pa=void 0}async function oR(n){n.Ta.set("Online")}async function aR(n){n._a.forEach((e,t)=>{lu(n,e)})}async function lR(n,e){Cm(n),cu(n)?(n.Ta.ra(e),Bu(n)):n.Ta.set("Unknown")}async function BR(n,e,t){if(n.Ta.set("Online"),e instanceof mg&&e.state===2&&e.cause)try{await async function(r,i){const o=i.cause;for(const a of i.targetIds){if(r._a.has(a)){const B=r.aa.get(a);B!==void 0&&(await r.remoteSyncer.rejectListen(B,o),r.oa.delete(B),r.aa.delete(a)),r._a.delete(a)}r.Pa.removeTarget(a)}}(n,e)}catch(s){Q(cn,"Failed to remove targets %s: %s ",e.targetIds.join(","),s),await va(n,s)}else if(e instanceof aa?n.Pa._e(e):e instanceof gg?n.Pa.he(e):n.Pa.ue(e),!t.isEqual(ne.min()))try{const s=await hm(n.localStore);t.compareTo(s)>=0&&await function(i,o){const a=i.Pa.fe(o);a.targetChanges.forEach((c,u)=>{if(c.resumeToken.approximateByteSize()>0){const f=i._a.get(u);f&&i._a.set(u,f.withResumeToken(c.resumeToken,o))}}),a.targetMismatches.forEach((c,u)=>{const f=i._a.get(c);if(!f)return;i._a.set(c,f.withResumeToken(Ke.EMPTY_BYTE_STRING,f.snapshotVersion)),dm(i,c);const C=new _n(f.target,c,u,f.sequenceNumber);lu(i,C)});const B=function(u,f){const C=new Map;f.targetChanges.forEach((E,b)=>{const F=u.aa.get(b);F!==void 0&&C.set(F,E)});let g=new Ge(ue);return f.targetMismatches.forEach((E,b)=>{const F=u.aa.get(E);F!==void 0&&(g=g.insert(F,b))}),new ho(f.snapshotVersion,C,g,f.documentUpdates,f.augmentedDocumentUpdates,f.resolvedLimboDocuments)}(i,a);return i.remoteSyncer.applyRemoteEvent(B)}(n,t)}catch(s){Q(cn,"Failed to raise snapshot:",s),await va(n,s)}}async function va(n,e,t){if(!Or(e))throw e;n.la.add(1),await mo(n),n.Ta.set("Offline"),t||(t=()=>hm(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{Q(cn,"Retrying IndexedDB access"),await t(),n.la.delete(1),await Cl(n)})}function pm(n,e){return e().catch(t=>va(n,t,e))}async function pl(n){const e=re(n),t=Bs(e);let s=e.sa.length>0?e.sa[e.sa.length-1].batchId:bc;for(;cR(e);)try{const r=await tR(e.localStore,s);if(r===null){e.sa.length===0&&t.en();break}s=r.batchId,uR(e,r)}catch(r){await va(e,r)}gm(e)&&mm(e)}function cR(n){return Qs(n)&&n.sa.length<10}function uR(n,e){n.sa.push(e);const t=Bs(n);t.Yt()&&t.Rn&&t.An(e.mutations)}function gm(n){return Qs(n)&&!Bs(n).Jt()&&n.sa.length>0}function mm(n){Bs(n).start()}async function hR(n){Bs(n).fn()}async function fR(n){const e=Bs(n);for(const t of n.sa)e.An(t.mutations)}async function dR(n,e,t){const s=n.sa.shift(),r=nu.from(s,e,t);await pm(n,()=>n.remoteSyncer.applySuccessfulWrite(r)),await pl(n)}async function CR(n,e){e&&Bs(n).Rn&&await async function(s,r){if(function(o){return hg(o)&&o!==O.ABORTED}(r.code)){const i=s.sa.shift();Bs(s).Xt(),await pm(s,()=>s.remoteSyncer.rejectFailedWrite(i.batchId,r)),await pl(s)}}(n,e),gm(n)&&mm(n)}async function Ud(n,e){const t=re(n);t.asyncQueue.verifyOperationInProgress(),Q(cn,"RemoteStore received new credentials");const s=Qs(t);t.la.add(3),await mo(t),s&&t.Ta.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.la.delete(3),await Cl(t)}async function pR(n,e){const t=re(n);e?(t.la.delete(2),await Cl(t)):e||(t.la.add(2),await mo(t),t.Ta.set("Unknown"))}function Gr(n){return n.Ia||(n.Ia=function(t,s,r){const i=re(t);return i.pn(),new bI(s,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{ct:oR.bind(null,n),Et:aR.bind(null,n),Tt:lR.bind(null,n),Tn:BR.bind(null,n)}),n.Ea.push(async e=>{e?(n.Ia.Xt(),cu(n)?Bu(n):n.Ta.set("Unknown")):(await n.Ia.stop(),Cm(n))})),n.Ia}function Bs(n){return n.Ra||(n.Ra=function(t,s,r){const i=re(t);return i.pn(),new NI(s,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{ct:()=>Promise.resolve(),Et:hR.bind(null,n),Tt:CR.bind(null,n),Vn:fR.bind(null,n),dn:dR.bind(null,n)}),n.Ea.push(async e=>{e?(n.Ra.Xt(),await pl(n)):(await n.Ra.stop(),n.sa.length>0&&(Q(cn,`Stopping write stream with ${n.sa.length} pending writes`),n.sa=[]))})),n.Ra}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uu{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Aa(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Aa(this.observer.error,e):In("Uncaught Error in snapshot listener:",e.toString()))}Va(){this.muted=!0}Aa(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hu{constructor(e,t,s,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=s,this.op=r,this.removalCallback=i,this.deferred=new Qt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,s,r,i){const o=Date.now()+s,a=new hu(e,t,o,r,i);return a.start(s),a}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new G(O.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function fu(n,e){if(In("AsyncQueue",`${e}: ${n}`),Or(n))return new G(O.UNAVAILABLE,`${e}: ${n}`);throw n}class qd{constructor(){this.activeTargetIds=YT()}Ba(e){this.activeTargetIds=this.activeTargetIds.add(e)}Ua(e){this.activeTargetIds=this.activeTargetIds.delete(e)}La(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class gR{constructor(){this.fu=new qd,this.mu={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,s){}addLocalQueryTarget(e,t=!0){return t&&this.fu.Ba(e),this.mu[e]||"not-current"}updateQueryState(e,t,s){this.mu[e]=t}removeLocalQueryTarget(e){this.fu.Ua(e)}isLocalQueryTarget(e){return this.fu.activeTargetIds.has(e)}clearQueryState(e){delete this.mu[e]}getAllActiveQueryTargets(){return this.fu.activeTargetIds}isActiveQueryTarget(e){return this.fu.activeTargetIds.has(e)}start(){return this.fu=new qd,Promise.resolve()}handleUserChange(e,t,s){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}function gB(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Os{static emptySet(e){return new Os(e.comparator)}constructor(e){this.comparator=e?(t,s)=>e(t,s)||$.comparator(t.key,s.key):(t,s)=>$.comparator(t.key,s.key),this.keyedMap=ar(),this.sortedSet=new Ge(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,s)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Os)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),s=e.sortedSet.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=s.getNext().key;if(!r.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const s=new Os;return s.comparator=this.comparator,s.keyedMap=e,s.sortedSet=t,s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jd{constructor(){this.pu=new Ge($.comparator)}track(e){const t=e.doc.key,s=this.pu.get(t);s?e.type!==0&&s.type===3?this.pu=this.pu.insert(t,e):e.type===3&&s.type!==1?this.pu=this.pu.insert(t,{type:s.type,doc:e.doc}):e.type===2&&s.type===2?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):e.type===2&&s.type===0?this.pu=this.pu.insert(t,{type:0,doc:e.doc}):e.type===1&&s.type===0?this.pu=this.pu.remove(t):e.type===1&&s.type===2?this.pu=this.pu.insert(t,{type:1,doc:s.doc}):e.type===0&&s.type===1?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):X(63341,{we:e,gu:s}):this.pu=this.pu.insert(t,e)}yu(){const e=[];return this.pu.inorderTraversal((t,s)=>{e.push(s)}),e}}class wr{constructor(e,t,s,r,i,o,a,B,c){this.query=e,this.docs=t,this.oldDocs=s,this.docChanges=r,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=B,this.hasCachedResults=c}static fromInitialDocuments(e,t,s,r,i){const o=[];return t.forEach(a=>{o.push({type:0,doc:a})}),new wr(e,t,Os.emptySet(t),o,s,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&fl(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,s=e.docChanges;if(t.length!==s.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==s[r].type||!t[r].doc.isEqual(s[r].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mR{constructor(){this.wu=void 0,this.bu=[]}Su(){return this.bu.some(e=>e.vu())}}class _R{constructor(){this.queries=jd(),this.onlineState="Unknown",this.Du=new Set}terminate(){(function(t,s){const r=re(t),i=r.queries;r.queries=jd(),i.forEach((o,a)=>{for(const B of a.bu)B.onError(s)})})(this,new G(O.ABORTED,"Firestore shutting down"))}}function jd(){return new js(n=>im(n),fl)}async function du(n,e){const t=re(n);let s=3;const r=e.query;let i=t.queries.get(r);i?!i.Su()&&e.vu()&&(s=2):(i=new mR,s=e.vu()?0:1);try{switch(s){case 0:i.wu=await t.onListen(r,!0);break;case 1:i.wu=await t.onListen(r,!1);break;case 2:await t.onFirstRemoteStoreListen(r)}}catch(o){const a=fu(o,`Initialization of query '${Ye(e.query)?Dn(e.query):Ei(e.query)}' failed`);return void e.onError(a)}t.queries.set(r,i),i.bu.push(e),e.xu(t.onlineState),i.wu&&e.Cu(i.wu)&&pu(t)}async function Cu(n,e){const t=re(n),s=e.query;let r=3;const i=t.queries.get(s);if(i){const o=i.bu.indexOf(e);o>=0&&(i.bu.splice(o,1),i.bu.length===0?r=e.vu()?0:1:!i.Su()&&e.vu()&&(r=2))}switch(r){case 0:return t.queries.delete(s),t.onUnlisten(s,!0);case 1:return t.queries.delete(s),t.onUnlisten(s,!1);case 2:return t.onLastRemoteStoreUnlisten(s);default:return}}function ER(n,e){const t=re(n);let s=!1;for(const r of e){const i=r.query,o=t.queries.get(i);if(o){for(const a of o.bu)a.Cu(r)&&(s=!0);o.wu=r}}s&&pu(t)}function DR(n,e,t){const s=re(n),r=s.queries.get(e);if(r)for(const i of r.bu)i.onError(t);s.queries.delete(e)}function pu(n){n.Du.forEach(e=>{e.next()})}var XB;(function(n){n.Default="default",n.Cache="cache"})(XB||(XB={}));class gu{constructor(e,t,s){this.query=e,this.Fu=t,this.Ou=!1,this.Mu=null,this.onlineState="Unknown",this.options=s||{}}Cu(e){if(!this.options.includeMetadataChanges){const s=[];for(const r of e.docChanges)r.type!==3&&s.push(r);e=new wr(e.query,e.docs,e.oldDocs,s,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Ou?this.Nu(e)&&(this.Fu.next(e),t=!0):this.Lu(e,this.onlineState)&&(this.Bu(e),t=!0),this.Mu=e,t}onError(e){this.Fu.error(e)}xu(e){this.onlineState=e;let t=!1;return this.Mu&&!this.Ou&&this.Lu(this.Mu,e)&&(this.Bu(this.Mu),t=!0),t}Lu(e,t){if(!e.fromCache||!this.vu())return!0;const s=t!=="Offline";return(!this.options.waitForSyncWhenOnline||!s)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Nu(e){if(e.docChanges.length>0)return!0;const t=this.Mu&&this.Mu.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}Bu(e){e=wr.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Ou=!0,this.Fu.next(e)}vu(){return this.options.source!==XB.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _m{constructor(e){this.key=e}}class Em{constructor(e){this.key=e}}class yR{constructor(e,t){this.query=e,this.zu=t,this.ju=null,this.hasCachedResults=!1,this.current=!1,this.Hu=Be(),this.mutatedKeys=Be(),this.Ju=Ye(e)?WB(e):Lc(e),this.Yu=new Os(this.Ju)}get Zu(){return this.zu}Xu(e,t){const s=t?t.ec:new Jd,r=t?t.Yu:this.Yu;let i=t?t.mutatedKeys:this.mutatedKeys,o=r,a=!1;const[B,c]=this.tc(this.query,r);e.inorderTraversal((f,C)=>{const g=r.get(f),E=Fv(this.query,C)?C:null,b=!!g&&this.mutatedKeys.has(g.key),F=!!E&&(E.hasLocalMutations||this.mutatedKeys.has(E.key)&&E.hasCommittedMutations);let j=!1;g&&E?g.data.isEqual(E.data)?b!==F&&(s.track({type:3,doc:E}),j=!0):this.nc(g,E)||(s.track({type:2,doc:E}),j=!0,(B&&this.Ju(E,B)>0||c&&this.Ju(E,c)<0)&&(a=!0)):!g&&E?(s.track({type:0,doc:E}),j=!0):g&&!E&&(s.track({type:1,doc:g}),j=!0,(B||c)&&(a=!0)),j&&(E?(o=o.add(E),i=F?i.add(f):i.delete(f)):(o=o.delete(f),i=i.delete(f)))});const u=this.rc(this.query);if(u)if(Ye(this.query)){const f=[];o.forEach(E=>f.push(E));const C=Bm(this.query,f);let g=new Os(WB(this.query));for(const E of C)g=g.add(E);o.forEach(E=>{g.has(E.key)||(i=i.delete(E.key),s.track({type:1,doc:E}))}),o=g}else{const f=this.sc(this.query);for(;o.size>u;){const C=f==="F"?o.last():o.first();o=o.delete(C.key),i=i.delete(C.key),s.track({type:1,doc:C})}}return{Yu:o,ec:s,Oo:a,mutatedKeys:i}}rc(e){var t;return Ye(e)?(t=pB(e))==null?void 0:t.limit:e.limit||void 0}sc(e){if(Ye(e)){const t=pB(e);return t&&t.limit<0?"L":"F"}return e.limitType}tc(e,t){var s;if(Ye(e)){const r=(s=pB(e))==null?void 0:s.limit;return[t.size===r?t.last():null,null]}return[e.limitType==="F"&&t.size===this.rc(this.query)?t.last():null,e.limitType==="L"&&t.size===this.rc(this.query)?t.first():null]}nc(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,s,r){const i=this.Yu;this.Yu=e.Yu,this.mutatedKeys=e.mutatedKeys;const o=e.ec.yu();o.sort((u,f)=>function(g,E){const b=F=>{switch(F){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return X(20277,{we:F})}};return b(g)-b(E)}(u.type,f.type)||this.Ju(u.doc,f.doc)),this._c(s),r=r??!1;const a=t&&!r?this.oc():[],B=this.Hu.size===0&&this.current&&!r?1:0,c=B!==this.ju;return this.ju=B,o.length!==0||c?{snapshot:new wr(this.query,e.Yu,i,o,e.mutatedKeys,B===0,c,!1,!!s&&s.resumeToken.approximateByteSize()>0),ac:a}:{ac:a}}xu(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Yu:this.Yu,ec:new Jd,mutatedKeys:this.mutatedKeys,Oo:!1},!1)):{ac:[]}}uc(e){return!this.zu.has(e)&&!!this.Yu.has(e)&&!this.Yu.get(e).hasLocalMutations}_c(e){e&&(e.addedDocuments.forEach(t=>this.zu=this.zu.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.zu=this.zu.delete(t)),this.current=e.current)}oc(){if(!this.current)return[];const e=this.Hu;this.Hu=Be(),this.Yu.forEach(s=>{this.uc(s.key)&&(this.Hu=this.Hu.add(s.key))});const t=[];return e.forEach(s=>{this.Hu.has(s)||t.push(new Em(s))}),this.Hu.forEach(s=>{e.has(s)||t.push(new _m(s))}),t}cc(e){this.zu=e.Wo,this.Hu=Be();const t=this.Xu(e.documents);return this.applyChanges(t,!0)}lc(){return wr.fromInitialDocuments(this.query,this.Yu,this.mutatedKeys,this.ju===0,this.hasCachedResults)}}const mu="SyncEngine";class wR{constructor(e,t,s){this.query=e,this.targetId=t,this.view=s}}class TR{constructor(e){this.key=e,this.Ec=!1}}class IR{constructor(e,t,s,r,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=s,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.hc={},this.Tc=new js(a=>im(a),fl),this.Pc=new Map,this.Ic=new Set,this.Rc=new Ge($.comparator),this.Ac=new Map,this.Vc=new su,this.dc={},this.fc=new Map,this.mc=ls.bs(),this.onlineState="Unknown",this.gc=void 0}get isPrimaryClient(){return this.gc===!0}}async function AR(n,e,t=!0){const s=Am(n);let r;const i=s.Tc.get(e);return i?(s.sharedClientState.addLocalQueryTarget(i.targetId),r=i.view.lc()):r=await Dm(s,e,t,!0),r}async function vR(n,e){const t=Am(n);await Dm(t,e,!0,!1)}async function Dm(n,e,t,s){const r=await nR(n.localStore,Ye(e)?e:on(e)),i=r.targetId,o=n.sharedClientState.addLocalQueryTarget(i,t);let a;return s&&(a=await RR(n,e,i,o==="current",r.resumeToken)),n.isPrimaryClient&&t&&fm(n.remoteStore,r),a}async function RR(n,e,t,s,r){n.yc=(f,C,g)=>async function(b,F,j,te){let ie=F.view.Xu(j);ie.Oo&&(ie=await Hd(b.localStore,F.query,!1).then(({documents:v})=>F.view.Xu(v,ie)));const me=te&&te.targetChanges.get(F.targetId),Me=te&&te.targetMismatches.get(F.targetId)!=null,Le=F.view.applyChanges(ie,b.isPrimaryClient,me,Me);return Qd(b,F.targetId,Le.ac),Le.snapshot}(n,f,C,g);const i=await Hd(n.localStore,e,!0),o=new yR(e,i.Wo),a=o.Xu(i.documents),B=fo.createSynthesizedTargetChangeForCurrentChange(t,s&&n.onlineState!=="Offline",r),c=o.applyChanges(a,n.isPrimaryClient,B);Qd(n,t,c.ac);const u=new wR(e,t,o);return n.Tc.set(e,u),n.Pc.has(t)?n.Pc.get(t).push(e):n.Pc.set(t,[e]),c.snapshot}async function SR(n,e,t){const s=re(n),r=s.Tc.get(e),i=s.Pc.get(r.targetId);if(i.length>1)return s.Pc.set(r.targetId,i.filter(o=>!fl(o,e))),void s.Tc.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(r.targetId),s.sharedClientState.isActiveQueryTarget(r.targetId)||await $B(s.localStore,r.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(r.targetId),t&&au(s.remoteStore,r.targetId),ZB(s,r.targetId)}).catch(Fr)):(ZB(s,r.targetId),await $B(s.localStore,r.targetId,!0))}async function bR(n,e){const t=re(n),s=t.Tc.get(e),r=t.Pc.get(s.targetId);t.isPrimaryClient&&r.length===1&&(t.sharedClientState.removeLocalQueryTarget(s.targetId),au(t.remoteStore,s.targetId))}async function NR(n,e,t){const s=MR(n);try{const r=await function(o,a){const B=re(o),c=Ee.now(),u=a.reduce((g,E)=>g.add(E.key),Be());let f,C;return B.persistence.runTransaction("Locally write mutations","readwrite",g=>{let E=Tt(),b=Be();return B.ko.getEntries(g,u).next(F=>{E=F,E.forEach((j,te)=>{te.isValidDocument()||(b=b.add(j))})}).next(()=>B.localDocuments.getOverlayedDocuments(g,E)).next(F=>{f=F;const j=[];for(const te of a){const ie=TT(te,f.get(te.key).overlayedDocument);ie!=null&&j.push(new ps(te.key,ie,zp(ie.value.mapValue),ot.exists(!0)))}return B.mutationQueue.addMutationBatch(g,c,j,a)}).next(F=>{C=F;const j=F.applyToLocalDocumentSet(f,b);return B.documentOverlayCache.saveOverlays(g,F.batchId,j)})}).then(()=>({batchId:C.batchId,changes:Cg(f)}))}(s.localStore,e);s.sharedClientState.addPendingMutation(r.batchId),function(o,a,B){let c=o.dc[o.currentUser.toKey()];c||(c=new Ge(ue)),c=c.insert(a,B),o.dc[o.currentUser.toKey()]=c}(s,r.batchId,t),await _o(s,r.changes),await pl(s.remoteStore)}catch(r){const i=fu(r,"Failed to persist write");t.reject(i)}}async function ym(n,e){const t=re(n);try{const s=await Zv(t.localStore,e);e.targetChanges.forEach((r,i)=>{const o=t.Ac.get(i);o&&(W(r.addedDocuments.size+r.modifiedDocuments.size+r.removedDocuments.size<=1,22616),r.addedDocuments.size>0?o.Ec=!0:r.modifiedDocuments.size>0?W(o.Ec,14607):r.removedDocuments.size>0&&(W(o.Ec,42227),o.Ec=!1))}),await _o(t,s,e)}catch(s){await Fr(s)}}function Kd(n,e,t){const s=re(n);if(s.isPrimaryClient&&t===0||!s.isPrimaryClient&&t===1){const r=[];s.Tc.forEach((i,o)=>{const a=o.view.xu(e);a.snapshot&&r.push(a.snapshot)}),function(o,a){const B=re(o);B.onlineState=a;let c=!1;B.queries.forEach((u,f)=>{for(const C of f.bu)C.xu(a)&&(c=!0)}),c&&pu(B)}(s.eventManager,e),r.length&&s.hc.Tn(r),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function PR(n,e,t){const s=re(n);s.sharedClientState.updateQueryState(e,"rejected",t);const r=s.Ac.get(e),i=r&&r.key;if(i){let o=new Ge($.comparator);o=o.insert(i,nt.newNoDocument(i,ne.min()));const a=Be().add(i),B=new ho(ne.min(),new Map,new Ge(ue),o,Tt(),a);await ym(s,B),s.Rc=s.Rc.remove(i),s.Ac.delete(e),_u(s)}else await $B(s.localStore,e,!1).then(()=>ZB(s,e,t)).catch(Fr)}async function FR(n,e){const t=re(n),s=e.batch.batchId;try{const r=await Xv(t.localStore,e);Tm(t,s,null),wm(t,s),t.sharedClientState.updateMutationState(s,"acknowledged"),await _o(t,r)}catch(r){await Fr(r)}}async function OR(n,e,t){const s=re(n);try{const r=await function(o,a){const B=re(o);return B.persistence.runTransaction("Reject batch","readwrite-primary",c=>{let u;return B.mutationQueue.lookupMutationBatch(c,a).next(f=>(W(f!==null,37113),u=f.keys(),B.mutationQueue.removeMutationBatch(c,f))).next(()=>B.mutationQueue.performConsistencyCheck(c)).next(()=>B.documentOverlayCache.removeOverlaysForBatchId(c,u,a)).next(()=>B.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(c,u)).next(()=>B.localDocuments.getDocuments(c,u))})}(s.localStore,e);Tm(s,e,t),wm(s,e),s.sharedClientState.updateMutationState(e,"rejected",t),await _o(s,r)}catch(r){await Fr(r)}}function wm(n,e){(n.fc.get(e)||[]).forEach(t=>{t.resolve()}),n.fc.delete(e)}function Tm(n,e,t){const s=re(n);let r=s.dc[s.currentUser.toKey()];if(r){const i=r.get(e);i&&(t?i.reject(t):i.resolve(),r=r.remove(e)),s.dc[s.currentUser.toKey()]=r}}function ZB(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const s of n.Pc.get(e))n.Tc.delete(s),t&&n.hc.wc(s,t);n.Pc.delete(e),n.isPrimaryClient&&n.Vc.e_(e).forEach(s=>{n.Vc.containsKey(s)||Im(n,s)})}function Im(n,e){n.Ic.delete(e.path.canonicalString());const t=n.Rc.get(e);t!==null&&(au(n.remoteStore,t),n.Rc=n.Rc.remove(e),n.Ac.delete(t),_u(n))}function Qd(n,e,t){for(const s of t)s instanceof _m?(n.Vc.addReference(s.key,e),LR(n,s)):s instanceof Em?(Q(mu,"Document no longer in limbo: "+s.key),n.Vc.removeReference(s.key,e),n.Vc.containsKey(s.key)||Im(n,s.key)):X(19791,{bc:s})}function LR(n,e){const t=e.key,s=t.path.canonicalString();n.Rc.get(t)||n.Ic.has(s)||(Q(mu,"New document in limbo: "+t),n.Ic.add(s),_u(n))}function _u(n){for(;n.Ic.size>0&&n.Rc.size<n.maxConcurrentLimboResolutions;){const e=n.Ic.values().next().value;n.Ic.delete(e);const t=new $(pe.fromString(e)),s=n.mc.next();n.Ac.set(s,new TR(t)),n.Rc=n.Rc.insert(t,s),fm(n.remoteStore,new _n(on(nl(t.path)),s,"TargetPurposeLimboResolution",il.wn))}}async function _o(n,e,t){const s=re(n),r=[],i=[],o=[];s.Tc.isEmpty()||(s.Tc.forEach((a,B)=>{o.push(s.yc(B,e,t).then(c=>{var u;if((c||t)&&s.isPrimaryClient){const f=c?!c.fromCache:(u=t==null?void 0:t.targetChanges.get(B.targetId))==null?void 0:u.current;s.sharedClientState.updateQueryState(B.targetId,f?"current":"not-current")}if(c){r.push(c);const f=iu.mo(B.targetId,c);i.push(f)}}))}),await Promise.all(o),s.hc.Tn(r),await async function(B,c){const u=re(B);try{await u.persistence.runTransaction("notifyLocalViewChanges","readwrite",f=>M.forEach(c,C=>M.forEach(C.Vo,g=>u.persistence.referenceDelegate.addReference(f,C.targetId,g)).next(()=>M.forEach(C.fo,g=>u.persistence.referenceDelegate.removeReference(f,C.targetId,g)))))}catch(f){if(!Or(f))throw f;Q(ou,"Failed to update sequence numbers: "+f)}for(const f of c){const C=f.targetId;if(!f.fromCache){const g=u.Lo.get(C),E=g.snapshotVersion,b=g.withLastLimboFreeSnapshotVersion(E);u.Lo=u.Lo.insert(C,b)}}}(s.localStore,i))}async function xR(n,e){const t=re(n);if(!t.currentUser.isEqual(e)){Q(mu,"User change. New user:",e.toKey());const s=await um(t.localStore,e);t.currentUser=e,function(i,o){i.fc.forEach(a=>{a.forEach(B=>{B.reject(new G(O.CANCELLED,o))})}),i.fc.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,s.removedBatchIds,s.addedBatchIds),await _o(t,s.$o)}}function kR(n,e){const t=re(n),s=t.Ac.get(e);if(s&&s.Ec)return Be().add(s.key);{let r=Be();const i=t.Pc.get(e);if(!i)return r;for(const o of i??[]){const a=t.Tc.get(o);r=r.unionWith(a.view.Zu)}return r}}function Am(n){const e=re(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=ym.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=kR.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=PR.bind(null,e),e.hc.Tn=ER.bind(null,e.eventManager),e.hc.wc=DR.bind(null,e.eventManager),e}function MR(n){const e=re(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=FR.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=OR.bind(null,e),e}class Ra{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=rl(e.databaseInfo.databaseId),this.sharedClientState=this.vc(e),this.persistence=this.Dc(e),await this.persistence.start(),this.localStore=this.xc(e),this.gcScheduler=this.Cc(e,this.localStore),this.indexBackfillerScheduler=this.Fc(e,this.localStore)}Cc(e,t){return null}Fc(e,t){return null}xc(e){return Yv(this.persistence,new zv,e.initialUser,this.serializer)}Dc(e){return new cm(ru.b_,this.serializer)}vc(e){return new gR}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Ra.provider={build:()=>new Ra};class VR extends Ra{constructor(e){super(),this.cacheSizeBytes=e}Cc(e,t){W(this.persistence.referenceDelegate instanceof Aa,46915);const s=this.persistence.referenceDelegate.garbageCollector;return new UI(s,e.asyncQueue,t)}Dc(e){const t=this.cacheSizeBytes!==void 0?wt.withCacheSize(this.cacheSizeBytes):wt.DEFAULT;return new cm(s=>Aa.b_(s,t),this.serializer)}}class ec{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=s=>Kd(this.syncEngine,s,1),this.remoteStore.remoteSyncer.handleCredentialChange=xR.bind(null,this.syncEngine),await pR(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new _R}()}createDatastore(e){const t=rl(e.databaseInfo.databaseId),s=SI(e.databaseInfo);return OI(e.authCredentials,e.appCheckCredentials,s,t)}createRemoteStore(e){return function(s,r,i,o,a){return new iR(s,r,i,o,a)}(this.localStore,this.datastore,e.asyncQueue,t=>Kd(this.syncEngine,t,0),function(){return bd.Ye()?new bd:new II}())}createSyncEngine(e,t){return function(r,i,o,a,B,c,u){const f=new IR(r,i,o,a,B,c);return u&&(f.gc=!0),f}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(r){const i=re(r);Q(cn,"RemoteStore shutting down."),i.la.add(5),await mo(i),i.ha.shutdown(),i.Ta.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}ec.provider={build:()=>new ec};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let GR=class{constructor(e){this.datastore=e,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastTransactionError=null,this.writtenDocs=new Set}async lookup(e){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw this.lastTransactionError=new G(O.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes."),this.lastTransactionError;const t=await async function(r,i){const o=re(r),a={documents:i.map(f=>Ui(o.serializer,f))},B=await o._t("BatchGetDocuments",o.serializer.databaseId,pe.emptyPath(),a,i.length),c=new Map;B.forEach(f=>{const C=oI(o.serializer,f);c.set(C.key.toString(),C)});const u=[];return i.forEach(f=>{const C=c.get(f.toString());W(!!C,55234,{key:f}),u.push(C)}),u}(this.datastore,e);return t.forEach(s=>this.recordVersion(s)),t}set(e,t){this.write(t.toMutation(e,this.precondition(e))),this.writtenDocs.add(e.toString())}update(e,t){try{this.write(t.toMutation(e,this.preconditionForUpdate(e)))}catch(s){this.lastTransactionError=s}this.writtenDocs.add(e.toString())}delete(e){this.write(new tl(e,this.precondition(e))),this.writtenDocs.add(e.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastTransactionError)throw this.lastTransactionError;const e=this.readVersions;this.mutations.forEach(t=>{e.delete(t.key.toString())}),e.forEach((t,s)=>{const r=$.fromPath(s);this.mutations.push(new tg(r,this.precondition(r)))}),await async function(s,r){const i=re(s),o={writes:r.map(a=>wg(i.serializer,a))};await i.nt("Commit",i.serializer.databaseId,pe.emptyPath(),o)}(this.datastore,this.mutations),this.committed=!0}recordVersion(e){let t;if(e.isFoundDocument())t=e.version;else{if(!e.isNoDocument())throw X(50498,{Mc:e.constructor.name});t=ne.min()}const s=this.readVersions.get(e.key.toString());if(s){if(!t.isEqual(s))throw new G(O.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(e.key.toString(),t)}precondition(e){const t=this.readVersions.get(e.toString());return!this.writtenDocs.has(e.toString())&&t?t.isEqual(ne.min())?ot.exists(!1):ot.updateTime(t):ot.none()}preconditionForUpdate(e){const t=this.readVersions.get(e.toString());if(!this.writtenDocs.has(e.toString())&&t){if(t.isEqual(ne.min()))throw new G(O.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return ot.updateTime(t)}return ot.exists(!0)}write(e){this.ensureCommitNotCalled(),this.mutations.push(e)}ensureCommitNotCalled(){}};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HR{constructor(e,t,s,r,i){this.asyncQueue=e,this.datastore=t,this.options=s,this.updateFunction=r,this.deferred=i,this.Nc=s.maxAttempts,this.Ht=new Vc(this.asyncQueue,"transaction_retry")}Lc(){this.Nc-=1,this.Bc()}Bc(){this.Ht.kt(async()=>{const e=new GR(this.datastore),t=this.Uc(e);t&&t.then(s=>{this.asyncQueue.enqueueAndForget(()=>e.commit().then(()=>{this.deferred.resolve(s)}).catch(r=>{this.kc(r)}))}).catch(s=>{this.kc(s)})})}Uc(e){try{const t=this.updateFunction(e);return!co(t)&&t.catch&&t.then?t:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(t){return this.deferred.reject(t),null}}kc(e){this.Nc>0&&this.qc(e)?(this.Nc-=1,this.asyncQueue.enqueueAndForget(()=>(this.Bc(),Promise.resolve()))):this.deferred.reject(e)}qc(e){if((e==null?void 0:e.name)==="FirebaseError"){const t=e.code;return t==="aborted"||t==="failed-precondition"||t==="already-exists"||!hg(t)}return!1}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cs="FirestoreClient";class UR{constructor(e,t,s,r,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=s,this._databaseInfo=r,this.user=ut.UNAUTHENTICATED,this.clientId=Sc.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(s,async o=>{Q(cs,"Received user=",o.uid),await this.authCredentialListener(o),this.user=o}),this.appCheckCredentials.start(s,o=>(Q(cs,"Received new app check token=",o),this.appCheckCredentialListener(o,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new Qt;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const s=fu(t,"Failed to shutdown persistence");e.reject(s)}}),e.promise}}async function mB(n,e){n.asyncQueue.verifyOperationInProgress(),Q(cs,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let s=t.initialUser;n.setCredentialChangeListener(async r=>{s.isEqual(r)||(await um(e.localStore,r),s=r)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function zd(n,e){n.asyncQueue.verifyOperationInProgress();const t=await qR(n);Q(cs,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(s=>Ud(e.remoteStore,s)),n.setAppCheckTokenChangeListener((s,r)=>Ud(e.remoteStore,r)),n._onlineComponents=e}async function qR(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){Q(cs,"Using user provided OfflineComponentProvider");try{await mB(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(r){return r.name==="FirebaseError"?r.code===O.FAILED_PRECONDITION||r.code===O.UNIMPLEMENTED:!(typeof DOMException<"u"&&r instanceof DOMException)||r.code===22||r.code===20||r.code===11}(t))throw t;Wt("Error using user provided cache. Falling back to memory cache: "+t),await mB(n,new Ra)}}else Q(cs,"Using default OfflineComponentProvider"),await mB(n,new VR(void 0));return n._offlineComponents}async function Eu(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(Q(cs,"Using user provided OnlineComponentProvider"),await zd(n,n._uninitializedComponentsProvider._online)):(Q(cs,"Using default OnlineComponentProvider"),await zd(n,new ec))),n._onlineComponents}function JR(n){return Eu(n).then(e=>e.syncEngine)}function vm(n){return Eu(n).then(e=>e.datastore)}async function Sa(n){const e=await Eu(n),t=e.eventManager;return t.onListen=AR.bind(null,e.syncEngine),t.onUnlisten=SR.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=vR.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=bR.bind(null,e.syncEngine),t}function jR(n,e,t,s){const r=new uu(s),i=new gu(e,r,t);return n.asyncQueue.enqueueAndForget(async()=>du(await Sa(n),i)),()=>{r.Va(),n.asyncQueue.enqueueAndForget(async()=>Cu(await Sa(n),i))}}function KR(n,e,t={}){const s=new Qt;return n.asyncQueue.enqueueAndForget(async()=>function(i,o,a,B,c){const u=new uu({next:C=>{u.Va(),o.enqueueAndForget(()=>Cu(i,f));const g=C.docs.has(a);!g&&C.fromCache?c.reject(new G(O.UNAVAILABLE,"Failed to get document because the client is offline.")):g&&C.fromCache&&B&&B.source==="server"?c.reject(new G(O.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):c.resolve(C)},error:C=>c.reject(C)}),f=new gu(nl(a.path),u,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return du(i,f)}(await Sa(n),n.asyncQueue,e,t,s)),s.promise}function QR(n,e,t={}){const s=new Qt;return n.asyncQueue.enqueueAndForget(async()=>function(i,o,a,B,c){const u=new uu({next:C=>{u.Va(),o.enqueueAndForget(()=>Cu(i,f)),C.fromCache&&B.source==="server"?c.reject(new G(O.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):c.resolve(C)},error:C=>c.reject(C)}),f=new gu(a instanceof Ti?Tv(a):a,u,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return du(i,f)}(await Sa(n),n.asyncQueue,e,t,s)),s.promise}function zR(n,e,t){const s=new Qt;return n.asyncQueue.enqueueAndForget(async()=>{try{const r=await vm(n);s.resolve(async function(o,a,B){var b;const c=re(o),{request:u,ve:f,parent:C}=cI(c.serializer,GT(a),B);c.connection.Ze||delete u.parent;const g=(await c._t("RunAggregationQuery",c.serializer.databaseId,C,u,1)).filter(F=>!!F.result);W(g.length===1,64727);const E=(b=g[0].result)==null?void 0:b.aggregateFields;return Object.keys(E).reduce((F,j)=>(F[f[j]]=E[j],F),{})}(r,e,t))}catch(r){s.reject(r)}}),s.promise}function WR(n,e){const t=new Qt;return n.asyncQueue.enqueueAndForget(async()=>NR(await JR(n),e,t)),t.promise}function $R(n,e,t){const s=new Qt;return n.asyncQueue.enqueueAndForget(async()=>{const r=await vm(n);new HR(n.asyncQueue,r,t,e,s).Lc()}),s.promise}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Wi=class{constructor(e,t,s,r,i){this._firestore=e,this._userDataWriter=t,this._key=s,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new Pe(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new YR(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(is("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}},YR=class extends Wi{data(){return super.data()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rm{convertValue(e,t="none"){switch(Qe(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Fe(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(ns(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw X(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const s={};return Cs(e,(r,i)=>{s[r]=this.convertValue(i,t)}),s}convertVectorValue(e){var s,r,i;const t=(i=(r=(s=e.fields)==null?void 0:s[xi].arrayValue)==null?void 0:r.values)==null?void 0:i.map(o=>Fe(o.doubleValue));return new At(t)}convertGeoPoint(e){return new an(Fe(e.latitude),Fe(e.longitude))}convertArray(e,t){return(e.values||[]).map(s=>this.convertValue(s,t))}convertServerTimestamp(e,t){switch(t){case"previous":const s=Bo(e);return s==null?null:this.convertValue(s,t);case"estimate":return this.convertTimestamp(pr(e));default:return null}}convertTimestamp(e){const t=ts(e);return new Ee(t.seconds,t.nanos)}convertDocumentKey(e,t){const s=pe.fromString(e);W(vg(s),9688,{name:e});const r=new Oi(s.get(1),s.get(3)),i=new $(s.popFirst(5));return r.isEqual(t)||In(`A document reference to ${i} refers to a different database (${r.projectId}/${r.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Du(n,e,t){let s;return s=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,s}class XR extends Rm{constructor(e){super(),this.firestore=e}convertBytes(e){return new Ft(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Pe(this.firestore,null,t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wd="AsyncQueue";class $d{constructor(e=Promise.resolve()){this.$c=[],this.Kc=!1,this.Qc=[],this.Wc=null,this.Gc=!1,this.zc=!1,this.jc=[],this.Ht=new Vc(this,"async_queue_retry"),this.Hc=()=>{const s=gB();s&&Q(Wd,"Visibility state changed to "+s.visibilityState),this.Ht.$t()},this.Jc=e;const t=gB();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.Hc)}get isShuttingDown(){return this.Kc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Yc(),this.Zc(e)}enterRestrictedMode(e){if(!this.Kc){this.Kc=!0,this.zc=e||!1;const t=gB();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.Hc)}}enqueue(e){if(this.Yc(),this.Kc)return new Promise(()=>{});const t=new Qt;return this.Zc(()=>this.Kc&&this.zc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.$c.push(e),this.Xc()))}async Xc(){if(this.$c.length!==0){try{await this.$c[0](),this.$c.shift(),this.Ht.reset()}catch(e){if(!Or(e))throw e;Q(Wd,"Operation failed with retryable error: "+e)}this.$c.length>0&&this.Ht.kt(()=>this.Xc())}}Zc(e){const t=this.Jc.then(()=>(this.Gc=!0,e().catch(s=>{throw this.Wc=s,this.Gc=!1,In("INTERNAL UNHANDLED ERROR: ",Yd(s)),s}).then(s=>(this.Gc=!1,s))));return this.Jc=t,t}enqueueAfterDelay(e,t,s){this.Yc(),this.jc.indexOf(e)>-1&&(t=0);const r=hu.createAndSchedule(this,e,t,s,i=>this.el(i));return this.Qc.push(r),r}Yc(){this.Wc&&X(47125,{tl:Yd(this.Wc)})}verifyOperationInProgress(){}async nl(){let e;do e=this.Jc,await e;while(e!==this.Jc)}rl(e){for(const t of this.Qc)if(t.timerId===e)return!0;return!1}il(e){return this.nl().then(()=>{this.Qc.sort((t,s)=>t.targetTimeMs-s.targetTimeMs);for(const t of this.Qc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.nl()})}sl(e){this.jc.push(e)}el(e){const t=this.Qc.indexOf(e);this.Qc.splice(t,1)}}function Yd(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class Yt extends ol{constructor(e,t,s,r){super(e,t,s,r),this.type="firestore",this._queue=new $d,this._persistenceKey=(r==null?void 0:r.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new $d(e),this._firestoreClient=void 0,await e}}}function HN(n,e){const t=Dc(),s=ga,r=ro(t,"firestore").getImmediate({identifier:s});if(!r._initialized){const i=HC("firestore");i&&jI(r,...i)}return r}function Hr(n){if(n._terminated)throw new G(O.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||ZR(n),n._firestoreClient}function ZR(n){var s,r,i,o;const e=n._freezeSettings(),t=xI(n._databaseId,((s=n._app)==null?void 0:s.options.appId)||"",n._persistenceKey,(r=n._app)==null?void 0:r.options.apiKey,e);n._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((o=e.localCache)!=null&&o._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new UR(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(B){const c=B==null?void 0:B._online.build();return{_offline:B==null?void 0:B._offline.build(c),_online:c}}(n._componentsProvider))}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Eo extends Rm{constructor(e){super(),this.firestore=e}convertBytes(e){return new Ft(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Pe(this.firestore,null,t)}}class Br{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class Yn extends Wi{constructor(e,t,s,r,i,o){super(e,t,s,r,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new ca(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const s=this._document.data.field(is("DocumentSnapshot.get",e));if(s!==null)return this._userDataWriter.convertValue(s,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new G(O.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=Yn._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}Yn._jsonSchemaVersion="firestore/documentSnapshot/1.0",Yn._jsonSchema={type:Je("string",Yn._jsonSchemaVersion),bundleSource:Je("string","DocumentSnapshot"),bundleName:Je("string"),bundle:Je("string")};class ca extends Yn{data(e={}){return super.data(e)}}class Ls{constructor(e,t,s,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new Br(r.hasPendingWrites,r.fromCache),this.query=s}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(s=>{e.call(t,new ca(this._firestore,this._userDataWriter,s.key,s,new Br(this._snapshot.mutatedKeys.has(s.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new G(O.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(r,i){if(r._snapshot.oldDocs.isEmpty()){let o=0;return r._snapshot.docChanges.map(a=>{Ye(r._snapshot.query)?WB(r._snapshot.query):Lc(r.query._query);const B=new ca(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Br(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);return a.doc,{type:"added",doc:B,oldIndex:-1,newIndex:o++}})}{let o=r._snapshot.oldDocs;return r._snapshot.docChanges.filter(a=>i||a.type!==3).map(a=>{const B=new ca(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Br(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);let c=-1,u=-1;return a.type!==0&&(c=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),u=o.indexOf(a.doc.key)),{type:eS(a.type),doc:B,oldIndex:c,newIndex:u}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new G(O.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=Ls._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=Sc.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],s=[],r=[];return this.docs.forEach(i=>{i._document!==null&&(t.push(i._document),s.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),r.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function eS(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return X(61501,{type:n})}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ls._jsonSchemaVersion="firestore/querySnapshot/1.0",Ls._jsonSchema={type:Je("string",Ls._jsonSchemaVersion),bundleSource:Je("string","QuerySnapshot"),bundleName:Je("string"),bundle:Je("string")};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tS{constructor(e="count",t){this._internalFieldPath=t,this.type="AggregateField",this.aggregateType=e}}class nS{constructor(e,t,s){this._userDataWriter=t,this._data=s,this.type="AggregateQuerySnapshot",this.query=e}data(){return this._userDataWriter.convertObjectMap(this._data)}_fieldsProto(){return new it({mapValue:{fields:this._data}}).clone().value.mapValue.fields}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sm(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new G(O.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class yu{}let Do=class extends yu{};function qN(n,e,...t){let s=[];e instanceof yu&&s.push(e),s=s.concat(t),function(i){const o=i.filter(B=>B instanceof wu).length,a=i.filter(B=>B instanceof gl).length;if(o>1||o>0&&a>0)throw new G(O.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const r of s)n=r._apply(n);return n}class gl extends Do{constructor(e,t,s){super(),this._field=e,this._op=t,this._value=s,this.type="where"}static _create(e,t,s){return new gl(e,t,s)}_apply(e){const t=this._parse(e);return Lm(e._query,t),new Xt(e.firestore,e.converter,qB(e._query,t))}_parse(e){const t=Lr(e.firestore);return function(i,o,a,B,c,u,f){let C;if(c.isKeyField()){if(u==="array-contains"||u==="array-contains-any")throw new G(O.INVALID_ARGUMENT,`Invalid Query. You can't perform '${u}' queries on documentId().`);if(u==="in"||u==="not-in"){Zd(f,u);const E=[];for(const b of f)E.push(Xd(B,i,b));C={arrayValue:{values:E}}}else C=Xd(B,i,f)}else u!=="in"&&u!=="not-in"&&u!=="array-contains-any"||Zd(f,u),C=Vg(a,o,f,u==="in"||u==="not-in");return qe.create(c,u,C)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function JN(n,e,t){const s=e,r=is("where",n);return gl._create(r,s,t)}class wu extends yu{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new wu(e,t)}_parse(e){const t=this._queryConstraints.map(s=>s._parse(e)).filter(s=>s.getFilters().length>0);return t.length===1?t[0]:$t.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(r,i){let o=r;const a=i.getFlattenedFilters();for(const B of a)Lm(o,B),o=qB(o,B)}(e._query,t),new Xt(e.firestore,e.converter,qB(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Tu extends Do{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Tu(e,t)}_apply(e){const t=function(r,i,o){if(r.startAt!==null)throw new G(O.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(r.endAt!==null)throw new G(O.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Gi(i,o)}(e._query,this._field,this._direction);return new Xt(e.firestore,e.converter,HT(e._query,t))}}function jN(n,e="asc"){const t=e,s=is("orderBy",n);return Tu._create(s,t)}class Iu extends Do{constructor(e,t,s){super(),this.type=e,this._limit=t,this._limitType=s}static _create(e,t,s){return new Iu(e,t,s)}_apply(e){return new Xt(e.firestore,e.converter,wa(e._query,this._limit,this._limitType))}}function KN(n){return uT("limit",n),Iu._create("limit",n,"F")}let bm=class Nm extends Do{constructor(e,t,s){super(),this.type=e,this._docOrFields=t,this._inclusive=s}static _create(e,t,s){return new Nm(e,t,s)}_apply(e){const t=Om(e,this.type,this._docOrFields,this._inclusive);return new Xt(e.firestore,e.converter,UT(e._query,t))}};function QN(...n){return bm._create("startAt",n,!0)}function zN(...n){return bm._create("startAfter",n,!1)}let Pm=class Fm extends Do{constructor(e,t,s){super(),this.type=e,this._docOrFields=t,this._inclusive=s}static _create(e,t,s){return new Fm(e,t,s)}_apply(e){const t=Om(e,this.type,this._docOrFields,this._inclusive);return new Xt(e.firestore,e.converter,qT(e._query,t))}};function WN(...n){return Pm._create("endBefore",n,!1)}function $N(...n){return Pm._create("endAt",n,!0)}function Om(n,e,t,s){if(t[0]=Ie(t[0]),t[0]instanceof Wi)return function(i,o,a,B,c){if(!B)throw new G(O.NOT_FOUND,`Can't use a DocumentSnapshot that doesn't exist for ${a}().`);const u=[];for(const f of ur(i))if(f.field.isKeyField())u.push(ma(o,B.key));else{const C=B.data.field(f.field);if(lo(C))throw new G(O.INVALID_ARGUMENT,'Invalid query. You are trying to start or end a query using a document for which the field "'+f.field+'" is an uncommitted server timestamp. (Since the value of this field is unknown, you cannot start/end a query with it.)');if(C===null){const g=f.field.canonicalString();throw new G(O.INVALID_ARGUMENT,`Invalid query. You are trying to start or end a query using a document for which the field '${g}' (used as the orderBy) does not exist.`)}u.push(C)}return new yr(u,c)}(n._query,n.firestore._databaseId,e,t[0]._document,s);{const r=Lr(n.firestore);return function(o,a,B,c,u,f){const C=o.explicitOrderBy;if(u.length>C.length)throw new G(O.INVALID_ARGUMENT,`Too many arguments provided to ${c}(). The number of arguments must be less than or equal to the number of orderBy() clauses`);const g=[];for(let E=0;E<u.length;E++){const b=u[E];if(C[E].field.isKeyField()){if(typeof b!="string")throw new G(O.INVALID_ARGUMENT,`Invalid query. Expected a string for document ID in ${c}(), but got a ${typeof b}`);if(!Oc(o)&&b.indexOf("/")!==-1)throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection and ordering by documentId(), the value passed to ${c}() must be a plain document ID, but '${b}' contains a slash.`);const F=o.path.child(pe.fromString(b));if(!$.isDocumentKey(F))throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection group and ordering by documentId(), the value passed to ${c}() must result in a valid document path, but '${F}' is not because it contains an odd number of segments.`);const j=new $(F);g.push(ma(a,j))}else{const F=Vg(B,c,b);g.push(F)}}return new yr(g,f)}(n._query,n.firestore._databaseId,r,e,t,s)}}function Xd(n,e,t){if(typeof(t=Ie(t))=="string"){if(t==="")throw new G(O.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Oc(e)&&t.indexOf("/")!==-1)throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const s=e.path.child(pe.fromString(t));if(!$.isDocumentKey(s))throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return ma(n,new $(s))}if(t instanceof Pe)return ma(n,t._key);throw new G(O.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${$a(t)}.`)}function Zd(n,e){if(!Array.isArray(n)||n.length===0)throw new G(O.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Lm(n,e){const t=function(r,i){for(const o of r)for(const a of o.getFlattenedFilters())if(i.indexOf(a.op)>=0)return a.op;return null}(n.filters,function(r){switch(r){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new G(O.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new G(O.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function sS(){return new tS("count")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eC(n){return function(t,s){if(typeof t!="object"||t===null)return!1;const r=t;for(const i of s)if(i in r&&typeof r[i]=="function")return!0;return!1}(n,["next","error","complete"])}function YN(n){return rS(n,{count:sS()})}function rS(n,e){const t=ht(n.firestore,Yt),s=Hr(t),r=Mp(e,(i,o)=>new rT(o,i.aggregateType,i._internalFieldPath));return zR(s,n._query,r).then(i=>function(a,B,c){const u=new Eo(a);return new nS(B,u,c)}(t,n,i))}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iS={maxAttempts:5};function pi(n,e){if((n=Ie(n)).firestore!==e)throw new G(O.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let oS=class{constructor(e,t){this._firestore=e,this._transaction=t,this._dataReader=Lr(e)}get(e){const t=pi(e,this._firestore),s=new XR(this._firestore);return this._transaction.lookup([t._key]).then(r=>{if(!r||r.length!==1)return X(24041);const i=r[0];if(i.isFoundDocument())return new Wi(this._firestore,s,i.key,i,t.converter);if(i.isNoDocument())return new Wi(this._firestore,s,t._key,null,t.converter);throw X(18433,{doc:i})})}set(e,t,s){const r=pi(e,this._firestore),i=Du(r.converter,t,s),o=Gc(this._dataReader,"Transaction.set",r._key,i,r.converter!==null,s);return this._transaction.set(r._key,o),this}update(e,t,s,...r){const i=pi(e,this._firestore);let o;return o=typeof(t=Ie(t))=="string"||t instanceof Co?Mg(this._dataReader,"Transaction.update",i._key,t,s,r):kg(this._dataReader,"Transaction.update",i._key,t),this._transaction.update(i._key,o),this}delete(e){const t=pi(e,this._firestore);return this._transaction.delete(t._key),this}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aS extends oS{constructor(e,t){super(e,t),this._firestore=e}get(e){const t=pi(e,this._firestore),s=new Eo(this._firestore);return super.get(e).then(r=>new Yn(this._firestore,s,t._key,r._document,new Br(!1,!1),t.converter))}}function ZN(n,e,t){n=ht(n,Yt);const s={...iS,...t};(function(o){if(o.maxAttempts<1)throw new G(O.INVALID_ARGUMENT,"Max attempts must be at least 1")})(s);const r=Hr(n);return $R(r,i=>e(new aS(n,i)),s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eP(n){n=ht(n,Pe);const e=ht(n.firestore,Yt),t=Hr(e);return KR(t,n._key).then(s=>xm(e,n,s))}function tP(n){n=ht(n,Xt);const e=ht(n.firestore,Yt),t=Hr(e),s=new Eo(e);return Sm(n._query),QR(t,n._query).then(r=>new Ls(e,s,n,r))}function nP(n,e,t){n=ht(n,Pe);const s=ht(n.firestore,Yt),r=Du(n.converter,e,t),i=Lr(s);return ml(s,[Gc(i,"setDoc",n._key,r,n.converter!==null,t).toMutation(n._key,ot.none())])}function sP(n,e,t,...s){n=ht(n,Pe);const r=ht(n.firestore,Yt),i=Lr(r);let o;return o=typeof(e=Ie(e))=="string"||e instanceof Co?Mg(i,"updateDoc",n._key,e,t,s):kg(i,"updateDoc",n._key,e),ml(r,[o.toMutation(n._key,ot.exists(!0))])}function rP(n){return ml(ht(n.firestore,Yt),[new tl(n._key,ot.none())])}function iP(n,e){const t=ht(n.firestore,Yt),s=KI(n),r=Du(n.converter,e),i=Lr(n.firestore);return ml(t,[Gc(i,"addDoc",s._key,r,n.converter!==null,{}).toMutation(s._key,ot.exists(!1))]).then(()=>s)}function oP(n,...e){var c,u,f;n=Ie(n);let t={includeMetadataChanges:!1,source:"default"},s=0;typeof e[s]!="object"||eC(e[s])||(t=e[s++]);const r={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(eC(e[s])){const C=e[s];e[s]=(c=C.next)==null?void 0:c.bind(C),e[s+1]=(u=C.error)==null?void 0:u.bind(C),e[s+2]=(f=C.complete)==null?void 0:f.bind(C)}let i,o,a;if(n instanceof Pe)o=ht(n.firestore,Yt),a=nl(n._key.path),i={next:C=>{e[s]&&e[s](xm(o,n,C))},error:e[s+1],complete:e[s+2]};else{const C=ht(n,Xt);o=ht(C.firestore,Yt),a=C._query;const g=new Eo(o);i={next:E=>{e[s]&&e[s](new Ls(o,g,C,E))},error:e[s+1],complete:e[s+2]},Sm(n._query)}const B=Hr(o);return jR(B,a,r,i)}function ml(n,e){const t=Hr(n);return WR(t,e)}function xm(n,e,t){const s=t.docs.get(e._key),r=new Eo(n);return new Yn(n,r,e._key,s,new Br(t.hasPendingWrites,t.fromCache),e.converter)}const tC="@firebase/firestore",nC="4.17.2";(function(e,t=!0){iT(da),es(new wn("firestore",(s,{instanceIdentifier:r,options:i})=>{const o=s.getProvider("app").getImmediate(),a=new Yt(new DI(s.getProvider("auth-internal")),new TI(o,s.getProvider("app-check-internal")),dT(o,r),o);return i={useFetchStreams:t,...i},a._setSettings(i),a},"PUBLIC").setMultipleInstances(!0)),Ht(tC,nC,e),Ht(tC,nC,"esm2020")})();var sC={};const rC="@firebase/database",iC="1.1.5";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let km="";function lS(n){km=n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BS{constructor(e){this.domStorage_=e,this.prefix_="firebase:"}set(e,t){t==null?this.domStorage_.removeItem(this.prefixedName_(e)):this.domStorage_.setItem(this.prefixedName_(e),$e(t))}get(e){const t=this.domStorage_.getItem(this.prefixedName_(e));return t==null?null:bi(t)}remove(e){this.domStorage_.removeItem(this.prefixedName_(e))}prefixedName_(e){return this.prefix_+e}toString(){return this.domStorage_.toString()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cS{constructor(){this.cache_={},this.isInMemoryStorage=!0}set(e,t){t==null?delete this.cache_[e]:this.cache_[e]=t}get(e){return un(this.cache_,e)?this.cache_[e]:null}remove(e){delete this.cache_[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mm=function(n){try{if(typeof window<"u"&&typeof window[n]<"u"){const e=window[n];return e.setItem("firebase:sentinel","cache"),e.removeItem("firebase:sentinel"),new BS(e)}}catch{}return new cS},Ns=Mm("localStorage"),tc=Mm("sessionStorage");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fr=new Qa("@firebase/database"),uS=function(){let n=1;return function(){return n++}}(),Vm=function(n){const e=eD(n),t=new ZE;t.update(e);const s=t.digest();return mc.encodeByteArray(s)},yo=function(...n){let e="";for(let t=0;t<n.length;t++){const s=n[t];Array.isArray(s)||s&&typeof s=="object"&&typeof s.length=="number"?e+=yo.apply(null,s):typeof s=="object"?e+=$e(s):e+=s,e+=" "}return e};let xs=null,oC=!0;const Gm=function(n,e){H(!e||n===!0||n===!1,"Can't turn on custom loggers persistently."),n===!0?(fr.logLevel=he.VERBOSE,xs=fr.log.bind(fr),e&&tc.set("logging_enabled",!0)):typeof n=="function"?xs=n:(xs=null,tc.remove("logging_enabled"))},rt=function(...n){if(oC===!0&&(oC=!1,xs===null&&tc.get("logging_enabled")===!0&&Gm(!0)),xs){const e=yo.apply(null,n);xs(e)}},wo=function(n){return function(...e){rt(n,...e)}},nc=function(...n){const e="FIREBASE INTERNAL ERROR: "+yo(...n);fr.error(e)},Rn=function(...n){const e=`FIREBASE FATAL ERROR: ${yo(...n)}`;throw fr.error(e),new Error(e)},_t=function(...n){const e="FIREBASE WARNING: "+yo(...n);fr.warn(e)},hS=function(){typeof window<"u"&&window.location&&window.location.protocol&&window.location.protocol.indexOf("https:")!==-1&&_t("Insecure Firebase access from a secure page. Please use https in calls to new Firebase().")},Au=function(n){return typeof n=="number"&&(n!==n||n===Number.POSITIVE_INFINITY||n===Number.NEGATIVE_INFINITY)},fS=function(n){if(document.readyState==="complete")n();else{let e=!1;const t=function(){if(!document.body){setTimeout(t,Math.floor(10));return}e||(e=!0,n())};document.addEventListener?(document.addEventListener("DOMContentLoaded",t,!1),window.addEventListener("load",t,!1)):document.attachEvent&&(document.attachEvent("onreadystatechange",()=>{document.readyState==="complete"&&t()}),window.attachEvent("onload",t))}},us="[MIN_NAME]",Sn="[MAX_NAME]",zs=function(n,e){if(n===e)return 0;if(n===us||e===Sn)return-1;if(e===us||n===Sn)return 1;{const t=aC(n),s=aC(e);return t!==null?s!==null?t-s===0?n.length-e.length:t-s:-1:s!==null?1:n<e?-1:1}},dS=function(n,e){return n===e?0:n<e?-1:1},Bi=function(n,e){if(e&&n in e)return e[n];throw new Error("Missing required key ("+n+") in object: "+$e(e))},vu=function(n){if(typeof n!="object"||n===null)return $e(n);const e=[];for(const s in n)e.push(s);e.sort();let t="{";for(let s=0;s<e.length;s++)s!==0&&(t+=","),t+=$e(e[s]),t+=":",t+=vu(n[e[s]]);return t+="}",t},Hm=function(n,e){const t=n.length;if(t<=e)return[n];const s=[];for(let r=0;r<t;r+=e)r+e>t?s.push(n.substring(r,t)):s.push(n.substring(r,r+e));return s};function lt(n,e){for(const t in n)n.hasOwnProperty(t)&&e(t,n[t])}const Um=function(n){H(!Au(n),"Invalid JSON number");const e=11,t=52,s=(1<<e-1)-1;let r,i,o,a,B;n===0?(i=0,o=0,r=1/n===-1/0?1:0):(r=n<0,n=Math.abs(n),n>=Math.pow(2,1-s)?(a=Math.min(Math.floor(Math.log(n)/Math.LN2),s),i=a+s,o=Math.round(n*Math.pow(2,t-a)-Math.pow(2,t))):(i=0,o=Math.round(n/Math.pow(2,1-s-t))));const c=[];for(B=t;B;B-=1)c.push(o%2?1:0),o=Math.floor(o/2);for(B=e;B;B-=1)c.push(i%2?1:0),i=Math.floor(i/2);c.push(r?1:0),c.reverse();const u=c.join("");let f="";for(B=0;B<64;B+=8){let C=parseInt(u.substr(B,8),2).toString(16);C.length===1&&(C="0"+C),f=f+C}return f.toLowerCase()},CS=function(){return!!(typeof window=="object"&&window.chrome&&window.chrome.extension&&!/^chrome/.test(window.location.href))},pS=function(){return typeof Windows=="object"&&typeof Windows.UI=="object"};function gS(n,e){let t="Unknown Error";n==="too_big"?t="The data requested exceeds the maximum size that can be accessed with a single request.":n==="permission_denied"?t="Client doesn't have permission to access the desired data.":n==="unavailable"&&(t="The service is unavailable");const s=new Error(n+" at "+e._path.toString()+": "+t);return s.code=n.toUpperCase(),s}const mS=new RegExp("^-?(0*)\\d{1,10}$"),_S=-2147483648,ES=2147483647,aC=function(n){if(mS.test(n)){const e=Number(n);if(e>=_S&&e<=ES)return e}return null},Ur=function(n){try{n()}catch(e){setTimeout(()=>{const t=e.stack||"";throw _t("Exception was thrown by user callback.",t),e},Math.floor(0))}},DS=function(){return(typeof window=="object"&&window.navigator&&window.navigator.userAgent||"").search(/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0},Ai=function(n,e){const t=setTimeout(n,e);return typeof t=="number"&&typeof Deno<"u"&&Deno.unrefTimer?Deno.unrefTimer(t):typeof t=="object"&&t.unref&&t.unref(),t};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yS{constructor(e,t){this.appCheckProvider=t,this.appName=e.name,ZC(e)&&e.settings.appCheckToken&&(this.serverAppAppCheckToken=e.settings.appCheckToken),this.appCheck=t==null?void 0:t.getImmediate({optional:!0}),this.appCheck||t==null||t.get().then(s=>this.appCheck=s)}getToken(e){if(this.serverAppAppCheckToken){if(e)throw new Error("Attempted reuse of `FirebaseServerApp.appCheckToken` after previous usage failed.");return Promise.resolve({token:this.serverAppAppCheckToken})}return this.appCheck?this.appCheck.getToken(e):new Promise((t,s)=>{setTimeout(()=>{this.appCheck?this.getToken(e).then(t,s):t(null)},0)})}addTokenChangeListener(e){var t;(t=this.appCheckProvider)==null||t.get().then(s=>s.addTokenListener(e))}notifyForInvalidToken(){_t(`Provided AppCheck credentials for the app named "${this.appName}" are invalid. This usually indicates your app was not initialized correctly.`)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wS{constructor(e,t,s){this.appName_=e,this.firebaseOptions_=t,this.authProvider_=s,this.auth_=null,this.auth_=s.getImmediate({optional:!0}),this.auth_||s.onInit(r=>this.auth_=r)}getToken(e){return this.auth_?this.auth_.getToken(e).catch(t=>t&&t.code==="auth/token-not-initialized"?(rt("Got auth/token-not-initialized error.  Treating as null token."),null):Promise.reject(t)):new Promise((t,s)=>{setTimeout(()=>{this.auth_?this.getToken(e).then(t,s):t(null)},0)})}addTokenChangeListener(e){this.auth_?this.auth_.addAuthTokenListener(e):this.authProvider_.get().then(t=>t.addAuthTokenListener(e))}removeTokenChangeListener(e){this.authProvider_.get().then(t=>t.removeAuthTokenListener(e))}notifyForInvalidToken(){let e='Provided authentication credentials for the app named "'+this.appName_+'" are invalid. This usually indicates your app was not initialized correctly. ';"credential"in this.firebaseOptions_?e+='Make sure the "credential" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':"serviceAccount"in this.firebaseOptions_?e+='Make sure the "serviceAccount" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':e+='Make sure the "apiKey" and "databaseURL" properties provided to initializeApp() match the values provided for your app at https://console.firebase.google.com/.',_t(e)}}class ua{constructor(e){this.accessToken=e}getToken(e){return Promise.resolve({accessToken:this.accessToken})}addTokenChangeListener(e){e(this.accessToken)}removeTokenChangeListener(e){}notifyForInvalidToken(){}}ua.OWNER="owner";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ru="5",qm="v",Jm="s",jm="r",Km="f",Qm=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,zm="ls",Wm="p",sc="ac",$m="websocket",Ym="long_polling";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xm{constructor(e,t,s,r,i=!1,o="",a=!1,B=!1,c=null){this.secure=t,this.namespace=s,this.webSocketOnly=r,this.nodeAdmin=i,this.persistenceKey=o,this.includeNamespaceInQueryParams=a,this.isUsingEmulator=B,this.emulatorOptions=c,this._host=e.toLowerCase(),this._domain=this._host.substr(this._host.indexOf(".")+1),this.internalHost=Ns.get("host:"+e)||this._host}isCacheableHost(){return this.internalHost.substr(0,2)==="s-"}isCustomHost(){return this._domain!=="firebaseio.com"&&this._domain!=="firebaseio-demo.com"}get host(){return this._host}set host(e){e!==this.internalHost&&(this.internalHost=e,this.isCacheableHost()&&Ns.set("host:"+this._host,this.internalHost))}toString(){let e=this.toURLString();return this.persistenceKey&&(e+="<"+this.persistenceKey+">"),e}toURLString(){const e=this.secure?"https://":"http://",t=this.includeNamespaceInQueryParams?`?ns=${this.namespace}`:"";return`${e}${this.host}/${t}`}}function TS(n){return n.host!==n.internalHost||n.isCustomHost()||n.includeNamespaceInQueryParams}function Zm(n,e,t){H(typeof e=="string","typeof type must == string"),H(typeof t=="object","typeof params must == object");let s;if(e===$m)s=(n.secure?"wss://":"ws://")+n.internalHost+"/.ws?";else if(e===Ym)s=(n.secure?"https://":"http://")+n.internalHost+"/.lp?";else throw new Error("Unknown connection type: "+e);TS(n)&&(t.ns=n.namespace);const r=[];return lt(t,(i,o)=>{r.push(i+"="+o)}),s+r.join("&")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IS{constructor(){this.counters_={}}incrementCounter(e,t=1){un(this.counters_,e)||(this.counters_[e]=0),this.counters_[e]+=t}get(){return xE(this.counters_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _B={},EB={};function Su(n){const e=n.toString();return _B[e]||(_B[e]=new IS),_B[e]}function AS(n,e){const t=n.toString();return EB[t]||(EB[t]=e()),EB[t]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vS{constructor(e){this.onMessage_=e,this.pendingResponses=[],this.currentResponseNum=0,this.closeAfterResponse=-1,this.onClose=null}closeAfter(e,t){this.closeAfterResponse=e,this.onClose=t,this.closeAfterResponse<this.currentResponseNum&&(this.onClose(),this.onClose=null)}handleResponse(e,t){for(this.pendingResponses[e]=t;this.pendingResponses[this.currentResponseNum];){const s=this.pendingResponses[this.currentResponseNum];delete this.pendingResponses[this.currentResponseNum];for(let r=0;r<s.length;++r)s[r]&&Ur(()=>{this.onMessage_(s[r])});if(this.currentResponseNum===this.closeAfterResponse){this.onClose&&(this.onClose(),this.onClose=null);break}this.currentResponseNum++}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lC="start",RS="close",SS="pLPCommand",bS="pRTLPCB",e_="id",t_="pw",n_="ser",NS="cb",PS="seg",FS="ts",OS="d",LS="dframe",s_=1870,r_=30,xS=s_-r_,kS=25e3,MS=3e4;class cr{constructor(e,t,s,r,i,o,a){this.connId=e,this.repoInfo=t,this.applicationId=s,this.appCheckToken=r,this.authToken=i,this.transportSessionId=o,this.lastSessionId=a,this.bytesSent=0,this.bytesReceived=0,this.everConnected_=!1,this.log_=wo(e),this.stats_=Su(t),this.urlFn=B=>(this.appCheckToken&&(B[sc]=this.appCheckToken),Zm(t,Ym,B))}open(e,t){this.curSegmentNum=0,this.onDisconnect_=t,this.myPacketOrderer=new vS(e),this.isClosed_=!1,this.connectTimeoutTimer_=setTimeout(()=>{this.log_("Timed out trying to connect."),this.onClosed_(),this.connectTimeoutTimer_=null},Math.floor(MS)),fS(()=>{if(this.isClosed_)return;this.scriptTagHolder=new bu((...i)=>{const[o,a,B,c,u]=i;if(this.incrementIncomingBytes_(i),!!this.scriptTagHolder)if(this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null),this.everConnected_=!0,o===lC)this.id=a,this.password=B;else if(o===RS)a?(this.scriptTagHolder.sendNewPolls=!1,this.myPacketOrderer.closeAfter(a,()=>{this.onClosed_()})):this.onClosed_();else throw new Error("Unrecognized command received: "+o)},(...i)=>{const[o,a]=i;this.incrementIncomingBytes_(i),this.myPacketOrderer.handleResponse(o,a)},()=>{this.onClosed_()},this.urlFn);const s={};s[lC]="t",s[n_]=Math.floor(Math.random()*1e8),this.scriptTagHolder.uniqueCallbackIdentifier&&(s[NS]=this.scriptTagHolder.uniqueCallbackIdentifier),s[qm]=Ru,this.transportSessionId&&(s[Jm]=this.transportSessionId),this.lastSessionId&&(s[zm]=this.lastSessionId),this.applicationId&&(s[Wm]=this.applicationId),this.appCheckToken&&(s[sc]=this.appCheckToken),typeof location<"u"&&location.hostname&&Qm.test(location.hostname)&&(s[jm]=Km);const r=this.urlFn(s);this.log_("Connecting via long-poll to "+r),this.scriptTagHolder.addTag(r,()=>{})})}start(){this.scriptTagHolder.startLongPoll(this.id,this.password),this.addDisconnectPingFrame(this.id,this.password)}static forceAllow(){cr.forceAllow_=!0}static forceDisallow(){cr.forceDisallow_=!0}static isAvailable(){return cr.forceAllow_?!0:!cr.forceDisallow_&&typeof document<"u"&&document.createElement!=null&&!CS()&&!pS()}markConnectionHealthy(){}shutdown_(){this.isClosed_=!0,this.scriptTagHolder&&(this.scriptTagHolder.close(),this.scriptTagHolder=null),this.myDisconnFrame&&(document.body.removeChild(this.myDisconnFrame),this.myDisconnFrame=null),this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null)}onClosed_(){this.isClosed_||(this.log_("Longpoll is closing itself"),this.shutdown_(),this.onDisconnect_&&(this.onDisconnect_(this.everConnected_),this.onDisconnect_=null))}close(){this.isClosed_||(this.log_("Longpoll is being closed."),this.shutdown_())}send(e){const t=$e(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const s=VC(t),r=Hm(s,xS);for(let i=0;i<r.length;i++)this.scriptTagHolder.enqueueSegment(this.curSegmentNum,r.length,r[i]),this.curSegmentNum++}addDisconnectPingFrame(e,t){this.myDisconnFrame=document.createElement("iframe");const s={};s[LS]="t",s[e_]=e,s[t_]=t,this.myDisconnFrame.src=this.urlFn(s),this.myDisconnFrame.style.display="none",document.body.appendChild(this.myDisconnFrame)}incrementIncomingBytes_(e){const t=$e(e).length;this.bytesReceived+=t,this.stats_.incrementCounter("bytes_received",t)}}class bu{constructor(e,t,s,r){this.onDisconnect=s,this.urlFn=r,this.outstandingRequests=new Set,this.pendingSegs=[],this.currentSerial=Math.floor(Math.random()*1e8),this.sendNewPolls=!0;{this.uniqueCallbackIdentifier=uS(),window[SS+this.uniqueCallbackIdentifier]=e,window[bS+this.uniqueCallbackIdentifier]=t,this.myIFrame=bu.createIFrame_();let i="";this.myIFrame.src&&this.myIFrame.src.substr(0,11)==="javascript:"&&(i='<script>document.domain="'+document.domain+'";<\/script>');const o="<html><body>"+i+"</body></html>";try{this.myIFrame.doc.open(),this.myIFrame.doc.write(o),this.myIFrame.doc.close()}catch(a){rt("frame writing exception"),a.stack&&rt(a.stack),rt(a)}}}static createIFrame_(){const e=document.createElement("iframe");if(e.style.display="none",document.body){document.body.appendChild(e);try{e.contentWindow.document||rt("No IE domain setting required")}catch{const s=document.domain;e.src="javascript:void((function(){document.open();document.domain='"+s+"';document.close();})())"}}else throw"Document body has not initialized. Wait to initialize Firebase until after the document is ready.";return e.contentDocument?e.doc=e.contentDocument:e.contentWindow?e.doc=e.contentWindow.document:e.document&&(e.doc=e.document),e}close(){this.alive=!1,this.myIFrame&&(this.myIFrame.doc.body.textContent="",setTimeout(()=>{this.myIFrame!==null&&(document.body.removeChild(this.myIFrame),this.myIFrame=null)},Math.floor(0)));const e=this.onDisconnect;e&&(this.onDisconnect=null,e())}startLongPoll(e,t){for(this.myID=e,this.myPW=t,this.alive=!0;this.newRequest_(););}newRequest_(){if(this.alive&&this.sendNewPolls&&this.outstandingRequests.size<(this.pendingSegs.length>0?2:1)){this.currentSerial++;const e={};e[e_]=this.myID,e[t_]=this.myPW,e[n_]=this.currentSerial;let t=this.urlFn(e),s="",r=0;for(;this.pendingSegs.length>0&&this.pendingSegs[0].d.length+r_+s.length<=s_;){const o=this.pendingSegs.shift();s=s+"&"+PS+r+"="+o.seg+"&"+FS+r+"="+o.ts+"&"+OS+r+"="+o.d,r++}return t=t+s,this.addLongPollTag_(t,this.currentSerial),!0}else return!1}enqueueSegment(e,t,s){this.pendingSegs.push({seg:e,ts:t,d:s}),this.alive&&this.newRequest_()}addLongPollTag_(e,t){this.outstandingRequests.add(t);const s=()=>{this.outstandingRequests.delete(t),this.newRequest_()},r=setTimeout(s,Math.floor(kS)),i=()=>{clearTimeout(r),s()};this.addTag(e,i)}addTag(e,t){setTimeout(()=>{try{if(!this.sendNewPolls)return;const s=this.myIFrame.doc.createElement("script");s.type="text/javascript",s.async=!0,s.src=e,s.onload=s.onreadystatechange=function(){const r=s.readyState;(!r||r==="loaded"||r==="complete")&&(s.onload=s.onreadystatechange=null,s.parentNode&&s.parentNode.removeChild(s),t())},s.onerror=()=>{rt("Long-poll script failed to load: "+e),this.sendNewPolls=!1,this.close()},this.myIFrame.doc.body.appendChild(s)}catch{}},Math.floor(1))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VS=16384,GS=45e3;let ba=null;typeof MozWebSocket<"u"?ba=MozWebSocket:typeof WebSocket<"u"&&(ba=WebSocket);class jt{constructor(e,t,s,r,i,o,a){this.connId=e,this.applicationId=s,this.appCheckToken=r,this.authToken=i,this.keepaliveTimer=null,this.frames=null,this.totalFrames=0,this.bytesSent=0,this.bytesReceived=0,this.log_=wo(this.connId),this.stats_=Su(t),this.connURL=jt.connectionURL_(t,o,a,r,s),this.nodeAdmin=t.nodeAdmin}static connectionURL_(e,t,s,r,i){const o={};return o[qm]=Ru,typeof location<"u"&&location.hostname&&Qm.test(location.hostname)&&(o[jm]=Km),t&&(o[Jm]=t),s&&(o[zm]=s),r&&(o[sc]=r),i&&(o[Wm]=i),Zm(e,$m,o)}open(e,t){this.onDisconnect=t,this.onMessage=e,this.log_("Websocket connecting to "+this.connURL),this.everConnected_=!1,Ns.set("previous_websocket_failure",!0);try{let s;jE(),this.mySock=new ba(this.connURL,[],s)}catch(s){this.log_("Error instantiating WebSocket.");const r=s.message||s.data;r&&this.log_(r),this.onClosed_();return}this.mySock.onopen=()=>{this.log_("Websocket connected."),this.everConnected_=!0},this.mySock.onclose=()=>{this.log_("Websocket connection was disconnected."),this.mySock=null,this.onClosed_()},this.mySock.onmessage=s=>{this.handleIncomingFrame(s)},this.mySock.onerror=s=>{this.log_("WebSocket error.  Closing connection.");const r=s.message||s.data;r&&this.log_(r),this.onClosed_()}}start(){}static forceDisallow(){jt.forceDisallow_=!0}static isAvailable(){let e=!1;if(typeof navigator<"u"&&navigator.userAgent){const t=/Android ([0-9]{0,}\.[0-9]{0,})/,s=navigator.userAgent.match(t);s&&s.length>1&&parseFloat(s[1])<4.4&&(e=!0)}return!e&&ba!==null&&!jt.forceDisallow_}static previouslyFailed(){return Ns.isInMemoryStorage||Ns.get("previous_websocket_failure")===!0}markConnectionHealthy(){Ns.remove("previous_websocket_failure")}appendFrame_(e){if(this.frames.push(e),this.frames.length===this.totalFrames){const t=this.frames.join("");this.frames=null;const s=bi(t);this.onMessage(s)}}handleNewFrameCount_(e){this.totalFrames=e,this.frames=[]}extractFrameCount_(e){if(H(this.frames===null,"We already have a frame buffer"),e.length<=6){const t=Number(e);if(!isNaN(t))return this.handleNewFrameCount_(t),null}return this.handleNewFrameCount_(1),e}handleIncomingFrame(e){if(this.mySock===null)return;const t=e.data;if(this.bytesReceived+=t.length,this.stats_.incrementCounter("bytes_received",t.length),this.resetKeepAlive(),this.frames!==null)this.appendFrame_(t);else{const s=this.extractFrameCount_(t);s!==null&&this.appendFrame_(s)}}send(e){this.resetKeepAlive();const t=$e(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const s=Hm(t,VS);s.length>1&&this.sendString_(String(s.length));for(let r=0;r<s.length;r++)this.sendString_(s[r])}shutdown_(){this.isClosed_=!0,this.keepaliveTimer&&(clearInterval(this.keepaliveTimer),this.keepaliveTimer=null),this.mySock&&(this.mySock.close(),this.mySock=null)}onClosed_(){this.isClosed_||(this.log_("WebSocket is closing itself"),this.shutdown_(),this.onDisconnect&&(this.onDisconnect(this.everConnected_),this.onDisconnect=null))}close(){this.isClosed_||(this.log_("WebSocket is being closed"),this.shutdown_())}resetKeepAlive(){clearInterval(this.keepaliveTimer),this.keepaliveTimer=setInterval(()=>{this.mySock&&this.sendString_("0"),this.resetKeepAlive()},Math.floor(GS))}sendString_(e){try{this.mySock.send(e)}catch(t){this.log_("Exception thrown from WebSocket.send():",t.message||t.data,"Closing connection."),setTimeout(this.onClosed_.bind(this),0)}}}jt.responsesRequiredToBeHealthy=2;jt.healthyTimeout=3e4;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $i{static get ALL_TRANSPORTS(){return[cr,jt]}static get IS_TRANSPORT_INITIALIZED(){return this.globalTransportInitialized_}constructor(e){this.initTransports_(e)}initTransports_(e){const t=jt&&jt.isAvailable();let s=t&&!jt.previouslyFailed();if(e.webSocketOnly&&(t||_t("wss:// URL used, but browser isn't known to support websockets.  Trying anyway."),s=!0),s)this.transports_=[jt];else{const r=this.transports_=[];for(const i of $i.ALL_TRANSPORTS)i&&i.isAvailable()&&r.push(i);$i.globalTransportInitialized_=!0}}initialTransport(){if(this.transports_.length>0)return this.transports_[0];throw new Error("No transports available")}upgradeTransport(){return this.transports_.length>1?this.transports_[1]:null}}$i.globalTransportInitialized_=!1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const HS=6e4,US=5e3,qS=10*1024,JS=100*1024,DB="t",BC="d",jS="s",cC="r",KS="e",uC="o",hC="a",fC="n",dC="p",QS="h";class zS{constructor(e,t,s,r,i,o,a,B,c,u){this.id=e,this.repoInfo_=t,this.applicationId_=s,this.appCheckToken_=r,this.authToken_=i,this.onMessage_=o,this.onReady_=a,this.onDisconnect_=B,this.onKill_=c,this.lastSessionId=u,this.connectionCount=0,this.pendingDataMessages=[],this.state_=0,this.log_=wo("c:"+this.id+":"),this.transportManager_=new $i(t),this.log_("Connection created"),this.start_()}start_(){const e=this.transportManager_.initialTransport();this.conn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,null,this.lastSessionId),this.primaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.conn_),s=this.disconnReceiver_(this.conn_);this.tx_=this.conn_,this.rx_=this.conn_,this.secondaryConn_=null,this.isHealthy_=!1,setTimeout(()=>{this.conn_&&this.conn_.open(t,s)},Math.floor(0));const r=e.healthyTimeout||0;r>0&&(this.healthyTimeout_=Ai(()=>{this.healthyTimeout_=null,this.isHealthy_||(this.conn_&&this.conn_.bytesReceived>JS?(this.log_("Connection exceeded healthy timeout but has received "+this.conn_.bytesReceived+" bytes.  Marking connection healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()):this.conn_&&this.conn_.bytesSent>qS?this.log_("Connection exceeded healthy timeout but has sent "+this.conn_.bytesSent+" bytes.  Leaving connection alive."):(this.log_("Closing unhealthy connection after timeout."),this.close()))},Math.floor(r)))}nextTransportId_(){return"c:"+this.id+":"+this.connectionCount++}disconnReceiver_(e){return t=>{e===this.conn_?this.onConnectionLost_(t):e===this.secondaryConn_?(this.log_("Secondary connection lost."),this.onSecondaryConnectionLost_()):this.log_("closing an old connection")}}connReceiver_(e){return t=>{this.state_!==2&&(e===this.rx_?this.onPrimaryMessageReceived_(t):e===this.secondaryConn_?this.onSecondaryMessageReceived_(t):this.log_("message on old connection"))}}sendRequest(e){const t={t:"d",d:e};this.sendData_(t)}tryCleanupConnection(){this.tx_===this.secondaryConn_&&this.rx_===this.secondaryConn_&&(this.log_("cleaning up and promoting a connection: "+this.secondaryConn_.connId),this.conn_=this.secondaryConn_,this.secondaryConn_=null)}onSecondaryControl_(e){if(DB in e){const t=e[DB];t===hC?this.upgradeIfSecondaryHealthy_():t===cC?(this.log_("Got a reset on secondary, closing it"),this.secondaryConn_.close(),(this.tx_===this.secondaryConn_||this.rx_===this.secondaryConn_)&&this.close()):t===uC&&(this.log_("got pong on secondary."),this.secondaryResponsesRequired_--,this.upgradeIfSecondaryHealthy_())}}onSecondaryMessageReceived_(e){const t=Bi("t",e),s=Bi("d",e);if(t==="c")this.onSecondaryControl_(s);else if(t==="d")this.pendingDataMessages.push(s);else throw new Error("Unknown protocol layer: "+t)}upgradeIfSecondaryHealthy_(){this.secondaryResponsesRequired_<=0?(this.log_("Secondary connection is healthy."),this.isHealthy_=!0,this.secondaryConn_.markConnectionHealthy(),this.proceedWithUpgrade_()):(this.log_("sending ping on secondary."),this.secondaryConn_.send({t:"c",d:{t:dC,d:{}}}))}proceedWithUpgrade_(){this.secondaryConn_.start(),this.log_("sending client ack on secondary"),this.secondaryConn_.send({t:"c",d:{t:hC,d:{}}}),this.log_("Ending transmission on primary"),this.conn_.send({t:"c",d:{t:fC,d:{}}}),this.tx_=this.secondaryConn_,this.tryCleanupConnection()}onPrimaryMessageReceived_(e){const t=Bi("t",e),s=Bi("d",e);t==="c"?this.onControl_(s):t==="d"&&this.onDataMessage_(s)}onDataMessage_(e){this.onPrimaryResponse_(),this.onMessage_(e)}onPrimaryResponse_(){this.isHealthy_||(this.primaryResponsesRequired_--,this.primaryResponsesRequired_<=0&&(this.log_("Primary connection is healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()))}onControl_(e){const t=Bi(DB,e);if(BC in e){const s=e[BC];if(t===QS){const r={...s};this.repoInfo_.isUsingEmulator&&(r.h=this.repoInfo_.host),this.onHandshake_(r)}else if(t===fC){this.log_("recvd end transmission on primary"),this.rx_=this.secondaryConn_;for(let r=0;r<this.pendingDataMessages.length;++r)this.onDataMessage_(this.pendingDataMessages[r]);this.pendingDataMessages=[],this.tryCleanupConnection()}else t===jS?this.onConnectionShutdown_(s):t===cC?this.onReset_(s):t===KS?nc("Server Error: "+s):t===uC?(this.log_("got pong on primary."),this.onPrimaryResponse_(),this.sendPingOnPrimaryIfNecessary_()):nc("Unknown control packet command: "+t)}}onHandshake_(e){const t=e.ts,s=e.v,r=e.h;this.sessionId=e.s,this.repoInfo_.host=r,this.state_===0&&(this.conn_.start(),this.onConnectionEstablished_(this.conn_,t),Ru!==s&&_t("Protocol version mismatch detected"),this.tryStartUpgrade_())}tryStartUpgrade_(){const e=this.transportManager_.upgradeTransport();e&&this.startUpgrade_(e)}startUpgrade_(e){this.secondaryConn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,this.sessionId),this.secondaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.secondaryConn_),s=this.disconnReceiver_(this.secondaryConn_);this.secondaryConn_.open(t,s),Ai(()=>{this.secondaryConn_&&(this.log_("Timed out trying to upgrade."),this.secondaryConn_.close())},Math.floor(HS))}onReset_(e){this.log_("Reset packet received.  New host: "+e),this.repoInfo_.host=e,this.state_===1?this.close():(this.closeConnections_(),this.start_())}onConnectionEstablished_(e,t){this.log_("Realtime connection established."),this.conn_=e,this.state_=1,this.onReady_&&(this.onReady_(t,this.sessionId),this.onReady_=null),this.primaryResponsesRequired_===0?(this.log_("Primary connection is healthy."),this.isHealthy_=!0):Ai(()=>{this.sendPingOnPrimaryIfNecessary_()},Math.floor(US))}sendPingOnPrimaryIfNecessary_(){!this.isHealthy_&&this.state_===1&&(this.log_("sending ping on primary."),this.sendData_({t:"c",d:{t:dC,d:{}}}))}onSecondaryConnectionLost_(){const e=this.secondaryConn_;this.secondaryConn_=null,(this.tx_===e||this.rx_===e)&&this.close()}onConnectionLost_(e){this.conn_=null,!e&&this.state_===0?(this.log_("Realtime connection failed."),this.repoInfo_.isCacheableHost()&&(Ns.remove("host:"+this.repoInfo_.host),this.repoInfo_.internalHost=this.repoInfo_.host)):this.state_===1&&this.log_("Realtime connection lost."),this.close()}onConnectionShutdown_(e){this.log_("Connection shutdown command received. Shutting down..."),this.onKill_&&(this.onKill_(e),this.onKill_=null),this.onDisconnect_=null,this.close()}sendData_(e){if(this.state_!==1)throw"Connection is not connected";this.tx_.send(e)}close(){this.state_!==2&&(this.log_("Closing realtime connection."),this.state_=2,this.closeConnections_(),this.onDisconnect_&&(this.onDisconnect_(),this.onDisconnect_=null))}closeConnections_(){this.log_("Shutting down all connections"),this.conn_&&(this.conn_.close(),this.conn_=null),this.secondaryConn_&&(this.secondaryConn_.close(),this.secondaryConn_=null),this.healthyTimeout_&&(clearTimeout(this.healthyTimeout_),this.healthyTimeout_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class i_{put(e,t,s,r){}merge(e,t,s,r){}refreshAuthToken(e){}refreshAppCheckToken(e){}onDisconnectPut(e,t,s){}onDisconnectMerge(e,t,s){}onDisconnectCancel(e,t){}reportStats(e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o_{constructor(e){this.allowedEvents_=e,this.listeners_={},H(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const s=[...this.listeners_[e]];for(let r=0;r<s.length;r++)s[r].callback.apply(s[r].context,t)}}on(e,t,s){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:s});const r=this.getInitialEvent(e);r&&t.apply(s,r)}off(e,t,s){this.validateEventType_(e);const r=this.listeners_[e]||[];for(let i=0;i<r.length;i++)if(r[i].callback===t&&(!s||s===r[i].context)){r.splice(i,1);return}}validateEventType_(e){H(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Na extends o_{static getInstance(){return new Na}constructor(){super(["online"]),this.online_=!0,typeof window<"u"&&typeof window.addEventListener<"u"&&!jC()&&(window.addEventListener("online",()=>{this.online_||(this.online_=!0,this.trigger("online",!0))},!1),window.addEventListener("offline",()=>{this.online_&&(this.online_=!1,this.trigger("online",!1))},!1))}getInitialEvent(e){return H(e==="online","Unknown event type: "+e),[this.online_]}currentlyOnline(){return this.online_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CC=32,pC=768;class De{constructor(e,t){if(t===void 0){this.pieces_=e.split("/");let s=0;for(let r=0;r<this.pieces_.length;r++)this.pieces_[r].length>0&&(this.pieces_[s]=this.pieces_[r],s++);this.pieces_.length=s,this.pieceNum_=0}else this.pieces_=e,this.pieceNum_=t}toString(){let e="";for(let t=this.pieceNum_;t<this.pieces_.length;t++)this.pieces_[t]!==""&&(e+="/"+this.pieces_[t]);return e||"/"}}function _e(){return new De("")}function ae(n){return n.pieceNum_>=n.pieces_.length?null:n.pieces_[n.pieceNum_]}function hs(n){return n.pieces_.length-n.pieceNum_}function Re(n){let e=n.pieceNum_;return e<n.pieces_.length&&e++,new De(n.pieces_,e)}function Nu(n){return n.pieceNum_<n.pieces_.length?n.pieces_[n.pieces_.length-1]:null}function WS(n){let e="";for(let t=n.pieceNum_;t<n.pieces_.length;t++)n.pieces_[t]!==""&&(e+="/"+encodeURIComponent(String(n.pieces_[t])));return e||"/"}function Yi(n,e=0){return n.pieces_.slice(n.pieceNum_+e)}function a_(n){if(n.pieceNum_>=n.pieces_.length)return null;const e=[];for(let t=n.pieceNum_;t<n.pieces_.length-1;t++)e.push(n.pieces_[t]);return new De(e,0)}function ke(n,e){const t=[];for(let s=n.pieceNum_;s<n.pieces_.length;s++)t.push(n.pieces_[s]);if(e instanceof De)for(let s=e.pieceNum_;s<e.pieces_.length;s++)t.push(e.pieces_[s]);else{const s=e.split("/");for(let r=0;r<s.length;r++)s[r].length>0&&t.push(s[r])}return new De(t,0)}function le(n){return n.pieceNum_>=n.pieces_.length}function mt(n,e){const t=ae(n),s=ae(e);if(t===null)return e;if(t===s)return mt(Re(n),Re(e));throw new Error("INTERNAL ERROR: innerPath ("+e+") is not within outerPath ("+n+")")}function $S(n,e){const t=Yi(n,0),s=Yi(e,0);for(let r=0;r<t.length&&r<s.length;r++){const i=zs(t[r],s[r]);if(i!==0)return i}return t.length===s.length?0:t.length<s.length?-1:1}function Pu(n,e){if(hs(n)!==hs(e))return!1;for(let t=n.pieceNum_,s=e.pieceNum_;t<=n.pieces_.length;t++,s++)if(n.pieces_[t]!==e.pieces_[s])return!1;return!0}function Gt(n,e){let t=n.pieceNum_,s=e.pieceNum_;if(hs(n)>hs(e))return!1;for(;t<n.pieces_.length;){if(n.pieces_[t]!==e.pieces_[s])return!1;++t,++s}return!0}class YS{constructor(e,t){this.errorPrefix_=t,this.parts_=Yi(e,0),this.byteLength_=Math.max(1,this.parts_.length);for(let s=0;s<this.parts_.length;s++)this.byteLength_+=ja(this.parts_[s]);l_(this)}}function XS(n,e){n.parts_.length>0&&(n.byteLength_+=1),n.parts_.push(e),n.byteLength_+=ja(e),l_(n)}function ZS(n){const e=n.parts_.pop();n.byteLength_-=ja(e),n.parts_.length>0&&(n.byteLength_-=1)}function l_(n){if(n.byteLength_>pC)throw new Error(n.errorPrefix_+"has a key path longer than "+pC+" bytes ("+n.byteLength_+").");if(n.parts_.length>CC)throw new Error(n.errorPrefix_+"path specified exceeds the maximum depth that can be written ("+CC+") or object contains a cycle "+As(n))}function As(n){return n.parts_.length===0?"":"in property '"+n.parts_.join(".")+"'"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fu extends o_{static getInstance(){return new Fu}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const s=!document[e];s!==this.visible_&&(this.visible_=s,this.trigger("visible",s))},!1)}getInitialEvent(e){return H(e==="visible","Unknown event type: "+e),[this.visible_]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ci=1e3,e0=60*5*1e3,gC=30*1e3,t0=1.3,n0=3e4,s0="server_kill",mC=3;class yn extends i_{constructor(e,t,s,r,i,o,a,B){if(super(),this.repoInfo_=e,this.applicationId_=t,this.onDataUpdate_=s,this.onConnectStatus_=r,this.onServerInfoUpdate_=i,this.authTokenProvider_=o,this.appCheckTokenProvider_=a,this.authOverride_=B,this.id=yn.nextPersistentConnectionId_++,this.log_=wo("p:"+this.id+":"),this.interruptReasons_={},this.listens=new Map,this.outstandingPuts_=[],this.outstandingGets_=[],this.outstandingPutCount_=0,this.outstandingGetCount_=0,this.onDisconnectRequestQueue_=[],this.connected_=!1,this.reconnectDelay_=ci,this.maxReconnectDelay_=e0,this.securityDebugCallback_=null,this.lastSessionId=null,this.establishConnectionTimer_=null,this.visible_=!1,this.requestCBHash_={},this.requestNumber_=0,this.realtime_=null,this.authToken_=null,this.appCheckToken_=null,this.forceTokenRefresh_=!1,this.invalidAuthTokenCount_=0,this.invalidAppCheckTokenCount_=0,this.firstConnection_=!0,this.lastConnectionAttemptTime_=null,this.lastConnectionEstablishedTime_=null,B)throw new Error("Auth override specified in options, but not supported on non Node.js platforms");Fu.getInstance().on("visible",this.onVisible_,this),e.host.indexOf("fblocal")===-1&&Na.getInstance().on("online",this.onOnline_,this)}sendRequest(e,t,s){const r=++this.requestNumber_,i={r,a:e,b:t};this.log_($e(i)),H(this.connected_,"sendRequest call when we're not connected not allowed."),this.realtime_.sendRequest(i),s&&(this.requestCBHash_[r]=s)}get(e){this.initConnection_();const t=new so,r={action:"g",request:{p:e._path.toString(),q:e._queryObject},onComplete:o=>{const a=o.d;o.s==="ok"?t.resolve(a):t.reject(a)}};this.outstandingGets_.push(r),this.outstandingGetCount_++;const i=this.outstandingGets_.length-1;return this.connected_&&this.sendGet_(i),t.promise}listen(e,t,s,r){this.initConnection_();const i=e._queryIdentifier,o=e._path.toString();this.log_("Listen called for "+o+" "+i),this.listens.has(o)||this.listens.set(o,new Map),H(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"listen() called for non-default but complete query"),H(!this.listens.get(o).has(i),"listen() called twice for same path/queryId.");const a={onComplete:r,hashFn:t,query:e,tag:s};this.listens.get(o).set(i,a),this.connected_&&this.sendListen_(a)}sendGet_(e){const t=this.outstandingGets_[e];this.sendRequest("g",t.request,s=>{delete this.outstandingGets_[e],this.outstandingGetCount_--,this.outstandingGetCount_===0&&(this.outstandingGets_=[]),t.onComplete&&t.onComplete(s)})}sendListen_(e){const t=e.query,s=t._path.toString(),r=t._queryIdentifier;this.log_("Listen on "+s+" for "+r);const i={p:s},o="q";e.tag&&(i.q=t._queryObject,i.t=e.tag),i.h=e.hashFn(),this.sendRequest(o,i,a=>{const B=a.d,c=a.s;yn.warnOnListenWarnings_(B,t),(this.listens.get(s)&&this.listens.get(s).get(r))===e&&(this.log_("listen response",a),c!=="ok"&&this.removeListen_(s,r),e.onComplete&&e.onComplete(c,B))})}static warnOnListenWarnings_(e,t){if(e&&typeof e=="object"&&un(e,"w")){const s=dr(e,"w");if(Array.isArray(s)&&~s.indexOf("no_index")){const r='".indexOn": "'+t._queryParams.getIndex().toString()+'"',i=t._path.toString();_t(`Using an unspecified index. Your data will be downloaded and filtered on the client. Consider adding ${r} at ${i} to your security rules for better performance.`)}}}refreshAuthToken(e){this.authToken_=e,this.log_("Auth token refreshed"),this.authToken_?this.tryAuth():this.connected_&&this.sendRequest("unauth",{},()=>{}),this.reduceReconnectDelayIfAdminCredential_(e)}reduceReconnectDelayIfAdminCredential_(e){(e&&e.length===40||YE(e))&&(this.log_("Admin auth credential detected.  Reducing max reconnect time."),this.maxReconnectDelay_=gC)}refreshAppCheckToken(e){this.appCheckToken_=e,this.log_("App check token refreshed"),this.appCheckToken_?this.tryAppCheck():this.connected_&&this.sendRequest("unappeck",{},()=>{})}tryAuth(){if(this.connected_&&this.authToken_){const e=this.authToken_,t=$E(e)?"auth":"gauth",s={cred:e};this.authOverride_===null?s.noauth=!0:typeof this.authOverride_=="object"&&(s.authvar=this.authOverride_),this.sendRequest(t,s,r=>{const i=r.s,o=r.d||"error";this.authToken_===e&&(i==="ok"?this.invalidAuthTokenCount_=0:this.onAuthRevoked_(i,o))})}}tryAppCheck(){this.connected_&&this.appCheckToken_&&this.sendRequest("appcheck",{token:this.appCheckToken_},e=>{const t=e.s,s=e.d||"error";t==="ok"?this.invalidAppCheckTokenCount_=0:this.onAppCheckRevoked_(t,s)})}unlisten(e,t){const s=e._path.toString(),r=e._queryIdentifier;this.log_("Unlisten called for "+s+" "+r),H(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"unlisten() called for non-default but complete query"),this.removeListen_(s,r)&&this.connected_&&this.sendUnlisten_(s,r,e._queryObject,t)}sendUnlisten_(e,t,s,r){this.log_("Unlisten on "+e+" for "+t);const i={p:e},o="n";r&&(i.q=s,i.t=r),this.sendRequest(o,i)}onDisconnectPut(e,t,s){this.initConnection_(),this.connected_?this.sendOnDisconnect_("o",e,t,s):this.onDisconnectRequestQueue_.push({pathString:e,action:"o",data:t,onComplete:s})}onDisconnectMerge(e,t,s){this.initConnection_(),this.connected_?this.sendOnDisconnect_("om",e,t,s):this.onDisconnectRequestQueue_.push({pathString:e,action:"om",data:t,onComplete:s})}onDisconnectCancel(e,t){this.initConnection_(),this.connected_?this.sendOnDisconnect_("oc",e,null,t):this.onDisconnectRequestQueue_.push({pathString:e,action:"oc",data:null,onComplete:t})}sendOnDisconnect_(e,t,s,r){const i={p:t,d:s};this.log_("onDisconnect "+e,i),this.sendRequest(e,i,o=>{r&&setTimeout(()=>{r(o.s,o.d)},Math.floor(0))})}put(e,t,s,r){this.putInternal("p",e,t,s,r)}merge(e,t,s,r){this.putInternal("m",e,t,s,r)}putInternal(e,t,s,r,i){this.initConnection_();const o={p:t,d:s};i!==void 0&&(o.h=i),this.outstandingPuts_.push({action:e,request:o,onComplete:r}),this.outstandingPutCount_++;const a=this.outstandingPuts_.length-1;this.connected_?this.sendPut_(a):this.log_("Buffering put: "+t)}sendPut_(e){const t=this.outstandingPuts_[e].action,s=this.outstandingPuts_[e].request,r=this.outstandingPuts_[e].onComplete;this.outstandingPuts_[e].queued=this.connected_,this.sendRequest(t,s,i=>{this.log_(t+" response",i),delete this.outstandingPuts_[e],this.outstandingPutCount_--,this.outstandingPutCount_===0&&(this.outstandingPuts_=[]),r&&r(i.s,i.d)})}reportStats(e){if(this.connected_){const t={c:e};this.log_("reportStats",t),this.sendRequest("s",t,s=>{if(s.s!=="ok"){const i=s.d;this.log_("reportStats","Error sending stats: "+i)}})}}onDataMessage_(e){if("r"in e){this.log_("from server: "+$e(e));const t=e.r,s=this.requestCBHash_[t];s&&(delete this.requestCBHash_[t],s(e.b))}else{if("error"in e)throw"A server-side error has occurred: "+e.error;"a"in e&&this.onDataPush_(e.a,e.b)}}onDataPush_(e,t){this.log_("handleServerMessage",e,t),e==="d"?this.onDataUpdate_(t.p,t.d,!1,t.t):e==="m"?this.onDataUpdate_(t.p,t.d,!0,t.t):e==="c"?this.onListenRevoked_(t.p,t.q):e==="ac"?this.onAuthRevoked_(t.s,t.d):e==="apc"?this.onAppCheckRevoked_(t.s,t.d):e==="sd"?this.onSecurityDebugPacket_(t):nc("Unrecognized action received from server: "+$e(e)+`
Are you using the latest client?`)}onReady_(e,t){this.log_("connection ready"),this.connected_=!0,this.lastConnectionEstablishedTime_=new Date().getTime(),this.handleTimestamp_(e),this.lastSessionId=t,this.firstConnection_&&this.sendConnectStats_(),this.restoreState_(),this.firstConnection_=!1,this.onConnectStatus_(!0)}scheduleConnect_(e){H(!this.realtime_,"Scheduling a connect when we're already connected/ing?"),this.establishConnectionTimer_&&clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=setTimeout(()=>{this.establishConnectionTimer_=null,this.establishConnection_()},Math.floor(e))}initConnection_(){!this.realtime_&&this.firstConnection_&&this.scheduleConnect_(0)}onVisible_(e){e&&!this.visible_&&this.reconnectDelay_===this.maxReconnectDelay_&&(this.log_("Window became visible.  Reducing delay."),this.reconnectDelay_=ci,this.realtime_||this.scheduleConnect_(0)),this.visible_=e}onOnline_(e){e?(this.log_("Browser went online."),this.reconnectDelay_=ci,this.realtime_||this.scheduleConnect_(0)):(this.log_("Browser went offline.  Killing connection."),this.realtime_&&this.realtime_.close())}onRealtimeDisconnect_(){if(this.log_("data client disconnected"),this.connected_=!1,this.realtime_=null,this.cancelSentTransactions_(),this.requestCBHash_={},this.shouldReconnect_()){this.visible_?this.lastConnectionEstablishedTime_&&(new Date().getTime()-this.lastConnectionEstablishedTime_>n0&&(this.reconnectDelay_=ci),this.lastConnectionEstablishedTime_=null):(this.log_("Window isn't visible.  Delaying reconnect."),this.reconnectDelay_=this.maxReconnectDelay_,this.lastConnectionAttemptTime_=new Date().getTime());const e=Math.max(0,new Date().getTime()-this.lastConnectionAttemptTime_);let t=Math.max(0,this.reconnectDelay_-e);t=Math.random()*t,this.log_("Trying to reconnect in "+t+"ms"),this.scheduleConnect_(t),this.reconnectDelay_=Math.min(this.maxReconnectDelay_,this.reconnectDelay_*t0)}this.onConnectStatus_(!1)}async establishConnection_(){if(this.shouldReconnect_()){this.log_("Making a connection attempt"),this.lastConnectionAttemptTime_=new Date().getTime(),this.lastConnectionEstablishedTime_=null;const e=this.onDataMessage_.bind(this),t=this.onReady_.bind(this),s=this.onRealtimeDisconnect_.bind(this),r=this.id+":"+yn.nextConnectionId_++,i=this.lastSessionId;let o=!1,a=null;const B=function(){a?a.close():(o=!0,s())},c=function(f){H(a,"sendRequest call when we're not connected not allowed."),a.sendRequest(f)};this.realtime_={close:B,sendRequest:c};const u=this.forceTokenRefresh_;this.forceTokenRefresh_=!1;try{const[f,C]=await Promise.all([this.authTokenProvider_.getToken(u),this.appCheckTokenProvider_.getToken(u)]);o?rt("getToken() completed but was canceled"):(rt("getToken() completed. Creating connection."),this.authToken_=f&&f.accessToken,this.appCheckToken_=C&&C.token,a=new zS(r,this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,e,t,s,g=>{_t(g+" ("+this.repoInfo_.toString()+")"),this.interrupt(s0)},i))}catch(f){this.log_("Failed to get token: "+f),o||(this.repoInfo_.nodeAdmin&&_t(f),B())}}}interrupt(e){rt("Interrupting connection for reason: "+e),this.interruptReasons_[e]=!0,this.realtime_?this.realtime_.close():(this.establishConnectionTimer_&&(clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=null),this.connected_&&this.onRealtimeDisconnect_())}resume(e){rt("Resuming connection for reason: "+e),delete this.interruptReasons_[e],df(this.interruptReasons_)&&(this.reconnectDelay_=ci,this.realtime_||this.scheduleConnect_(0))}handleTimestamp_(e){const t=e-new Date().getTime();this.onServerInfoUpdate_({serverTimeOffset:t})}cancelSentTransactions_(){for(let e=0;e<this.outstandingPuts_.length;e++){const t=this.outstandingPuts_[e];t&&"h"in t.request&&t.queued&&(t.onComplete&&t.onComplete("disconnect"),delete this.outstandingPuts_[e],this.outstandingPutCount_--)}this.outstandingPutCount_===0&&(this.outstandingPuts_=[])}onListenRevoked_(e,t){let s;t?s=t.map(i=>vu(i)).join("$"):s="default";const r=this.removeListen_(e,s);r&&r.onComplete&&r.onComplete("permission_denied")}removeListen_(e,t){const s=new De(e).toString();let r;if(this.listens.has(s)){const i=this.listens.get(s);r=i.get(t),i.delete(t),i.size===0&&this.listens.delete(s)}else r=void 0;return r}onAuthRevoked_(e,t){rt("Auth token revoked: "+e+"/"+t),this.authToken_=null,this.forceTokenRefresh_=!0,this.realtime_.close(),(e==="invalid_token"||e==="permission_denied")&&(this.invalidAuthTokenCount_++,this.invalidAuthTokenCount_>=mC&&(this.reconnectDelay_=gC,this.authTokenProvider_.notifyForInvalidToken()))}onAppCheckRevoked_(e,t){rt("App check token revoked: "+e+"/"+t),this.appCheckToken_=null,this.forceTokenRefresh_=!0,(e==="invalid_token"||e==="permission_denied")&&(this.invalidAppCheckTokenCount_++,this.invalidAppCheckTokenCount_>=mC&&this.appCheckTokenProvider_.notifyForInvalidToken())}onSecurityDebugPacket_(e){this.securityDebugCallback_?this.securityDebugCallback_(e):"msg"in e&&console.log("FIREBASE: "+e.msg.replace(`
`,`
FIREBASE: `))}restoreState_(){this.tryAuth(),this.tryAppCheck();for(const e of this.listens.values())for(const t of e.values())this.sendListen_(t);for(let e=0;e<this.outstandingPuts_.length;e++)this.outstandingPuts_[e]&&this.sendPut_(e);for(;this.onDisconnectRequestQueue_.length;){const e=this.onDisconnectRequestQueue_.shift();this.sendOnDisconnect_(e.action,e.pathString,e.data,e.onComplete)}for(let e=0;e<this.outstandingGets_.length;e++)this.outstandingGets_[e]&&this.sendGet_(e)}sendConnectStats_(){const e={};let t="js";e["sdk."+t+"."+km.replace(/\./g,"-")]=1,jC()?e["framework.cordova"]=1:JE()&&(e["framework.reactnative"]=1),this.reportStats(e)}shouldReconnect_(){const e=Na.getInstance().currentlyOnline();return df(this.interruptReasons_)&&e}}yn.nextPersistentConnectionId_=0;yn.nextConnectionId_=0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce{constructor(e,t){this.name=e,this.node=t}static Wrap(e,t){return new ce(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _l{getCompare(){return this.compare.bind(this)}indexedValueChanged(e,t){const s=new ce(us,e),r=new ce(us,t);return this.compare(s,r)!==0}minPost(){return ce.MIN}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ta;class B_ extends _l{static get __EMPTY_NODE(){return ta}static set __EMPTY_NODE(e){ta=e}compare(e,t){return zs(e.name,t.name)}isDefinedOn(e){throw br("KeyIndex.isDefinedOn not expected to be called.")}indexedValueChanged(e,t){return!1}minPost(){return ce.MIN}maxPost(){return new ce(Sn,ta)}makePost(e,t){return H(typeof e=="string","KeyIndex indexValue must always be a string."),new ce(e,ta)}toString(){return".key"}}const ln=new B_;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class na{constructor(e,t,s,r,i=null){this.isReverse_=r,this.resultGenerator_=i,this.nodeStack_=[];let o=1;for(;!e.isEmpty();)if(e=e,o=t?s(e.key,t):1,r&&(o*=-1),o<0)this.isReverse_?e=e.left:e=e.right;else if(o===0){this.nodeStack_.push(e);break}else this.nodeStack_.push(e),this.isReverse_?e=e.right:e=e.left}getNext(){if(this.nodeStack_.length===0)return null;let e=this.nodeStack_.pop(),t;if(this.resultGenerator_?t=this.resultGenerator_(e.key,e.value):t={key:e.key,value:e.value},this.isReverse_)for(e=e.left;!e.isEmpty();)this.nodeStack_.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack_.push(e),e=e.left;return t}hasNext(){return this.nodeStack_.length>0}peek(){if(this.nodeStack_.length===0)return null;const e=this.nodeStack_[this.nodeStack_.length-1];return this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value}}}class tt{constructor(e,t,s,r,i){this.key=e,this.value=t,this.color=s??tt.RED,this.left=r??It.EMPTY_NODE,this.right=i??It.EMPTY_NODE}copy(e,t,s,r,i){return new tt(e??this.key,t??this.value,s??this.color,r??this.left,i??this.right)}count(){return this.left.count()+1+this.right.count()}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||!!e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min_(){return this.left.isEmpty()?this:this.left.min_()}minKey(){return this.min_().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let r=this;const i=s(e,r.key);return i<0?r=r.copy(null,null,null,r.left.insert(e,t,s),null):i===0?r=r.copy(null,t,null,null,null):r=r.copy(null,null,null,null,r.right.insert(e,t,s)),r.fixUp_()}removeMin_(){if(this.left.isEmpty())return It.EMPTY_NODE;let e=this;return!e.left.isRed_()&&!e.left.left.isRed_()&&(e=e.moveRedLeft_()),e=e.copy(null,null,null,e.left.removeMin_(),null),e.fixUp_()}remove(e,t){let s,r;if(s=this,t(e,s.key)<0)!s.left.isEmpty()&&!s.left.isRed_()&&!s.left.left.isRed_()&&(s=s.moveRedLeft_()),s=s.copy(null,null,null,s.left.remove(e,t),null);else{if(s.left.isRed_()&&(s=s.rotateRight_()),!s.right.isEmpty()&&!s.right.isRed_()&&!s.right.left.isRed_()&&(s=s.moveRedRight_()),t(e,s.key)===0){if(s.right.isEmpty())return It.EMPTY_NODE;r=s.right.min_(),s=s.copy(r.key,r.value,null,null,s.right.removeMin_())}s=s.copy(null,null,null,null,s.right.remove(e,t))}return s.fixUp_()}isRed_(){return this.color}fixUp_(){let e=this;return e.right.isRed_()&&!e.left.isRed_()&&(e=e.rotateLeft_()),e.left.isRed_()&&e.left.left.isRed_()&&(e=e.rotateRight_()),e.left.isRed_()&&e.right.isRed_()&&(e=e.colorFlip_()),e}moveRedLeft_(){let e=this.colorFlip_();return e.right.left.isRed_()&&(e=e.copy(null,null,null,null,e.right.rotateRight_()),e=e.rotateLeft_(),e=e.colorFlip_()),e}moveRedRight_(){let e=this.colorFlip_();return e.left.left.isRed_()&&(e=e.rotateRight_(),e=e.colorFlip_()),e}rotateLeft_(){const e=this.copy(null,null,tt.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight_(){const e=this.copy(null,null,tt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip_(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth_(){const e=this.check_();return Math.pow(2,e)<=this.count()+1}check_(){if(this.isRed_()&&this.left.isRed_())throw new Error("Red node has red child("+this.key+","+this.value+")");if(this.right.isRed_())throw new Error("Right child of ("+this.key+","+this.value+") is red");const e=this.left.check_();if(e!==this.right.check_())throw new Error("Black depths differ");return e+(this.isRed_()?0:1)}}tt.RED=!0;tt.BLACK=!1;class r0{copy(e,t,s,r,i){return this}insert(e,t,s){return new tt(e,t,null)}remove(e,t){return this}count(){return 0}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}check_(){return 0}isRed_(){return!1}}class It{constructor(e,t=It.EMPTY_NODE){this.comparator_=e,this.root_=t}insert(e,t){return new It(this.comparator_,this.root_.insert(e,t,this.comparator_).copy(null,null,tt.BLACK,null,null))}remove(e){return new It(this.comparator_,this.root_.remove(e,this.comparator_).copy(null,null,tt.BLACK,null,null))}get(e){let t,s=this.root_;for(;!s.isEmpty();){if(t=this.comparator_(e,s.key),t===0)return s.value;t<0?s=s.left:t>0&&(s=s.right)}return null}getPredecessorKey(e){let t,s=this.root_,r=null;for(;!s.isEmpty();)if(t=this.comparator_(e,s.key),t===0){if(s.left.isEmpty())return r?r.key:null;for(s=s.left;!s.right.isEmpty();)s=s.right;return s.key}else t<0?s=s.left:t>0&&(r=s,s=s.right);throw new Error("Attempted to find predecessor key for a nonexistent key.  What gives?")}isEmpty(){return this.root_.isEmpty()}count(){return this.root_.count()}minKey(){return this.root_.minKey()}maxKey(){return this.root_.maxKey()}inorderTraversal(e){return this.root_.inorderTraversal(e)}reverseTraversal(e){return this.root_.reverseTraversal(e)}getIterator(e){return new na(this.root_,null,this.comparator_,!1,e)}getIteratorFrom(e,t){return new na(this.root_,e,this.comparator_,!1,t)}getReverseIteratorFrom(e,t){return new na(this.root_,e,this.comparator_,!0,t)}getReverseIterator(e){return new na(this.root_,null,this.comparator_,!0,e)}}It.EMPTY_NODE=new r0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function i0(n,e){return zs(n.name,e.name)}function Ou(n,e){return zs(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let rc;function o0(n){rc=n}const c_=function(n){return typeof n=="number"?"number:"+Um(n):"string:"+n},u_=function(n){if(n.isLeafNode()){const e=n.val();H(typeof e=="string"||typeof e=="number"||typeof e=="object"&&un(e,".sv"),"Priority must be a string or number.")}else H(n===rc||n.isEmpty(),"priority of unexpected type.");H(n===rc||n.getPriority().isEmpty(),"Priority nodes can't have a priority of their own.")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let _C;class Ze{static set __childrenNodeConstructor(e){_C=e}static get __childrenNodeConstructor(){return _C}constructor(e,t=Ze.__childrenNodeConstructor.EMPTY_NODE){this.value_=e,this.priorityNode_=t,this.lazyHash_=null,H(this.value_!==void 0&&this.value_!==null,"LeafNode shouldn't be created with null/undefined value."),u_(this.priorityNode_)}isLeafNode(){return!0}getPriority(){return this.priorityNode_}updatePriority(e){return new Ze(this.value_,e)}getImmediateChild(e){return e===".priority"?this.priorityNode_:Ze.__childrenNodeConstructor.EMPTY_NODE}getChild(e){return le(e)?this:ae(e)===".priority"?this.priorityNode_:Ze.__childrenNodeConstructor.EMPTY_NODE}hasChild(){return!1}getPredecessorChildName(e,t){return null}updateImmediateChild(e,t){return e===".priority"?this.updatePriority(t):t.isEmpty()&&e!==".priority"?this:Ze.__childrenNodeConstructor.EMPTY_NODE.updateImmediateChild(e,t).updatePriority(this.priorityNode_)}updateChild(e,t){const s=ae(e);return s===null?t:t.isEmpty()&&s!==".priority"?this:(H(s!==".priority"||hs(e)===1,".priority must be the last token in a path"),this.updateImmediateChild(s,Ze.__childrenNodeConstructor.EMPTY_NODE.updateChild(Re(e),t)))}isEmpty(){return!1}numChildren(){return 0}forEachChild(e,t){return!1}val(e){return e&&!this.getPriority().isEmpty()?{".value":this.getValue(),".priority":this.getPriority().val()}:this.getValue()}hash(){if(this.lazyHash_===null){let e="";this.priorityNode_.isEmpty()||(e+="priority:"+c_(this.priorityNode_.val())+":");const t=typeof this.value_;e+=t+":",t==="number"?e+=Um(this.value_):e+=this.value_,this.lazyHash_=Vm(e)}return this.lazyHash_}getValue(){return this.value_}compareTo(e){return e===Ze.__childrenNodeConstructor.EMPTY_NODE?1:e instanceof Ze.__childrenNodeConstructor?-1:(H(e.isLeafNode(),"Unknown node type"),this.compareToLeafNode_(e))}compareToLeafNode_(e){const t=typeof e.value_,s=typeof this.value_,r=Ze.VALUE_TYPE_ORDER.indexOf(t),i=Ze.VALUE_TYPE_ORDER.indexOf(s);return H(r>=0,"Unknown leaf type: "+t),H(i>=0,"Unknown leaf type: "+s),r===i?s==="object"?0:this.value_<e.value_?-1:this.value_===e.value_?0:1:i-r}withIndex(){return this}isIndexed(){return!0}equals(e){if(e===this)return!0;if(e.isLeafNode()){const t=e;return this.value_===t.value_&&this.priorityNode_.equals(t.priorityNode_)}else return!1}}Ze.VALUE_TYPE_ORDER=["object","boolean","number","string"];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let h_,f_;function a0(n){h_=n}function l0(n){f_=n}class B0 extends _l{compare(e,t){const s=e.node.getPriority(),r=t.node.getPriority(),i=s.compareTo(r);return i===0?zs(e.name,t.name):i}isDefinedOn(e){return!e.getPriority().isEmpty()}indexedValueChanged(e,t){return!e.getPriority().equals(t.getPriority())}minPost(){return ce.MIN}maxPost(){return new ce(Sn,new Ze("[PRIORITY-POST]",f_))}makePost(e,t){const s=h_(e);return new ce(t,new Ze("[PRIORITY-POST]",s))}toString(){return".priority"}}const Oe=new B0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const c0=Math.log(2);class u0{constructor(e){const t=i=>parseInt(Math.log(i)/c0,10),s=i=>parseInt(Array(i+1).join("1"),2);this.count=t(e+1),this.current_=this.count-1;const r=s(this.count);this.bits_=e+1&r}nextBitIsOne(){const e=!(this.bits_&1<<this.current_);return this.current_--,e}}const Pa=function(n,e,t,s){n.sort(e);const r=function(B,c){const u=c-B;let f,C;if(u===0)return null;if(u===1)return f=n[B],C=t?t(f):f,new tt(C,f.node,tt.BLACK,null,null);{const g=parseInt(u/2,10)+B,E=r(B,g),b=r(g+1,c);return f=n[g],C=t?t(f):f,new tt(C,f.node,tt.BLACK,E,b)}},i=function(B){let c=null,u=null,f=n.length;const C=function(E,b){const F=f-E,j=f;f-=E;const te=r(F+1,j),ie=n[F],me=t?t(ie):ie;g(new tt(me,ie.node,b,null,te))},g=function(E){c?(c.left=E,c=E):(u=E,c=E)};for(let E=0;E<B.count;++E){const b=B.nextBitIsOne(),F=Math.pow(2,B.count-(E+1));b?C(F,tt.BLACK):(C(F,tt.BLACK),C(F,tt.RED))}return u},o=new u0(n.length),a=i(o);return new It(s||e,a)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let yB;const nr={};class En{static get Default(){return H(nr&&Oe,"ChildrenNode.ts has not been loaded"),yB=yB||new En({".priority":nr},{".priority":Oe}),yB}constructor(e,t){this.indexes_=e,this.indexSet_=t}get(e){const t=dr(this.indexes_,e);if(!t)throw new Error("No index defined for "+e);return t instanceof It?t:null}hasIndex(e){return un(this.indexSet_,e.toString())}addIndex(e,t){H(e!==ln,"KeyIndex always exists and isn't meant to be added to the IndexMap.");const s=[];let r=!1;const i=t.getIterator(ce.Wrap);let o=i.getNext();for(;o;)r=r||e.isDefinedOn(o.node),s.push(o),o=i.getNext();let a;r?a=Pa(s,e.getCompare()):a=nr;const B=e.toString(),c={...this.indexSet_};c[B]=e;const u={...this.indexes_};return u[B]=a,new En(u,c)}addToIndexes(e,t){const s=fa(this.indexes_,(r,i)=>{const o=dr(this.indexSet_,i);if(H(o,"Missing index implementation for "+i),r===nr)if(o.isDefinedOn(e.node)){const a=[],B=t.getIterator(ce.Wrap);let c=B.getNext();for(;c;)c.name!==e.name&&a.push(c),c=B.getNext();return a.push(e),Pa(a,o.getCompare())}else return nr;else{const a=t.get(e.name);let B=r;return a&&(B=B.remove(new ce(e.name,a))),B.insert(e,e.node)}});return new En(s,this.indexSet_)}removeFromIndexes(e,t){const s=fa(this.indexes_,r=>{if(r===nr)return r;{const i=t.get(e.name);return i?r.remove(new ce(e.name,i)):r}});return new En(s,this.indexSet_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ui;class se{static get EMPTY_NODE(){return ui||(ui=new se(new It(Ou),null,En.Default))}constructor(e,t,s){this.children_=e,this.priorityNode_=t,this.indexMap_=s,this.lazyHash_=null,this.priorityNode_&&u_(this.priorityNode_),this.children_.isEmpty()&&H(!this.priorityNode_||this.priorityNode_.isEmpty(),"An empty node cannot have a priority")}isLeafNode(){return!1}getPriority(){return this.priorityNode_||ui}updatePriority(e){return this.children_.isEmpty()?this:new se(this.children_,e,this.indexMap_)}getImmediateChild(e){if(e===".priority")return this.getPriority();{const t=this.children_.get(e);return t===null?ui:t}}getChild(e){const t=ae(e);return t===null?this:this.getImmediateChild(t).getChild(Re(e))}hasChild(e){return this.children_.get(e)!==null}updateImmediateChild(e,t){if(H(t,"We should always be passing snapshot nodes"),e===".priority")return this.updatePriority(t);{const s=new ce(e,t);let r,i;t.isEmpty()?(r=this.children_.remove(e),i=this.indexMap_.removeFromIndexes(s,this.children_)):(r=this.children_.insert(e,t),i=this.indexMap_.addToIndexes(s,this.children_));const o=r.isEmpty()?ui:this.priorityNode_;return new se(r,o,i)}}updateChild(e,t){const s=ae(e);if(s===null)return t;{H(ae(e)!==".priority"||hs(e)===1,".priority must be the last token in a path");const r=this.getImmediateChild(s).updateChild(Re(e),t);return this.updateImmediateChild(s,r)}}isEmpty(){return this.children_.isEmpty()}numChildren(){return this.children_.count()}val(e){if(this.isEmpty())return null;const t={};let s=0,r=0,i=!0;if(this.forEachChild(Oe,(o,a)=>{t[o]=a.val(e),s++,i&&se.INTEGER_REGEXP_.test(o)?r=Math.max(r,Number(o)):i=!1}),!e&&i&&r<2*s){const o=[];for(const a in t)o[a]=t[a];return o}else return e&&!this.getPriority().isEmpty()&&(t[".priority"]=this.getPriority().val()),t}hash(){if(this.lazyHash_===null){let e="";this.getPriority().isEmpty()||(e+="priority:"+c_(this.getPriority().val())+":"),this.forEachChild(Oe,(t,s)=>{const r=s.hash();r!==""&&(e+=":"+t+":"+r)}),this.lazyHash_=e===""?"":Vm(e)}return this.lazyHash_}getPredecessorChildName(e,t,s){const r=this.resolveIndex_(s);if(r){const i=r.getPredecessorKey(new ce(e,t));return i?i.name:null}else return this.children_.getPredecessorKey(e)}getFirstChildName(e){const t=this.resolveIndex_(e);if(t){const s=t.minKey();return s&&s.name}else return this.children_.minKey()}getFirstChild(e){const t=this.getFirstChildName(e);return t?new ce(t,this.children_.get(t)):null}getLastChildName(e){const t=this.resolveIndex_(e);if(t){const s=t.maxKey();return s&&s.name}else return this.children_.maxKey()}getLastChild(e){const t=this.getLastChildName(e);return t?new ce(t,this.children_.get(t)):null}forEachChild(e,t){const s=this.resolveIndex_(e);return s?s.inorderTraversal(r=>t(r.name,r.node)):this.children_.inorderTraversal(t)}getIterator(e){return this.getIteratorFrom(e.minPost(),e)}getIteratorFrom(e,t){const s=this.resolveIndex_(t);if(s)return s.getIteratorFrom(e,r=>r);{const r=this.children_.getIteratorFrom(e.name,ce.Wrap);let i=r.peek();for(;i!=null&&t.compare(i,e)<0;)r.getNext(),i=r.peek();return r}}getReverseIterator(e){return this.getReverseIteratorFrom(e.maxPost(),e)}getReverseIteratorFrom(e,t){const s=this.resolveIndex_(t);if(s)return s.getReverseIteratorFrom(e,r=>r);{const r=this.children_.getReverseIteratorFrom(e.name,ce.Wrap);let i=r.peek();for(;i!=null&&t.compare(i,e)>0;)r.getNext(),i=r.peek();return r}}compareTo(e){return this.isEmpty()?e.isEmpty()?0:-1:e.isLeafNode()||e.isEmpty()?1:e===To?-1:0}withIndex(e){if(e===ln||this.indexMap_.hasIndex(e))return this;{const t=this.indexMap_.addIndex(e,this.children_);return new se(this.children_,this.priorityNode_,t)}}isIndexed(e){return e===ln||this.indexMap_.hasIndex(e)}equals(e){if(e===this)return!0;if(e.isLeafNode())return!1;{const t=e;if(this.getPriority().equals(t.getPriority()))if(this.children_.count()===t.children_.count()){const s=this.getIterator(Oe),r=t.getIterator(Oe);let i=s.getNext(),o=r.getNext();for(;i&&o;){if(i.name!==o.name||!i.node.equals(o.node))return!1;i=s.getNext(),o=r.getNext()}return i===null&&o===null}else return!1;else return!1}}resolveIndex_(e){return e===ln?null:this.indexMap_.get(e.toString())}}se.INTEGER_REGEXP_=/^(0|[1-9]\d*)$/;class h0 extends se{constructor(){super(new It(Ou),se.EMPTY_NODE,En.Default)}compareTo(e){return e===this?0:1}equals(e){return e===this}getPriority(){return this}getImmediateChild(e){return se.EMPTY_NODE}isEmpty(){return!1}}const To=new h0;Object.defineProperties(ce,{MIN:{value:new ce(us,se.EMPTY_NODE)},MAX:{value:new ce(Sn,To)}});B_.__EMPTY_NODE=se.EMPTY_NODE;Ze.__childrenNodeConstructor=se;o0(To);l0(To);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const f0=!0;function We(n,e=null){if(n===null)return se.EMPTY_NODE;if(typeof n=="object"&&".priority"in n&&(e=n[".priority"]),H(e===null||typeof e=="string"||typeof e=="number"||typeof e=="object"&&".sv"in e,"Invalid priority type found: "+typeof e),typeof n=="object"&&".value"in n&&n[".value"]!==null&&(n=n[".value"]),typeof n!="object"||".sv"in n){const t=n;return new Ze(t,We(e))}if(!(n instanceof Array)&&f0){const t=[];let s=!1;if(lt(n,(o,a)=>{if(o.substring(0,1)!=="."){const B=We(a);B.isEmpty()||(s=s||!B.getPriority().isEmpty(),t.push(new ce(o,B)))}}),t.length===0)return se.EMPTY_NODE;const i=Pa(t,i0,o=>o.name,Ou);if(s){const o=Pa(t,Oe.getCompare());return new se(i,We(e),new En({".priority":o},{".priority":Oe}))}else return new se(i,We(e),En.Default)}else{let t=se.EMPTY_NODE;return lt(n,(s,r)=>{if(un(n,s)&&s.substring(0,1)!=="."){const i=We(r);(i.isLeafNode()||!i.isEmpty())&&(t=t.updateImmediateChild(s,i))}}),t.updatePriority(We(e))}}a0(We);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lu extends _l{constructor(e){super(),this.indexPath_=e,H(!le(e)&&ae(e)!==".priority","Can't create PathIndex with empty path or .priority key")}extractChild(e){return e.getChild(this.indexPath_)}isDefinedOn(e){return!e.getChild(this.indexPath_).isEmpty()}compare(e,t){const s=this.extractChild(e.node),r=this.extractChild(t.node),i=s.compareTo(r);return i===0?zs(e.name,t.name):i}makePost(e,t){const s=We(e),r=se.EMPTY_NODE.updateChild(this.indexPath_,s);return new ce(t,r)}maxPost(){const e=se.EMPTY_NODE.updateChild(this.indexPath_,To);return new ce(Sn,e)}toString(){return Yi(this.indexPath_,0).join("/")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d0 extends _l{compare(e,t){const s=e.node.compareTo(t.node);return s===0?zs(e.name,t.name):s}isDefinedOn(e){return!0}indexedValueChanged(e,t){return!e.equals(t)}minPost(){return ce.MIN}maxPost(){return ce.MAX}makePost(e,t){const s=We(e);return new ce(t,s)}toString(){return".value"}}const xu=new d0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function d_(n){return{type:"value",snapshotNode:n}}function Tr(n,e){return{type:"child_added",snapshotNode:e,childName:n}}function Xi(n,e){return{type:"child_removed",snapshotNode:e,childName:n}}function Zi(n,e,t){return{type:"child_changed",snapshotNode:e,childName:n,oldSnap:t}}function C0(n,e){return{type:"child_moved",snapshotNode:e,childName:n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ku{constructor(e){this.index_=e}updateChild(e,t,s,r,i,o){H(e.isIndexed(this.index_),"A node must be indexed if only a child is updated");const a=e.getImmediateChild(t);return a.getChild(r).equals(s.getChild(r))&&a.isEmpty()===s.isEmpty()||(o!=null&&(s.isEmpty()?e.hasChild(t)?o.trackChildChange(Xi(t,a)):H(e.isLeafNode(),"A child remove without an old child only makes sense on a leaf node"):a.isEmpty()?o.trackChildChange(Tr(t,s)):o.trackChildChange(Zi(t,s,a))),e.isLeafNode()&&s.isEmpty())?e:e.updateImmediateChild(t,s).withIndex(this.index_)}updateFullNode(e,t,s){return s!=null&&(e.isLeafNode()||e.forEachChild(Oe,(r,i)=>{t.hasChild(r)||s.trackChildChange(Xi(r,i))}),t.isLeafNode()||t.forEachChild(Oe,(r,i)=>{if(e.hasChild(r)){const o=e.getImmediateChild(r);o.equals(i)||s.trackChildChange(Zi(r,i,o))}else s.trackChildChange(Tr(r,i))})),t.withIndex(this.index_)}updatePriority(e,t){return e.isEmpty()?se.EMPTY_NODE:e.updatePriority(t)}filtersNodes(){return!1}getIndexedFilter(){return this}getIndex(){return this.index_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eo{constructor(e){this.indexedFilter_=new ku(e.getIndex()),this.index_=e.getIndex(),this.startPost_=eo.getStartPost_(e),this.endPost_=eo.getEndPost_(e),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}getStartPost(){return this.startPost_}getEndPost(){return this.endPost_}matches(e){const t=this.startIsInclusive_?this.index_.compare(this.getStartPost(),e)<=0:this.index_.compare(this.getStartPost(),e)<0,s=this.endIsInclusive_?this.index_.compare(e,this.getEndPost())<=0:this.index_.compare(e,this.getEndPost())<0;return t&&s}updateChild(e,t,s,r,i,o){return this.matches(new ce(t,s))||(s=se.EMPTY_NODE),this.indexedFilter_.updateChild(e,t,s,r,i,o)}updateFullNode(e,t,s){t.isLeafNode()&&(t=se.EMPTY_NODE);let r=t.withIndex(this.index_);r=r.updatePriority(se.EMPTY_NODE);const i=this;return t.forEachChild(Oe,(o,a)=>{i.matches(new ce(o,a))||(r=r.updateImmediateChild(o,se.EMPTY_NODE))}),this.indexedFilter_.updateFullNode(e,r,s)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.indexedFilter_}getIndex(){return this.index_}static getStartPost_(e){if(e.hasStart()){const t=e.getIndexStartName();return e.getIndex().makePost(e.getIndexStartValue(),t)}else return e.getIndex().minPost()}static getEndPost_(e){if(e.hasEnd()){const t=e.getIndexEndName();return e.getIndex().makePost(e.getIndexEndValue(),t)}else return e.getIndex().maxPost()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p0{constructor(e){this.withinDirectionalStart=t=>this.reverse_?this.withinEndPost(t):this.withinStartPost(t),this.withinDirectionalEnd=t=>this.reverse_?this.withinStartPost(t):this.withinEndPost(t),this.withinStartPost=t=>{const s=this.index_.compare(this.rangedFilter_.getStartPost(),t);return this.startIsInclusive_?s<=0:s<0},this.withinEndPost=t=>{const s=this.index_.compare(t,this.rangedFilter_.getEndPost());return this.endIsInclusive_?s<=0:s<0},this.rangedFilter_=new eo(e),this.index_=e.getIndex(),this.limit_=e.getLimit(),this.reverse_=!e.isViewFromLeft(),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}updateChild(e,t,s,r,i,o){return this.rangedFilter_.matches(new ce(t,s))||(s=se.EMPTY_NODE),e.getImmediateChild(t).equals(s)?e:e.numChildren()<this.limit_?this.rangedFilter_.getIndexedFilter().updateChild(e,t,s,r,i,o):this.fullLimitUpdateChild_(e,t,s,i,o)}updateFullNode(e,t,s){let r;if(t.isLeafNode()||t.isEmpty())r=se.EMPTY_NODE.withIndex(this.index_);else if(this.limit_*2<t.numChildren()&&t.isIndexed(this.index_)){r=se.EMPTY_NODE.withIndex(this.index_);let i;this.reverse_?i=t.getReverseIteratorFrom(this.rangedFilter_.getEndPost(),this.index_):i=t.getIteratorFrom(this.rangedFilter_.getStartPost(),this.index_);let o=0;for(;i.hasNext()&&o<this.limit_;){const a=i.getNext();if(this.withinDirectionalStart(a))if(this.withinDirectionalEnd(a))r=r.updateImmediateChild(a.name,a.node),o++;else break;else continue}}else{r=t.withIndex(this.index_),r=r.updatePriority(se.EMPTY_NODE);let i;this.reverse_?i=r.getReverseIterator(this.index_):i=r.getIterator(this.index_);let o=0;for(;i.hasNext();){const a=i.getNext();o<this.limit_&&this.withinDirectionalStart(a)&&this.withinDirectionalEnd(a)?o++:r=r.updateImmediateChild(a.name,se.EMPTY_NODE)}}return this.rangedFilter_.getIndexedFilter().updateFullNode(e,r,s)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.rangedFilter_.getIndexedFilter()}getIndex(){return this.index_}fullLimitUpdateChild_(e,t,s,r,i){let o;if(this.reverse_){const f=this.index_.getCompare();o=(C,g)=>f(g,C)}else o=this.index_.getCompare();const a=e;H(a.numChildren()===this.limit_,"");const B=new ce(t,s),c=this.reverse_?a.getFirstChild(this.index_):a.getLastChild(this.index_),u=this.rangedFilter_.matches(B);if(a.hasChild(t)){const f=a.getImmediateChild(t);let C=r.getChildAfterChild(this.index_,c,this.reverse_);for(;C!=null&&(C.name===t||a.hasChild(C.name));)C=r.getChildAfterChild(this.index_,C,this.reverse_);const g=C==null?1:o(C,B);if(u&&!s.isEmpty()&&g>=0)return i!=null&&i.trackChildChange(Zi(t,s,f)),a.updateImmediateChild(t,s);{i!=null&&i.trackChildChange(Xi(t,f));const b=a.updateImmediateChild(t,se.EMPTY_NODE);return C!=null&&this.rangedFilter_.matches(C)?(i!=null&&i.trackChildChange(Tr(C.name,C.node)),b.updateImmediateChild(C.name,C.node)):b}}else return s.isEmpty()?e:u&&o(c,B)>=0?(i!=null&&(i.trackChildChange(Xi(c.name,c.node)),i.trackChildChange(Tr(t,s))),a.updateImmediateChild(t,s).updateImmediateChild(c.name,se.EMPTY_NODE)):e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mu{constructor(){this.limitSet_=!1,this.startSet_=!1,this.startNameSet_=!1,this.startAfterSet_=!1,this.endSet_=!1,this.endNameSet_=!1,this.endBeforeSet_=!1,this.limit_=0,this.viewFrom_="",this.indexStartValue_=null,this.indexStartName_="",this.indexEndValue_=null,this.indexEndName_="",this.index_=Oe}hasStart(){return this.startSet_}isViewFromLeft(){return this.viewFrom_===""?this.startSet_:this.viewFrom_==="l"}getIndexStartValue(){return H(this.startSet_,"Only valid if start has been set"),this.indexStartValue_}getIndexStartName(){return H(this.startSet_,"Only valid if start has been set"),this.startNameSet_?this.indexStartName_:us}hasEnd(){return this.endSet_}getIndexEndValue(){return H(this.endSet_,"Only valid if end has been set"),this.indexEndValue_}getIndexEndName(){return H(this.endSet_,"Only valid if end has been set"),this.endNameSet_?this.indexEndName_:Sn}hasLimit(){return this.limitSet_}hasAnchoredLimit(){return this.limitSet_&&this.viewFrom_!==""}getLimit(){return H(this.limitSet_,"Only valid if limit has been set"),this.limit_}getIndex(){return this.index_}loadsAllData(){return!(this.startSet_||this.endSet_||this.limitSet_)}isDefault(){return this.loadsAllData()&&this.index_===Oe}copy(){const e=new Mu;return e.limitSet_=this.limitSet_,e.limit_=this.limit_,e.startSet_=this.startSet_,e.startAfterSet_=this.startAfterSet_,e.indexStartValue_=this.indexStartValue_,e.startNameSet_=this.startNameSet_,e.indexStartName_=this.indexStartName_,e.endSet_=this.endSet_,e.endBeforeSet_=this.endBeforeSet_,e.indexEndValue_=this.indexEndValue_,e.endNameSet_=this.endNameSet_,e.indexEndName_=this.indexEndName_,e.index_=this.index_,e.viewFrom_=this.viewFrom_,e}}function g0(n){return n.loadsAllData()?new ku(n.getIndex()):n.hasLimit()?new p0(n):new eo(n)}function m0(n,e){const t=n.copy();return t.limitSet_=!0,t.limit_=e,t.viewFrom_="l",t}function _0(n,e){const t=n.copy();return t.limitSet_=!0,t.limit_=e,t.viewFrom_="r",t}function ic(n,e,t){const s=n.copy();return s.startSet_=!0,e===void 0&&(e=null),s.indexStartValue_=e,t!=null?(s.startNameSet_=!0,s.indexStartName_=t):(s.startNameSet_=!1,s.indexStartName_=""),s}function E0(n,e,t){let s;return n.index_===ln||t?s=ic(n,e,t):s=ic(n,e,Sn),s.startAfterSet_=!0,s}function oc(n,e,t){const s=n.copy();return s.endSet_=!0,e===void 0&&(e=null),s.indexEndValue_=e,t!==void 0?(s.endNameSet_=!0,s.indexEndName_=t):(s.endNameSet_=!1,s.indexEndName_=""),s}function D0(n,e,t){let s;return n.index_===ln||t?s=oc(n,e,t):s=oc(n,e,us),s.endBeforeSet_=!0,s}function Vu(n,e){const t=n.copy();return t.index_=e,t}function EC(n){const e={};if(n.isDefault())return e;let t;if(n.index_===Oe?t="$priority":n.index_===xu?t="$value":n.index_===ln?t="$key":(H(n.index_ instanceof Lu,"Unrecognized index type!"),t=n.index_.toString()),e.orderBy=$e(t),n.startSet_){const s=n.startAfterSet_?"startAfter":"startAt";e[s]=$e(n.indexStartValue_),n.startNameSet_&&(e[s]+=","+$e(n.indexStartName_))}if(n.endSet_){const s=n.endBeforeSet_?"endBefore":"endAt";e[s]=$e(n.indexEndValue_),n.endNameSet_&&(e[s]+=","+$e(n.indexEndName_))}return n.limitSet_&&(n.isViewFromLeft()?e.limitToFirst=n.limit_:e.limitToLast=n.limit_),e}function DC(n){const e={};if(n.startSet_&&(e.sp=n.indexStartValue_,n.startNameSet_&&(e.sn=n.indexStartName_),e.sin=!n.startAfterSet_),n.endSet_&&(e.ep=n.indexEndValue_,n.endNameSet_&&(e.en=n.indexEndName_),e.ein=!n.endBeforeSet_),n.limitSet_){e.l=n.limit_;let t=n.viewFrom_;t===""&&(n.isViewFromLeft()?t="l":t="r"),e.vf=t}return n.index_!==Oe&&(e.i=n.index_.toString()),e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fa extends i_{reportStats(e){throw new Error("Method not implemented.")}static getListenId_(e,t){return t!==void 0?"tag$"+t:(H(e._queryParams.isDefault(),"should have a tag if it's not a default query."),e._path.toString())}constructor(e,t,s,r){super(),this.repoInfo_=e,this.onDataUpdate_=t,this.authTokenProvider_=s,this.appCheckTokenProvider_=r,this.log_=wo("p:rest:"),this.listens_={}}listen(e,t,s,r){const i=e._path.toString();this.log_("Listen called for "+i+" "+e._queryIdentifier);const o=Fa.getListenId_(e,s),a={};this.listens_[o]=a;const B=EC(e._queryParams);this.restRequest_(i+".json",B,(c,u)=>{let f=u;if(c===404&&(f=null,c=null),c===null&&this.onDataUpdate_(i,f,!1,s),dr(this.listens_,o)===a){let C;c?c===401?C="permission_denied":C="rest_error:"+c:C="ok",r(C,null)}})}unlisten(e,t){const s=Fa.getListenId_(e,t);delete this.listens_[s]}get(e){const t=EC(e._queryParams),s=e._path.toString(),r=new so;return this.restRequest_(s+".json",t,(i,o)=>{let a=o;i===404&&(a=null,i=null),i===null?(this.onDataUpdate_(s,a,!1,null),r.resolve(a)):r.reject(new Error(a))}),r.promise}refreshAuthToken(e){}restRequest_(e,t={},s){return t.format="export",Promise.all([this.authTokenProvider_.getToken(!1),this.appCheckTokenProvider_.getToken(!1)]).then(([r,i])=>{r&&r.accessToken&&(t.auth=r.accessToken),i&&i.token&&(t.ac=i.token);const o=(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host+e+"?ns="+this.repoInfo_.namespace+XE(t);this.log_("Sending REST request for "+o);const a=new XMLHttpRequest;a.onreadystatechange=()=>{if(s&&a.readyState===4){this.log_("REST Response for "+o+" received. status:",a.status,"response:",a.responseText);let B=null;if(a.status>=200&&a.status<300){try{B=bi(a.responseText)}catch{_t("Failed to parse JSON response for "+o+": "+a.responseText)}s(null,B)}else a.status!==401&&a.status!==404&&_t("Got unsuccessful REST response for "+o+" Status: "+a.status),s(a.status);s=null}},a.open("GET",o,!0),a.send()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y0{constructor(){this.rootNode_=se.EMPTY_NODE}getNode(e){return this.rootNode_.getChild(e)}updateSnapshot(e,t){this.rootNode_=this.rootNode_.updateChild(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oa(){return{value:null,children:new Map}}function C_(n,e,t){if(le(e))n.value=t,n.children.clear();else if(n.value!==null)n.value=n.value.updateChild(e,t);else{const s=ae(e);n.children.has(s)||n.children.set(s,Oa());const r=n.children.get(s);e=Re(e),C_(r,e,t)}}function ac(n,e,t){n.value!==null?t(e,n.value):w0(n,(s,r)=>{const i=new De(e.toString()+"/"+s);ac(r,i,t)})}function w0(n,e){n.children.forEach((t,s)=>{e(s,t)})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T0{constructor(e){this.collection_=e,this.last_=null}get(){const e=this.collection_.get(),t={...e};return this.last_&&lt(this.last_,(s,r)=>{t[s]=t[s]-r}),this.last_=e,t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yC=10*1e3,I0=30*1e3,A0=5*60*1e3;class v0{constructor(e,t){this.server_=t,this.statsToReport_={},this.statsListener_=new T0(e);const s=yC+(I0-yC)*Math.random();Ai(this.reportStats_.bind(this),Math.floor(s))}reportStats_(){const e=this.statsListener_.get(),t={};let s=!1;lt(e,(r,i)=>{i>0&&un(this.statsToReport_,r)&&(t[r]=i,s=!0)}),s&&this.server_.reportStats(t),Ai(this.reportStats_.bind(this),Math.floor(Math.random()*2*A0))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Kt;(function(n){n[n.OVERWRITE=0]="OVERWRITE",n[n.MERGE=1]="MERGE",n[n.ACK_USER_WRITE=2]="ACK_USER_WRITE",n[n.LISTEN_COMPLETE=3]="LISTEN_COMPLETE"})(Kt||(Kt={}));function Gu(){return{fromUser:!0,fromServer:!1,queryId:null,tagged:!1}}function Hu(){return{fromUser:!1,fromServer:!0,queryId:null,tagged:!1}}function Uu(n){return{fromUser:!1,fromServer:!0,queryId:n,tagged:!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class La{constructor(e,t,s){this.path=e,this.affectedTree=t,this.revert=s,this.type=Kt.ACK_USER_WRITE,this.source=Gu()}operationForChild(e){if(le(this.path)){if(this.affectedTree.value!=null)return H(this.affectedTree.children.isEmpty(),"affectedTree should not have overlapping affected paths."),this;{const t=this.affectedTree.subtree(new De(e));return new La(_e(),t,this.revert)}}else return H(ae(this.path)===e,"operationForChild called for unrelated child."),new La(Re(this.path),this.affectedTree,this.revert)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class to{constructor(e,t){this.source=e,this.path=t,this.type=Kt.LISTEN_COMPLETE}operationForChild(e){return le(this.path)?new to(this.source,_e()):new to(this.source,Re(this.path))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{constructor(e,t,s){this.source=e,this.path=t,this.snap=s,this.type=Kt.OVERWRITE}operationForChild(e){return le(this.path)?new qs(this.source,_e(),this.snap.getImmediateChild(e)):new qs(this.source,Re(this.path),this.snap)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ir{constructor(e,t,s){this.source=e,this.path=t,this.children=s,this.type=Kt.MERGE}operationForChild(e){if(le(this.path)){const t=this.children.subtree(new De(e));return t.isEmpty()?null:t.value?new qs(this.source,_e(),t.value):new Ir(this.source,_e(),t)}else return H(ae(this.path)===e,"Can't get a merge for a child not on the path of the operation"),new Ir(this.source,Re(this.path),this.children)}toString(){return"Operation("+this.path+": "+this.source.toString()+" merge: "+this.children.toString()+")"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fs{constructor(e,t,s){this.node_=e,this.fullyInitialized_=t,this.filtered_=s}isFullyInitialized(){return this.fullyInitialized_}isFiltered(){return this.filtered_}isCompleteForPath(e){if(le(e))return this.isFullyInitialized()&&!this.filtered_;const t=ae(e);return this.isCompleteForChild(t)}isCompleteForChild(e){return this.isFullyInitialized()&&!this.filtered_||this.node_.hasChild(e)}getNode(){return this.node_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R0{constructor(e){this.query_=e,this.index_=this.query_._queryParams.getIndex()}}function S0(n,e,t,s){const r=[],i=[];return e.forEach(o=>{o.type==="child_changed"&&n.index_.indexedValueChanged(o.oldSnap,o.snapshotNode)&&i.push(C0(o.childName,o.snapshotNode))}),hi(n,r,"child_removed",e,s,t),hi(n,r,"child_added",e,s,t),hi(n,r,"child_moved",i,s,t),hi(n,r,"child_changed",e,s,t),hi(n,r,"value",e,s,t),r}function hi(n,e,t,s,r,i){const o=s.filter(a=>a.type===t);o.sort((a,B)=>N0(n,a,B)),o.forEach(a=>{const B=b0(n,a,i);r.forEach(c=>{c.respondsTo(a.type)&&e.push(c.createEvent(B,n.query_))})})}function b0(n,e,t){return e.type==="value"||e.type==="child_removed"||(e.prevName=t.getPredecessorChildName(e.childName,e.snapshotNode,n.index_)),e}function N0(n,e,t){if(e.childName==null||t.childName==null)throw br("Should only compare child_ events.");const s=new ce(e.childName,e.snapshotNode),r=new ce(t.childName,t.snapshotNode);return n.index_.compare(s,r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function El(n,e){return{eventCache:n,serverCache:e}}function vi(n,e,t,s){return El(new fs(e,t,s),n.serverCache)}function p_(n,e,t,s){return El(n.eventCache,new fs(e,t,s))}function xa(n){return n.eventCache.isFullyInitialized()?n.eventCache.getNode():null}function Js(n){return n.serverCache.isFullyInitialized()?n.serverCache.getNode():null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let wB;const P0=()=>(wB||(wB=new It(dS)),wB);class ve{static fromObject(e){let t=new ve(null);return lt(e,(s,r)=>{t=t.set(new De(s),r)}),t}constructor(e,t=P0()){this.value=e,this.children=t}isEmpty(){return this.value===null&&this.children.isEmpty()}findRootMostMatchingPathAndValue(e,t){if(this.value!=null&&t(this.value))return{path:_e(),value:this.value};if(le(e))return null;{const s=ae(e),r=this.children.get(s);if(r!==null){const i=r.findRootMostMatchingPathAndValue(Re(e),t);return i!=null?{path:ke(new De(s),i.path),value:i.value}:null}else return null}}findRootMostValueAndPath(e){return this.findRootMostMatchingPathAndValue(e,()=>!0)}subtree(e){if(le(e))return this;{const t=ae(e),s=this.children.get(t);return s!==null?s.subtree(Re(e)):new ve(null)}}set(e,t){if(le(e))return new ve(t,this.children);{const s=ae(e),i=(this.children.get(s)||new ve(null)).set(Re(e),t),o=this.children.insert(s,i);return new ve(this.value,o)}}remove(e){if(le(e))return this.children.isEmpty()?new ve(null):new ve(null,this.children);{const t=ae(e),s=this.children.get(t);if(s){const r=s.remove(Re(e));let i;return r.isEmpty()?i=this.children.remove(t):i=this.children.insert(t,r),this.value===null&&i.isEmpty()?new ve(null):new ve(this.value,i)}else return this}}get(e){if(le(e))return this.value;{const t=ae(e),s=this.children.get(t);return s?s.get(Re(e)):null}}setTree(e,t){if(le(e))return t;{const s=ae(e),i=(this.children.get(s)||new ve(null)).setTree(Re(e),t);let o;return i.isEmpty()?o=this.children.remove(s):o=this.children.insert(s,i),new ve(this.value,o)}}fold(e){return this.fold_(_e(),e)}fold_(e,t){const s={};return this.children.inorderTraversal((r,i)=>{s[r]=i.fold_(ke(e,r),t)}),t(e,this.value,s)}findOnPath(e,t){return this.findOnPath_(e,_e(),t)}findOnPath_(e,t,s){const r=this.value?s(t,this.value):!1;if(r)return r;if(le(e))return null;{const i=ae(e),o=this.children.get(i);return o?o.findOnPath_(Re(e),ke(t,i),s):null}}foreachOnPath(e,t){return this.foreachOnPath_(e,_e(),t)}foreachOnPath_(e,t,s){if(le(e))return this;{this.value&&s(t,this.value);const r=ae(e),i=this.children.get(r);return i?i.foreachOnPath_(Re(e),ke(t,r),s):new ve(null)}}foreach(e){this.foreach_(_e(),e)}foreach_(e,t){this.children.inorderTraversal((s,r)=>{r.foreach_(ke(e,s),t)}),this.value&&t(e,this.value)}foreachChild(e){this.children.inorderTraversal((t,s)=>{s.value&&e(t,s.value)})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(e){this.writeTree_=e}static empty(){return new zt(new ve(null))}}function Ri(n,e,t){if(le(e))return new zt(new ve(t));{const s=n.writeTree_.findRootMostValueAndPath(e);if(s!=null){const r=s.path;let i=s.value;const o=mt(r,e);return i=i.updateChild(o,t),new zt(n.writeTree_.set(r,i))}else{const r=new ve(t),i=n.writeTree_.setTree(e,r);return new zt(i)}}}function lc(n,e,t){let s=n;return lt(t,(r,i)=>{s=Ri(s,ke(e,r),i)}),s}function wC(n,e){if(le(e))return zt.empty();{const t=n.writeTree_.setTree(e,new ve(null));return new zt(t)}}function Bc(n,e){return Ws(n,e)!=null}function Ws(n,e){const t=n.writeTree_.findRootMostValueAndPath(e);return t!=null?n.writeTree_.get(t.path).getChild(mt(t.path,e)):null}function TC(n){const e=[],t=n.writeTree_.value;return t!=null?t.isLeafNode()||t.forEachChild(Oe,(s,r)=>{e.push(new ce(s,r))}):n.writeTree_.children.inorderTraversal((s,r)=>{r.value!=null&&e.push(new ce(s,r.value))}),e}function Xn(n,e){if(le(e))return n;{const t=Ws(n,e);return t!=null?new zt(new ve(t)):new zt(n.writeTree_.subtree(e))}}function cc(n){return n.writeTree_.isEmpty()}function Ar(n,e){return g_(_e(),n.writeTree_,e)}function g_(n,e,t){if(e.value!=null)return t.updateChild(n,e.value);{let s=null;return e.children.inorderTraversal((r,i)=>{r===".priority"?(H(i.value!==null,"Priority writes must always be leaf nodes"),s=i.value):t=g_(ke(n,r),i,t)}),!t.getChild(n).isEmpty()&&s!==null&&(t=t.updateChild(ke(n,".priority"),s)),t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dl(n,e){return D_(e,n)}function F0(n,e,t,s,r){H(s>n.lastWriteId,"Stacking an older write on top of newer ones"),r===void 0&&(r=!0),n.allWrites.push({path:e,snap:t,writeId:s,visible:r}),r&&(n.visibleWrites=Ri(n.visibleWrites,e,t)),n.lastWriteId=s}function O0(n,e,t,s){H(s>n.lastWriteId,"Stacking an older merge on top of newer ones"),n.allWrites.push({path:e,children:t,writeId:s,visible:!0}),n.visibleWrites=lc(n.visibleWrites,e,t),n.lastWriteId=s}function L0(n,e){for(let t=0;t<n.allWrites.length;t++){const s=n.allWrites[t];if(s.writeId===e)return s}return null}function x0(n,e){const t=n.allWrites.findIndex(a=>a.writeId===e);H(t>=0,"removeWrite called with nonexistent writeId.");const s=n.allWrites[t];n.allWrites.splice(t,1);let r=s.visible,i=!1,o=n.allWrites.length-1;for(;r&&o>=0;){const a=n.allWrites[o];a.visible&&(o>=t&&k0(a,s.path)?r=!1:Gt(s.path,a.path)&&(i=!0)),o--}if(r){if(i)return M0(n),!0;if(s.snap)n.visibleWrites=wC(n.visibleWrites,s.path);else{const a=s.children;lt(a,B=>{n.visibleWrites=wC(n.visibleWrites,ke(s.path,B))})}return!0}else return!1}function k0(n,e){if(n.snap)return Gt(n.path,e);for(const t in n.children)if(n.children.hasOwnProperty(t)&&Gt(ke(n.path,t),e))return!0;return!1}function M0(n){n.visibleWrites=m_(n.allWrites,V0,_e()),n.allWrites.length>0?n.lastWriteId=n.allWrites[n.allWrites.length-1].writeId:n.lastWriteId=-1}function V0(n){return n.visible}function m_(n,e,t){let s=zt.empty();for(let r=0;r<n.length;++r){const i=n[r];if(e(i)){const o=i.path;let a;if(i.snap)Gt(t,o)?(a=mt(t,o),s=Ri(s,a,i.snap)):Gt(o,t)&&(a=mt(o,t),s=Ri(s,_e(),i.snap.getChild(a)));else if(i.children){if(Gt(t,o))a=mt(t,o),s=lc(s,a,i.children);else if(Gt(o,t))if(a=mt(o,t),le(a))s=lc(s,_e(),i.children);else{const B=dr(i.children,ae(a));if(B){const c=B.getChild(Re(a));s=Ri(s,_e(),c)}}}else throw br("WriteRecord should have .snap or .children")}}return s}function __(n,e,t,s,r){if(!s&&!r){const i=Ws(n.visibleWrites,e);if(i!=null)return i;{const o=Xn(n.visibleWrites,e);if(cc(o))return t;if(t==null&&!Bc(o,_e()))return null;{const a=t||se.EMPTY_NODE;return Ar(o,a)}}}else{const i=Xn(n.visibleWrites,e);if(!r&&cc(i))return t;if(!r&&t==null&&!Bc(i,_e()))return null;{const o=function(c){return(c.visible||r)&&(!s||!~s.indexOf(c.writeId))&&(Gt(c.path,e)||Gt(e,c.path))},a=m_(n.allWrites,o,e),B=t||se.EMPTY_NODE;return Ar(a,B)}}}function G0(n,e,t){let s=se.EMPTY_NODE;const r=Ws(n.visibleWrites,e);if(r)return r.isLeafNode()||r.forEachChild(Oe,(i,o)=>{s=s.updateImmediateChild(i,o)}),s;if(t){const i=Xn(n.visibleWrites,e);return t.forEachChild(Oe,(o,a)=>{const B=Ar(Xn(i,new De(o)),a);s=s.updateImmediateChild(o,B)}),TC(i).forEach(o=>{s=s.updateImmediateChild(o.name,o.node)}),s}else{const i=Xn(n.visibleWrites,e);return TC(i).forEach(o=>{s=s.updateImmediateChild(o.name,o.node)}),s}}function H0(n,e,t,s,r){H(s||r,"Either existingEventSnap or existingServerSnap must exist");const i=ke(e,t);if(Bc(n.visibleWrites,i))return null;{const o=Xn(n.visibleWrites,i);return cc(o)?r.getChild(t):Ar(o,r.getChild(t))}}function U0(n,e,t,s){const r=ke(e,t),i=Ws(n.visibleWrites,r);if(i!=null)return i;if(s.isCompleteForChild(t)){const o=Xn(n.visibleWrites,r);return Ar(o,s.getNode().getImmediateChild(t))}else return null}function q0(n,e){return Ws(n.visibleWrites,e)}function J0(n,e,t,s,r,i,o){let a;const B=Xn(n.visibleWrites,e),c=Ws(B,_e());if(c!=null)a=c;else if(t!=null)a=Ar(B,t);else return[];if(a=a.withIndex(o),!a.isEmpty()&&!a.isLeafNode()){const u=[],f=o.getCompare(),C=i?a.getReverseIteratorFrom(s,o):a.getIteratorFrom(s,o);let g=C.getNext();for(;g&&u.length<r;)f(g,s)!==0&&u.push(g),g=C.getNext();return u}else return[]}function j0(){return{visibleWrites:zt.empty(),allWrites:[],lastWriteId:-1}}function ka(n,e,t,s){return __(n.writeTree,n.treePath,e,t,s)}function qu(n,e){return G0(n.writeTree,n.treePath,e)}function IC(n,e,t,s){return H0(n.writeTree,n.treePath,e,t,s)}function Ma(n,e){return q0(n.writeTree,ke(n.treePath,e))}function K0(n,e,t,s,r,i){return J0(n.writeTree,n.treePath,e,t,s,r,i)}function Ju(n,e,t){return U0(n.writeTree,n.treePath,e,t)}function E_(n,e){return D_(ke(n.treePath,e),n.writeTree)}function D_(n,e){return{treePath:n,writeTree:e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q0{constructor(){this.changeMap=new Map}trackChildChange(e){const t=e.type,s=e.childName;H(t==="child_added"||t==="child_changed"||t==="child_removed","Only child changes supported for tracking"),H(s!==".priority","Only non-priority child changes can be tracked.");const r=this.changeMap.get(s);if(r){const i=r.type;if(t==="child_added"&&i==="child_removed")this.changeMap.set(s,Zi(s,e.snapshotNode,r.snapshotNode));else if(t==="child_removed"&&i==="child_added")this.changeMap.delete(s);else if(t==="child_removed"&&i==="child_changed")this.changeMap.set(s,Xi(s,r.oldSnap));else if(t==="child_changed"&&i==="child_added")this.changeMap.set(s,Tr(s,e.snapshotNode));else if(t==="child_changed"&&i==="child_changed")this.changeMap.set(s,Zi(s,e.snapshotNode,r.oldSnap));else throw br("Illegal combination of changes: "+e+" occurred after "+r)}else this.changeMap.set(s,e)}getChanges(){return Array.from(this.changeMap.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class z0{getCompleteChild(e){return null}getChildAfterChild(e,t,s){return null}}const y_=new z0;class ju{constructor(e,t,s=null){this.writes_=e,this.viewCache_=t,this.optCompleteServerCache_=s}getCompleteChild(e){const t=this.viewCache_.eventCache;if(t.isCompleteForChild(e))return t.getNode().getImmediateChild(e);{const s=this.optCompleteServerCache_!=null?new fs(this.optCompleteServerCache_,!0,!1):this.viewCache_.serverCache;return Ju(this.writes_,e,s)}}getChildAfterChild(e,t,s){const r=this.optCompleteServerCache_!=null?this.optCompleteServerCache_:Js(this.viewCache_),i=K0(this.writes_,r,t,1,s,e);return i.length===0?null:i[0]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W0(n){return{filter:n}}function $0(n,e){H(e.eventCache.getNode().isIndexed(n.filter.getIndex()),"Event snap not indexed"),H(e.serverCache.getNode().isIndexed(n.filter.getIndex()),"Server snap not indexed")}function Y0(n,e,t,s,r){const i=new Q0;let o,a;if(t.type===Kt.OVERWRITE){const c=t;c.source.fromUser?o=uc(n,e,c.path,c.snap,s,r,i):(H(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered()&&!le(c.path),o=Va(n,e,c.path,c.snap,s,r,a,i))}else if(t.type===Kt.MERGE){const c=t;c.source.fromUser?o=Z0(n,e,c.path,c.children,s,r,i):(H(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered(),o=hc(n,e,c.path,c.children,s,r,a,i))}else if(t.type===Kt.ACK_USER_WRITE){const c=t;c.revert?o=nb(n,e,c.path,s,r,i):o=eb(n,e,c.path,c.affectedTree,s,r,i)}else if(t.type===Kt.LISTEN_COMPLETE)o=tb(n,e,t.path,s,i);else throw br("Unknown operation type: "+t.type);const B=i.getChanges();return X0(e,o,B),{viewCache:o,changes:B}}function X0(n,e,t){const s=e.eventCache;if(s.isFullyInitialized()){const r=s.getNode().isLeafNode()||s.getNode().isEmpty(),i=xa(n);(t.length>0||!n.eventCache.isFullyInitialized()||r&&!s.getNode().equals(i)||!s.getNode().getPriority().equals(i.getPriority()))&&t.push(d_(xa(e)))}}function w_(n,e,t,s,r,i){const o=e.eventCache;if(Ma(s,t)!=null)return e;{let a,B;if(le(t))if(H(e.serverCache.isFullyInitialized(),"If change path is empty, we must have complete server data"),e.serverCache.isFiltered()){const c=Js(e),u=c instanceof se?c:se.EMPTY_NODE,f=qu(s,u);a=n.filter.updateFullNode(e.eventCache.getNode(),f,i)}else{const c=ka(s,Js(e));a=n.filter.updateFullNode(e.eventCache.getNode(),c,i)}else{const c=ae(t);if(c===".priority"){H(hs(t)===1,"Can't have a priority with additional path components");const u=o.getNode();B=e.serverCache.getNode();const f=IC(s,t,u,B);f!=null?a=n.filter.updatePriority(u,f):a=o.getNode()}else{const u=Re(t);let f;if(o.isCompleteForChild(c)){B=e.serverCache.getNode();const C=IC(s,t,o.getNode(),B);C!=null?f=o.getNode().getImmediateChild(c).updateChild(u,C):f=o.getNode().getImmediateChild(c)}else f=Ju(s,c,e.serverCache);f!=null?a=n.filter.updateChild(o.getNode(),c,f,u,r,i):a=o.getNode()}}return vi(e,a,o.isFullyInitialized()||le(t),n.filter.filtersNodes())}}function Va(n,e,t,s,r,i,o,a){const B=e.serverCache;let c;const u=o?n.filter:n.filter.getIndexedFilter();if(le(t))c=u.updateFullNode(B.getNode(),s,null);else if(u.filtersNodes()&&!B.isFiltered()){const g=B.getNode().updateChild(t,s);c=u.updateFullNode(B.getNode(),g,null)}else{const g=ae(t);if(!B.isCompleteForPath(t)&&hs(t)>1)return e;const E=Re(t),F=B.getNode().getImmediateChild(g).updateChild(E,s);g===".priority"?c=u.updatePriority(B.getNode(),F):c=u.updateChild(B.getNode(),g,F,E,y_,null)}const f=p_(e,c,B.isFullyInitialized()||le(t),u.filtersNodes()),C=new ju(r,f,i);return w_(n,f,t,r,C,a)}function uc(n,e,t,s,r,i,o){const a=e.eventCache;let B,c;const u=new ju(r,e,i);if(le(t))c=n.filter.updateFullNode(e.eventCache.getNode(),s,o),B=vi(e,c,!0,n.filter.filtersNodes());else{const f=ae(t);if(f===".priority")c=n.filter.updatePriority(e.eventCache.getNode(),s),B=vi(e,c,a.isFullyInitialized(),a.isFiltered());else{const C=Re(t),g=a.getNode().getImmediateChild(f);let E;if(le(C))E=s;else{const b=u.getCompleteChild(f);b!=null?Nu(C)===".priority"&&b.getChild(a_(C)).isEmpty()?E=b:E=b.updateChild(C,s):E=se.EMPTY_NODE}if(g.equals(E))B=e;else{const b=n.filter.updateChild(a.getNode(),f,E,C,u,o);B=vi(e,b,a.isFullyInitialized(),n.filter.filtersNodes())}}}return B}function AC(n,e){return n.eventCache.isCompleteForChild(e)}function Z0(n,e,t,s,r,i,o){let a=e;return s.foreach((B,c)=>{const u=ke(t,B);AC(e,ae(u))&&(a=uc(n,a,u,c,r,i,o))}),s.foreach((B,c)=>{const u=ke(t,B);AC(e,ae(u))||(a=uc(n,a,u,c,r,i,o))}),a}function vC(n,e,t){return t.foreach((s,r)=>{e=e.updateChild(s,r)}),e}function hc(n,e,t,s,r,i,o,a){if(e.serverCache.getNode().isEmpty()&&!e.serverCache.isFullyInitialized())return e;let B=e,c;le(t)?c=s:c=new ve(null).setTree(t,s);const u=e.serverCache.getNode();return c.children.inorderTraversal((f,C)=>{if(u.hasChild(f)){const g=e.serverCache.getNode().getImmediateChild(f),E=vC(n,g,C);B=Va(n,B,new De(f),E,r,i,o,a)}}),c.children.inorderTraversal((f,C)=>{const g=!e.serverCache.isCompleteForChild(f)&&C.value===null;if(!u.hasChild(f)&&!g){const E=e.serverCache.getNode().getImmediateChild(f),b=vC(n,E,C);B=Va(n,B,new De(f),b,r,i,o,a)}}),B}function eb(n,e,t,s,r,i,o){if(Ma(r,t)!=null)return e;const a=e.serverCache.isFiltered(),B=e.serverCache;if(s.value!=null){if(le(t)&&B.isFullyInitialized()||B.isCompleteForPath(t))return Va(n,e,t,B.getNode().getChild(t),r,i,a,o);if(le(t)){let c=new ve(null);return B.getNode().forEachChild(ln,(u,f)=>{c=c.set(new De(u),f)}),hc(n,e,t,c,r,i,a,o)}else return e}else{let c=new ve(null);return s.foreach((u,f)=>{const C=ke(t,u);B.isCompleteForPath(C)&&(c=c.set(u,B.getNode().getChild(C)))}),hc(n,e,t,c,r,i,a,o)}}function tb(n,e,t,s,r){const i=e.serverCache,o=p_(e,i.getNode(),i.isFullyInitialized()||le(t),i.isFiltered());return w_(n,o,t,s,y_,r)}function nb(n,e,t,s,r,i){let o;if(Ma(s,t)!=null)return e;{const a=new ju(s,e,r),B=e.eventCache.getNode();let c;if(le(t)||ae(t)===".priority"){let u;if(e.serverCache.isFullyInitialized())u=ka(s,Js(e));else{const f=e.serverCache.getNode();H(f instanceof se,"serverChildren would be complete if leaf node"),u=qu(s,f)}u=u,c=n.filter.updateFullNode(B,u,i)}else{const u=ae(t);let f=Ju(s,u,e.serverCache);f==null&&e.serverCache.isCompleteForChild(u)&&(f=B.getImmediateChild(u)),f!=null?c=n.filter.updateChild(B,u,f,Re(t),a,i):e.eventCache.getNode().hasChild(u)?c=n.filter.updateChild(B,u,se.EMPTY_NODE,Re(t),a,i):c=B,c.isEmpty()&&e.serverCache.isFullyInitialized()&&(o=ka(s,Js(e)),o.isLeafNode()&&(c=n.filter.updateFullNode(c,o,i)))}return o=e.serverCache.isFullyInitialized()||Ma(s,_e())!=null,vi(e,c,o,n.filter.filtersNodes())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sb{constructor(e,t){this.query_=e,this.eventRegistrations_=[];const s=this.query_._queryParams,r=new ku(s.getIndex()),i=g0(s);this.processor_=W0(i);const o=t.serverCache,a=t.eventCache,B=r.updateFullNode(se.EMPTY_NODE,o.getNode(),null),c=i.updateFullNode(se.EMPTY_NODE,a.getNode(),null),u=new fs(B,o.isFullyInitialized(),r.filtersNodes()),f=new fs(c,a.isFullyInitialized(),i.filtersNodes());this.viewCache_=El(f,u),this.eventGenerator_=new R0(this.query_)}get query(){return this.query_}}function rb(n){return n.viewCache_.serverCache.getNode()}function ib(n){return xa(n.viewCache_)}function ob(n,e){const t=Js(n.viewCache_);return t&&(n.query._queryParams.loadsAllData()||!le(e)&&!t.getImmediateChild(ae(e)).isEmpty())?t.getChild(e):null}function RC(n){return n.eventRegistrations_.length===0}function ab(n,e){n.eventRegistrations_.push(e)}function SC(n,e,t){const s=[];if(t){H(e==null,"A cancel should cancel all event registrations.");const r=n.query._path;n.eventRegistrations_.forEach(i=>{const o=i.createCancelEvent(t,r);o&&s.push(o)})}if(e){let r=[];for(let i=0;i<n.eventRegistrations_.length;++i){const o=n.eventRegistrations_[i];if(!o.matches(e))r.push(o);else if(e.hasAnyCallback()){r=r.concat(n.eventRegistrations_.slice(i+1));break}}n.eventRegistrations_=r}else n.eventRegistrations_=[];return s}function bC(n,e,t,s){e.type===Kt.MERGE&&e.source.queryId!==null&&(H(Js(n.viewCache_),"We should always have a full cache before handling merges"),H(xa(n.viewCache_),"Missing event cache, even though we have a server cache"));const r=n.viewCache_,i=Y0(n.processor_,r,e,t,s);return $0(n.processor_,i.viewCache),H(i.viewCache.serverCache.isFullyInitialized()||!r.serverCache.isFullyInitialized(),"Once a server snap is complete, it should never go back"),n.viewCache_=i.viewCache,T_(n,i.changes,i.viewCache.eventCache.getNode(),null)}function lb(n,e){const t=n.viewCache_.eventCache,s=[];return t.getNode().isLeafNode()||t.getNode().forEachChild(Oe,(i,o)=>{s.push(Tr(i,o))}),t.isFullyInitialized()&&s.push(d_(t.getNode())),T_(n,s,t.getNode(),e)}function T_(n,e,t,s){const r=s?[s]:n.eventRegistrations_;return S0(n.eventGenerator_,e,t,r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ga;class I_{constructor(){this.views=new Map}}function Bb(n){H(!Ga,"__referenceConstructor has already been defined"),Ga=n}function cb(){return H(Ga,"Reference.ts has not been loaded"),Ga}function ub(n){return n.views.size===0}function Ku(n,e,t,s){const r=e.source.queryId;if(r!==null){const i=n.views.get(r);return H(i!=null,"SyncTree gave us an op for an invalid query."),bC(i,e,t,s)}else{let i=[];for(const o of n.views.values())i=i.concat(bC(o,e,t,s));return i}}function A_(n,e,t,s,r){const i=e._queryIdentifier,o=n.views.get(i);if(!o){let a=ka(t,r?s:null),B=!1;a?B=!0:s instanceof se?(a=qu(t,s),B=!1):(a=se.EMPTY_NODE,B=!1);const c=El(new fs(a,B,!1),new fs(s,r,!1));return new sb(e,c)}return o}function hb(n,e,t,s,r,i){const o=A_(n,e,s,r,i);return n.views.has(e._queryIdentifier)||n.views.set(e._queryIdentifier,o),ab(o,t),lb(o,t)}function fb(n,e,t,s){const r=e._queryIdentifier,i=[];let o=[];const a=ds(n);if(r==="default")for(const[B,c]of n.views.entries())o=o.concat(SC(c,t,s)),RC(c)&&(n.views.delete(B),c.query._queryParams.loadsAllData()||i.push(c.query));else{const B=n.views.get(r);B&&(o=o.concat(SC(B,t,s)),RC(B)&&(n.views.delete(r),B.query._queryParams.loadsAllData()||i.push(B.query)))}return a&&!ds(n)&&i.push(new(cb())(e._repo,e._path)),{removed:i,events:o}}function v_(n){const e=[];for(const t of n.views.values())t.query._queryParams.loadsAllData()||e.push(t);return e}function Zn(n,e){let t=null;for(const s of n.views.values())t=t||ob(s,e);return t}function R_(n,e){if(e._queryParams.loadsAllData())return yl(n);{const s=e._queryIdentifier;return n.views.get(s)}}function S_(n,e){return R_(n,e)!=null}function ds(n){return yl(n)!=null}function yl(n){for(const e of n.views.values())if(e.query._queryParams.loadsAllData())return e;return null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ha;function db(n){H(!Ha,"__referenceConstructor has already been defined"),Ha=n}function Cb(){return H(Ha,"Reference.ts has not been loaded"),Ha}let pb=1;class NC{constructor(e){this.listenProvider_=e,this.syncPointTree_=new ve(null),this.pendingWriteTree_=j0(),this.tagToQueryMap=new Map,this.queryToTagMap=new Map}}function b_(n,e,t,s,r){return F0(n.pendingWriteTree_,e,t,s,r),r?qr(n,new qs(Gu(),e,t)):[]}function gb(n,e,t,s){O0(n.pendingWriteTree_,e,t,s);const r=ve.fromObject(t);return qr(n,new Ir(Gu(),e,r))}function qn(n,e,t=!1){const s=L0(n.pendingWriteTree_,e);if(x0(n.pendingWriteTree_,e)){let i=new ve(null);return s.snap!=null?i=i.set(_e(),!0):lt(s.children,o=>{i=i.set(new De(o),!0)}),qr(n,new La(s.path,i,t))}else return[]}function Io(n,e,t){return qr(n,new qs(Hu(),e,t))}function mb(n,e,t){const s=ve.fromObject(t);return qr(n,new Ir(Hu(),e,s))}function _b(n,e){return qr(n,new to(Hu(),e))}function Eb(n,e,t){const s=zu(n,t);if(s){const r=Wu(s),i=r.path,o=r.queryId,a=mt(i,e),B=new to(Uu(o),a);return $u(n,i,B)}else return[]}function Ua(n,e,t,s,r=!1){const i=e._path,o=n.syncPointTree_.get(i);let a=[];if(o&&(e._queryIdentifier==="default"||S_(o,e))){const B=fb(o,e,t,s);ub(o)&&(n.syncPointTree_=n.syncPointTree_.remove(i));const c=B.removed;if(a=B.events,!r){const u=c.findIndex(C=>C._queryParams.loadsAllData())!==-1,f=n.syncPointTree_.findOnPath(i,(C,g)=>ds(g));if(u&&!f){const C=n.syncPointTree_.subtree(i);if(!C.isEmpty()){const g=wb(C);for(let E=0;E<g.length;++E){const b=g[E],F=b.query,j=O_(n,b);n.listenProvider_.startListening(Si(F),no(n,F),j.hashFn,j.onComplete)}}}!f&&c.length>0&&!s&&(u?n.listenProvider_.stopListening(Si(e),null):c.forEach(C=>{const g=n.queryToTagMap.get(wl(C));n.listenProvider_.stopListening(Si(C),g)}))}Tb(n,c)}return a}function N_(n,e,t,s){const r=zu(n,s);if(r!=null){const i=Wu(r),o=i.path,a=i.queryId,B=mt(o,e),c=new qs(Uu(a),B,t);return $u(n,o,c)}else return[]}function Db(n,e,t,s){const r=zu(n,s);if(r){const i=Wu(r),o=i.path,a=i.queryId,B=mt(o,e),c=ve.fromObject(t),u=new Ir(Uu(a),B,c);return $u(n,o,u)}else return[]}function fc(n,e,t,s=!1){const r=e._path;let i=null,o=!1;n.syncPointTree_.foreachOnPath(r,(C,g)=>{const E=mt(C,r);i=i||Zn(g,E),o=o||ds(g)});let a=n.syncPointTree_.get(r);a?(o=o||ds(a),i=i||Zn(a,_e())):(a=new I_,n.syncPointTree_=n.syncPointTree_.set(r,a));let B;i!=null?B=!0:(B=!1,i=se.EMPTY_NODE,n.syncPointTree_.subtree(r).foreachChild((g,E)=>{const b=Zn(E,_e());b&&(i=i.updateImmediateChild(g,b))}));const c=S_(a,e);if(!c&&!e._queryParams.loadsAllData()){const C=wl(e);H(!n.queryToTagMap.has(C),"View does not exist, but we have a tag");const g=Ib();n.queryToTagMap.set(C,g),n.tagToQueryMap.set(g,C)}const u=Dl(n.pendingWriteTree_,r);let f=hb(a,e,t,u,i,B);if(!c&&!o&&!s){const C=R_(a,e);f=f.concat(Ab(n,e,C))}return f}function Qu(n,e,t){const r=n.pendingWriteTree_,i=n.syncPointTree_.findOnPath(e,(o,a)=>{const B=mt(o,e),c=Zn(a,B);if(c)return c});return __(r,e,i,t,!0)}function yb(n,e){const t=e._path;let s=null;n.syncPointTree_.foreachOnPath(t,(c,u)=>{const f=mt(c,t);s=s||Zn(u,f)});let r=n.syncPointTree_.get(t);r?s=s||Zn(r,_e()):(r=new I_,n.syncPointTree_=n.syncPointTree_.set(t,r));const i=s!=null,o=i?new fs(s,!0,!1):null,a=Dl(n.pendingWriteTree_,e._path),B=A_(r,e,a,i?o.getNode():se.EMPTY_NODE,i);return ib(B)}function qr(n,e){return P_(e,n.syncPointTree_,null,Dl(n.pendingWriteTree_,_e()))}function P_(n,e,t,s){if(le(n.path))return F_(n,e,t,s);{const r=e.get(_e());t==null&&r!=null&&(t=Zn(r,_e()));let i=[];const o=ae(n.path),a=n.operationForChild(o),B=e.children.get(o);if(B&&a){const c=t?t.getImmediateChild(o):null,u=E_(s,o);i=i.concat(P_(a,B,c,u))}return r&&(i=i.concat(Ku(r,n,s,t))),i}}function F_(n,e,t,s){const r=e.get(_e());t==null&&r!=null&&(t=Zn(r,_e()));let i=[];return e.children.inorderTraversal((o,a)=>{const B=t?t.getImmediateChild(o):null,c=E_(s,o),u=n.operationForChild(o);u&&(i=i.concat(F_(u,a,B,c)))}),r&&(i=i.concat(Ku(r,n,s,t))),i}function O_(n,e){const t=e.query,s=no(n,t);return{hashFn:()=>(rb(e)||se.EMPTY_NODE).hash(),onComplete:r=>{if(r==="ok")return s?Eb(n,t._path,s):_b(n,t._path);{const i=gS(r,t);return Ua(n,t,null,i)}}}}function no(n,e){const t=wl(e);return n.queryToTagMap.get(t)}function wl(n){return n._path.toString()+"$"+n._queryIdentifier}function zu(n,e){return n.tagToQueryMap.get(e)}function Wu(n){const e=n.indexOf("$");return H(e!==-1&&e<n.length-1,"Bad queryKey."),{queryId:n.substr(e+1),path:new De(n.substr(0,e))}}function $u(n,e,t){const s=n.syncPointTree_.get(e);H(s,"Missing sync point for query tag that we're tracking");const r=Dl(n.pendingWriteTree_,e);return Ku(s,t,r,null)}function wb(n){return n.fold((e,t,s)=>{if(t&&ds(t))return[yl(t)];{let r=[];return t&&(r=v_(t)),lt(s,(i,o)=>{r=r.concat(o)}),r}})}function Si(n){return n._queryParams.loadsAllData()&&!n._queryParams.isDefault()?new(Cb())(n._repo,n._path):n}function Tb(n,e){for(let t=0;t<e.length;++t){const s=e[t];if(!s._queryParams.loadsAllData()){const r=wl(s),i=n.queryToTagMap.get(r);n.queryToTagMap.delete(r),n.tagToQueryMap.delete(i)}}}function Ib(){return pb++}function Ab(n,e,t){const s=e._path,r=no(n,e),i=O_(n,t),o=n.listenProvider_.startListening(Si(e),r,i.hashFn,i.onComplete),a=n.syncPointTree_.subtree(s);if(r)H(!ds(a.value),"If we're adding a query, it shouldn't be shadowed");else{const B=a.fold((c,u,f)=>{if(!le(c)&&u&&ds(u))return[yl(u).query];{let C=[];return u&&(C=C.concat(v_(u).map(g=>g.query))),lt(f,(g,E)=>{C=C.concat(E)}),C}});for(let c=0;c<B.length;++c){const u=B[c];n.listenProvider_.stopListening(Si(u),no(n,u))}}return o}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yu{constructor(e){this.node_=e}getImmediateChild(e){const t=this.node_.getImmediateChild(e);return new Yu(t)}node(){return this.node_}}class Xu{constructor(e,t){this.syncTree_=e,this.path_=t}getImmediateChild(e){const t=ke(this.path_,e);return new Xu(this.syncTree_,t)}node(){return Qu(this.syncTree_,this.path_)}}const vb=function(n){return n=n||{},n.timestamp=n.timestamp||new Date().getTime(),n},PC=function(n,e,t){if(!n||typeof n!="object")return n;if(H(".sv"in n,"Unexpected leaf node or priority contents"),typeof n[".sv"]=="string")return Rb(n[".sv"],e,t);if(typeof n[".sv"]=="object")return Sb(n[".sv"],e);H(!1,"Unexpected server value: "+JSON.stringify(n,null,2))},Rb=function(n,e,t){switch(n){case"timestamp":return t.timestamp;default:H(!1,"Unexpected server value: "+n)}},Sb=function(n,e,t){n.hasOwnProperty("increment")||H(!1,"Unexpected server value: "+JSON.stringify(n,null,2));const s=n.increment;typeof s!="number"&&H(!1,"Unexpected increment value: "+s);const r=e.node();if(H(r!==null&&typeof r<"u","Expected ChildrenNode.EMPTY_NODE for nulls"),!r.isLeafNode())return s;const o=r.getValue();return typeof o!="number"?s:o+s},L_=function(n,e,t,s){return Zu(e,new Xu(t,n),s)},x_=function(n,e,t){return Zu(n,new Yu(e),t)};function Zu(n,e,t){const s=n.getPriority().val(),r=PC(s,e.getImmediateChild(".priority"),t);let i;if(n.isLeafNode()){const o=n,a=PC(o.getValue(),e,t);return a!==o.getValue()||r!==o.getPriority().val()?new Ze(a,We(r)):n}else{const o=n;return i=o,r!==o.getPriority().val()&&(i=i.updatePriority(new Ze(r))),o.forEachChild(Oe,(a,B)=>{const c=Zu(B,e.getImmediateChild(a),t);c!==B&&(i=i.updateImmediateChild(a,c))}),i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eh{constructor(e="",t=null,s={children:{},childCount:0}){this.name=e,this.parent=t,this.node=s}}function th(n,e){let t=e instanceof De?e:new De(e),s=n,r=ae(t);for(;r!==null;){const i=dr(s.node.children,r)||{children:{},childCount:0};s=new eh(r,s,i),t=Re(t),r=ae(t)}return s}function Jr(n){return n.node.value}function k_(n,e){n.node.value=e,dc(n)}function M_(n){return n.node.childCount>0}function bb(n){return Jr(n)===void 0&&!M_(n)}function Tl(n,e){lt(n.node.children,(t,s)=>{e(new eh(t,n,s))})}function V_(n,e,t,s){t&&e(n),Tl(n,r=>{V_(r,e,!0)})}function Nb(n,e,t){let s=n.parent;for(;s!==null;){if(e(s))return!0;s=s.parent}return!1}function Ao(n){return new De(n.parent===null?n.name:Ao(n.parent)+"/"+n.name)}function dc(n){n.parent!==null&&Pb(n.parent,n.name,n)}function Pb(n,e,t){const s=bb(t),r=un(n.node.children,e);s&&r?(delete n.node.children[e],n.node.childCount--,dc(n)):!s&&!r&&(n.node.children[e]=t.node,n.node.childCount++,dc(n))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fb=/[\[\].#$\/\u0000-\u001F\u007F]/,Ob=/[\[\].#$\u0000-\u001F\u007F]/,TB=10*1024*1024,nh=function(n){return typeof n=="string"&&n.length!==0&&!Fb.test(n)},G_=function(n){return typeof n=="string"&&n.length!==0&&!Ob.test(n)},Lb=function(n){return n&&(n=n.replace(/^\/*\.info(\/|$)/,"/")),G_(n)},Cc=function(n){return n===null||typeof n=="string"||typeof n=="number"&&!Au(n)||n&&typeof n=="object"&&un(n,".sv")},$s=function(n,e,t,s){s&&e===void 0||Il(Ja(n,"value"),e,t)},Il=function(n,e,t){const s=t instanceof De?new YS(t,n):t;if(e===void 0)throw new Error(n+"contains undefined "+As(s));if(typeof e=="function")throw new Error(n+"contains a function "+As(s)+" with contents = "+e.toString());if(Au(e))throw new Error(n+"contains "+e.toString()+" "+As(s));if(typeof e=="string"&&e.length>TB/3&&ja(e)>TB)throw new Error(n+"contains a string greater than "+TB+" utf8 bytes "+As(s)+" ('"+e.substring(0,50)+"...')");if(e&&typeof e=="object"){let r=!1,i=!1;if(lt(e,(o,a)=>{if(o===".value")r=!0;else if(o!==".priority"&&o!==".sv"&&(i=!0,!nh(o)))throw new Error(n+" contains an invalid key ("+o+") "+As(s)+`.  Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`);XS(s,o),Il(n,a,s),ZS(s)}),r&&i)throw new Error(n+' contains ".value" child '+As(s)+" in addition to actual children.")}},xb=function(n,e){let t,s;for(t=0;t<e.length;t++){s=e[t];const i=Yi(s);for(let o=0;o<i.length;o++)if(!(i[o]===".priority"&&o===i.length-1)){if(!nh(i[o]))throw new Error(n+"contains an invalid key ("+i[o]+") in path "+s.toString()+`. Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`)}}e.sort($S);let r=null;for(t=0;t<e.length;t++){if(s=e[t],r!==null&&Gt(r,s))throw new Error(n+"contains a path "+r.toString()+" that is ancestor of another path "+s.toString());r=s}},kb=function(n,e,t,s){const r=Ja(n,"values");if(!(e&&typeof e=="object")||Array.isArray(e))throw new Error(r+" must be an object containing the children to replace.");const i=[];lt(e,(o,a)=>{const B=new De(o);if(Il(r,a,ke(t,B)),Nu(B)===".priority"&&!Cc(a))throw new Error(r+"contains an invalid value for '"+B.toString()+"', which must be a valid Firebase priority (a string, finite number, server value, or null).");i.push(B)}),xb(r,i)},sh=function(n,e,t,s){if(!G_(t))throw new Error(Ja(n,e)+'was an invalid path = "'+t+`". Paths must be non-empty strings and can't contain ".", "#", "$", "[", or "]"`)},Mb=function(n,e,t,s){t&&(t=t.replace(/^\/*\.info(\/|$)/,"/")),sh(n,e,t)},rh=function(n,e){if(ae(e)===".info")throw new Error(n+" failed = Can't modify data under /.info/")},Vb=function(n,e){const t=e.path.toString();if(typeof e.repoInfo.host!="string"||e.repoInfo.host.length===0||!nh(e.repoInfo.namespace)&&e.repoInfo.host.split(":")[0]!=="localhost"||t.length!==0&&!Lb(t))throw new Error(Ja(n,"url")+`must be a valid firebase URL and the path can't contain ".", "#", "$", "[", or "]".`)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gb{constructor(){this.eventLists_=[],this.recursionDepth_=0}}function Al(n,e){let t=null;for(let s=0;s<e.length;s++){const r=e[s],i=r.getPath();t!==null&&!Pu(i,t.path)&&(n.eventLists_.push(t),t=null),t===null&&(t={events:[],path:i}),t.events.push(r)}t&&n.eventLists_.push(t)}function H_(n,e,t){Al(n,t),U_(n,s=>Pu(s,e))}function qt(n,e,t){Al(n,t),U_(n,s=>Gt(s,e)||Gt(e,s))}function U_(n,e){n.recursionDepth_++;let t=!0;for(let s=0;s<n.eventLists_.length;s++){const r=n.eventLists_[s];if(r){const i=r.path;e(i)?(Hb(n.eventLists_[s]),n.eventLists_[s]=null):t=!1}}t&&(n.eventLists_=[]),n.recursionDepth_--}function Hb(n){for(let e=0;e<n.events.length;e++){const t=n.events[e];if(t!==null){n.events[e]=null;const s=t.getEventRunner();xs&&rt("event: "+t.toString()),Ur(s)}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ub="repo_interrupt",qb=25;class Jb{constructor(e,t,s,r){this.repoInfo_=e,this.forceRestClient_=t,this.authTokenProvider_=s,this.appCheckProvider_=r,this.dataUpdateCount=0,this.statsListener_=null,this.eventQueue_=new Gb,this.nextWriteId_=1,this.interceptServerDataCallback_=null,this.onDisconnect_=Oa(),this.transactionQueueTree_=new eh,this.persistentConnection_=null,this.key=this.repoInfo_.toURLString()}toString(){return(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host}}function jb(n,e,t){if(n.stats_=Su(n.repoInfo_),n.forceRestClient_||DS())n.server_=new Fa(n.repoInfo_,(s,r,i,o)=>{FC(n,s,r,i,o)},n.authTokenProvider_,n.appCheckProvider_),setTimeout(()=>OC(n,!0),0);else{if(typeof t<"u"&&t!==null){if(typeof t!="object")throw new Error("Only objects are supported for option databaseAuthVariableOverride");try{$e(t)}catch(s){throw new Error("Invalid authOverride provided: "+s)}}n.persistentConnection_=new yn(n.repoInfo_,e,(s,r,i,o)=>{FC(n,s,r,i,o)},s=>{OC(n,s)},s=>{Kb(n,s)},n.authTokenProvider_,n.appCheckProvider_,t),n.server_=n.persistentConnection_}n.authTokenProvider_.addTokenChangeListener(s=>{n.server_.refreshAuthToken(s)}),n.appCheckProvider_.addTokenChangeListener(s=>{n.server_.refreshAppCheckToken(s.token)}),n.statsReporter_=AS(n.repoInfo_,()=>new v0(n.stats_,n.server_)),n.infoData_=new y0,n.infoSyncTree_=new NC({startListening:(s,r,i,o)=>{let a=[];const B=n.infoData_.getNode(s._path);return B.isEmpty()||(a=Io(n.infoSyncTree_,s._path,B),setTimeout(()=>{o("ok")},0)),a},stopListening:()=>{}}),ih(n,"connected",!1),n.serverSyncTree_=new NC({startListening:(s,r,i,o)=>(n.server_.listen(s,i,r,(a,B)=>{const c=o(a,B);qt(n.eventQueue_,s._path,c)}),[]),stopListening:(s,r)=>{n.server_.unlisten(s,r)}})}function q_(n){const t=n.infoData_.getNode(new De(".info/serverTimeOffset")).val()||0;return new Date().getTime()+t}function vl(n){return vb({timestamp:q_(n)})}function FC(n,e,t,s,r){n.dataUpdateCount++;const i=new De(e);t=n.interceptServerDataCallback_?n.interceptServerDataCallback_(e,t):t;let o=[];if(r)if(s){const B=fa(t,c=>We(c));o=Db(n.serverSyncTree_,i,B,r)}else{const B=We(t);o=N_(n.serverSyncTree_,i,B,r)}else if(s){const B=fa(t,c=>We(c));o=mb(n.serverSyncTree_,i,B)}else{const B=We(t);o=Io(n.serverSyncTree_,i,B)}let a=i;o.length>0&&(a=vr(n,i)),qt(n.eventQueue_,a,o)}function OC(n,e){ih(n,"connected",e),e===!1&&$b(n)}function Kb(n,e){lt(e,(t,s)=>{ih(n,t,s)})}function ih(n,e,t){const s=new De("/.info/"+e),r=We(t);n.infoData_.updateSnapshot(s,r);const i=Io(n.infoSyncTree_,s,r);qt(n.eventQueue_,s,i)}function oh(n){return n.nextWriteId_++}function Qb(n,e,t){const s=yb(n.serverSyncTree_,e);return s!=null?Promise.resolve(s):n.server_.get(e).then(r=>{const i=We(r).withIndex(e._queryParams.getIndex());fc(n.serverSyncTree_,e,t,!0);let o;if(e._queryParams.loadsAllData())o=Io(n.serverSyncTree_,e._path,i);else{const a=no(n.serverSyncTree_,e);o=N_(n.serverSyncTree_,e._path,i,a)}return qt(n.eventQueue_,e._path,o),Ua(n.serverSyncTree_,e,t,null,!0),i},r=>(vo(n,"get for query "+$e(e)+" failed: "+r),Promise.reject(new Error(r))))}function zb(n,e,t,s,r){vo(n,"set",{path:e.toString(),value:t,priority:s});const i=vl(n),o=We(t,s),a=Qu(n.serverSyncTree_,e),B=x_(o,a,i),c=oh(n),u=b_(n.serverSyncTree_,e,B,c,!0);Al(n.eventQueue_,u),n.server_.put(e.toString(),o.val(!0),(C,g)=>{const E=C==="ok";E||_t("set at "+e+" failed: "+C);const b=qn(n.serverSyncTree_,c,!E);qt(n.eventQueue_,e,b),pc(n,r,C,g)});const f=lh(n,e);vr(n,f),qt(n.eventQueue_,f,[])}function Wb(n,e,t,s){vo(n,"update",{path:e.toString(),value:t});let r=!0;const i=vl(n),o={};if(lt(t,(a,B)=>{r=!1,o[a]=L_(ke(e,a),We(B),n.serverSyncTree_,i)}),r)rt("update() called with empty data.  Don't do anything."),pc(n,s,"ok",void 0);else{const a=oh(n),B=gb(n.serverSyncTree_,e,o,a);Al(n.eventQueue_,B),n.server_.merge(e.toString(),t,(c,u)=>{const f=c==="ok";f||_t("update at "+e+" failed: "+c);const C=qn(n.serverSyncTree_,a,!f),g=C.length>0?vr(n,e):e;qt(n.eventQueue_,g,C),pc(n,s,c,u)}),lt(t,c=>{const u=lh(n,ke(e,c));vr(n,u)}),qt(n.eventQueue_,e,[])}}function $b(n){vo(n,"onDisconnectEvents");const e=vl(n),t=Oa();ac(n.onDisconnect_,_e(),(r,i)=>{const o=L_(r,i,n.serverSyncTree_,e);C_(t,r,o)});let s=[];ac(t,_e(),(r,i)=>{s=s.concat(Io(n.serverSyncTree_,r,i));const o=lh(n,r);vr(n,o)}),n.onDisconnect_=Oa(),qt(n.eventQueue_,_e(),s)}function Yb(n,e,t){let s;ae(e._path)===".info"?s=fc(n.infoSyncTree_,e,t):s=fc(n.serverSyncTree_,e,t),H_(n.eventQueue_,e._path,s)}function Xb(n,e,t){let s;ae(e._path)===".info"?s=Ua(n.infoSyncTree_,e,t):s=Ua(n.serverSyncTree_,e,t),H_(n.eventQueue_,e._path,s)}function Zb(n){n.persistentConnection_&&n.persistentConnection_.interrupt(Ub)}function vo(n,...e){let t="";n.persistentConnection_&&(t=n.persistentConnection_.id+":"),rt(t,...e)}function pc(n,e,t,s){e&&Ur(()=>{if(t==="ok")e(null);else{const r=(t||"error").toUpperCase();let i=r;s&&(i+=": "+s);const o=new Error(i);o.code=r,e(o)}})}function J_(n,e,t){return Qu(n.serverSyncTree_,e,t)||se.EMPTY_NODE}function ah(n,e=n.transactionQueueTree_){if(e||Rl(n,e),Jr(e)){const t=K_(n,e);H(t.length>0,"Sending zero length transaction queue"),t.every(r=>r.status===0)&&eN(n,Ao(e),t)}else M_(e)&&Tl(e,t=>{ah(n,t)})}function eN(n,e,t){const s=t.map(c=>c.currentWriteId),r=J_(n,e,s);let i=r;const o=r.hash();for(let c=0;c<t.length;c++){const u=t[c];H(u.status===0,"tryToSendTransactionQueue_: items in queue should all be run."),u.status=1,u.retryCount++;const f=mt(e,u.path);i=i.updateChild(f,u.currentOutputSnapshotRaw)}const a=i.val(!0),B=e;n.server_.put(B.toString(),a,c=>{vo(n,"transaction put response",{path:B.toString(),status:c});let u=[];if(c==="ok"){const f=[];for(let C=0;C<t.length;C++)t[C].status=2,u=u.concat(qn(n.serverSyncTree_,t[C].currentWriteId)),t[C].onComplete&&f.push(()=>t[C].onComplete(null,!0,t[C].currentOutputSnapshotResolved)),t[C].unwatcher();Rl(n,th(n.transactionQueueTree_,e)),ah(n,n.transactionQueueTree_),qt(n.eventQueue_,e,u);for(let C=0;C<f.length;C++)Ur(f[C])}else{if(c==="datastale")for(let f=0;f<t.length;f++)t[f].status===3?t[f].status=4:t[f].status=0;else{_t("transaction at "+B.toString()+" failed: "+c);for(let f=0;f<t.length;f++)t[f].status=4,t[f].abortReason=c}vr(n,e)}},o)}function vr(n,e){const t=j_(n,e),s=Ao(t),r=K_(n,t);return tN(n,r,s),s}function tN(n,e,t){if(e.length===0)return;const s=[];let r=[];const o=e.filter(a=>a.status===0).map(a=>a.currentWriteId);for(let a=0;a<e.length;a++){const B=e[a],c=mt(t,B.path);let u=!1,f;if(H(c!==null,"rerunTransactionsUnderNode_: relativePath should not be null."),B.status===4)u=!0,f=B.abortReason,r=r.concat(qn(n.serverSyncTree_,B.currentWriteId,!0));else if(B.status===0)if(B.retryCount>=qb)u=!0,f="maxretry",r=r.concat(qn(n.serverSyncTree_,B.currentWriteId,!0));else{const C=J_(n,B.path,o);B.currentInputSnapshot=C;const g=e[a].update(C.val());if(g!==void 0){Il("transaction failed: Data returned ",g,B.path);let E=We(g);typeof g=="object"&&g!=null&&un(g,".priority")||(E=E.updatePriority(C.getPriority()));const F=B.currentWriteId,j=vl(n),te=x_(E,C,j);B.currentOutputSnapshotRaw=E,B.currentOutputSnapshotResolved=te,B.currentWriteId=oh(n),o.splice(o.indexOf(F),1),r=r.concat(b_(n.serverSyncTree_,B.path,te,B.currentWriteId,B.applyLocally)),r=r.concat(qn(n.serverSyncTree_,F,!0))}else u=!0,f="nodata",r=r.concat(qn(n.serverSyncTree_,B.currentWriteId,!0))}qt(n.eventQueue_,t,r),r=[],u&&(e[a].status=2,function(C){setTimeout(C,Math.floor(0))}(e[a].unwatcher),e[a].onComplete&&(f==="nodata"?s.push(()=>e[a].onComplete(null,!1,e[a].currentInputSnapshot)):s.push(()=>e[a].onComplete(new Error(f),!1,null))))}Rl(n,n.transactionQueueTree_);for(let a=0;a<s.length;a++)Ur(s[a]);ah(n,n.transactionQueueTree_)}function j_(n,e){let t,s=n.transactionQueueTree_;for(t=ae(e);t!==null&&Jr(s)===void 0;)s=th(s,t),e=Re(e),t=ae(e);return s}function K_(n,e){const t=[];return Q_(n,e,t),t.sort((s,r)=>s.order-r.order),t}function Q_(n,e,t){const s=Jr(e);if(s)for(let r=0;r<s.length;r++)t.push(s[r]);Tl(e,r=>{Q_(n,r,t)})}function Rl(n,e){const t=Jr(e);if(t){let s=0;for(let r=0;r<t.length;r++)t[r].status!==2&&(t[s]=t[r],s++);t.length=s,k_(e,t.length>0?t:void 0)}Tl(e,s=>{Rl(n,s)})}function lh(n,e){const t=Ao(j_(n,e)),s=th(n.transactionQueueTree_,e);return Nb(s,r=>{IB(n,r)}),IB(n,s),V_(s,r=>{IB(n,r)}),t}function IB(n,e){const t=Jr(e);if(t){const s=[];let r=[],i=-1;for(let o=0;o<t.length;o++)t[o].status===3||(t[o].status===1?(H(i===o-1,"All SENT items should be at beginning of queue."),i=o,t[o].status=3,t[o].abortReason="set"):(H(t[o].status===0,"Unexpected transaction status in abort"),t[o].unwatcher(),r=r.concat(qn(n.serverSyncTree_,t[o].currentWriteId,!0)),t[o].onComplete&&s.push(t[o].onComplete.bind(null,new Error("set"),!1,null))));i===-1?k_(e,void 0):t.length=i+1,qt(n.eventQueue_,Ao(e),r);for(let o=0;o<s.length;o++)Ur(s[o])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nN(n){let e="";const t=n.split("/");for(let s=0;s<t.length;s++)if(t[s].length>0){let r=t[s];try{r=decodeURIComponent(r.replace(/\+/g," "))}catch{}e+="/"+r}return e}function sN(n){const e={};n.charAt(0)==="?"&&(n=n.substring(1));for(const t of n.split("&")){if(t.length===0)continue;const s=t.split("=");s.length===2?e[decodeURIComponent(s[0])]=decodeURIComponent(s[1]):_t(`Invalid query segment '${t}' in query '${n}'`)}return e}const LC=function(n,e){const t=rN(n),s=t.namespace;t.domain==="firebase.com"&&Rn(t.host+" is no longer supported. Please use <YOUR FIREBASE>.firebaseio.com instead"),(!s||s==="undefined")&&t.domain!=="localhost"&&Rn("Cannot parse Firebase url. Please use https://<YOUR FIREBASE>.firebaseio.com"),t.secure||hS();const r=t.scheme==="ws"||t.scheme==="wss";return{repoInfo:new Xm(t.host,t.secure,s,r,e,"",s!==t.subdomain),path:new De(t.pathString)}},rN=function(n){let e="",t="",s="",r="",i="",o=!0,a="https",B=443;if(typeof n=="string"){let c=n.indexOf("//");c>=0&&(a=n.substring(0,c-1),n=n.substring(c+2));let u=n.indexOf("/");u===-1&&(u=n.length);let f=n.indexOf("?");f===-1&&(f=n.length),e=n.substring(0,Math.min(u,f)),u<f&&(r=nN(n.substring(u,f)));const C=sN(n.substring(Math.min(n.length,f)));c=e.indexOf(":"),c>=0?(o=a==="https"||a==="wss",B=parseInt(e.substring(c+1),10)):c=e.length;const g=e.slice(0,c);if(g.toLowerCase()==="localhost")t="localhost";else if(g.split(".").length<=2)t=g;else{const E=e.indexOf(".");s=e.substring(0,E).toLowerCase(),t=e.substring(E+1),i=s}"ns"in C&&(i=C.ns)}return{host:e,port:B,domain:t,subdomain:s,secure:o,scheme:a,pathString:r,namespace:i}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xC="-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz",iN=function(){let n=0;const e=[];return function(t){const s=t===n;n=t;let r;const i=new Array(8);for(r=7;r>=0;r--)i[r]=xC.charAt(t%64),t=Math.floor(t/64);H(t===0,"Cannot push at time == 0");let o=i.join("");if(s){for(r=11;r>=0&&e[r]===63;r--)e[r]=0;e[r]++}else for(r=0;r<12;r++)e[r]=Math.floor(Math.random()*64);for(r=0;r<12;r++)o+=xC.charAt(e[r]);return H(o.length===20,"nextPushId: Length should be 20."),o}}();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class z_{constructor(e,t,s,r){this.eventType=e,this.eventRegistration=t,this.snapshot=s,this.prevName=r}getPath(){const e=this.snapshot.ref;return this.eventType==="value"?e._path:e.parent._path}getEventType(){return this.eventType}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.getPath().toString()+":"+this.eventType+":"+$e(this.snapshot.exportVal())}}class W_{constructor(e,t,s){this.eventRegistration=e,this.error=t,this.path=s}getPath(){return this.path}getEventType(){return"cancel"}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.path.toString()+":cancel"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $_{constructor(e,t){this.snapshotCallback=e,this.cancelCallback=t}onValue(e,t){this.snapshotCallback.call(null,e,t)}onCancel(e){return H(this.hasCancelCallback,"Raising a cancel event on a listener with no cancel callback"),this.cancelCallback.call(null,e)}get hasCancelCallback(){return!!this.cancelCallback}matches(e){return this.snapshotCallback===e.snapshotCallback||this.snapshotCallback.userCallback!==void 0&&this.snapshotCallback.userCallback===e.snapshotCallback.userCallback&&this.snapshotCallback.context===e.snapshotCallback.context}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jt{constructor(e,t,s,r){this._repo=e,this._path=t,this._queryParams=s,this._orderByCalled=r}get key(){return le(this._path)?null:Nu(this._path)}get ref(){return new hn(this._repo,this._path)}get _queryIdentifier(){const e=DC(this._queryParams),t=vu(e);return t==="{}"?"default":t}get _queryObject(){return DC(this._queryParams)}isEqual(e){if(e=Ie(e),!(e instanceof Jt))return!1;const t=this._repo===e._repo,s=Pu(this._path,e._path),r=this._queryIdentifier===e._queryIdentifier;return t&&s&&r}toJSON(){return this.toString()}toString(){return this._repo.toString()+WS(this._path)}}function Bh(n,e){if(n._orderByCalled===!0)throw new Error(e+": You can't combine multiple orderBy calls.")}function Ys(n){let e=null,t=null;if(n.hasStart()&&(e=n.getIndexStartValue()),n.hasEnd()&&(t=n.getIndexEndValue()),n.getIndex()===ln){const s="Query: When ordering by key, you may only pass one argument to startAt(), endAt(), or equalTo().",r="Query: When ordering by key, the argument passed to startAt(), startAfter(), endAt(), endBefore(), or equalTo() must be a string.";if(n.hasStart()){if(n.getIndexStartName()!==us)throw new Error(s);if(typeof e!="string")throw new Error(r)}if(n.hasEnd()){if(n.getIndexEndName()!==Sn)throw new Error(s);if(typeof t!="string")throw new Error(r)}}else if(n.getIndex()===Oe){if(e!=null&&!Cc(e)||t!=null&&!Cc(t))throw new Error("Query: When ordering by priority, the first argument passed to startAt(), startAfter() endAt(), endBefore(), or equalTo() must be a valid priority value (null, a number, or a string).")}else if(H(n.getIndex()instanceof Lu||n.getIndex()===xu,"unknown index type."),e!=null&&typeof e=="object"||t!=null&&typeof t=="object")throw new Error("Query: First argument passed to startAt(), startAfter(), endAt(), endBefore(), or equalTo() cannot be an object.")}function Sl(n){if(n.hasStart()&&n.hasEnd()&&n.hasLimit()&&!n.hasAnchoredLimit())throw new Error("Query: Can't combine startAt(), startAfter(), endAt(), endBefore(), and limit(). Use limitToFirst() or limitToLast() instead.")}class hn extends Jt{constructor(e,t){super(e,t,new Mu,!1)}get parent(){const e=a_(this._path);return e===null?null:new hn(this._repo,e)}get root(){let e=this;for(;e.parent!==null;)e=e.parent;return e}}class Rr{constructor(e,t,s){this._node=e,this.ref=t,this._index=s}get priority(){return this._node.getPriority().val()}get key(){return this.ref.key}get size(){return this._node.numChildren()}child(e){const t=new De(e),s=Sr(this.ref,e);return new Rr(this._node.getChild(t),s,Oe)}exists(){return!this._node.isEmpty()}exportVal(){return this._node.val(!0)}forEach(e){return this._node.isLeafNode()?!1:!!this._node.forEachChild(this._index,(s,r)=>e(new Rr(r,Sr(this.ref,s),Oe)))}hasChild(e){const t=new De(e);return!this._node.getChild(t).isEmpty()}hasChildren(){return this._node.isLeafNode()?!1:!this._node.isEmpty()}toJSON(){return this.exportVal()}val(){return this._node.val()}}function aP(n,e){return n=Ie(n),n._checkNotDeleted("ref"),e!==void 0?Sr(n._root,e):n._root}function Sr(n,e){return n=Ie(n),ae(n._path)===null?Mb("child","path",e):sh("child","path",e),new hn(n._repo,ke(n._path,e))}function lP(n,e){n=Ie(n),rh("push",n._path),$s("push",e,n._path,!0);const t=q_(n._repo),s=iN(t),r=Sr(n,s),i=Sr(n,s);let o;return o=Promise.resolve(i),r.then=o.then.bind(o),r.catch=o.then.bind(o,void 0),r}function BP(n){return rh("remove",n._path),oN(n,null)}function oN(n,e){n=Ie(n),rh("set",n._path),$s("set",e,n._path,!1);const t=new so;return zb(n._repo,n._path,e,null,t.wrapCallback(()=>{})),t.promise}function cP(n,e){kb("update",e,n._path);const t=new so;return Wb(n._repo,n._path,e,t.wrapCallback(()=>{})),t.promise}function uP(n){n=Ie(n);const e=new $_(()=>{}),t=new bl(e);return Qb(n._repo,n,t).then(s=>new Rr(s,new hn(n._repo,n._path),n._queryParams.getIndex()))}class bl{constructor(e){this.callbackContext=e}respondsTo(e){return e==="value"}createEvent(e,t){const s=t._queryParams.getIndex();return new z_("value",this,new Rr(e.snapshotNode,new hn(t._repo,t._path),s))}getEventRunner(e){return e.getEventType()==="cancel"?()=>this.callbackContext.onCancel(e.error):()=>this.callbackContext.onValue(e.snapshot,null)}createCancelEvent(e,t){return this.callbackContext.hasCancelCallback?new W_(this,e,t):null}matches(e){return e instanceof bl?!e.callbackContext||!this.callbackContext?!0:e.callbackContext.matches(this.callbackContext):!1}hasAnyCallback(){return this.callbackContext!==null}}class ch{constructor(e,t){this.eventType=e,this.callbackContext=t}respondsTo(e){let t=e==="children_added"?"child_added":e;return t=t==="children_removed"?"child_removed":t,this.eventType===t}createCancelEvent(e,t){return this.callbackContext.hasCancelCallback?new W_(this,e,t):null}createEvent(e,t){H(e.childName!=null,"Child events should have a childName.");const s=Sr(new hn(t._repo,t._path),e.childName),r=t._queryParams.getIndex();return new z_(e.type,this,new Rr(e.snapshotNode,s,r),e.prevName)}getEventRunner(e){return e.getEventType()==="cancel"?()=>this.callbackContext.onCancel(e.error):()=>this.callbackContext.onValue(e.snapshot,e.prevName)}matches(e){return e instanceof ch?this.eventType===e.eventType&&(!this.callbackContext||!e.callbackContext||this.callbackContext.matches(e.callbackContext)):!1}hasAnyCallback(){return!!this.callbackContext}}function Ro(n,e,t,s,r){const i=new $_(t,void 0),o=e==="value"?new bl(i):new ch(e,i);return Yb(n._repo,n,o),()=>Xb(n._repo,n,o)}function hP(n,e,t,s){return Ro(n,"value",e)}function fP(n,e,t,s){return Ro(n,"child_added",e)}function dP(n,e,t,s){return Ro(n,"child_changed",e)}function CP(n,e,t,s){return Ro(n,"child_moved",e)}function pP(n,e,t,s){return Ro(n,"child_removed",e)}class fn{}class Y_ extends fn{constructor(e,t){super(),this._value=e,this._key=t,this.type="endAt"}_apply(e){$s("endAt",this._value,e._path,!0);const t=oc(e._queryParams,this._value,this._key);if(Sl(t),Ys(t),e._queryParams.hasEnd())throw new Error("endAt: Starting point was already set (by another call to endAt, endBefore or equalTo).");return new Jt(e._repo,e._path,t,e._orderByCalled)}}function gP(n,e){return new Y_(n,e)}class aN extends fn{constructor(e,t){super(),this._value=e,this._key=t,this.type="endBefore"}_apply(e){$s("endBefore",this._value,e._path,!1);const t=D0(e._queryParams,this._value,this._key);if(Sl(t),Ys(t),e._queryParams.hasEnd())throw new Error("endBefore: Starting point was already set (by another call to endAt, endBefore or equalTo).");return new Jt(e._repo,e._path,t,e._orderByCalled)}}function mP(n,e){return new aN(n,e)}class X_ extends fn{constructor(e,t){super(),this._value=e,this._key=t,this.type="startAt"}_apply(e){$s("startAt",this._value,e._path,!0);const t=ic(e._queryParams,this._value,this._key);if(Sl(t),Ys(t),e._queryParams.hasStart())throw new Error("startAt: Starting point was already set (by another call to startAt, startBefore or equalTo).");return new Jt(e._repo,e._path,t,e._orderByCalled)}}function _P(n=null,e){return new X_(n,e)}class lN extends fn{constructor(e,t){super(),this._value=e,this._key=t,this.type="startAfter"}_apply(e){$s("startAfter",this._value,e._path,!1);const t=E0(e._queryParams,this._value,this._key);if(Sl(t),Ys(t),e._queryParams.hasStart())throw new Error("startAfter: Starting point was already set (by another call to startAt, startAfter, or equalTo).");return new Jt(e._repo,e._path,t,e._orderByCalled)}}function EP(n,e){return new lN(n,e)}class BN extends fn{constructor(e){super(),this._limit=e,this.type="limitToFirst"}_apply(e){if(e._queryParams.hasLimit())throw new Error("limitToFirst: Limit was already set (by another call to limitToFirst or limitToLast).");return new Jt(e._repo,e._path,m0(e._queryParams,this._limit),e._orderByCalled)}}function DP(n){if(typeof n!="number"||Math.floor(n)!==n||n<=0)throw new Error("limitToFirst: First argument must be a positive integer.");return new BN(n)}class cN extends fn{constructor(e){super(),this._limit=e,this.type="limitToLast"}_apply(e){if(e._queryParams.hasLimit())throw new Error("limitToLast: Limit was already set (by another call to limitToFirst or limitToLast).");return new Jt(e._repo,e._path,_0(e._queryParams,this._limit),e._orderByCalled)}}function yP(n){if(typeof n!="number"||Math.floor(n)!==n||n<=0)throw new Error("limitToLast: First argument must be a positive integer.");return new cN(n)}class uN extends fn{constructor(e){super(),this._path=e,this.type="orderByChild"}_apply(e){Bh(e,"orderByChild");const t=new De(this._path);if(le(t))throw new Error("orderByChild: cannot pass in empty path. Use orderByValue() instead.");const s=new Lu(t),r=Vu(e._queryParams,s);return Ys(r),new Jt(e._repo,e._path,r,!0)}}function wP(n){if(n==="$key")throw new Error('orderByChild: "$key" is invalid.  Use orderByKey() instead.');if(n==="$priority")throw new Error('orderByChild: "$priority" is invalid.  Use orderByPriority() instead.');if(n==="$value")throw new Error('orderByChild: "$value" is invalid.  Use orderByValue() instead.');return sh("orderByChild","path",n),new uN(n)}class hN extends fn{constructor(){super(...arguments),this.type="orderByKey"}_apply(e){Bh(e,"orderByKey");const t=Vu(e._queryParams,ln);return Ys(t),new Jt(e._repo,e._path,t,!0)}}function TP(){return new hN}class fN extends fn{constructor(){super(...arguments),this.type="orderByValue"}_apply(e){Bh(e,"orderByValue");const t=Vu(e._queryParams,xu);return Ys(t),new Jt(e._repo,e._path,t,!0)}}function IP(){return new fN}class dN extends fn{constructor(e,t){super(),this._value=e,this._key=t,this.type="equalTo"}_apply(e){if($s("equalTo",this._value,e._path,!1),e._queryParams.hasStart())throw new Error("equalTo: Starting point was already set (by another call to startAt/startAfter or equalTo).");if(e._queryParams.hasEnd())throw new Error("equalTo: Ending point was already set (by another call to endAt/endBefore or equalTo).");return new Y_(this._value,this._key)._apply(new X_(this._value,this._key)._apply(e))}}function AP(n,e){return new dN(n,e)}function vP(n,...e){let t=Ie(n);for(const s of e)t=s._apply(t);return t}Bb(hn);db(hn);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CN="FIREBASE_DATABASE_EMULATOR_HOST",gc={};let pN=!1;function gN(n,e,t,s){const r=e.lastIndexOf(":"),i=e.substring(0,r),o=Ka(i);n.repoInfo_=new Xm(e,o,n.repoInfo_.namespace,n.repoInfo_.webSocketOnly,n.repoInfo_.nodeAdmin,n.repoInfo_.persistenceKey,n.repoInfo_.includeNamespaceInQueryParams,!0,t),s&&(n.authTokenProvider_=s)}function mN(n,e,t,s,r){let i=s||n.options.databaseURL;i===void 0&&(n.options.projectId||Rn("Can't determine Firebase Database URL. Be sure to include  a Project ID when calling firebase.initializeApp()."),rt("Using default host for project ",n.options.projectId),i=`${n.options.projectId}-default-rtdb.firebaseio.com`);let o=LC(i,r),a=o.repoInfo,B;typeof process<"u"&&sC&&(B=sC[CN]),B?(i=`http://${B}?ns=${a.namespace}`,o=LC(i,r),a=o.repoInfo):o.repoInfo.secure;const c=new wS(n.name,n.options,e);Vb("Invalid Firebase Database URL",o),le(o.path)||Rn("Database URL must point to the root of a Firebase Database (not including a child path).");const u=EN(a,n,c,new yS(n,t));return new DN(u,n)}function _N(n,e){const t=gc[e];(!t||t[n.key]!==n)&&Rn(`Database ${e}(${n.repoInfo_}) has already been deleted.`),Zb(n),delete t[n.key]}function EN(n,e,t,s){let r=gc[e.name];r||(r={},gc[e.name]=r);let i=r[n.toURLString()];return i&&Rn("Database initialized multiple times. Please make sure the format of the database URL matches with each database() call."),i=new Jb(n,pN,t,s),r[n.toURLString()]=i,i}class DN{constructor(e,t){this._repoInternal=e,this.app=t,this.type="database",this._instanceStarted=!1}get _repo(){return this._instanceStarted||(jb(this._repoInternal,this.app.options.appId,this.app.options.databaseAuthVariableOverride),this._instanceStarted=!0),this._repoInternal}get _root(){return this._rootInternal||(this._rootInternal=new hn(this._repo,_e())),this._rootInternal}_delete(){return this._rootInternal!==null&&(_N(this._repo,this.app.name),this._repoInternal=null,this._rootInternal=null),Promise.resolve()}_checkNotDeleted(e){this._rootInternal===null&&Rn("Cannot call "+e+" on a deleted database.")}}function RP(n=Dc(),e){const t=ro(n,"database").getImmediate({identifier:e});if(!t._instanceStarted){const s=HC("database");s&&yN(t,...s)}return t}function yN(n,e,t,s={}){n=Ie(n),n._checkNotDeleted("useEmulator");const r=`${e}:${t}`,i=n._repoInternal;if(n._instanceStarted){if(r===n._repoInternal.repoInfo_.host&&ks(s,i.repoInfo_.emulatorOptions))return;Rn("connectDatabaseEmulator() cannot initialize or alter the emulator configuration after the database instance has started.")}let o;if(i.repoInfo_.nodeAdmin)s.mockUserToken&&Rn('mockUserToken is not supported by the Admin SDK. For client access with mock users, please use the "firebase" package instead of "firebase-admin".'),o=new ua(ua.OWNER);else if(s.mockUserToken){const a=typeof s.mockUserToken=="string"?s.mockUserToken:qC(s.mockUserToken,n.app.options.projectId);o=new ua(a)}Ka(e)&&WC(e),gN(i,r,s,o)}function SP(n,e){Gm(n,e)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wN(n){lS(da),es(new wn("database",(e,{instanceIdentifier:t})=>{const s=e.getProvider("app").getImmediate(),r=e.getProvider("auth-internal"),i=e.getProvider("app-check-internal");return mN(s,r,i,t)},"PUBLIC").setMultipleInstances(!0)),Ht(rC,iC,n),Ht(rC,iC,"esm2020")}function bP(n){return{".sv":{increment:n}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */yn.prototype.simpleListen=function(n,e){this.sendRequest("q",{p:n},e)};yn.prototype.echo=function(n,e){this.sendRequest("echo",{d:n},e)};wN();export{CP as $,YN as A,eP as B,tP as C,ON as D,RP as E,aP as F,SP as G,hP as H,lP as I,oN as J,cP as K,bP as L,BP as M,wP as N,TP as O,IP as P,DP as Q,yP as R,_P as S,EP as T,mP as U,gP as V,AP as W,vP as X,uP as Y,fP as Z,dP as _,Dc as a,pP as a0,vN as b,AN as c,HN as d,zN as e,SN as f,IN as g,$N as h,ny as i,WN as j,oP as k,KN as l,KI as m,FN as n,jN as o,nP as p,qN as q,iP as r,QN as s,xN as t,sP as u,ZN as v,JN as w,rP as x,kN as y,LN as z};
