import{r as R,e as ct,aJ as Ct,f as vt,aK as kt,j as o,h as lt,aL as Rt,au as Ee,at as Fe,d as De,aB as At,aM as zt,l as Ae,c as Ce,s as Ne,aN as Mt,a as Qe,ax as Be,m as He,aO as Wt,aP as Nt,n as It,a4 as Oe,aQ as Ot,ay as Lt,t as rt,B as L,G as le,H as ye,E as W,T as k,K as F,S as D,P as Pe,w as de,C as St,I as Le,aj as Et,a7 as Ft,aH as Dt,v as Bt,ar as Ht,ap as Vt,L as Re,aR as jt,Z as Jt,ak as Yt,aS as Kt,aT as Ze,x as Se,N as Ut,aU as Gt,aV as $t,ah as qt,aW as Xt,aX as dt,ac as Qt,aY as Zt,aZ as _t,a_ as eo,a$ as pt,b0 as ft,b1 as to,b2 as oo,b3 as no,b4 as ro,b5 as ao,b6 as io,b7 as so,b8 as co,b9 as lo,ba as po,bb as fo,bc as uo,bd as mo}from"./index-BkK-Y9PI.js";import{B as ho}from"./BreadcrumbsNav-Cf8retcK.js";import{T as go,a as xo,b as _e,c as et,d as bo}from"./TableRow-w4BvTxzi.js";import{A as yo,g as tt,s as ut,p as wo,W as vo}from"./Index-CrbhSgwN.js";import{T as No,a as mt}from"./ToggleButtonGroup-DyIv-i-6.js";import{D as So}from"./Dialog-CKH7XXUo.js";import{D as jo,a as Po,b as To}from"./DialogTitle-BG8WeJxC.js";import"./MyInputField-hG2fwO4t.js";import"./dataConversion-D4-F2B6M.js";import"./MyForm-BlzfM2hA.js";import"./FormControlLabel-DWHZ9Ikk.js";import"./Alert-COFrrBbl.js";import"./Collapse-SgjVBiw_.js";const Co={entering:{transform:"none"},entered:{transform:"none"}},ko=R.forwardRef(function(t,r){const a=ct(),p={enter:a.transitions.duration.enteringScreen,exit:a.transitions.duration.leavingScreen},{addEndListener:l,appear:m=!0,children:f,easing:h,in:A,onEnter:x,onEntered:S,onEntering:j,onExit:P,onExited:V,onExiting:B,style:Q,timeout:Z=p,TransitionComponent:_=Ct,...ee}=t,U=R.useRef(null),I=vt(U,kt(f),r),y=g=>T=>{if(g){const s=U.current;T===void 0?g(s):g(s,T)}},J=y(j),H=y((g,T)=>{Rt(g);const s=lt({style:Q,timeout:Z,easing:h},{mode:"enter"});g.style.webkitTransition=a.transitions.create("transform",s),g.style.transition=a.transitions.create("transform",s),x&&x(g,T)}),q=y(S),G=y(B),ie=y(g=>{const T=lt({style:Q,timeout:Z,easing:h},{mode:"exit"});g.style.webkitTransition=a.transitions.create("transform",T),g.style.transition=a.transitions.create("transform",T),P&&P(g)}),c=y(V),N=g=>{l&&l(U.current,g)};return o.jsx(_,{appear:m,in:A,nodeRef:U,onEnter:H,onEntered:q,onEntering:J,onExit:ie,onExited:c,onExiting:G,addEndListener:N,timeout:Z,...ee,children:(g,{ownerState:T,...s})=>R.cloneElement(f,{style:{transform:"scale(0)",visibility:g==="exited"&&!A?"hidden":void 0,...Co[g],...Q,...f.props.style},ref:I,...s})})});function Ro(e){return Fe("MuiSpeedDial",e)}const Ue=Ee("MuiSpeedDial",["root","fab","directionUp","directionDown","directionLeft","directionRight","actions","actionsClosed"]),Ao=e=>{const{classes:t,open:r,direction:a}=e,p={root:["root",`direction${Qe(a)}`],fab:["fab"],actions:["actions",!r&&"actionsClosed"]};return Be(p,Ro,t)};function Me(e){if(e==="up"||e==="down")return"vertical";if(e==="right"||e==="left")return"horizontal"}const je=32,Ge=16,zo=Ne("div",{name:"MuiSpeedDial",slot:"Root",overridesResolver:(e,t)=>{const{ownerState:r}=e;return[t.root,t[`direction${Qe(r.direction)}`]]}})(He(({theme:e})=>({zIndex:(e.vars||e).zIndex.speedDial,display:"flex",alignItems:"center",pointerEvents:"none",variants:[{props:{direction:"up"},style:{flexDirection:"column-reverse",[`& .${Ue.actions}`]:{flexDirection:"column-reverse",marginBottom:-je,paddingBottom:Ge+je}}},{props:{direction:"down"},style:{flexDirection:"column",[`& .${Ue.actions}`]:{flexDirection:"column",marginTop:-je,paddingTop:Ge+je}}},{props:{direction:"left"},style:{flexDirection:"row-reverse",[`& .${Ue.actions}`]:{flexDirection:"row-reverse",marginRight:-je,paddingRight:Ge+je}}},{props:{direction:"right"},style:{flexDirection:"row",[`& .${Ue.actions}`]:{flexDirection:"row",marginLeft:-je,paddingLeft:Ge+je}}}]}))),Mo=Ne(Nt,{name:"MuiSpeedDial",slot:"Fab",overridesResolver:(e,t)=>t.fab})({pointerEvents:"auto"}),Wo=Ne("div",{name:"MuiSpeedDial",slot:"Actions",overridesResolver:(e,t)=>{const{ownerState:r}=e;return[t.actions,!r.open&&t.actionsClosed]}})({display:"flex",pointerEvents:"auto",variants:[{props:({ownerState:e})=>!e.open,style:{transition:"top 0s linear 0.2s",pointerEvents:"none"}}]}),Io=R.forwardRef(function(t,r){const a=De({props:t,name:"MuiSpeedDial"}),p=ct(),l={enter:p.transitions.duration.enteringScreen,exit:p.transitions.duration.leavingScreen},{ariaLabel:m,FabProps:{ref:f,...h}={},children:A,className:x,direction:S="up",hidden:j=!1,icon:P,onBlur:V,onClose:B,onFocus:Q,onKeyDown:Z,onMouseEnter:_,onMouseLeave:ee,onOpen:U,open:I,openIcon:y,slots:J={},slotProps:H={},TransitionComponent:q,TransitionProps:G,transitionDuration:ie=l,...c}=a,[N,g]=At({controlled:I,default:!1,name:"SpeedDial",state:"open"}),T={...a,open:N,direction:S},s=Ao(T),d=zt(),C=R.useRef(0),Y=R.useRef(),z=R.useRef([]);z.current=[z.current[0]];const re=R.useCallback(v=>{z.current[0]=v},[]),pe=vt(f,re),Te=(v,O)=>K=>{z.current[v+1]=K,O&&O(K)},oe=v=>{Z&&Z(v);const O=v.key.replace("Arrow","").toLowerCase(),{current:K=O}=Y;if(v.key==="Escape"){g(!1),z.current[0].focus(),B&&B(v,"escapeKeyDown");return}if(Me(O)===Me(K)&&Me(O)!==void 0){v.preventDefault();const i=O===K?1:-1,b=Wt(C.current+i,0,z.current.length-1);z.current[b].focus(),C.current=b,Y.current=K}};R.useEffect(()=>{N||(C.current=0,Y.current=void 0)},[N]);const n=v=>{v.type==="mouseleave"&&ee&&ee(v),v.type==="blur"&&V&&V(v),d.clear(),v.type==="blur"?d.start(0,()=>{g(!1),B&&B(v,"blur")}):(g(!1),B&&B(v,"mouseLeave"))},ce=v=>{h.onClick&&h.onClick(v),d.clear(),N?(g(!1),B&&B(v,"toggle")):(g(!0),U&&U(v,"toggle"))},fe=v=>{v.type==="mouseenter"&&_&&_(v),v.type==="focus"&&Q&&Q(v),d.clear(),N||d.start(0,()=>{g(!0),U&&U(v,{focus:"focus",mouseenter:"mouseEnter"}[v.type])})},M=m.replace(/^[^a-z]+|[^\w:.-]+/gi,""),te=R.Children.toArray(A).filter(v=>R.isValidElement(v)),me=te.map((v,O)=>{const{FabProps:{ref:K,...i}={},tooltipPlacement:b}=v.props,u=b||(Me(S)==="vertical"?"left":"top");return R.cloneElement(v,{FabProps:{...i,ref:Te(O,K)},delay:30*(N?O:te.length-O),open:N,tooltipPlacement:u,id:`${M}-action-${O}`})}),he={transition:q,...J},ge={transition:G,...H},E={slots:he,slotProps:ge},[ne,X]=Ae("root",{elementType:zo,externalForwardedProps:{...E,...c},ownerState:T,ref:r,className:Ce(s.root,x),additionalProps:{role:"presentation"},getSlotProps:v=>({...v,onKeyDown:O=>{var K;(K=v.onKeyDown)==null||K.call(v,O),oe(O)},onBlur:O=>{var K;(K=v.onBlur)==null||K.call(v,O),n(O)},onFocus:O=>{var K;(K=v.onFocus)==null||K.call(v,O),fe(O)},onMouseEnter:O=>{var K;(K=v.onMouseEnter)==null||K.call(v,O),fe(O)},onMouseLeave:O=>{var K;(K=v.onMouseLeave)==null||K.call(v,O),n(O)}})}),[se,$]=Ae("transition",{elementType:ko,externalForwardedProps:E,ownerState:T});return o.jsxs(ne,{...X,children:[o.jsx(se,{in:!j,timeout:ie,unmountOnExit:!0,...$,children:o.jsx(Mo,{color:"primary","aria-label":m,"aria-haspopup":"true","aria-expanded":N,"aria-controls":`${M}-actions`,...h,onClick:ce,className:Ce(s.fab,h.className),ref:pe,ownerState:T,children:R.isValidElement(P)&&Mt(P,["SpeedDialIcon"])?R.cloneElement(P,{open:N}):P})}),o.jsx(Wo,{id:`${M}-actions`,role:"menu","aria-orientation":Me(S),className:Ce(s.actions,!N&&s.actionsClosed),ownerState:T,children:me})]})});function Oo(e){return Fe("MuiSpeedDialAction",e)}const $e=Ee("MuiSpeedDialAction",["fab","fabClosed","staticTooltip","staticTooltipClosed","staticTooltipLabel","tooltipPlacementLeft","tooltipPlacementRight"]),Lo=e=>{const{open:t,tooltipPlacement:r,classes:a}=e,p={fab:["fab",!t&&"fabClosed"],staticTooltip:["staticTooltip",`tooltipPlacement${Qe(r)}`,!t&&"staticTooltipClosed"],staticTooltipLabel:["staticTooltipLabel"]};return Be(p,Oo,a)},Eo=Ne(Nt,{name:"MuiSpeedDialAction",slot:"Fab",skipVariantsResolver:!1,overridesResolver:(e,t)=>{const{ownerState:r}=e;return[t.fab,!r.open&&t.fabClosed]}})(He(({theme:e})=>({margin:8,color:(e.vars||e).palette.text.secondary,backgroundColor:(e.vars||e).palette.background.paper,"&:hover":{backgroundColor:e.vars?e.vars.palette.SpeedDialAction.fabHoverBg:Ot(e.palette.background.paper,.15)},transition:`${e.transitions.create("transform",{duration:e.transitions.duration.shorter})}, opacity 0.8s`,opacity:1,variants:[{props:({ownerState:t})=>!t.open,style:{opacity:0,transform:"scale(0)"}}]}))),Fo=Ne("span",{name:"MuiSpeedDialAction",slot:"StaticTooltip",overridesResolver:(e,t)=>{const{ownerState:r}=e;return[t.staticTooltip,!r.open&&t.staticTooltipClosed,t[`tooltipPlacement${Qe(r.tooltipPlacement)}`]]}})(He(({theme:e})=>({position:"relative",display:"flex",alignItems:"center",[`& .${$e.staticTooltipLabel}`]:{transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.shorter}),opacity:1},variants:[{props:({ownerState:t})=>!t.open,style:{[`& .${$e.staticTooltipLabel}`]:{opacity:0,transform:"scale(0.5)"}}},{props:{tooltipPlacement:"left"},style:{[`& .${$e.staticTooltipLabel}`]:{transformOrigin:"100% 50%",right:"100%",marginRight:8}}},{props:{tooltipPlacement:"right"},style:{[`& .${$e.staticTooltipLabel}`]:{transformOrigin:"0% 50%",left:"100%",marginLeft:8}}}]}))),Do=Ne("span",{name:"MuiSpeedDialAction",slot:"StaticTooltipLabel",overridesResolver:(e,t)=>t.staticTooltipLabel})(He(({theme:e})=>({position:"absolute",...e.typography.body1,backgroundColor:(e.vars||e).palette.background.paper,borderRadius:(e.vars||e).shape.borderRadius,boxShadow:(e.vars||e).shadows[1],color:(e.vars||e).palette.text.secondary,padding:"4px 16px",wordBreak:"keep-all"}))),qe=R.forwardRef(function(t,r){var C;const a=De({props:t,name:"MuiSpeedDialAction"}),{className:p,delay:l=0,FabProps:m={},icon:f,id:h,open:A,TooltipClasses:x,tooltipOpen:S=!1,tooltipPlacement:j="left",tooltipTitle:P,slots:V={},slotProps:B={},...Q}=a,Z={...a,tooltipPlacement:j},_=Lo(Z),ee={slots:V,slotProps:{fab:m,...B,tooltip:It(typeof B.tooltip=="function"?B.tooltip(Z):B.tooltip,{title:P,open:S,placement:j,classes:x})}},[U,I]=R.useState((C=ee.slotProps.tooltip)==null?void 0:C.open),y=()=>{I(!1)},J=()=>{I(!0)},H={transitionDelay:`${l}ms`},[q,G]=Ae("fab",{elementType:Eo,externalForwardedProps:ee,ownerState:Z,shouldForwardComponentProp:!0,className:Ce(_.fab,p),additionalProps:{style:H,tabIndex:-1,role:"menuitem",size:"small"}}),[ie,c]=Ae("tooltip",{elementType:Oe,externalForwardedProps:ee,shouldForwardComponentProp:!0,ref:r,additionalProps:{id:h},ownerState:Z,getSlotProps:Y=>({...Y,onClose:z=>{var re;(re=Y.onClose)==null||re.call(Y,z),y()},onOpen:z=>{var re;(re=Y.onOpen)==null||re.call(Y,z),J()}})}),[N,g]=Ae("staticTooltip",{elementType:Fo,externalForwardedProps:ee,ownerState:Z,ref:r,className:_.staticTooltip,additionalProps:{id:h}}),[T,s]=Ae("staticTooltipLabel",{elementType:Do,externalForwardedProps:ee,ownerState:Z,className:_.staticTooltipLabel,additionalProps:{style:H,id:`${h}-label`}}),d=o.jsx(q,{...G,children:f});return c.open?o.jsxs(N,{...g,...Q,children:[o.jsx(T,{...s,children:c.title}),R.cloneElement(d,{"aria-labelledby":`${h}-label`})]}):(!A&&U&&I(!1),o.jsx(ie,{...c,title:c.title,open:A&&U,placement:c.placement,classes:c.classes,...Q,children:d}))}),Bo=Lt(o.jsx("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"}),"Add");function Ho(e){return Fe("MuiSpeedDialIcon",e)}const be=Ee("MuiSpeedDialIcon",["root","icon","iconOpen","iconWithOpenIconOpen","openIcon","openIconOpen"]),Vo=e=>{const{classes:t,open:r,openIcon:a}=e;return Be({root:["root"],icon:["icon",r&&"iconOpen",a&&r&&"iconWithOpenIconOpen"],openIcon:["openIcon",r&&"openIconOpen"]},Ho,t)},Jo=Ne("span",{name:"MuiSpeedDialIcon",slot:"Root",overridesResolver:(e,t)=>{const{ownerState:r}=e;return[{[`& .${be.icon}`]:t.icon},{[`& .${be.icon}`]:r.open&&t.iconOpen},{[`& .${be.icon}`]:r.open&&r.openIcon&&t.iconWithOpenIconOpen},{[`& .${be.openIcon}`]:t.openIcon},{[`& .${be.openIcon}`]:r.open&&t.openIconOpen},t.root]}})(He(({theme:e})=>({height:24,[`& .${be.icon}`]:{transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.short})},[`& .${be.openIcon}`]:{position:"absolute",transition:e.transitions.create(["transform","opacity"],{duration:e.transitions.duration.short}),opacity:0,transform:"rotate(-45deg)"},variants:[{props:({ownerState:t})=>t.open,style:{[`& .${be.icon}`]:{transform:"rotate(45deg)"}}},{props:({ownerState:t})=>t.open&&t.openIcon,style:{[`& .${be.icon}`]:{opacity:0}}},{props:({ownerState:t})=>t.open,style:{[`& .${be.openIcon}`]:{transform:"rotate(0deg)",opacity:1}}}]}))),Pt=R.forwardRef(function(t,r){const a=De({props:t,name:"MuiSpeedDialIcon"}),{className:p,icon:l,open:m,openIcon:f,...h}=a,A=a,x=Vo(A);function S(j,P){return R.isValidElement(j)?R.cloneElement(j,{className:P}):j}return o.jsxs(Jo,{className:Ce(x.root,p),ref:r,ownerState:A,...h,children:[f?S(f,x.openIcon):null,l?S(l,x.icon):o.jsx(Bo,{className:x.icon})]})});Pt.muiName="SpeedDialIcon";function Yo(e){return Fe("MuiTableContainer",e)}Ee("MuiTableContainer",["root"]);const Ko=e=>{const{classes:t}=e;return Be({root:["root"]},Yo,t)},Uo=Ne("div",{name:"MuiTableContainer",slot:"Root",overridesResolver:(e,t)=>t.root})({width:"100%",overflowX:"auto"}),Go=R.forwardRef(function(t,r){const a=De({props:t,name:"MuiTableContainer"}),{className:p,component:l="div",...m}=a,f={...a,component:l},h=Ko(f);return o.jsx(Uo,{ref:r,as:l,className:Ce(h.root,p),ownerState:f,...m})});function $o(e){return Fe("MuiTableHead",e)}Ee("MuiTableHead",["root"]);const qo=e=>{const{classes:t}=e;return Be({root:["root"]},$o,t)},Xo=Ne("thead",{name:"MuiTableHead",slot:"Root",overridesResolver:(e,t)=>t.root})({display:"table-header-group"}),Qo={variant:"head"},ht="thead",Zo=R.forwardRef(function(t,r){const a=De({props:t,name:"MuiTableHead"}),{className:p,component:l=ht,...m}=a,f={...a,component:l},h=qo(f);return o.jsx(go.Provider,{value:Qo,children:o.jsx(Xo,{as:l,className:Ce(h.root,p),ref:r,role:l===ht?null:"rowgroup",ownerState:f,...m})})});function at(e){"@babel/helpers - typeof";return at=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},at(e)}function ue(e,t){if(t.length<e)throw new TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+t.length+" present")}function ae(e){ue(1,arguments);var t=Object.prototype.toString.call(e);return e instanceof Date||at(e)==="object"&&t==="[object Date]"?new Date(e.getTime()):typeof e=="number"||t==="[object Number]"?new Date(e):((typeof e=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}var _o={};function en(){return _o}function gt(e){var t=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds()));return t.setUTCFullYear(e.getFullYear()),e.getTime()-t.getTime()}function Xe(e,t){ue(2,arguments);var r=ae(e),a=ae(t),p=r.getTime()-a.getTime();return p<0?-1:p>0?1:p}function tn(e,t){ue(2,arguments);var r=ae(e),a=ae(t),p=r.getFullYear()-a.getFullYear(),l=r.getMonth()-a.getMonth();return p*12+l}function on(e,t){return ue(2,arguments),ae(e).getTime()-ae(t).getTime()}var nn={ceil:Math.ceil,round:Math.round,floor:Math.floor,trunc:function(t){return t<0?Math.ceil(t):Math.floor(t)}},rn="trunc";function an(e){return nn[rn]}function sn(e){ue(1,arguments);var t=ae(e);return t.setHours(23,59,59,999),t}function cn(e){ue(1,arguments);var t=ae(e),r=t.getMonth();return t.setFullYear(t.getFullYear(),r+1,0),t.setHours(23,59,59,999),t}function ln(e){ue(1,arguments);var t=ae(e);return sn(t).getTime()===cn(t).getTime()}function dn(e,t){ue(2,arguments);var r=ae(e),a=ae(t),p=Xe(r,a),l=Math.abs(tn(r,a)),m;if(l<1)m=0;else{r.getMonth()===1&&r.getDate()>27&&r.setDate(30),r.setMonth(r.getMonth()-p*l);var f=Xe(r,a)===-p;ln(ae(e))&&l===1&&Xe(e,a)===1&&(f=!1),m=p*(l-Number(f))}return m===0?0:m}function pn(e,t,r){ue(2,arguments);var a=on(e,t)/1e3;return an()(a)}var fn={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},un=function(t,r,a){var p,l=fn[t];return typeof l=="string"?p=l:r===1?p=l.one:p=l.other.replace("{{count}}",r.toString()),a!=null&&a.addSuffix?a.comparison&&a.comparison>0?"in "+p:p+" ago":p};function ot(e){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=t.width?String(t.width):e.defaultWidth,a=e.formats[r]||e.formats[e.defaultWidth];return a}}var mn={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},hn={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},gn={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},xn={date:ot({formats:mn,defaultWidth:"full"}),time:ot({formats:hn,defaultWidth:"full"}),dateTime:ot({formats:gn,defaultWidth:"full"})},bn={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},yn=function(t,r,a,p){return bn[t]};function We(e){return function(t,r){var a=r!=null&&r.context?String(r.context):"standalone",p;if(a==="formatting"&&e.formattingValues){var l=e.defaultFormattingWidth||e.defaultWidth,m=r!=null&&r.width?String(r.width):l;p=e.formattingValues[m]||e.formattingValues[l]}else{var f=e.defaultWidth,h=r!=null&&r.width?String(r.width):e.defaultWidth;p=e.values[h]||e.values[f]}var A=e.argumentCallback?e.argumentCallback(t):t;return p[A]}}var wn={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},vn={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},Nn={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},Sn={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},jn={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},Pn={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},Tn=function(t,r){var a=Number(t),p=a%100;if(p>20||p<10)switch(p%10){case 1:return a+"st";case 2:return a+"nd";case 3:return a+"rd"}return a+"th"},Cn={ordinalNumber:Tn,era:We({values:wn,defaultWidth:"wide"}),quarter:We({values:vn,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:We({values:Nn,defaultWidth:"wide"}),day:We({values:Sn,defaultWidth:"wide"}),dayPeriod:We({values:jn,defaultWidth:"wide",formattingValues:Pn,defaultFormattingWidth:"wide"})};function Ie(e){return function(t){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=r.width,p=a&&e.matchPatterns[a]||e.matchPatterns[e.defaultMatchWidth],l=t.match(p);if(!l)return null;var m=l[0],f=a&&e.parsePatterns[a]||e.parsePatterns[e.defaultParseWidth],h=Array.isArray(f)?Rn(f,function(S){return S.test(m)}):kn(f,function(S){return S.test(m)}),A;A=e.valueCallback?e.valueCallback(h):h,A=r.valueCallback?r.valueCallback(A):A;var x=t.slice(m.length);return{value:A,rest:x}}}function kn(e,t){for(var r in e)if(e.hasOwnProperty(r)&&t(e[r]))return r}function Rn(e,t){for(var r=0;r<e.length;r++)if(t(e[r]))return r}function An(e){return function(t){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=t.match(e.matchPattern);if(!a)return null;var p=a[0],l=t.match(e.parsePattern);if(!l)return null;var m=e.valueCallback?e.valueCallback(l[0]):l[0];m=r.valueCallback?r.valueCallback(m):m;var f=t.slice(p.length);return{value:m,rest:f}}}var zn=/^(\d+)(th|st|nd|rd)?/i,Mn=/\d+/i,Wn={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},In={any:[/^b/i,/^(a|c)/i]},On={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},Ln={any:[/1/i,/2/i,/3/i,/4/i]},En={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},Fn={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},Dn={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},Bn={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},Hn={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},Vn={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},Jn={ordinalNumber:An({matchPattern:zn,parsePattern:Mn,valueCallback:function(t){return parseInt(t,10)}}),era:Ie({matchPatterns:Wn,defaultMatchWidth:"wide",parsePatterns:In,defaultParseWidth:"any"}),quarter:Ie({matchPatterns:On,defaultMatchWidth:"wide",parsePatterns:Ln,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:Ie({matchPatterns:En,defaultMatchWidth:"wide",parsePatterns:Fn,defaultParseWidth:"any"}),day:Ie({matchPatterns:Dn,defaultMatchWidth:"wide",parsePatterns:Bn,defaultParseWidth:"any"}),dayPeriod:Ie({matchPatterns:Hn,defaultMatchWidth:"any",parsePatterns:Vn,defaultParseWidth:"any"})},Yn={code:"en-US",formatDistance:un,formatLong:xn,formatRelative:yn,localize:Cn,match:Jn,options:{weekStartsOn:0,firstWeekContainsDate:1}};function Tt(e,t){if(e==null)throw new TypeError("assign requires that input parameter not be null or undefined");for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r]);return e}function Kn(e){return Tt({},e)}var xt=1440,Un=2520,nt=43200,Gn=86400;function $n(e,t,r){var a,p;ue(2,arguments);var l=en(),m=(a=(p=r==null?void 0:r.locale)!==null&&p!==void 0?p:l.locale)!==null&&a!==void 0?a:Yn;if(!m.formatDistance)throw new RangeError("locale must contain formatDistance property");var f=Xe(e,t);if(isNaN(f))throw new RangeError("Invalid time value");var h=Tt(Kn(r),{addSuffix:!!(r!=null&&r.addSuffix),comparison:f}),A,x;f>0?(A=ae(t),x=ae(e)):(A=ae(e),x=ae(t));var S=pn(x,A),j=(gt(x)-gt(A))/1e3,P=Math.round((S-j)/60),V;if(P<2)return r!=null&&r.includeSeconds?S<5?m.formatDistance("lessThanXSeconds",5,h):S<10?m.formatDistance("lessThanXSeconds",10,h):S<20?m.formatDistance("lessThanXSeconds",20,h):S<40?m.formatDistance("halfAMinute",0,h):S<60?m.formatDistance("lessThanXMinutes",1,h):m.formatDistance("xMinutes",1,h):P===0?m.formatDistance("lessThanXMinutes",1,h):m.formatDistance("xMinutes",P,h);if(P<45)return m.formatDistance("xMinutes",P,h);if(P<90)return m.formatDistance("aboutXHours",1,h);if(P<xt){var B=Math.round(P/60);return m.formatDistance("aboutXHours",B,h)}else{if(P<Un)return m.formatDistance("xDays",1,h);if(P<nt){var Q=Math.round(P/xt);return m.formatDistance("xDays",Q,h)}else if(P<Gn)return V=Math.round(P/nt),m.formatDistance("aboutXMonths",V,h)}if(V=dn(x,A),V<12){var Z=Math.round(P/nt);return m.formatDistance("xMonths",Z,h)}else{var _=V%12,ee=Math.floor(V/12);return _<3?m.formatDistance("aboutXYears",ee,h):_<9?m.formatDistance("overXYears",ee,h):m.formatDistance("almostXYears",ee+1,h)}}function qn(e,t){return ue(1,arguments),$n(e,Date.now(),t)}function Xn(e){return new Promise(t=>{setTimeout(()=>{t({html:`
            <div style="position:relative; width:100%; min-height:100vh;">

  <!-- Full page watermark -->
  <div style="
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background-repeat:repeat;
    background-image: repeating-linear-gradient(
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 100px
    ),
    repeating-linear-gradient(
      90deg,
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 300px
    );
    z-index:9999;
  ">
    <div style="
      position:absolute;      
      top:50%;
      left:50%;
      transform:translate(-50%,-50%) rotate(-60deg);
      font-size:72px;
      color:rgba(150,150,150,0.2);
      font-weight:bold;
      white-space:nowrap;
      font-family:Arial, sans-serif;
      pointer-events:none;
    ">
      DEMO DATA - NOT REAL
    </div>
  </div>

  <!-- Disclaimer Banner -->
  <div style="
    position:sticky;
    top:0;
    background-color:rgba(255,255,0,0.9);
    color:#000;
    padding:10px;
    font-size:16px;
    text-align:center;
    font-weight:bold;
    border-bottom:2px solid #000;
    z-index:1000;
  ">
    This page displays DEMO DATA for review purposes only. No real information is shown.
  </div>

  <!-- Your existing dummy HTML -->
  <div style="position:relative; z-index:1; padding:20px; background-color:white;">

    <table width="100%" border="1" style="border-collapse: collapse;">
      <tr>
        <td width="55%">
          <div style="border: thin; position: relative; width: 100%;">
            <b style="color:#0000FF;">
              <font face="Verdana">(Demo Data Generated on 08/08/2025, 12:00:00)</font>
            </b><br/>
            <b style="color:#660033;">&nbsp;<label><font face='BN BIDISHA Opentype'>J.L No </font>:</label>&nbsp;</b>999
            <b style="color:#660033;">&nbsp;&nbsp; <font face='BN BIDISHA Opentype'>Thana </font>:&nbsp;</b>
            <font face='BN BIDISHA Opentype'>Demo Thana</font>&nbsp;<br/>
          </div>

          <div class="table-responsive" style="border: thin; position: relative; left: 3px; width: 97%;">
            <table class="table" width="95%" border="1" style="border-collapse: collapse;">
              <tr>
                <th width="43%"><div align="left"><font face='BN BIDISHA Opentype'>Khatian No</font>&nbsp;&nbsp;:&nbsp;</div></th>
                <th width="57%" bgcolor="#CCCCCC"><div align="left"><font face='BN BIDISHA Opentype'>00</font></div></th>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Nam</font>&nbsp;&nbsp;:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Name</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Pita/Swami</font>&nbsp;&nbsp;:</td>
                <td bgcolor="#CCCCCC"><font face='BN BIDISHA Opentype'>Demo Parent</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Dharan</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Type</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Thikana</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Address</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Zamir Pariman</font>:</td>
                <td bgcolor="#CCCCCC">0.00 Ekar</td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Dager Sankhyan</font>:</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <p><strong><font style="color: #0048FF;font-size:18px" face='BN BIDISHA Opentype'>Atrasbatber Dager Bibaran O Pariman:</font></strong></p>
          <p><font style="color: #8000ff;font-size:12px" face='BN BIDISHA Opentype'>(This is demo data only. No real land records are shown.)</font></p>

          <div class="table-responsive" style="border: thin none; position: relative; left: 5px; width: 97%; overflow: auto; top: -10px; margin-top:1em; margin-right: 5px;">
            <table class="table table-fixed" width="95%" align="center" style="border-collapse: collapse">
              <thead>
                <tr>
                  <th><center>Dag No</center></th>
                  <th><center>Shreni</center></th>
                  <th><center>Ansh</center></th>
                  <th><center>Ansh Pariman (ekar)</center></th>
                  <th><center>Dakhaldar</center></th>
                  <th><center>Mantaby</center></th>
                </tr>
              </thead>
              <tbody>
                <tr bgcolor="#CCCCCC">
                  <td align="center">0001</td>
                  <td align="center">Demo Class</td>
                  <td align="center">1.0000</td>
                  <td align="center">0.00</td>
                  <td align="center">Demo Holder</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
                <tr>
                  <td align="center">0002</td>
                  <td align="center">Demo Class</td>
                  <td align="center">0.5000</td>
                  <td align="center">0.00</td>
                  <td align="center">Nil</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>

        <td width="45%" valign="top">
          <div class="table-responsive" style="border: thin; width: 95%; height: 300px; overflow: auto;">
            <center style="color:gray; padding-top:120px;">Demo Map / Additional Info</center>
          </div>
        </td>
      </tr>
    </table>

  </div>
</div>
          `})},1e3)})}function Qn(e){if(!e)return null;const t=parseFloat(e.replace(/[^0-9.]/g,""));if(isNaN(t)||t<=0)return null;const r=(t*100).toFixed(2),a=(t*60.5).toFixed(2);return{acre:t.toFixed(4),satak:r,katha:a}}function Zn(e){if(!e)return"default";const t=e.toLowerCase();return t.includes("executed")||t.includes("completed")||t.includes("approved")||t.includes("success")?"success":t.includes("under mutation")||t.includes("pending")||t.includes("in progress")||t.includes("process")?"warning":t.includes("registered")||t.includes("initiated")||t.includes("hearing")?"info":t.includes("rejected")||t.includes("dismissed")||t.includes("error")||t.includes("cancelled")?"error":"primary"}function _n({parsedData:e,locationInfo:t={},landDetails:r={},onCaseAction:a,onSwitchToHtml:p,onSavePdf:l,onSharePdf:m,onPrintPdf:f,onRetry:h,onBack:A,darkMode:x}){var M,te,me,he,ge;const{t:S}=rt(),j=ct(),[P,V]=R.useState(null),[B,Q]=R.useState(""),{isError:Z,errorType:_,title:ee,errorMessage:U,isPdf:I,docTitle:y,docSubtitle:J,fileSizeKb:H,pdfData:q,moduleType:G="kyp",isWarishNotice:ie,metadata:c={},tables:N=[],rsLrPairs:g=[],mutationCases:T=[]}=e||{},s=!!(ie||c!=null&&c.warishNotice),d=(c==null?void 0:c.warishNotice)||{},{selectedDistrict:C,selectedBlock:Y,selectedMouza:z}=t,re=(E,ne)=>{var X;E&&(de(),(X=navigator.clipboard)==null||X.writeText(E),V(ne),setTimeout(()=>V(null),2e3))},pe=R.useMemo(()=>Qn(c.totalArea),[c.totalArea]),Te=R.useMemo(()=>{if(!B.trim())return N;const E=B.toLowerCase();return N.map(ne=>({...ne,rows:ne.rows.filter(X=>X.some(se=>se.toLowerCase().includes(E)))}))},[N,B]),oe=c.ownerName||(c.khatianNo?`Khatian #${c.khatianNo}`:"")||(r!=null&&r.mainNo?`${r.searchBy==="plot"?"Plot":"Khatian"} #${r.mainNo}`:"")||(r!=null&&r.caseNumber||r!=null&&r.caseNo?`Case #${r.caseNumber||r.caseNo}`:"")||(r!=null&&r.applicationNo||r!=null&&r.appNo?`App #${r.applicationNo||r.appNo}`:"")||(r!=null&&r.grnNo?`GRN #${r.grnNo}`:"")||"Land Record",n=pe||c.plotCount;if(Z){const E=_==="no_record",X=E?"search_off":_==="captcha"?"vpn_key_alert":"warning_amber";return o.jsx(L,{sx:{p:{xs:2,sm:3},maxWidth:720,mx:"auto",width:"100%",boxSizing:"border-box"},children:o.jsxs(le,{elevation:0,sx:{borderRadius:4,overflow:"hidden",border:`1.5px solid ${ye(j.palette.warning.main,x?.4:.25)}`,bgcolor:x?"rgba(28, 22, 18, 0.85)":"rgba(255, 251, 245, 0.95)",backdropFilter:"blur(12px)",boxShadow:x?"0 8px 32px rgba(0, 0, 0, 0.5)":"0 8px 32px rgba(217, 119, 6, 0.08)",textAlign:"center",p:{xs:3,sm:4}},children:[o.jsx(L,{sx:{width:72,height:72,borderRadius:"50%",mx:"auto",mb:2.5,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:ye(j.palette.warning.main,.14),color:j.palette.warning.main},children:o.jsx(W,{sx:{fontSize:40},children:X})}),o.jsx(k,{variant:"h5",fontWeight:800,color:"text.primary",gutterBottom:!0,children:ee||(E?"Record Not Found":"Notice / Alert")}),o.jsx(k,{variant:"body1",color:"text.secondary",sx:{maxWidth:520,mx:"auto",mb:3,lineHeight:1.6},children:U||"No matching record was returned by the portal for this query."}),o.jsxs(L,{sx:{p:2,mb:3.5,borderRadius:3,bgcolor:x?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.03)",border:`1px solid ${j.palette.divider}`,display:"flex",flexWrap:"wrap",gap:1.5,justifyContent:"center",alignItems:"center"},children:[(C==null?void 0:C.name)&&o.jsx(F,{size:"small",label:`District: ${C.name}`,variant:"outlined"}),(Y==null?void 0:Y.name)&&o.jsx(F,{size:"small",label:`Block: ${Y.name}`,variant:"outlined"}),(z==null?void 0:z.name)&&o.jsx(F,{size:"small",label:`Mouza: ${z.name}`,variant:"outlined"}),(r==null?void 0:r.mainNo)&&o.jsx(F,{size:"small",color:"primary",label:`${r.searchBy==="plot"?S("recentSearch.plotNo","Plot"):S("recentSearch.khatianNo","Khatian")}: ${r.mainNo}${r.subNo?"/"+r.subNo:""}`,sx:{fontWeight:700}}),((r==null?void 0:r.caseNumber)||(r==null?void 0:r.caseNo))&&o.jsx(F,{size:"small",color:"primary",label:`${S("recentSearch.caseNo","Case No")}: ${(r==null?void 0:r.caseNumber)||(r==null?void 0:r.caseNo)}`,sx:{fontWeight:700}}),!(r!=null&&r.caseNumber)&&!(r!=null&&r.caseNo)&&((r==null?void 0:r.applicationNo)||(r==null?void 0:r.appNo))&&o.jsx(F,{size:"small",color:"primary",label:`${S("recentSearch.appNo","App No")}: ${(r==null?void 0:r.applicationNo)||(r==null?void 0:r.appNo)}`,sx:{fontWeight:700}}),(r==null?void 0:r.grnNo)&&o.jsx(F,{size:"small",color:"primary",label:`GRN: ${r.grnNo}`,sx:{fontWeight:700}})]}),o.jsxs(D,{direction:{xs:"column",sm:"row"},spacing:1.5,justifyContent:"center",alignItems:"center",children:[A&&o.jsx(Pe,{variant:"outlined",color:"primary",startIcon:o.jsx(W,{children:"arrow_back"}),onClick:()=>{de(),A()},sx:{borderRadius:2.5,px:2.5,py:1,textTransform:"none",fontWeight:700},children:S("kyp.recordView.editSearchQuery","Edit Search Query")}),h&&o.jsx(Pe,{variant:"contained",color:"primary",startIcon:o.jsx(W,{children:"refresh"}),onClick:()=>{de(),h()},sx:{borderRadius:2.5,px:3,py:1,textTransform:"none",fontWeight:700},children:S("kyp.recordView.retrySearch","Retry Search")}),p&&o.jsx(Pe,{variant:"text",color:"inherit",startIcon:o.jsx(W,{children:"html"}),onClick:()=>{de(),p()},sx:{borderRadius:2.5,textTransform:"none",fontWeight:600},children:"View Portal Page"})]})]})})}if(I)return o.jsx(L,{sx:{p:{xs:1.5,sm:2},maxWidth:860,mx:"auto",width:"100%",boxSizing:"border-box"},children:o.jsxs(D,{spacing:2,children:[o.jsx(le,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",border:`1.5px solid ${x?"rgba(225, 29, 72, 0.35)":"rgba(225, 29, 72, 0.25)"}`,background:x?"linear-gradient(135deg, #2b1318 0%, #15161d 100%)":"linear-gradient(135deg, #fff1f2 0%, #ffffff 100%)",boxShadow:x?"0 6px 24px rgba(0, 0, 0, 0.45)":"0 6px 24px rgba(225, 29, 72, 0.08)",p:{xs:2.5,sm:3}},children:o.jsxs(D,{spacing:2,children:[o.jsxs(D,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:[o.jsxs(D,{direction:"row",spacing:1,alignItems:"center",children:[o.jsx(L,{sx:{width:44,height:44,borderRadius:2.5,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:"error.main",color:"#fff",boxShadow:"0 4px 12px rgba(225, 29, 72, 0.35)"},children:o.jsx(W,{children:"picture_as_pdf"})}),o.jsxs(L,{children:[o.jsx(k,{variant:"h6",fontWeight:800,color:"text.primary",sx:{lineHeight:1.2},children:y||"Official Land Record PDF"}),o.jsx(k,{variant:"caption",color:"text.secondary",children:J||"Certified Government Statement"})]})]}),o.jsxs(D,{direction:"row",spacing:1,alignItems:"center",children:[H&&o.jsx(F,{size:"small",label:`~${H} KB`,sx:{fontWeight:700,fontSize:"0.75rem"}}),o.jsx(F,{size:"small",color:"success",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"verified"}),label:"Official Seal",sx:{fontWeight:700,fontSize:"0.75rem"}})]})]}),o.jsx(St,{}),o.jsxs(D,{direction:"row",spacing:1.5,flexWrap:"wrap",children:[l&&o.jsx(Pe,{variant:"contained",color:"error",startIcon:o.jsx(W,{children:"download"}),onClick:()=>{de(),l()},sx:{borderRadius:2.5,px:2.5,textTransform:"none",fontWeight:700},children:"Download PDF"}),m&&o.jsx(Pe,{variant:"outlined",color:"inherit",startIcon:o.jsx(W,{children:"share"}),onClick:()=>{de(),m()},sx:{borderRadius:2.5,px:2,textTransform:"none",fontWeight:600},children:"Share"}),f&&o.jsx(Pe,{variant:"outlined",color:"inherit",startIcon:o.jsx(W,{children:"print"}),onClick:()=>{de(),f()},sx:{borderRadius:2.5,px:2,textTransform:"none",fontWeight:600},children:"Print"})]})]})}),o.jsx(le,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",border:`1px solid ${j.palette.divider}`,bgcolor:x?"#1a222c":"#525659",height:"70vh",minHeight:520,width:"100%",position:"relative"},children:o.jsx("iframe",{src:q!=null&&q.startsWith("data:application/pdf;base64,")?q:`data:application/pdf;base64,${q}#toolbar=0`,title:"PDF Document",style:{width:"100%",height:"100%",border:"none"}})})]})});const ce=G==="rs-lr",fe=g[0]||((te=(M=N[0])==null?void 0:M.rows)!=null&&te[0]?{lrPlot:N[0].rows[0][0],rsPlot:N[0].rows[0][1]}:null);return o.jsx(L,{sx:{p:{xs:1.5,sm:2},maxWidth:1e3,width:"100%",mx:"auto",boxSizing:"border-box",overflowX:"hidden"},children:o.jsxs(D,{spacing:2,sx:{width:"100%",maxWidth:"100%",overflowX:"hidden"},children:[ce&&fe&&o.jsx(le,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",background:x?"linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%)":"linear-gradient(135deg, #eef2ff 0%, #faf5ff 100%)",border:`1.5px solid ${x?"rgba(79, 70, 229, 0.4)":"rgba(79, 70, 229, 0.25)"}`,boxShadow:x?"0 4px 18px rgba(0, 0, 0, 0.4)":"0 4px 18px rgba(79, 70, 229, 0.08)",p:{xs:2,sm:2.5}},children:o.jsxs(D,{spacing:2,children:[o.jsx(L,{children:o.jsx(k,{variant:"caption",fontWeight:800,color:"primary",letterSpacing:"0.04em",children:"RS ⇄ LR PLOT MAPPING (দাগ রূপান্তর)"})}),o.jsxs(L,{sx:{display:"grid",gridTemplateColumns:{xs:"1fr auto 1fr"},alignItems:"center",justifyContent:"center",textAlign:"center",gap:1.5,p:2,borderRadius:3,bgcolor:x?"rgba(255, 255, 255, 0.04)":"rgba(255, 255, 255, 0.8)",border:`1px solid ${j.palette.divider}`},children:[o.jsxs(L,{children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"LR PLOT (হাল দাগ)"}),o.jsx(k,{variant:"h4",fontWeight:900,color:"primary.main",children:fe.lrPlot}),o.jsx(Oe,{title:P==="lr"?"Copied!":"Copy LR Plot",children:o.jsx(Le,{size:"small",onClick:()=>re(fe.lrPlot,"lr"),children:o.jsx(W,{sx:{fontSize:16},children:P==="lr"?"done":"content_copy"})})})]}),o.jsx(L,{sx:{color:"primary.main"},children:o.jsx(W,{sx:{fontSize:32},children:"sync_alt"})}),o.jsxs(L,{children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"RS PLOT (সাবেক দাগ)"}),o.jsx(k,{variant:"h4",fontWeight:900,color:"secondary.main",children:fe.rsPlot}),o.jsx(Oe,{title:P==="rs"?"Copied!":"Copy RS Plot",children:o.jsx(Le,{size:"small",onClick:()=>re(fe.rsPlot,"rs"),children:o.jsx(W,{sx:{fontSize:16},children:P==="rs"?"done":"content_copy"})})})]})]}),(c.jlNo||c.thana)&&o.jsxs(D,{direction:"row",spacing:1,flexWrap:"wrap",children:[c.jlNo&&o.jsx(F,{size:"small",label:`J.L. No: ${c.jlNo}`,sx:{fontWeight:700}}),c.thana&&o.jsx(F,{size:"small",label:`Thana: ${c.thana}`,sx:{fontWeight:600}})]})]})}),s&&o.jsx(le,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",width:"100%",boxSizing:"border-box",background:x?"linear-gradient(135deg, #1c1917 0%, #291e12 100%)":"linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)",border:`1.5px solid ${x?"rgba(245, 158, 11, 0.35)":"rgba(245, 158, 11, 0.25)"}`,boxShadow:x?"0 4px 18px rgba(0, 0, 0, 0.4)":"0 4px 18px rgba(245, 158, 11, 0.12)",p:{xs:2,sm:2.5}},children:o.jsxs(D,{spacing:2,children:[o.jsx(D,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:o.jsxs(D,{direction:"row",spacing:.8,flexWrap:"wrap",alignItems:"center",children:[o.jsx(F,{size:"small",color:d.noticeType==="investigation"?"info":"warning",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:d.noticeType==="investigation"?"policy":"gavel"}),label:d.noticeType==="investigation"?S("wb.warish.investigationNoticeTitle","Inquiry / Investigation Notice (তদন্তের নোটিশ)"):S("wb.warish.hearingNoticeTitle","Hearing Notice (শুনানীর নোটিশ)"),sx:{fontWeight:800,fontSize:"0.78rem"}}),d.caseNo&&o.jsx(F,{size:"small",label:`Case: ${d.caseNo}`,variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}}),d.caseDate&&o.jsx(F,{size:"small",label:`Date: ${d.caseDate}`,sx:{fontWeight:600,fontSize:"0.75rem"}})]})}),o.jsxs(L,{children:[o.jsx(k,{variant:"caption",color:"warning.main",fontWeight:800,letterSpacing:"0.04em",children:d.authorityLaw||"প: ব: ভূ: স: আইনের ৫০ ধারা অনুসারে"}),o.jsxs(D,{direction:"row",spacing:1,alignItems:"center",flexWrap:"wrap",children:[o.jsx(k,{variant:"h5",fontWeight:800,color:"text.primary",sx:{fontSize:{xs:"1.2rem",sm:"1.45rem"},whiteSpace:"normal",wordBreak:"break-word"},children:d.noticeTitle||"উত্তরাধিকার নথিভুক্তকরণ শুনানীর নোটিশ"}),d.caseNo&&o.jsx(Oe,{title:P==="warishCase"?"Copied!":"Copy Case No",children:o.jsx(Le,{size:"small",onClick:()=>re(d.caseNo,"warishCase"),children:o.jsx(W,{sx:{fontSize:18},children:P==="warishCase"?"done":"content_copy"})})})]}),o.jsxs(D,{direction:"row",spacing:1,flexWrap:"wrap",sx:{mt:1},children:[d.district&&o.jsx(F,{size:"small",label:`District: ${d.district}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.block&&o.jsx(F,{size:"small",label:`Block: ${d.block}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.mouza&&o.jsx(F,{size:"small",label:`Mouza: ${d.mouza}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),d.mouzaCode&&o.jsx(F,{size:"small",label:`Code: ${d.mouzaCode}`,variant:"outlined",sx:{fontWeight:600,fontSize:"0.75rem"}})]})]}),(d.hearingDate||d.hearingTime)&&o.jsx(L,{sx:{p:1.5,borderRadius:2.5,bgcolor:x?"rgba(245, 158, 11, 0.08)":"rgba(245, 158, 11, 0.12)",border:`1px solid ${ye(j.palette.warning.main,.3)}`},children:o.jsxs(D,{direction:{xs:"column",sm:"row"},spacing:2,alignItems:{xs:"flex-start",sm:"center"},justifyContent:"space-between",children:[o.jsxs(D,{direction:"row",spacing:1.5,alignItems:"center",children:[o.jsx(L,{sx:{p:1,borderRadius:2,bgcolor:ye(j.palette.warning.main,.2),color:"warning.main",display:"flex"},children:o.jsx(W,{sx:{fontSize:28},children:"event_upcoming"})}),o.jsxs(L,{children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:S("wb.warish.hearingSchedule","Hearing / Appearance Schedule")}),o.jsxs(k,{variant:"h6",fontWeight:900,color:"text.primary",children:[d.hearingDate," ",d.hearingTime?`@ ${d.hearingTime}`:""]})]})]}),d.authorityOffice&&o.jsx(k,{variant:"caption",color:"text.secondary",sx:{fontStyle:"italic",maxWidth:300},children:d.authorityOffice})]})}),(d.predecessorKhatian||d.predecessorPlots&&d.predecessorPlots.length>0)&&o.jsx(le,{elevation:0,sx:{p:1.5,borderRadius:2.5,bgcolor:x?"rgba(255, 255, 255, 0.03)":"rgba(255, 255, 255, 0.75)",border:`1px solid ${j.palette.divider}`},children:o.jsxs(D,{spacing:1.2,children:[o.jsxs(D,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:[o.jsx(k,{variant:"caption",fontWeight:800,color:"primary",letterSpacing:"0.04em",children:S("wb.warish.predecessorRecord","PREDECESSOR'S LAND RECORD (পূর্বসূরীর খতিয়ান ও দাগ)")}),((me=d.predecessorPlots)==null?void 0:me.length)>0&&o.jsx(Pe,{size:"small",variant:"outlined",startIcon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"content_copy"}),onClick:()=>re(d.predecessorPlots.join(", "),"allPlots"),sx:{textTransform:"none",py:.2,px:1,fontSize:"0.75rem",borderRadius:2},children:P==="allPlots"?S("wb.warish.allPlotsCopied","Copied!"):S("wb.warish.copyAllPlots","Copy All Plots")})]}),o.jsxs(D,{direction:"row",spacing:1,flexWrap:"wrap",alignItems:"center",children:[d.predecessorKhatian&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"badge"}),label:`Khatian: ${d.predecessorKhatian}`,color:"primary",sx:{fontWeight:800,fontSize:"0.78rem"}}),d.predecessorJlNo&&o.jsx(F,{size:"small",label:`J.L. No: ${d.predecessorJlNo}`,sx:{fontWeight:700,fontSize:"0.75rem"}}),((he=d.predecessorPlots)==null?void 0:he.length)>0&&o.jsx(F,{size:"small",label:`${d.predecessorPlots.length} Plots`,color:"secondary",variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}})]}),((ge=d.predecessorPlots)==null?void 0:ge.length)>0&&o.jsx(L,{sx:{display:"flex",flexWrap:"wrap",gap:.6,pt:.5},children:d.predecessorPlots.map((E,ne)=>o.jsx(F,{size:"small",label:E,variant:"outlined",sx:{fontSize:"0.75rem",fontWeight:600,bgcolor:x?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.02)"}},ne))})]})}),d.hearingNoticeText&&o.jsxs(L,{sx:{p:1.5,borderRadius:2,bgcolor:x?"rgba(0, 0, 0, 0.25)":"rgba(0, 0, 0, 0.03)",borderLeft:`4px solid ${j.palette.warning.main}`},children:[o.jsxs(k,{variant:"caption",color:"text.secondary",fontWeight:700,sx:{display:"block",mb:.5},children:[S("wb.warish.legalNoticeDirectives","Official Directives / নোটিশের নির্দেশাবলী"),":"]}),o.jsx(k,{variant:"body2",color:"text.primary",sx:{lineHeight:1.6,textAlign:"justify"},children:d.hearingNoticeText})]}),(d.authorityDesignation||d.authorityDate)&&o.jsxs(D,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,sx:{pt:.5},children:[o.jsxs(D,{direction:"row",spacing:1,alignItems:"center",children:[o.jsx(W,{color:"action",sx:{fontSize:18},children:"verified_user"}),o.jsxs(k,{variant:"caption",color:"text.secondary",fontWeight:600,children:[d.authorityDesignation||"রাজস্ব আধিকারিক"," ",d.authorityOffice?`· ${d.authorityOffice}`:""]})]}),d.authorityDate&&o.jsxs(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:["Issued: ",d.authorityDate]})]})]})}),!ce&&!s&&o.jsx(le,{elevation:0,sx:{borderRadius:3.5,overflow:"hidden",width:"100%",boxSizing:"border-box",wordBreak:"break-word",background:x?"linear-gradient(135deg, #132f2b 0%, #0d1b1e 100%)":"linear-gradient(135deg, #e8f5f1 0%, #f0fdf4 100%)",border:`1.5px solid ${x?"rgba(33, 122, 100, 0.35)":"rgba(33, 122, 100, 0.25)"}`,boxShadow:x?"0 4px 16px rgba(0, 0, 0, 0.35)":"0 4px 16px rgba(33, 122, 100, 0.06)"},children:o.jsx(Et,{sx:{p:{xs:2,sm:2.5}},children:o.jsxs(D,{spacing:1.5,children:[o.jsx(D,{direction:"row",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1,children:o.jsxs(D,{direction:"row",spacing:.8,flexWrap:"wrap",alignItems:"center",children:[c.jlNo&&o.jsx(F,{size:"small",label:`J.L. No: ${c.jlNo}`,sx:{fontWeight:700,fontSize:"0.75rem",bgcolor:x?"rgba(255, 255, 255, 0.08)":"rgba(33, 122, 100, 0.12)",color:"primary.main"}}),c.thana&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"local_police"}),label:`Thana: ${c.thana}`,sx:{fontWeight:600,fontSize:"0.75rem"}}),c.classification&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"landscape"}),label:`Character: ${c.classification}`,variant:"outlined",color:"primary",sx:{fontWeight:600,fontSize:"0.75rem"}})]})}),o.jsxs(L,{children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,letterSpacing:"0.04em",children:c.ownerName?"RAYAT / OWNER":"PROPERTY DETAILS"}),o.jsxs(D,{direction:"row",spacing:1,alignItems:"center",flexWrap:"wrap",children:[o.jsx(k,{variant:"h5",fontWeight:800,color:"text.primary",sx:{fontSize:{xs:"1.2rem",sm:"1.45rem"},whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word"},children:oe}),c.ownerName&&o.jsx(Oe,{title:P==="owner"?"Copied!":"Copy Name",children:o.jsx(Le,{size:"small",onClick:()=>re(c.ownerName,"owner"),children:o.jsx(W,{sx:{fontSize:18},children:P==="owner"?"done":"content_copy"})})})]}),c.address&&o.jsxs(k,{variant:"body2",color:"text.secondary",sx:{mt:.5,whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word"},children:[o.jsx("strong",{children:"Address:"})," ",c.address]})]}),o.jsxs(D,{direction:"row",flexWrap:"wrap",gap:1,children:[c.khatianNo&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"badge"}),label:`Khatian: ${c.khatianNo}`,color:"primary",variant:"outlined",sx:{fontWeight:700,fontSize:"0.75rem"}}),c.fatherHusband&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"person"}),label:`Father/Husband: ${c.fatherHusband}`,sx:{fontWeight:600,fontSize:"0.75rem",maxWidth:"100%",wordBreak:"break-word"}}),c.tenantType&&o.jsx(F,{size:"small",icon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"shield"}),label:`Type: ${c.tenantType}`,color:"info",variant:"outlined",sx:{fontWeight:600,fontSize:"0.75rem"}})]})]})})}),n&&!s&&o.jsxs(L,{sx:{display:"grid",gridTemplateColumns:{xs:"repeat(2, 1fr)",sm:c.plotCount?"repeat(4, 1fr)":"repeat(3, 1fr)"},gap:1.2,width:"100%",boxSizing:"border-box"},children:[pe&&o.jsxs(o.Fragment,{children:[o.jsxs(le,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${j.palette.divider}`,textAlign:"center"},children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"ACRES"}),o.jsx(k,{variant:"h6",fontWeight:800,color:"primary.main",sx:{my:.2},children:pe.acre}),o.jsx(k,{variant:"caption",color:"text.secondary",children:"Total Land"})]}),o.jsxs(le,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${j.palette.divider}`,textAlign:"center"},children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"SATAK / DECIMAL"}),o.jsx(k,{variant:"h6",fontWeight:800,sx:{my:.2},children:pe.satak}),o.jsx(k,{variant:"caption",color:"text.secondary",children:"1 Acre = 100 Satak"})]}),o.jsxs(le,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${j.palette.divider}`,textAlign:"center"},children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"KATHA (APPROX)"}),o.jsx(k,{variant:"h6",fontWeight:800,sx:{my:.2},children:pe.katha}),o.jsx(k,{variant:"caption",color:"text.secondary",children:"WB Measure"})]})]}),c.plotCount&&o.jsxs(le,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${j.palette.divider}`,textAlign:"center"},children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:700,children:"TOTAL PLOTS"}),o.jsx(k,{variant:"h6",fontWeight:800,color:"secondary.main",sx:{my:.2},children:c.plotCount}),o.jsx(k,{variant:"caption",color:"text.secondary",children:"Plots in Khatian"})]})]}),c.summaryItems&&c.summaryItems.length>0&&o.jsxs(le,{elevation:0,sx:{borderRadius:3,p:1.5,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",border:`1px solid ${j.palette.divider}`,width:"100%",boxSizing:"border-box"},children:[o.jsx(k,{variant:"caption",fontWeight:800,color:"text.secondary",letterSpacing:"0.04em",sx:{mb:1,display:"block"},children:"ADDITIONAL PARTICULARS"}),o.jsx(L,{sx:{display:"grid",gridTemplateColumns:{xs:"1fr",sm:"repeat(2, 1fr)"},gap:1,width:"100%",boxSizing:"border-box"},children:c.summaryItems.map((E,ne)=>o.jsxs(L,{sx:{p:1,borderRadius:2,bgcolor:x?"rgba(255, 255, 255, 0.03)":"rgba(0, 0, 0, 0.02)",display:"flex",justifyContent:"space-between",alignItems:"center",gap:1.5},children:[o.jsx(k,{variant:"caption",color:"text.secondary",fontWeight:600,sx:{flexShrink:0},children:E.key}),o.jsx(k,{variant:"body2",fontWeight:700,color:"text.primary",sx:{whiteSpace:"normal",wordBreak:"break-word",overflowWrap:"break-word",textAlign:"right"},children:E.value})]},ne))})]}),N.length>0&&o.jsxs(D,{spacing:1.5,sx:{width:"100%",maxWidth:"100%"},children:[o.jsxs(D,{direction:{xs:"column",sm:"row"},justifyContent:"space-between",alignItems:{xs:"flex-start",sm:"center"},gap:1,sx:{width:"100%"},children:[o.jsxs(k,{variant:"subtitle1",fontWeight:800,color:"text.primary",children:["Detailed Records (",N.reduce((E,ne)=>E+ne.rows.length,0)," entries)"]}),o.jsx(Ft,{size:"small",placeholder:"Filter in records...",value:B,onChange:E=>Q(E.target.value),InputProps:{startAdornment:o.jsx(Dt,{position:"start",children:o.jsx(W,{fontSize:"small",children:"search"})})},sx:{width:{xs:"100%",sm:220}}})]}),Te.map((E,ne)=>o.jsxs(le,{elevation:0,sx:{borderRadius:3,overflow:"hidden",border:`1px solid ${j.palette.divider}`,bgcolor:x?"rgba(22, 27, 34, 0.7)":"#ffffff",width:"100%",maxWidth:"100%",boxSizing:"border-box"},children:[E.title&&o.jsx(L,{sx:{p:1.2,px:2,bgcolor:x?"rgba(255, 255, 255, 0.04)":"rgba(0, 0, 0, 0.02)"},children:o.jsx(k,{variant:"subtitle2",fontWeight:800,color:"primary.main",children:E.title})}),o.jsx(Go,{sx:{maxHeight:440,width:"100%",maxWidth:"100%",overflowX:"auto",display:"block",WebkitOverflowScrolling:"touch",boxSizing:"border-box"},children:o.jsxs(xo,{stickyHeader:!0,size:"small",sx:{minWidth:540,width:"100%"},children:[o.jsx(Zo,{children:o.jsx(_e,{children:E.headers.map((X,se)=>{const $=typeof X=="string"&&(X.length>12||X.includes(" "));return o.jsx(et,{sx:{fontWeight:700,bgcolor:x?"#1a222c":"#f1f5f9",color:"text.primary",whiteSpace:$?"normal":"nowrap",wordBreak:$?"break-word":"normal",overflowWrap:"break-word",minWidth:$?110:80,maxWidth:$?200:"none",py:1.2,px:1.5,fontSize:"0.8rem",lineHeight:1.35,verticalAlign:"bottom"},children:X},se)})})}),o.jsx(bo,{children:E.rows.length===0?o.jsx(_e,{children:o.jsx(et,{colSpan:E.headers.length,align:"center",sx:{py:3},children:o.jsx(k,{variant:"body2",color:"text.secondary",children:"No matching records found"})})}):E.rows.map((X,se)=>o.jsx(_e,{hover:!0,sx:{"&:nth-of-type(even)":{bgcolor:x?"rgba(255, 255, 255, 0.02)":"rgba(0, 0, 0, 0.015)"}},children:X.map(($,v)=>{const O=$.match(/((?:MN|WR|CN)\/\d{4}\/\d+\/\d+)/i),K=typeof $=="string"&&($.toLowerCase().includes("executed")||$.toLowerCase().includes("mutation")||$.toLowerCase().includes("registered")||$.toLowerCase().includes("completed")),i=typeof $=="string"&&($.length>12||$.includes(" "));return o.jsx(et,{sx:{fontSize:"0.84rem",whiteSpace:i?"normal":"nowrap",wordBreak:i?"break-word":"normal",overflowWrap:"break-word",minWidth:i?120:80,maxWidth:i?260:"none",py:1.1,px:1.5,color:$==="—"?"text.disabled":"text.primary",verticalAlign:"top",lineHeight:1.35},children:O?o.jsx(F,{size:"small",label:$,color:"primary",variant:"filled",clickable:!0,onClick:()=>a==null?void 0:a($),deleteIcon:o.jsx(W,{sx:{fontSize:"14px !important"},children:"arrow_forward"}),onDelete:()=>a==null?void 0:a($),sx:{fontWeight:700,fontSize:"0.75rem"}}):K?o.jsx(F,{size:"small",label:$,color:Zn($),variant:"outlined",sx:{fontWeight:700,fontSize:"0.72rem"}}):$},v)})},se))})]})})]},ne))]})]})})}function ke(e){if(!e||typeof e!="string")return e;const t=["০","১","২","৩","৪","৫","৬","৭","৮","৯"];return e.replace(/[০-৯]/g,r=>t.indexOf(r))}function we(e){return e?e.replace(/&nbsp;/g," ").replace(/\s+/g," ").replace(/^[:\-–\s]+/,"").replace(/[:\-–\s]+$/,"").trim():""}const er={"dag no":"Plot No (দাগ নং)",dag:"Plot No (দাগ নং)",dags:"Plot No (দাগ নং)","দাগ নং":"Plot No (দাগ নং)",দাগ:"Plot No (দাগ নং)","lr dag no":"LR Plot (এল.আর দাগ)","lr plotno":"LR Plot (এল.আর দাগ)","lr plot":"LR Plot (এল.আর দাগ)","হাল দাগ নং":"LR Plot (এল.আর দাগ)","rs dag no":"RS Plot (আর.এস দাগ)","rs plotno":"RS Plot (আর.এস দাগ)","rs plot":"RS Plot (আর.এস দাগ)","সাবেক দাগ নং":"RS Plot (আর.এস দাগ)",shreni:"Land Character (শ্রেণি)",classification:"Land Character (শ্রেণি)",শ্রেণি:"Land Character (শ্রেণি)",শ্রেণী:"Land Character (শ্রেণি)","land code":"Land Code (শ্রেণী কোড)","classification of land":"Classification of Land (জমির শ্রেণী)",ansh:"Share (অংশ)",অংশ:"Share (অংশ)","ansh pariman (ekar)":"Share Area (Acres)","ansh pariman":"Share Area (Acres)","অংশ পরিমাণ(একর)":"Share Area (Acres)","অংশ পরিমাণ":"Share Area (Acres)",pariman:"Area (Acres)",পরিমাণ:"Area (Acres)","zamir moat pariman(ekar)":"Total Plot Area (Acres)","জমির মোট পরিমাণ(একর)":"Total Plot Area (Acres)",dakhaldar:"Possessor / Bargadar (দখলদার)",দখলদার:"Possessor / Bargadar (দখলদার)",mantaby:"Remarks (মন্তব্য)",mantabya:"Remarks (মন্তব্য)",remarks:"Remarks (মন্তব্য)",মন্তব্য:"Remarks (মন্তব্য)","raiter nam":"Owner Name (মালিকের নাম)","owner name":"Owner Name (মালিকের নাম)","রায়তের নাম":"Owner Name (মালিকের নাম)","মালিকের নাম":"Owner Name (মালিকের নাম)","pita/swami":"Father/Husband (পিতা/স্বামী)","পিতা/স্বামী":"Father/Husband (পিতা/স্বামী)",পিতা:"Father (পিতা)",স্বামী:"Husband (স্বামী)","seller name":"Seller Name (বিক্রেতার নাম)","seller khatian":"Seller Khatian (বিক্রেতার খতিয়ান)","seller guardian name":"Seller Guardian (অভিভাবকের নাম)","buyer name":"Buyer Name (ক্রেতার নাম)","buyer khatian":"Buyer Khatian (ক্রেতার খতিয়ান)","buyer address":"Buyer Address (ক্রেতার ঠিকানা)","applicant's name":"Applicant Name (আবেদনকারী)","applicant name":"Applicant Name (আবেদনকারী)","applicant's address":"Applicant Address (ঠিকানা)","applicant address":"Applicant Address (ঠিকানা)","applicant's khatian":"Applicant Khatian (খতিয়ান)","case no":"Case No (কেস নং)",txtcaseno:"Case No (কেস নং)","কেস নং":"Case No (কেস নং)","case date":"Case Date (কেসের তারিখ)","deed no":"Deed No (দলিল নং)","deed year":"Deed Year (দলিলের বছর)","execution date":"Execution Date (সম্পাদনের তারিখ)","hearing date":"Hearing Date (শুনানির তারিখ)","date & time":"Date & Time (তারিখ ও সময়)",venue:"Venue (স্থান)",status:"Status (অবস্থা)","view plot / ror":"Plot / ROR (দাগ/খতিয়ান)","view plot":"Plot (দাগ)",download:"Document (ডকুমেন্ট)","application no.":"Application No (আবেদন নং)","application no":"Application No (আবেদন নং)","application date":"Application Date (আবেদনের তারিখ)","application type":"Application Type (আবেদনের ধরণ)","nature of application":"Nature of Application (প্রকৃতি)",demand:"Demand (দাবি)",due:"Dues (বকেয়া)","dager myap":"Plot Map (নকশা)","দাগের ম্যাপ":"Plot Map (নকশা)","khatian no":"Khatian No (খতিয়ান নং)",khatian:"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)"};function bt(e){const t=we(e).toLowerCase();for(const[r,a]of Object.entries(er))if(t===r.toLowerCase()||t.includes(r.toLowerCase()))return a;return we(e)}function yt(e){if(!e)return"";let t=we(e);return(t.includes("Demo Data")||t.includes("demo data"))&&(t=t.replace(/\(.*Demo Data.*?\)/gi,"").replace(/Demo Data.*?Generated.*?\)/gi,"")),t.includes("Atrasbatber Dager Bibaran")||t.includes("Bibaran O Pariman")||t.includes("দাগের বিবরণ ও পরিমাণ")?"Plot Details & Area Share (দাগের বিবরণ ও পরিমাণ)":(t.includes("Khatian")||t.includes("খতিয়ান")||t.includes("খতিয়ান"))&&(t.includes("Bibaran")||t.includes("বিবরণ")||t.includes("List"))?"Associated Khatians & Owners (খতিয়ান ও মালিকের বিবরণ)":(t.includes("RS")||t.includes("সাবেক"))&&(t.includes("LR")||t.includes("হাল"))?"RS-LR Plot Cross Reference (আর.এস - এল.আর দাগ রূপান্তর)":t.includes("Mutation")||t.includes("মিউটেশন")?"Mutation Case Docket (মিউটেশন কেস বিবরণ)":t.includes("Barga")||t.includes("বর্গাদার")?"Recorded Bargadars / Sharecroppers (বর্গাদার তথ্য)":t.includes("Land Class")||t.includes("শ্রেণী কোড")?"Land Classification Directory (জমির শ্রেণী)":we(t)}function tr(e){if(!e||typeof e!="string")return{isError:!0,errorType:"empty",message:"No data received from portal server."};const t=e.trim();if(t.length===0)return{isError:!0,errorType:"empty",message:"Empty response received."};if(/invalid\s*captcha|captcha\s*not\s*match|enter\s*proper\s*captcha/i.test(t))return{isError:!0,errorType:"captcha",title:"Captcha Verification Failed",message:"The portal rejected the security captcha. Please go back and retry with a fresh captcha image."};if(/session\s*expired|please\s*login\s*again/i.test(t))return{isError:!0,errorType:"session_expired",title:"Session Expired",message:"Your Banglarbhumi session has timed out. Please login again to continue."};if(/record\s*not\s*found|case\s*details\s*not\s*found|no\s*record\s*found|no\s*data\s*found|sorry\s*no\s*data|no\s*land\s*revenue.*?found|কোন\s*তথ্য\s*পাওয়া\s*যায়নি|তথ্য\s*পাওয়া\s*যায়নি/i.test(t)){let r="No land records found matching your query in the government registry.";return/no\s*land\s*revenue.*?found/i.test(t)?r="No Land Revenue (Khajna) application found for this Khatian.":/case\s*details\s*not\s*found/i.test(t)?r="Case details not found for the entered Case Number. Please verify the case number format.":/sorry\s*no\s*data\s*found\s*or\s*30\s*days/i.test(t)?r="No certified copy record found, or application validity period (30 days) has expired.":/record\s*not\s*found/i.test(t)&&(r="No record found for the entered Plot, Khatian, or Case Number."),{isError:!0,errorType:"no_record",title:"No Record Found",message:r}}return/the\s*length\s*of\s*case\s*no\s*cannot\s*be\s*less/i.test(t)||/application\s*no\.\s*not\s*valid/i.test(t)?{isError:!0,errorType:"invalid_input",title:"Invalid Input Format",message:t.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim()}:null}function or(e=""){const t=e.toLowerCase();return t.includes("/rs-lr")?"rs-lr":t.includes("/khajna-status")?"khajna-status":t.includes("/mutation-case-details")?"mutation-case-details":t.includes("/mutation-case-status")?"mutation-case-status":t.includes("/mutation-status")||t.includes("/mutation")?"mutation-status":t.includes("/land-class")?"land-class":t.includes("/warish-status")?"warish-status":t.includes("/conversion-status")?"conversion-status":t.includes("/revenue-no-dues")?"revenue-no-dues":t.includes("/barga-info")?"barga-info":t.includes("/app-reprint")?"app-reprint":t.includes("/signed-copy")?"signed-copy":t.includes("/grn-search")?"grn-search":(t.includes("/kyp"),"kyp")}function nr(e,t="warish-status"){if(!e||typeof e!="string"||!(t==="warish-status"||e.includes("notice-table")&&(e.includes("উত্তরাধিকার")||e.includes("শুনানী")||e.includes("তদন্ত")))||!e.includes("বাদী")&&!e.includes("পূর্বসূরী")&&!e.includes("notice-table"))return null;const a=M=>(M||"").replace(/<[^>]+>/g," ").replace(/&nbsp;/g," ").replace(/\s+/g," ").trim();let p="উত্তরাধিকার নথিভুক্তকরণ নোটিশ",l="hearing";e.includes("শুনানীর নোটিশ")?(p="উত্তরাধিকার নথিভুক্তকরণ শুনানীর নোটিশ",l="hearing"):e.includes("তদন্তের নোটিশ")&&(p="উত্তরাধিকার নথিভুক্তকরণ তদন্তের নোটিশ",l="investigation");let m="";const f=e.match(/কেস\s*নং\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([A-Za-z0-9_\/]+)/i)||e.match(/কেস\s*নং\s*[:\-]?\s*([A-Za-z0-9_\/]+)/i);f&&(m=a(f[1]));let h="";const A=e.match(/কেস\s*তারিখ\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([\d\/]+)/i)||e.match(/কেস\s*তারিখ\s*[:\-]?\s*([\d\/]+)/i);A&&(h=a(A[1]));let x="";const S=e.match(/জেলা\s*:\s*([^<]+)/);S&&(x=a(S[1]));let j="";const P=e.match(/ব্লক\s*:\s*([^<]+)/);P&&(j=a(P[1]));let V="";const B=e.match(/মৌজা\s*:\s*([^<]+)/);B&&(V=a(B[1]));let Q="";const Z=e.match(/মৌজা\s*কোড\s*:\s*([^<]+)/);Z&&(Q=a(Z[1]));function _(M){if(!M)return[];const te=[],me=/<TR[^>]*>([\s\S]*?)<\/TR>/gi;let he;for(;(he=me.exec(M))!==null;){const ge=/<TD[^>]*>([\s\S]*?)<\/TD>/gi,E=[];let ne;for(;(ne=ge.exec(he[1]))!==null;)E.push(a(ne[1]));const X=E.filter(Boolean);X.length>=2&&!X.some(se=>se.includes("নাম")||se.includes("বাদী")||se.includes("বিবাদী")||se.includes("ঠিকানা"))&&te.push({name:X[0]||"",guardian:X[1]||"",address:X[2]||""})}return te}const ee=e.indexOf("বাদী"),U=e.indexOf("বিবাদী"),I=e.indexOf("justified-text")!==-1?e.indexOf("justified-text"):e.indexOf("এতদ্বারা জানানো");let y=[];if(ee!==-1){const M=U!==-1?U:I;y=_(e.substring(ee,M!==-1?M:void 0))}let J=[];if(U!==-1){const M=I!==-1?I:e.indexOf("পূর্বসূরী");J=_(e.substring(U,M!==-1?M:void 0))}let H="",q="",G="";const ie=e.match(/<TD[^>]*class=["']justified-text["'][^>]*>([\s\S]*?)<\/TD>/i)||e.match(/(এতদ্বারা\s*জানানো\s*যাইতেছে[\s\S]*?আইন\s*মোতাবেক\s*ব্যবস্থা\s*গ্রহণ\s*করা\s*হইবে।?)/i);if(ie){H=a(ie[1]);const M=H.match(/(\d{1,2}\/\d{1,2}\/\d{4})\s*তারিখে\s*বেলা/);M&&(q=a(M[1]));const te=H.match(/বেলা\s*([^ঘ]+)ঘটিকায়/);te&&(G=a(te[1]))}let c="";const N=e.match(/খতিয়ান\s*নং\s*[:\-]?\s*([০-৯\d]+)/);N&&(c=a(N[1]));let g="";const T=e.match(/জে\.?এল\.?নং\s*[:\-]?\s*([০-৯\d]+)/);T&&(g=a(T[1]));let s=[];const d=e.match(/দাগ\s*নং\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>([\s\S]*?)<\/TD>/i)||e.match(/দাগ\s*নং\s*[:\-]?\s*([\d\s,\/]+)/i);d&&(s=a(d[1]).split(",").map(M=>M.trim()).filter(Boolean));let C="";const Y=e.indexOf("রাজস্ব আধিকারিক");if(Y!==-1){const M=e.substring(Math.max(0,Y-200),Y+300),te=M.match(/তারিখ\s*[:\-]?\s*<\/TD>\s*<TD[^>]*>\s*([\d\/]+)/i)||M.match(/তারিখ\s*[:\-]?\s*([\d\/]+)/i);te&&(C=a(te[1]))}const z=e.includes("রাজস্ব আধিকারিক")?"রাজস্ব আধিকারিক (Revenue Officer)":"",re=e.includes("সমষ্টি ভূমি ও ভূমি সংস্কার")?"সমষ্টি ভূমি ও ভূমি সংস্কার আধিকারিকের করণ (Office of the BL&LRO)":"",pe=e.includes("৫০ ধারা")?"প: ব: ভূ: স: আইনের ৫০ ধারা অনুসারে":"",Te={noticeTitle:p,noticeType:l,caseNo:m,caseDate:h,district:x,block:j,mouza:V,mouzaCode:Q,petitioners:y,respondents:J,hearingNoticeText:H,hearingDate:q,hearingTime:G,predecessorKhatian:c,predecessorJlNo:g,predecessorPlots:s,authorityDate:C,authorityDesignation:z,authorityOffice:re,authorityLaw:pe},oe=[];m&&oe.push({key:"Case Number (কেস নং)",value:m}),h&&oe.push({key:"Case Date (কেস তারিখ)",value:h}),q&&oe.push({key:l==="hearing"?"Hearing Schedule (শুনানীর সময়সূচী)":"Inquiry Schedule (তদন্তের সময়সূচী)",value:`${q}${G?" @ "+G:""}`}),c&&oe.push({key:"Predecessor Khatian (পূর্বসূরীর খতিয়ান)",value:c}),g&&oe.push({key:"J.L. No (জে.এল. নং)",value:g}),s.length>0&&oe.push({key:"Plots Involved (দাগের সংখ্যা)",value:`${s.length} Plots`}),x&&oe.push({key:"District (জেলা)",value:x}),j&&oe.push({key:"Block (ব্লক)",value:j}),V&&oe.push({key:"Mouza (মৌজা)",value:V}),z&&oe.push({key:"Issuing Officer (আধিকারিক)",value:z}),C&&oe.push({key:"Notice Issue Date (ইস্যু তারিখ)",value:C});const n=[];y.length>0&&n.push({title:`বাদী / Petitioner(s) (${y.length})`,headers:["#","নাম (Name)","পিতা/স্বামীর নাম (Guardian)","ঠিকানা (Address)"],rows:y.map((M,te)=>[String(te+1),M.name,M.guardian||"—",M.address||"—"])}),J.length>0&&n.push({title:`বিবাদী / Respondent(s) & Other Heirs (${J.length})`,headers:["#","নাম (Name)","পিতা/স্বামীর নাম (Guardian)","ঠিকানা (Address)"],rows:J.map((M,te)=>[String(te+1),M.name,M.guardian||"—",M.address||"—"])}),s.length>0&&n.push({title:`পূর্বসূরীর দাগ ও খতিয়ানের বিবরণ (Predecessor Plots) (${s.length})`,headers:["#","দাগ নং (Plot No)","পূর্বসূরীর খতিয়ান নং","জে.এল.নং","মৌজা"],rows:s.map((M,te)=>[String(te+1),M,c||"—",g||"—",V||"—"])});const fe=y.map(M=>M.name).join(", ")||(m?`Case: ${m}`:"Succession Application");return{success:!0,isError:!1,errorType:null,title:null,errorMessage:null,moduleType:t,isWarishNotice:!0,metadata:{ownerName:fe,caseNo:m,caseDate:h,khatianNo:c,jlNo:g,plotCount:s.length?String(s.length):"",summaryItems:oe,warishNotice:Te},tables:n,caseNumbers:[m].filter(Boolean),rsLrPairs:[],mutationCases:[],rawHtml:e}}function rr(e,t=""){const r=or(t);if(!e||typeof e!="string")return{success:!1,isError:!0,errorType:"empty",title:"No Data",errorMessage:"No response received from the server.",moduleType:r,metadata:{},tables:[],rawHtml:e};if(e.startsWith("JVBERi0x")||e.startsWith("%PDF")||e.length>500&&e.includes("JVBERi0x")){const l=r==="revenue-no-dues"||t.includes("revenue-no-dues");return{success:!0,isPdf:!0,pdfData:e,moduleType:r,docTitle:l?"Land Revenue Clearance Certificate (No Dues)":"Application & Payment Reprint Docket",docSubtitle:l?"Certified clearance issued by the Directorate of Land Records & Surveys, West Bengal":"Official application acknowledgement docket & fee receipt",fileSizeKb:Math.round(e.length*.75/1024),metadata:{docType:l?"Revenue Clearance Certificate":"Reprint Docket",format:"Certified PDF Document"},tables:[],caseNumbers:[],rawHtml:e}}const a=tr(e);if(a)return{success:!1,isError:!0,errorType:a.errorType,title:a.title,errorMessage:a.message,moduleType:r,metadata:{},tables:[],caseNumbers:[],rawHtml:e};if((r==="warish-status"||e.includes("notice-table")&&(e.includes("উত্তরাধিকার")||e.includes("শুনানী")||e.includes("তদন্ত")))&&(e.includes("বাদী")||e.includes("পূর্বসূরী")||e.includes("শুনানী")||e.includes("তদন্ত"))){const l=nr(e,r);if(l)return l}try{const m=new DOMParser().parseFromString(e,"text/html");m.querySelectorAll("script, style, noscript").forEach(I=>I.remove());const f={},h=[],A=[],x=/((?:MN|WR|CN|REV)\/\d{4}\/\d+\/\d+)/gi,j=(m.body.innerText||"").match(x);j&&j.forEach(I=>{const y=I.toUpperCase();A.includes(y)||A.push(y)}),m.querySelectorAll("b, label, span, div, td").forEach(I=>{const y=I.innerText.trim();if(y.includes("J.L No")||y.includes("J.L. No")||y.includes("JL No")||y.includes("J.l No")||y.includes("জে.এল নং")||y.includes("জে.এল. নং")||y.includes("জে.এল")){const J=y.match(/(?:J\.?[Ll]\.?\s*No|জে\.?এল\.?\s*নং|জে\.?এল)\s*[:\-]?\s*([০-৯\d]+)/i);J&&!f.jlNo&&(f.jlNo=ke(J[1]))}if(y.includes("Thana")||y.includes("Police Station")||y.includes("থানা")){const J=y.match(/(?:Thana|Police Station|থানা)\s*[:\-]?\s*([A-Za-z\u0980-\u09FF\s]+)/i);if(J&&!f.thana){const H=we(J[1].split(`
`)[0]);H&&H.length>1&&!H.includes("Live Data")&&(f.thana=H)}}});const P=m.querySelectorAll("table"),V=[],B=[],Q=[];P.forEach(I=>{var ie;if(I.querySelector("table"))return;const y=Array.from(I.querySelectorAll("tr")).filter(c=>c.closest("table")===I);if(y.length===0)return;if(y.length===2||y.length===1&&I.querySelector("th")&&I.querySelector("td")){const c=y[0],N=y.length>1?y[1]:null;if(c&&N){const g=Array.from(c.querySelectorAll("th, td")).filter(C=>C.closest("tr")===c).map(C=>we(C.innerText).toLowerCase()),T=Array.from(N.querySelectorAll("td, th")).filter(C=>C.closest("tr")===N).map(C=>we(C.innerText)),s=g.some(C=>C.includes("dag no")||C.includes("দাগ নং")),d=g.some(C=>C.includes("pariman")||C.includes("পরিমাণ"));if(s&&d&&T.length>=3){g.forEach((C,Y)=>{const z=T[Y];z&&((C.includes("dag no")||C.includes("দাগ নং"))&&!f.plotNo&&(f.plotNo=ke(z)),(C.includes("shreni")||C.includes("শ্রেণি")||C.includes("শ্রেণী"))&&!f.classification&&(f.classification=z),(C.includes("pariman")||C.includes("পরিমাণ"))&&!f.totalArea&&(f.totalArea=ke(z)))});return}}}let J=!0;const H=[];if(y.forEach(c=>{const N=Array.from(c.querySelectorAll("td, th")).filter(g=>g.closest("tr")===c);if(N.length===2){const g=we(N[0].innerText),T=we(N[1].innerText);if(g&&T&&T!=="-"){H.push({key:g,value:T});const s=g.toLowerCase();(s.includes("khatian")||s.includes("খতিয়ান")||s.includes("খতিয়ান"))&&!f.khatianNo&&(f.khatianNo=ke(T)),(s.includes("raiter nam")||s.includes("owner name")||s.includes("রায়তের নাম")||s.includes("মালিকের নাম"))&&!f.ownerName&&(f.ownerName=T),(s.includes("pita")||s.includes("father")||s.includes("husband")||s.includes("পিতা")||s.includes("স্বামী"))&&!f.fatherHusband&&(f.fatherHusband=T),(s.includes("thikana")||s.includes("address")||s.includes("ঠিকানা"))&&!f.address&&(f.address=T),(s.includes("pariman")||s.includes("area")||s.includes("পরিমাণ"))&&!f.totalArea&&(f.totalArea=ke(T)),(s.includes("sankhya")||s.includes("count")||s.includes("সংখ্যা"))&&!f.plotCount&&(f.plotCount=ke(T)),(s.includes("shreni")||s.includes("classification")||s.includes("শ্রেণি")||s.includes("শ্রেণী"))&&!f.classification&&(f.classification=T),(s.includes("dharan")||s.includes("type")||s.includes("ধরন"))&&!f.tenantType&&(f.tenantType=T)}}else J=!1}),J&&H.length>=2){V.push(...H);return}let q=[];const G=Array.from(I.querySelectorAll("thead")).find(c=>c.closest("table")===I);if(G){const c=Array.from(G.querySelectorAll("th, td")).filter(N=>N.closest("table")===I);q=Array.from(c).map(N=>bt(N.innerText))}else if(y.length>1){const c=Array.from(y[0].querySelectorAll("th, td")).filter(g=>g.closest("tr")===y[0]);(y[0].querySelector("th")!==null||c.length>2)&&(q=c.map(g=>bt(g.innerText)))}if(q.length>=2){const c=[],N=G?0:1;for(let g=N;g<y.length;g++){const T=y[g];if(G&&T.parentElement===G)continue;const s=Array.from(T.querySelectorAll("td, th")).filter(d=>d.closest("tr")===T).map(d=>we(d.innerText));if(s.length>0&&s.some(d=>d.length>0)){const d=s.map(C=>{const Y=C.toLowerCase();return Y==="nil"||C==="-"||Y==="na"||Y==="n/a"?"—":C});r==="rs-lr"&&d.length>=2&&B.push({lrPlot:d[0],rsPlot:d[1]}),r.startsWith("mutation")&&((ie=d[0])!=null&&ie.match(/(MN\/\d{4}\/\d+\/\d+)/i))&&Q.push({caseNo:d[0],caseDate:d[1]||"",seller:d[2]||"",buyer:d[4]||d[3]||"",status:d[d.length-1]||""}),c.push(d)}}if(c.length>0){let g="",T=I.previousElementSibling;for(;T&&!g;)T.tagName.match(/^H[1-6]|P|STRONG|B$/i)&&(g=yt(T.innerText)),T=T.previousElementSibling;h.push({title:g||yt(r)||"Detailed Records",headers:q,rows:c})}}});const Z=["khatian","খতিয়ান","খতিয়ান","raiter nam","owner name","রায়তের নাম","মালিকের নাম","pita","swami","father","husband","পিতা","স্বামী","zamir pariman","জমির পরিমাণ","pariman","পরিমাণ","dager sankhyan","dager sankhya","দাগের সংখ্যা","plot count","jl no","জে.এল নং","thana","থানা"],_=[],ee=new Set;V.forEach(I=>{const y=I.key.toLowerCase().trim();!Z.some(H=>y.includes(H))&&!ee.has(y)&&(ee.add(y),_.push(I))}),_.length>0&&(f.summaryItems=_);const U=Object.keys(f).length>0||h.length>0;return{success:U,isError:!U,errorType:U?null:"no_record",title:U?null:"No Record Found",errorMessage:U?null:"No record details could be extracted from this response.",moduleType:r,metadata:f,tables:h,caseNumbers:A,rsLrPairs:B,mutationCases:Q,rawHtml:e}}catch(l){return console.warn("Failed to parse WB HTML:",l),{success:!1,isError:!0,errorType:"parse_error",title:"Parse Error",errorMessage:"Could not interpret portal response.",moduleType:r,metadata:{},tables:[],caseNumbers:[],rawHtml:e}}}function it(e){if(!e||typeof e!="string")return!1;const t=e.trim();return!!(t.startsWith("%PDF-")||t.startsWith("%PDF")||t.startsWith("JVBE")||t.startsWith("data:application/pdf")||t.substring(0,200).includes("%PDF-")&&!t.substring(0,200).toLowerCase().includes("<html"))}function st(e){if(!e||typeof e!="string")return"";const t=e.trim();if(t.startsWith("JVBE"))return t;if(t.startsWith("data:application/pdf;base64,"))return t.replace("data:application/pdf;base64,","").trim();try{const r=e.length;let a="";const p=8192;for(let l=0;l<r;l+=p){const m=Math.min(l+p,r),f=new Uint8Array(m-l);for(let h=l;h<m;h++)f[h-l]=e.charCodeAt(h)&255;a+=String.fromCharCode.apply(null,f)}return btoa(a)}catch(r){return console.error("[pdfViewerHelper] Failed to convert raw PDF to Base64",r),""}}function ar({pdfData:e,title:t="Certificate PDF",caption:r=""}){const a=st(e);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=yes">
  <title>${t}</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"><\/script>
  <style>
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      min-height: 100%;
      background: #343a40;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #fff;
    }

    .pdf-top-bar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: #212529;
      padding: 10px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.4);
      border-bottom: 1px solid #444;
    }

    .pdf-meta {
      display: flex;
      flex-direction: column;
      overflow: hidden;
      margin-right: 12px;
    }

    .pdf-main-title {
      font-size: 14px;
      font-weight: 700;
      color: #f8f9fa;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-sub-title {
      font-size: 12px;
      color: #adb5bd;
      margin-top: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-btn-group {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }

    .pdf-btn {
      background: #1976d2;
      color: #fff;
      border: none;
      padding: 7px 14px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: background 0.15s ease-in-out;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    .pdf-btn:hover, .pdf-btn:active {
      background: #1565c0;
    }

    .pdf-btn.secondary {
      background: #495057;
    }

    .pdf-btn.secondary:hover, .pdf-btn.secondary:active {
      background: #5a6268;
    }

    #loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 50px 20px;
      gap: 16px;
      text-align: center;
    }

    .loading-spinner {
      width: 44px;
      height: 44px;
      border: 4px solid rgba(255, 255, 255, 0.2);
      border-top-color: #1976d2;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading-text {
      font-size: 14px;
      font-weight: 600;
      color: #dee2e6;
    }

    #pages-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px 8px 80px;
      gap: 20px;
      width: 100%;
    }

    .pdf-page-card {
      background: #ffffff;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35);
      border-radius: 4px;
      overflow: hidden;
      max-width: 100%;
      display: flex;
      justify-content: center;
    }

    .pdf-page-card canvas {
      display: block;
      max-width: 100%;
      height: auto !important;
    }

    .fallback-box {
      max-width: 440px;
      margin: 10px auto;
      background: #2b3035;
      border-radius: 12px;
      padding: 30px 24px;
      text-align: center;
      border: 1px solid #444;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }

    @media print {
      .pdf-top-bar {
        display: none !important;
      }
      body {
        background: #fff !important;
      }
      #pages-wrapper {
        padding: 0 !important;
        gap: 0 !important;
      }
      .pdf-page-card {
        box-shadow: none !important;
        border-radius: 0 !important;
        margin: 0 !important;
        page-break-after: always;
      }
    }
  </style>
</head>
<body>
  <div class="pdf-top-bar no-print">
    <div class="pdf-meta">
      <div class="pdf-main-title">${t||"Revenue No Due Certificate"}</div>
      <div class="pdf-sub-title">${r||"Certified Document"}</div>
    </div>
    <div class="pdf-btn-group">
      <button class="pdf-btn" onclick="downloadPdf()">
        Download
      </button>
      <button class="pdf-btn secondary" onclick="printPdf()">
        Print
      </button>
    </div>
  </div>

  <div id="loading-container">
    <div class="loading-spinner"></div>
    <div class="loading-text">Loading Certificate PDF...</div>
  </div>

  <div id="pages-wrapper"></div>

  <script>
    const base64Data = "${a}";

    function getPdfBytes() {
      const raw = atob(base64Data);
      const len = raw.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = raw.charCodeAt(i);
      }
      return bytes;
    }

    function downloadPdf() {
      // Primary: notify container through WebView console message bridge
      try {
        console.log(JSON.stringify({ action: "DOWNLOAD_PDF" }));
      } catch (e) {}

      // Fallback for standard browser
      try {
        const bytes = getPdfBytes();
        const blob = new Blob([bytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = '${(t||"Certificate").replace(/[^a-zA-Z0-9_-]/g,"_")}.pdf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 10000);
      } catch (_) {}
    }

    function printPdf() {
      try {
        console.log(JSON.stringify({ action: "PRINT_PDF" }));
      } catch (e) {}
      try {
        window.print();
      } catch (_) {}
    }

    function renderPdf() {
      if (!window.pdfjsLib) {
        showFallback('PDF renderer not available');
        return;
      }

      try {
        // Disable external worker to avoid Cross-Origin SecurityError in WebView.
        // PDF.js will use FakeWorker in main thread.
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = '';

        const bytes = getPdfBytes();
        const loadingTask = pdfjsLib.getDocument({
          data: bytes,
        });

        loadingTask.promise.then(function(pdf) {
          const loadingEl = document.getElementById('loading-container');
          if (loadingEl) loadingEl.style.display = 'none';

          const container = document.getElementById('pages-wrapper');
          container.innerHTML = '';

          for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            pdf.getPage(pageNum).then(function(page) {
              const scale = 1.5; // High resolution rendering
              const viewport = page.getViewport({ scale: scale });

              const pageCard = document.createElement('div');
              pageCard.className = 'pdf-page-card';

              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              canvas.height = viewport.height;
              canvas.width = viewport.width;

              pageCard.appendChild(canvas);
              container.appendChild(pageCard);

              page.render({ canvasContext: ctx, viewport: viewport });
            });
          }
        }).catch(function(err) {
          console.error('[PDF.js] Render Error:', err);
          showFallback(err.message);
        });
      } catch (e) {
        showFallback(e.message);
      }
    }

    function showFallback(msg) {
      const loadingEl = document.getElementById('loading-container');
      if (loadingEl) {
        loadingEl.innerHTML = \`
          <div class="fallback-box">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: #1976d2; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
            </div>
            <h3 style="margin-top:0; color:#fff; font-size:17px;">\${'${t||"Revenue No Due Certificate"}'}</h3>
            <p style="color:#ced4da; font-size:14px; line-height: 1.5; margin-bottom: 24px;">
              Certified PDF certificate ready. Tap below to download and save it to your device.
            </p>
            <button onclick="downloadPdf()" class="pdf-btn" style="padding:12px 28px; font-size:15px; margin: 0 auto; box-shadow: 0 4px 12px rgba(25, 118, 210, 0.4);">
              Download Certificate PDF
            </button>
          </div>
        \`;
      }
    }

    if (window.pdfjsLib) {
      renderPdf();
    } else {
      let attempts = 0;
      const timer = setInterval(() => {
        attempts++;
        if (window.pdfjsLib) {
          clearInterval(timer);
          renderPdf();
        } else if (attempts > 30) { // 3 seconds timeout
          clearInterval(timer);
          showFallback('PDF engine timed out');
        }
      }, 100);
    }
  <\/script>
</body>
</html>`}const wt="WB Land, Plot & Khatian Info",ir="https://play.google.com/store/apps/details?id=in.svt.wblandsinfo",sr="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGMAAABjCAYAAACPO76VAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAAAm4ElEQVR4Xu2deZxlVXXvv3ufc8eaurp6HmiggW67QUCERF8Q8Yl+Ep/PKCqSvCBEUXyaSHgq5H2SSIxDNKI4EwaJYpzoBBWNgnGIQRCZGqGZaeimZ7q6q+pW1R3P2e+PtfY+51YT+t58Pvm8/qOXdt17ztnDWuu3prPPPhez+NyzHYfpkCA798Rh+v9Hh8E4hOgwGIcQHQbjEKLDYBxCdBiMQ4gOg3EI0WEwDiE6DMYhRIfBOIToMBiHEJle16acA2PAAeaAYz3rnJxwzz+kH+M/Os6Tn+c/Sy43uh8myGDk4IDzejx32rxUxhickU9wOGdA/t/N9PMJN4d6BkMm1DnmcG2ANHWAw8YRthhh4giMwRgBKD/JXP5M7sgZB076BUyDtnKTG6f9HA6xioylbpG6AHUyRzZnxk1mYAbjcigBGINLUvnXcbh2gktTASOyOOfC/EbtEgfG0jMaPYPhcJjQUoRxBkgdpGCrMfFwmahaxEYWbPAXUY0/ED0Gdcl1g8nZsBfIN3J5vQUwcm2cw3VZSdbWqfvK1ApcmF0oDNNtFvrXYHPfSR2QkjYSOtMtOtNNXCcBG0mE8J6SZqyI9xycegYjU4RXhoEkxRlHcWyAeF4FG1tc6iB14sahn1CmLlE8Rm3byVljvJXnlJpZgKAiHaSvNvOt5bSMIQ6Wa5Cbfy6ZAKbwNhc2+fT86IeVNmkzoT0+S2eqgYnyKVilNHRB/Hz0n0rgxhhIUzBQXjJMceEAxhjSdipAYDTEiOieFYdTZek4zqcXcRfn5JzRPkEEdyAQOBlPgMwa+jG6gDB+3qBSDXPCgHieTCxsZ2Masa1w3jgNu50UlziiUkRp6RDFhYO4VGTznmx6hkGodzDUQh0W51Kcg+LSIeKRCrRFKOMTmFd3iON63Q+lVujDsvdiZ8SaHDKQMw4jWVJ7an/1ABlQ47vzwqtF5kJTNpe3Vh03n3QVCeNPK+BY+e5ziA+pwasTmauwoEppbECM0VuE8tEr9Q6GF8s5XOIojFaIh8tiITg1B80jQesKhFqLfDOZNVunCVv7qzGH7s6ohQvQfgRpKsoIOOm8xkgI6SLnG3qDkO/ee7JckSsakD7OFw1hSG2g4SfYfuIojFWJB4u4RBp4vHul3sHwAjmHLUQU5lUgyYWJMKkIJ30y0b3WUqcaz7mwHzpTi1qUNuhydqP27aCRWqbalolWxP5WxP5mxEQrYqZt6ARwvWd5s9B8kgc+ZzR+jhDvlCdDzkOVBxVDw52IWxgbwMRWE70O3iP1kcClmUscxfkVCosGcUkKKM+qw+655570wKnKfZzScCFNMiEkZGSubg0kzlBrWToJLKokrB7psGwgYbSQ0uzA7kaBLbWYrdOWmY5hsOioFgS8jBPvyd4TjOQswCoQWfrW63kwc3IEw/ECRIbW7hrtiTpEWmH1CEjvYOBwmpyLy4eIqyVIJIlnSn8eQA6ULdf3wMue/H2HxTGbWOoty4ljLV531DSnL51hzVCboTgVH3eGTmLY0YzYuK/ILc8M8KOtA4w3LSOllNgCqc9FMlOqjPj7IZ8rMtVnfAlp3kHByOVCACJLMt2ksaMmWOVkPBj1AQaQpJg4orRiGFuMIFXWxLBIncFqovcMdLm/P90FhChGaxsJVbmc4IDIOPY3LYMF+N/rJjh/7SSLqh1oG0gMpKoYD7p1EInX3rW3wmfuH+VfnhmkUkipRCmJJvOgIxf+dPN4wEFuDqfhMpxXsoa0mdDcNkGaphjbeybovaWy5IzcQ5D6M/LhEJ4kHOSqFkkGclGFEFJ3d6JIAxhtH6KXgjPeiFhZTbjmjJ184EV7WRR3YDbCtQwulSzpUg1FiYG2hUYErYhTFzS4/sxdXHryOK0OzHYMkefJEarALLc8B4+GcB8iHaW/MyZ3syn/jJG7bje3iOiB+gID1I2tNwaNnposhfGcGn2i9G7vCAAZJ+s54ukisEEqrQCIgclmxKqBhGvP3MVZK2ahHuPafvlBx/FjargJ3pg6XCOikBoufdE4l586TjuxNJMMfG9AHpiQnPWvpBYtbRH+0fsN5zTc5UomKWgyefqhnsHw/HYf5BgM8/pzHjCxOm+MXlSnCRqfqF1+7UssrJEYqgXHJ166h1MWNcQbVCnSVYXO85JFkWyOjoG65d3H7+dd6yeYavkFjjyTQbqcQflj/yUrJlzgQcOil8VLmcs7vVLPYAjNYbDrUKO+UQF9+YK6h/NWppaYAyBIq0sZzhhSoNaKeMcLJjlr5TTM2mCAIWI4IHJQTvVfAsUUbHbnIItEDlIJX+87cR8vWVxnoumNQcJpGNiJZxmQNSkn3ipzB4vKMeKV4L3Shy893Qf1DIbBZdHJf+YmTDGkSLjqQkkbeb4dmhuCDCqAiBP6Trct6+e1eNvaSWhHGZL4DwMlmEgifvDMEJ95YIyrN83jrvEyrmAgTmU075KAaxuGSwnvPmE/RWNoJcqDNpBwaeRmM6dNr38fCsP5YFVynJXDefl7p57BEDh0zckrVc+jbpkpLJcUUZdwKoguX0uC1746Uq3RYKbZxBhLO7G84egaS6ttaGk/b8TGQDnlJ7uqvOHHyzj/p0u4/K75XHbnGGffuoyLb1/Es20LhdSH+HDrRtNy1rI6v7W4wUzbhFLWaP5WWHR1wJ83JKlj/+wM49M1ktTJ/YhvG0gU48ELwaFH6gMMJeN0vcYnPtGQs+r2arV+GcFggmDZ4p2waI0hTVMm69Psn55izcKl/N6aE2k2U+YXWpy1fEbCiy4iOi9lMeX23RXe8bPF/PrZMpViymglYaTiaANXPTzMJbcvppZakMcqml9SSA3lKOHVK2dwWLlRNo7UFxzCvkBnLM1Om/GZKerNBi9bvYY3v+gllKKYVpJIW+c9RjsqiZPl/ejg1B8YRv54axMTUMty3iRyFuOF0z/iPQ5jRQn7Z6aZmJlhzcJl/PVrzmHDRZfykpWr2bF9F6tLMxw3nEBHaxtfnVhodAxX/GaUXQ3L0mqbghVwDVCNHEsGOnx3ywA3bh6GOMeEDz3O8OKxJsNRQjvxvilBRj4NzbTD3toUnXaHVx57Ap875x1848L38/lzL+KEpSuoNesBgOdM1Jll9kx9gSFx3i+Py3ecJG6D3N3603krkSOxtHaSsHe6xnSzzikrjuJTb7yADe+8jPe+6g0sHpnPwzu34ZodjhtpUS0mvizKFBqnPDBR4t69JeYVExKnsV5ndM5QMA5rHT/fXqWTCoDG+SoOSA3LB9osrnRopqI04c8w02yxZ3qSKHX8/gkv5qsXXMwNb3sf55z2MirFMpG1DMQFNX0/qQLiDTToqj/qCwxhOtW4n3cMq2VkrjJRkjaGZqfDs9OTtDpt/vsx6/jCORdy40V/zh+f/iqWjo4BsLc2yeN7dmHiAkuHZJ4MeQXFwM5GRL1jiG1OelW0t9OCgX2NiNmOlTDpWyoiQwXHgnJK4sSUppsN9tQmGSqVeOtpL+drf3wJXz7/Yl51/ClUSqUwRydNSFL/GM9bv/eNvOzdvPVCfYEhzxukpnL5myvILEVJvhrq7RbPTk9hgd8/4VS+ev7FfO3C93POaWcwUh0AYMe+vVz9bz/knKs/wV1PP06xXKakoceTQywQBwuLKaVIFg1FJVkS9nfKiTMMFFIqNu1etlELjiNHKZb1tqn6DIsGhnnvGb/Hhndeyuf+4F2cftwJRFEEwC8efYDfPLMZcsYVvmuWN5rQAuAe9T6oLzDI2YBUR0iAMrqe5BAWnWGm1WRPbYKBQpHzf+sMvvn293Hd+e/l1cefQqUolrZ5z07+7ocbeMNVH+PS73yV+7c/TSG2OGPYMR1p8vYVjVQ4dAzrR1usndei1rJY/4TQ+EpGOGwmhhcvqlMoSNJ2mut8yZQ4Q602y9T4Pi449Qxu/pO/4MNveCsnrlwNQKPd4l8fuo8//vKVvOmqv+Wepx9X+TWH5TTiT2T3GXqiz5uNvsGQ4TVHIII5l/mIcdDstBirDPDul/0u37zw/Xz23Hfx0mPWEUcxAPdv3cwHv3MDr//SR/nwLRt4ct9uRgYGGRkYwBpZbHxo3FJv69KLkgNILMOFDu85foKiNYw3rJbJ0iZxlp0zBU6e3+DcY2qykDjXQi3sqxs2720xZA3n/dYrOHJsCQDT9Vm+e+/tnHfdFbz1+s/wrftup5l2qBSL3WN42/feRrcx9ucTQn2BYfy9gk6fkm0+QIGaaTUZqw5y9Xnv4eNvvIBTjjwWgDRNue3xTfzp16/iTVd/nE/97PvsmplkbHCY4UoVi8GlIlA5djy0N+LR/ZFUQ3oTbZxaXcvy2iNqXPHS3SyspIw3YvbVY8YbEfsbES9d3ODzL9vNimoH19HwITFFBIkcm/ZGPL0/5cVHHcm6lasYn57iy7fdyjlXf4ILv/ZFbn3kfqI4YuHQCKVCIcNT05g3PxMACbap37Xk1269UM9gePdz/sCT5wLAGNpJhwWDI7xwxVEA1Fstbn3wXi64/tP84XVX8JVf/5xas8HCoREGi2XN0d7TFAwLz9YtP95SFA5N5ougSygty3nHTPKdV2/nw6fu47xjpnnbmik+d/ouvnXWdk4abeKaKp4PoSFsGP7lqQJpajl+xQq++quf87ovfJj3/dM/cMeWxyiVSiwYHKZgI62SfD/t7ctsvC50gjxIWhj0Qz2DkRmWZsoAQUgWiAUakjSl3moCcMfmRzjv+iu5ceOdJMDCwWGqxaIoVZOqC+WpCmIgjlK+/0SR/fUICt7SRAmhhG9FvGCwzZ+eMM5nXrqLK16ym/OOnWJBlELTarLWCbwJFx1PTBT48eYCw0NlfvT4Jt5/01d5ZM8ORqpV5lcHKUQRqfImUs1Rq1e6D88hTGvFp4Zrgo56o57BABnZVy7kHEQSrNdQt+PUGrO004QFg8OU4phU9yhJ9RF0jJGtd6F3NXbcsyvm1qeLUHSqEk85D20beXbRlqUOGpr4/VgyuBiSdRDDhkcLbJ4wDBQNtU6bgXKZedUBrNHVXA2JYZRM5Gw8tLLw58gvDuruky5NHJz6AsP5xKRlpxa53kMzd86ZQxzFlAoxDtneI88yfJyVSkzG9g+i5EFRbKGTOq7bWGKmZTFRPgxkY0gpKw9PhQdtpxWNIc0KjIJj22TE1zeVKEWOuBBTLhWIjMGlkrCEx26Hyubt/i64+IDlt+iodfYJBP2CYfyEeqftvP6N59yHkjyp+kQ3OeDkfAgAgX8jOw8cjJQdv9xe4J8fLUHJG6I306yUkPtnnTcMpypy8t0YoGi4/sEyj4xbhkoOU4ghFAYKrPE7XrRSDErNpPJ1gHxkLTIU0fbdmjgY9QWGjO8n0X8+HIuGFSHPqHbyHhVQ8dKoON4j9H/SyxDrjeXn7y6zp2ahoM/LjY7jkTV+8JyW/FxGlVNybNoT8eWNZSqxI7IWq6V24NV/MfI9BMZcRPInvCmJXPmL2flMmt6oLzDCNLo1Uv75R6U5QHLeYYzB6CovHovcNfzallZU0iyDZbiccu/umC9tLENROPY4YHSisP+yW6EOZSoSwK+4s8r2abkzJ46wunvc70DxIIhy5bFwd8JQBvUxQGaM2kCNyw+kmaVn6guMTMUemDl8eq+Zaw5OWfNIGKm6/AJf8BzjBcrmiQ0MllKu2Vjmrh0FKOn10MTvNtRlew2VGXMWKo7vPlHixkdLDJdScGDjWDzSSbI1vo8h2zrq/+HRF/Kn5LuHQsbwbAkMcxXx/NQXGNlD+W5lBHLyp9trPasCiFeAf6pG2ACQPYLN6iZH6uQ5+LN1w9/cVmG2YyD21Qoigsu2lTp9TCpKNZiSY+d0xEdvr5Kkuh5lDTaORdddGtTkrze3QQxp6FmS6KiG5XwoNOJJXbL3SX2BAWo1PlaHk2oJagxdWARVisKfi5y3trmkrxU4B/PKKbduLnHtxiqUVHEQJlQsMsXpoC52fPLOCvfttoyWU1wKxlpMLJsbvHc68jJ5wwia9xcU5OwQMrG8HKqGObnk4NQXGE4tLyNvLX56eQrYrXLJBcJoiLR6SYU1kn3CcGisdzqmMcTWUCo4PvnrMvfsKkAlp6ugvDlUTfjOY2Wu3ViW8KSLilEcY/3mMg8cGZpiWArOXM0rS55Zfz+RRUfvHZJb+6G+wPBMZA4sk4XwFU5lVUReFAdhp4WP82gBIEf58Jc7VgUMFR27Zw1/9YsqtZaR6krH8N0MqoOyY+tkzOW/qNJOoRIbUt0FaAtx17j57z7tdXMeRJ37NXRXNnL6f47ceRDqCwwN8cEK5VNWVhUDtZAujcqRIKGngsRy3TfIrf76ECXqc7I8AcyvpNzyVMyn7qpIMjdqnXnlRtAyhg/+YoBNeyNGK6nsfncOrMHEsUafrPjMIJVzvsACX1B5zvJVHyqw8qrbfHCEYqYfPPoCQ/Tp3c9XD/JdKHPRwKyGEWkrfUKsNgKQV4RDly0C+c3Wel10yXDR8dm7KtzyZBmquTtQBESqjms2lvnGQ0XmV5Oc8ThMFGOjCBxYZ3SXh/ASwnBYc9Ih0d3pfnxv9E6uSqgMhzqZLDUHPfRAfYHRTUH6Oee7rSF8V8zkON8nszMRJiSC5xjbkTqoFmA2gUt/VuWpiVjLXW1eSfnl1iIf+WWVYuwoBOXI5SiOMk8MU4shSLhURv310D0vlYaHXBExN8Tiwc2dOhj1CUamOH8sjpkxlQmjLXRRzaGWSS6wqsk6tUQxUp1Dhwi61D5GX7iZX3Y8uDfm0p8OMuuAGCjAzlnDB35aZbxuGC6KmgRbCSe2KHfd3vqDTvXGFXQvVcAjbxzaNQAloAjf+XJbYtxcbR2M+gPDx93sRKb/3KncR/AT7+WhTyDfQTONQaoef1mVEk4EJTrGqik3PR7zyTurUHUkEVz+80Hu3B4zVklJUuXXh0hrMVF8wPQSRsVoQBcLVY1OWJvjGdrPIRJmEdcLoI36gaJfMEKyFcvxrhnCKVbnz2JlGrwiX0HNJd3gEJTu1RIO1Zl0+V3Px8YxVHJc+esyP3qyxA2bynzlwRKj1TBr6Ouc/mCAtRkzLpMpf8+RPU9XXjwigVv1eJWVUJp7wHSsLsM9OPUFhsyVMeWC0uWvBptuxoNGvWM9F4O5vbe5GbysWRc/j5DDUI1Fa3/yo0H+5rYqAyVHMUJfNxCFS3sBI4+yV7rTwsIHFj+f32kCXWILOT+whiqfNzx3gticTs9PPYPhle7IK1SF9ccaart4EPkkTOiBDwkmpwQfpqVJhqDRSiwkQ43xPk6nDioFGG/AZEuenzuQsgthRsaVJRAxIB/n88HIM69iqaF7nvIiCQa+vYDgjOQ1eaXZ6iDBinqinsEQUgWZzACkxM9Emhtb5Sin3JxUclaLgNyOChee1AH69C1TjF4TjYAm9HLkKNrcnbi+IC9NHcZGoaTV6lVCo0F3nWt7/zxec4mcMxSsJP5SHMvDKMRl/U5FED3IWpVI9V/mGU4VL980BHg2jChJrGJOKMp5je/v/LK1HKpe1eT9mDkFebBlGDkjVq3fc1eCG5ENBfK6tIllU5rwL5+eDN71wpG2cVhrmWzMMlGfYdfUBJ00lcfEQdnqHZr8/UD9QdEHGKi+RFBVmh5nySr/KoDv5I9FQGE7FwdCrPWJNosPEs7EPvPx21ufDO/zlrdo6es0MfvxQ+L2sd6X2TJILuyoKg2AJbYR5VKJv7/9x5xzzSf4g+s+xcadzzBUrqgWhA/xFO3mZDn/ufPjf0x9gZEx6Z8diAaDLKr0PKk+vEpVWT5m+0YuqFV0ohrxXoMob66naJMwpz92GmpU5zig02zR2F+jOTVNqzZNszZLc2qGZm2GZm2a5lSN5qScb9VmaNVmaU3P0p5pkM422bJrF/dsfpwHd2xlttOiYOesiGbKgWCUues9UF9giO5zXqCKcajivLLmMplb8vBgZsxLeNPSQDYVGyM/OaHAeLDzYQH02UjulCR2WeIQXj0T8tNELklwnZS03SFpt0laLdJmm7SVkLY7uHaHtNUmbbVJWh2SZouk2aA92yRqdii1EgrNjvzWlC9tczlTmMiJ58Nlj9QXGDJJFiLQIELOMLqA0DZdZpJn0HsIhtlWk4nZWaYbs+yfrtHsdMKdsAfbA6MDZWavPGCg2WpRa9apt9vhnDWG1KXMtpvMtJq001QAU9CbSZvpVotm2sFgmGm3mGzMMNWoM1FvMNWcpdZs0OokuE6H1tQM7dl6lp9ygKgZyFF/WPQHhoRAnUz1IKFJz/twnKknF9/zzxzkjtc5R63ZYO/0JPPKVd59xu/ypbe+h9894RRIEp6dmqLeasl81t9QIj7pS9YwogMMCweHOGJkPvMrVVLdxpI6hzWWpUPzWDlvPpW4oB4ISeoYLlZYOTzKgsogBjhmbCEnL1/FCUtW8MKlK3jh0iM4ev5C0jSlVm9gjKE9U6c9Uw9y+Dzn84Twc4BlPi/19QsJLkmJChGlFSNSmbhUjEOTujUwUZ9l3eIj2HDRpSwanscPHribC2/4PHEUEUcRFkPiUmqNOq2kzTFjS3jdiafyplNOZ93yVQDUm01++chv+PYdP+eWB+9lx+QE5UKRwXKJyEb6YzB5h3C0koQ0SbjyD9/BK088jQe3buai665kojHLbLvNa9a/iI//4TuolMtc+6/f5xM/2EChUGS4VOIL57+HF61ew/fvvp2/+uaXueFdH+DFa9eDM0SRGMFso8FdTz7Cp2/ewF1bn2SoUsXhKI8MYeI4FA4gv0VV3zaJ6yT/db+QgLdKkDdW1VvEJX1d022xRr0IzQf769NMzkyzduFSPvSat7DhnZfxwf/5vwIQAJVSiVeeeCpXX/R+bvqzy7ns987myNEF7KvV2Dddo5MkOpOMC444iphuNtg/M83S+WO84viTOWrBEmabLVyS8Dtr17F62QqWzV/Ay9efRLVQpNZosGLeGGcefzLL5i9gsj5LrT7LgnnzGB0aYXR4mIFymYFShSXzF/DaU3+Hz7/tT1kxMp+ZZhNSR6fRzBYWReBQQGQLh71Rz2BkYcdPOOeceqWUoTlnM9ByHcZnatSbDU5duZorzr6Af37X/+Xis17P0YuWgm7F/8adP+eyf/oHfvbw/bQ7EvNftHoNf3Pu2/nBpR/hk295O6etOoZGo87eqQkaSUvrfRtywC8f24RzjiiOecGylTRbLYZLFY4/Qt67ADh26XKOGFtI0mywevFyquUKzjnueHQTxlhS/bWgXz/+MK/5yJ9z5gf/jCtu+gZJmrBu1dGc+YITqTcbYAxJq0OadAQLJ0Zp/B6wAxPo81LPYIAoNrvfDCe6j7tP0Gi1SNsdXnnc8XzxLe/kxosu44LTX8WikVEAdk6M8+V/v4Wzr/oYF3/7Wj7/bz/krV/5DH903RVsuPs2xqenADhi0RL+5DVn870PfJhrL7yE1554KiZ1PDs1wWyzCQ5KhQKP7tzGrv3jABy/8khckrB03hhrlx8ReFoyOsZxi1dAu83aZSsxxrB3coJHd22nVCgECbfv38ct9/6Kf7/rNq68+UZ2jO8FYLQ6INtBMfKrdEn265D+EbR4RpiyJ+oZjC4V+5jts3jIzC4sA/gzaxYv4yvnX8zX3/4B3njq6QyVqwBs2bubT93yz7zxqr/l/2y4nruf2Uy5WGbJ8AjOwI8evp93/uMXefPVf8sXfnozW/buBmB4YJA3/7dX8PX3/iU3XfxB3v6ys5hXqtBoNykWimzbP86DW54C4IRVR1GOI9YuXc6y+Qt5Zs8utu7ehTGWtctXQhSxZtkKAB7csplt48/quxjC/cKBYU47dh0nveCFnHfmq1k4MspMfZaHtm8ljmPJl6n/GVkx1CyddZttL9QzGKjuBe3uiA3ZfYLRGObBW798Ff/j5N9moFwB4KHtW7j8u//I67/0MT70LzfyyJ6djAwMMlodJLaW1DmKNmbB0DADlQr3bXuav7j567z+qo/ylzfdwH1PP4FzjmKhyOnrT+KLF17CTZdczprFK6g3m9SaTTZueQKAVYuWsXxoPmuXrcRayy333smPN94pfK08kiXD81i9ZBkAG596gql6nSiKghJfsnYdP7n8Cm776Bf4yB+9k3KxyHW33MwPf3MPw9VBQHOnV4evLJ1GkFBp9kZ9geHyN1pOfrvVkDFijCF1jsjY8MqYpzuefJhLvnUNZ1/1Ma746ffYNrmP0cEh3YqvP8Kl9boz8qZTbCNGBwaZVx1k+8R+rvzZ93nTNZ/goq99gVsevIdGqwXASauPY/3yI2hpnrlviwA2f3CYtStWsV5f3PnVEw9x15OPAXD0kmWcuPJIFg7PA5AXKC3YXAzoJAlT9VnGazWm67MAvPCoYzh28dLw/gk+NGm+VOWEQqcf6gsMqZdctvDj5/O1tZMbrEanxWyzTqPV4icP38fbrv80b7nmk1x7+7+yv1Fn4dAIQ5WyrHL7ciz/cMdlVuX0seZgpczC4RFmO22+ec9tXPCVz/Dmv/84N9zxE/bP1Fg+Oh9rDcVCgU3btrBz/16pytafxPqVq6g3m2zc8jQPbNtKq91i2egYZ647meGBQcanJnlw25awEdob9B2PbeJVH3o/Z/zVn3HuJ/+aLbt38vITT+Gy170FkoROkgCm63UQXQbQ4/4CVV9gOL3h9DdxMqXf8SG8DJQq7Jyc4JJvX8v513+a86//LBs23kmHlAWDIwyUSmI5qV9r0tCmY+kKlkqmwOMXI6FSLDA2OEQUx/xi80O899vXce7Vf8e9O7YyVK5SjAtsG9/Lo9u2AvDG3zmTY5ev5PEd23hqfA9b9u3mqd07WTgyyltefhZDlSqPbNvC1r17KPmXKFWHU406m3Zt5+l9u/n+3bdz3+ZHAXjp2uM5YnSMVqejXBvdR9wtST539kJ9gSEkyhFkxCH99hZwxMZgreEnjz3ALY/cD9ayYHiYclzQhO8VLCboc0zmaT4M5pcacsseToQuRDFjA0MMV6vcs/1pfvXMExTiiEJkmW41uWezhKMVi5dSLBS5/+nHqTXr7JuZ5oGtm7HWssrni6efYKpZp6jPOzwNFYocPTrGwsERXrbuhRy/6mjPtrLjMNZIOaz8eUPyOy89OL1Qz2B4XYTSTW//xSNzd58IByOVQeYPDFH02+4RBeutogDhz+fJ4xROaAs/friRkr7WWIYrFapaIFjkAc+9mug9/frxh3FAO0257yl5p1uH4Z7Nj5ECkcTNsPXzt9es5+Y//wg//ouP80+Xfphjlkl5/MO77+SZ/eMUtaIysT7bmKOD/vyiDzCMWkSaOlya6o2eLKXn0XdG7zwNUoOTgSj8KhDaFuPf8dN3NLwCQyhUAJ0ygOQR5LKA4hw2ijCRLEuU4gKP7niGfVOTAEzNTHPvlicpFQoUopj7nnqSZluS//jUBJu2baFQkF2G2CyFV8oV1h15DCeuPo4F80aZmpnmultv5mPf+xZRXCC2lqhYxFqLSeVVAxFc3xnpk/pam5LfOYfi8iFstYhJ5nQ1hIXDkIyNWJtGl+wxpcZYfD3gr4e2mZkZHdsvM4Qop2qTKGdIWi2aU9MkqaMQWV570mmsmDfGzon9fO83d4Vqq1Io8Yr1JzFcGWDv1AQ/ffh+eXoHxFhOX72G+YPDJIn/nRRDM014cs8u7n/mKUxk5Y1dC+WRYYj02YZxYC3JdIvGjikRwcvRA/UOhg8paUpxQZXC2ACu4xUuTUTt8vdAyp3PKdPRva9VXU4doTuU+W06chD+hJVTYyyt2Vk6Mw0cjulGgyRNsMYyVB2QZ9fGkCQdJut1nEuxNmK4UiW2utnNOabqdRKtlPwOEgxYaxkslYmMIbVQGhwkLhW6wiHW0t47TWu8Lm/65IzmYNQ7GCBKSlKiSkx5+TxRTprli6Buky0O+sF9xWXE/EPJ6sOcvMolo2Rw+I4yFtoXf6jnZJzsPqXTaNKpN3GpbHj22/bDnit95Gr9r2R7a3DCh9HCQjwupx7/tRBRqFaIiwUJ2Sq7N4rGM5MkzY54jF7rhXoHIzzylHBVWDRIYX4V2vKLZB4Ioz87JHlDClff37uQ0ZDq07lXuPQUdvKKE/JASMPM+/3GBc07RqoKhyPtdEjbiawdKVgyns9BfkYtr52Or6C6jCkByFrZCFcoyH8/I5cXnO7Lao/P0Nozg4ut3i8p7z1QH2D4P2JFJjKUVg5jS0Xo6I97BLQOJC9caOKy8kEMM4jv9SZ/nIAlbZRVXzbqQF6/cs13M/IGszUgEUeVK+FMJJEfbArknVPB9twaDC4YWTZOl7CxIa23aWybhARcJPL8hwp5Duq5mvJSGqPvY3QSmjuncc0OJlKr9cYFyoSez8X9kAOCtrMCUPzEbwMKuPuv8ifnFc7lgHAZSPKhN5WJvpTv9O0io4312DnlzwOBfxQsJ2RK+c0qUodzWjUpKA6HiS2uldDcWRMvjNTp0NjcI/UORiaD/IksaaNNY8cUyWwbIouJbE4QYUIigddWgEjIt9EQIxrJlbe+vYY06eNDTdBe9plrkyfxKK86BRGZ33tjvpNnBTUe1GSc90LUMK3BxpZ0tkVj2yRps4OJImntX+4Pwh6c+ghTGcuGzDxdx2EjQzxSJp5XxhYjsczcb/+JW4tmpVcGTvCQnG6ln5zXbqrMrp763YGxBxYMOTX7Y4KhZq0screcvXKQ154LEuBVYHVk53CdlM5Ek/ZEXV7qiUwmsRYJueR2UOodDNWWrxgyJSmXKZiClf8aWSXGFK1swXfd9wXSLwdSUG9QrSpEWx5gXRkc2elcvtHrhny5nAdDN1nnQmp4Da2Ln9A1FCOpA5OmpK2EpN4hrbdJO7J0bazJynKH/iqbgNErHL2D4fSPn0SdIz+RSwlPwExEUKv09JaSiZwn0XnuitF/qcgYxglxn0xpqr+ucXMKN2TVq9Ex/PhdjwFyJE38wPIpHu8FVS+xuqEv8JJZn0PG7RWOnnOGRkwcUrIZLUfT7IfSMAZsbCWhqyacWgp+76wGZP/dOf1v2jnC5mdpIufFBjTB6sWsr2+n3/VT3pHxc3nH9d/Vg1Jpj1O5Qj+9lp9Tw05ANrIQi+d77WTWIutUvjT3BWAv1DMYxsjqpFiRr0l1I5iamQsvjeg/a6St1e9WNg8c8C9cn9PPj5P/bvPn/TU5J3urtBoLc2XtnDE4fy7wluuf41s2OoiMbu68Xl7I5A1yq2pUP3KtN+oZjMP0X0+HwTiE6DAYhxAdBuMQosNgHEJ0GIxDiA6DcQjRYTAOIToMxiFEh8E4hOgwGIcQ/T/gfRHwTcJLGAAAAABJRU5ErkJggg==";function Ve(e="official"){const t=e==="compact";return`
    <div class="app-pdf-footer" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-top: auto; padding-top: 10px; border-top: ${t?"1px solid #94a3b8":e==="bilingual"?"1px solid #c084fc":e==="legal"?"1px solid #d97706":"1px solid #cbd5e1"}; font-size: 9.5px; opacity: 0.88; color: ${t?"#334155":"#475569"};">
      <div style="display: flex; align-items: center; gap: 6px;">
        <img src="${sr}" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain; vertical-align: middle;" alt="${wt} Icon" />
        <span style="font-weight: 700; color: ${t?"#1e293b":"#334155"};">${wt}</span>
      </div>
      <div style="font-size: 9.5px;">
        <a href="${ir}" target="_blank" style="color: ${t?"#475569":e==="bilingual"?"#7c3aed":e==="legal"?"#78350f":"#1976d2"}; text-decoration: none; font-weight: 600;">Get App: play.google.com/store/apps/details?id=in.svt.wblandsinfo</a>
      </div>
    </div>
  `}function cr({html:e,title:t="Land Record",caption:r="",designId:a="official"}){const p=new Date,l=p.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),m=p.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit",hour12:!0}),f=`${l}, ${m}`,h={html:e,title:t,caption:r,formattedDate:l,formattedTime:m,fullTimestamp:f};switch(a){case"modern":return dr(h);case"compact":return pr(h);case"bilingual":return fr(h);case"legal":return ur(h);case"official":default:return lr(h)}}function lr({html:e,title:t,caption:r,formattedDate:a,formattedTime:p,fullTimestamp:l}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1a1a1a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Times New Roman", Times, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .official-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .official-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      position: relative;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .official-header {
      border: 2px solid #175953;
      background: #f7faf9;
      border-radius: 4px;
      padding: 14px;
      margin-bottom: 12px;
      text-align: center;
      position: relative;
    }
    .gov-title-main {
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 0.8px;
      color: #175953;
      text-transform: uppercase;
      margin: 0 0 3px 0;
    }
    .gov-doc-badge {
      display: inline-block;
      background: #175953;
      color: #ffffff;
      font-size: 11.5px;
      font-weight: 700;
      padding: 4px 14px;
      border-radius: 3px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      margin: 4px 0 8px 0;
    }
    .official-meta-strip {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      background: #eef5f4;
      border-top: 1px solid #bcd8d5;
      padding: 6px 12px;
      font-size: 11px;
      font-weight: 600;
      color: #134e48;
      border-radius: 2px;
    }
    /* Standard Tables */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #175953 !important;
      font-size: 12px !important;
      page-break-inside: avoid;
    }
    th {
      background-color: #175953 !important;
      color: #ffffff !important;
      font-size: 12px !important;
      font-weight: 700 !important;
      padding: 7px 8px !important;
      border: 1px solid #10423e !important;
      text-align: left;
    }
    td {
      border: 1px solid #cbd5e1 !important;
      padding: 6px 8px !important;
      font-size: 12px !important;
      color: #1e293b !important;
    }
    tr:nth-child(even) td {
      background-color: #f8fafc !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .official-footer {
      margin-top: 20px;
      border-top: 1.5px solid #175953;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      line-height: 1.4;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="official-wrap">
    <div class="official-header">
      <div class="gov-title-main">Land Record Information</div>
      <div class="gov-doc-badge">Record of Rights (RoR) / খতিয়ান ও দাগের তথ্য</div>
      <div class="official-meta-strip">
        <span><b>Location:</b> ${t}</span>
        ${r?`<span><b>Details:</b> ${r}</span>`:""}
        <span><b>Date:</b> ${l}</span>
      </div>
    </div>

    <div class="content-body">
      ${e}
    </div>

    <div class="official-footer">
      <div><b>Land Record Extract</b> • ${t}</div>
      <div>Date: ${l}</div>
    </div>

    ${Ve("official")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function dr({html:e,title:t,caption:r,formattedDate:a,formattedTime:p,fullTimestamp:l}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #f8fafc;
      color: #0f172a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { background: #ffffff !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .modern-wrap { padding: 0 !important; min-height: 96vh !important; }
    }
    .modern-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 14px 20px 14px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .modern-hero {
      background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
      color: #ffffff;
      padding: 18px 20px;
      border-radius: 12px;
      margin-bottom: 16px;
      box-shadow: 0 4px 16px rgba(37, 99, 235, 0.16);
    }
    .hero-badge-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .hero-badge {
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 10.5px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .hero-title {
      font-size: 18px;
      font-weight: 800;
      margin: 0 0 4px 0;
      letter-spacing: -0.3px;
    }
    .hero-sub {
      font-size: 12.5px;
      color: #dbeafe;
      margin: 0;
    }
    .hero-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 12px;
    }
    .hero-tag {
      background: rgba(255, 255, 255, 0.15);
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 500;
    }
    /* Modern Card Tables */
    table {
      border-collapse: separate !important;
      border-spacing: 0 !important;
      width: 100% !important;
      margin: 12px 0 !important;
      border-radius: 10px !important;
      overflow: hidden !important;
      border: 1px solid #e2e8f0 !important;
      background: #ffffff !important;
      box-shadow: 0 2px 8px rgba(0,0,0,0.03) !important;
      page-break-inside: avoid;
    }
    th {
      background: #f1f5f9 !important;
      color: #334155 !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 10px 12px !important;
      border-bottom: 1px solid #cbd5e1 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
      text-transform: uppercase;
      letter-spacing: 0.4px;
    }
    td {
      padding: 8px 12px !important;
      font-size: 12px !important;
      color: #1e293b !important;
      border-bottom: 1px solid #f1f5f9 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
    }
    tr:last-child td { border-bottom: none !important; }
    tr:hover td { background: #f8fafc !important; }
    
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .modern-footer {
      margin-top: 20px;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 10px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="modern-wrap">
    <div class="modern-hero">
      <div class="hero-badge-row">
        <span class="hero-badge">Land Record</span>
        <span style="font-size: 11px; opacity: 0.85;">${t}</span>
      </div>
      <h1 class="hero-title">${t}</h1>
      ${r?`<p class="hero-sub">${r}</p>`:""}
      <div class="hero-tags">
        <span class="hero-tag">Date: ${l}</span>
        <span class="hero-tag">Format: Modern Card</span>
      </div>
    </div>

    <div class="content-body">
      ${e}
    </div>

    <div class="modern-footer">
      <div><b>Record Details</b> • ${t}</div>
      <div>Date: ${l}</div>
    </div>

    ${Ve("modern")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function pr({html:e,title:t,caption:r,formattedDate:a,formattedTime:p,fullTimestamp:l}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Print Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff !important;
      color: #000000 !important;
      font-family: Arial, Helvetica, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 8mm 6mm 8mm 6mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .compact-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .compact-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 10px 12px 16px 12px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .compact-header {
      border-bottom: 2px solid #000000;
      padding-bottom: 6px;
      margin-bottom: 8px;
    }
    .compact-title {
      font-size: 15px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 0 0 3px 0;
    }
    .compact-meta {
      font-size: 11px;
      font-weight: 600;
      color: #000000;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    /* Strictly Monochrome Ink-Saver Tables */
    table, tr, td, th {
      background: #ffffff !important;
      background-color: #ffffff !important;
      color: #000000 !important;
      border-color: #000000 !important;
    }
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      border: 1.5px solid #000000 !important;
      margin: 6px 0 !important;
      page-break-inside: avoid;
    }
    th {
      font-size: 11.5px !important;
      font-weight: 800 !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      text-transform: uppercase;
    }
    td {
      font-size: 11px !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      line-height: 1.2 !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .compact-footer {
      border-top: 1px solid #333333;
      margin-top: 12px;
      padding-top: 4px;
      display: flex;
      justify-content: space-between;
      font-size: 9.5px;
      font-weight: 600;
      color: #1e293b;
      opacity: 0.92;
    }
  </style>
</head>
<body>
  <div class="compact-wrap">
    <div class="compact-header">
      <div class="compact-title">WEST BENGAL LAND RECORD (RoR) - PRINT LAYOUT</div>
      <div class="compact-meta">
        <span><b>Location:</b> ${t}</span>
        ${r?`<span><b>Details:</b> ${r}</span>`:""}
        <span><b>Date:</b> ${l}</span>
      </div>
    </div>

    <div class="content-body">
      ${e}
    </div>

    <div class="compact-footer">
      <span>Eco Ink-Saver Layout • ${t}</span>
      <span>Date: ${l}</span>
    </div>

    ${Ve("compact")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function fr({html:e,title:t,caption:r,formattedDate:a,formattedTime:p,fullTimestamp:l}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Bilingual Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1e1b4b;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .bilingual-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .bilingual-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .bilingual-header {
      background: linear-gradient(135deg, #4c1d95 0%, #7c3aed 100%);
      color: #ffffff;
      padding: 16px 18px;
      border-radius: 8px;
      margin-bottom: 12px;
      border-bottom: 3px solid #c084fc;
    }
    .bilingual-top-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 6px;
    }
    .bilingual-title-en {
      font-size: 16px;
      font-weight: 800;
      letter-spacing: 0.4px;
    }
    .bilingual-title-bn {
      font-size: 13.5px;
      font-weight: 600;
      color: #f3e8ff;
      margin-top: 2px;
    }
    .bilingual-docket {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      background: #faf5ff;
      border: 1px solid #e9d5ff;
      border-radius: 6px;
      padding: 10px 14px;
      margin-bottom: 12px;
      font-size: 11.5px;
    }
    .bilingual-docket-col b {
      color: #6b21a8;
    }
    /* Bilingual Tables */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #7c3aed !important;
      page-break-inside: avoid;
    }
    th {
      background: #7c3aed !important;
      color: #ffffff !important;
      font-size: 12px !important;
      font-weight: 700 !important;
      padding: 8px 10px !important;
      border: 1px solid #6d28d9 !important;
      text-align: left;
    }
    td {
      border: 1px solid #e9d5ff !important;
      padding: 7px 10px !important;
      font-size: 12px !important;
      color: #1e1b4b !important;
    }
    tr:nth-child(even) td {
      background-color: #faf5ff !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .bilingual-footer {
      margin-top: 20px;
      border-top: 2px solid #7c3aed;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #4c1d95;
      font-weight: 600;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="bilingual-wrap">
    <div class="bilingual-header">
      <div class="bilingual-top-row">
        <div>
          <div class="bilingual-title-en">LAND & REVENUE RECORD</div>
          <div class="bilingual-title-bn">ভূমি ও খতিয়ান-দাগের তথ্য বিবরণী</div>
        </div>
        <div style="font-size: 11px; color: #f3e8ff; text-align: right;">
          <div>${t}</div>
          <div>${a}</div>
        </div>
      </div>
    </div>

    <div class="bilingual-docket">
      <div class="bilingual-docket-col">
        <div><b>Location (অবস্থান):</b> ${t}</div>
        ${r?`<div><b>Record Info (বিবরণ):</b> ${r}</div>`:""}
      </div>
      <div class="bilingual-docket-col">
        <div><b>Format (ফরম্যাট):</b> Bilingual Layout</div>
        <div><b>Date (তারিখ):</b> ${l}</div>
      </div>
    </div>

    <div class="content-body">
      ${e}
    </div>

    <div class="bilingual-footer">
      <span>Bilingual Record • উভয় ভাষায় তথ্য বিবরণী</span>
      <span>${t} • ${l}</span>
    </div>

    ${Ve("bilingual")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function ur({html:e,title:t,caption:r,formattedDate:a,formattedTime:p,fullTimestamp:l}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Classic Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1c1917;
      font-family: "Times New Roman", Times, Georgia, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .legal-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .legal-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .legal-header {
      border: 3px double #78350f;
      background: #fffbeb;
      padding: 14px;
      text-align: center;
      margin-bottom: 12px;
    }
    .legal-title {
      font-size: 16px;
      font-weight: 900;
      text-transform: uppercase;
      color: #78350f;
      letter-spacing: 0.8px;
      margin: 0 0 4px 0;
    }
    .legal-sub {
      font-size: 11.5px;
      font-weight: 600;
      color: #92400e;
      margin: 0;
    }
    .legal-docket-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0;
      font-size: 11.5px;
      border: 1.5px solid #78350f;
    }
    .legal-docket-table td {
      padding: 6px 10px;
      border: 1px solid #d97706;
    }
    .legal-docket-label {
      font-weight: bold;
      background: #fef3c7;
      color: #78350f;
      width: 25%;
    }
    /* Strict Ledger Grid */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      border: 1.5px solid #78350f !important;
      margin: 10px 0 !important;
      page-break-inside: avoid;
    }
    th {
      background: #78350f !important;
      color: #ffffff !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 7px 8px !important;
      border: 1px solid #451a03 !important;
      text-transform: uppercase;
    }
    td {
      border: 1px solid #d97706 !important;
      padding: 6px 8px !important;
      font-size: 11.5px !important;
      color: #1c1917 !important;
    }
    tr:nth-child(even) td {
      background-color: #fffdf5 !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .legal-footer {
      margin-top: 18px;
      border-top: 1.5px solid #78350f;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #78350f;
      font-weight: 600;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="legal-wrap">
    <div class="legal-header">
      <div class="legal-title">LAND & PROPERTY RECORD</div>
      <div class="legal-sub">Khatian & Plot Record Particulars</div>
    </div>

    <table class="legal-docket-table">
      <tr>
        <td class="legal-docket-label">Record Date:</td>
        <td>${l}</td>
        <td class="legal-docket-label">Format:</td>
        <td>Classic Ledger Grid</td>
      </tr>
      <tr>
        <td class="legal-docket-label">Location:</td>
        <td colspan="3">${t}</td>
      </tr>
      ${r?`
      <tr>
        <td class="legal-docket-label">Particulars:</td>
        <td colspan="3">${r}</td>
      </tr>
      `:""}
    </table>

    <div class="content-body">
      ${e}
    </div>

    <div class="legal-footer">
      <span>Classic Ledger Format • ${t}</span>
      <span>Date: ${l}</span>
    </div>

    ${Ve("legal")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function Rr(){var K;const{t:e,i18n:t}=rt(),r=(K=t.language)==null?void 0:K.startsWith("bn"),{t:a}=rt("inputField"),{errorAlert:p,setHeaderButtons:l,successAlert:m,darkMode:f}=Bt(),{user:h,logoutUser:A,isLoggedIn:x}=Ht(),{selectedDistrict:S,selectedBlock:j,selectedMouza:P,searchLandDetails:V,setSearchLandDetails:B}=Vt(),[Q,Z]=R.useState(!1),[_,ee]=R.useState(()=>Re.get("pdfDesign")||jt),[U,I]=R.useState(!1),[y,J]=R.useState(""),[H,q]=R.useState(!0),G=Jt(),ie=Yt(),{districtId:c,blockId:N,mouzaId:g,recordData:T}=Kt(),s=ie.pathname,d=R.useRef(""),C=R.useMemo(()=>{const i=(s||"").split("/").filter(Boolean);if(i.length>1&&i[0]==="wb"){const b=i[1];return b.startsWith("mutation")?"mutation":b}return i[0]||"general"},[s]),Y=$t==="dual",[z,re]=R.useState(()=>{const i=Re.get(`${Ze}${C}`);return i==="app"||i==="html"?i:"app"}),pe=i=>{i&&(i==="app"||i==="html")&&(re(i),Re.set(`${Ze}${C}`,i))};R.useEffect(()=>{{const i=Re.get(`${Ze}${C}`);re(i==="app"||i==="html"?i:"app")}},[C,Y]);const[Te,oe]=R.useState(!1),n=R.useMemo(()=>{if(T)try{return JSON.parse(T)}catch(i){console.error("Failed to parse recordData from params",i)}return V},[T,V]),ce=R.useMemo(()=>rr(y,s),[y,s]),fe=i=>{if(!(!c||!N||!g||!i)){if(s.includes("/mutation-status/")){const b={...n,caseNumber:i},u=encodeURIComponent(JSON.stringify(b));G(`/wb/mutation-case-status/${c}/${N}/${g}/${u}`,{replace:!0})}else if(s.includes("/mutation-case-status/")){const b=i.replace(/\//g,"_"),u={...n,caseNumber:b},w=encodeURIComponent(JSON.stringify(u));G(`/wb/mutation-case-details/${c}/${N}/${g}/${w}`,{replace:!0})}}},M=()=>{var i,b;if(de(),B(u=>({...u,...n,caseNumber:String((n==null?void 0:n.caseNumber)||(n==null?void 0:n.caseNo)||(u==null?void 0:u.caseNumber)||"").toUpperCase(),caseNo:String((n==null?void 0:n.caseNo)||(n==null?void 0:n.caseNumber)||(u==null?void 0:u.caseNo)||"").toUpperCase(),applicationNo:String((n==null?void 0:n.applicationNo)||(n==null?void 0:n.appNo)||(u==null?void 0:u.applicationNo)||"").toUpperCase(),appNo:String((n==null?void 0:n.appNo)||(n==null?void 0:n.applicationNo)||(u==null?void 0:u.appNo)||"").toUpperCase(),applnNo:String((n==null?void 0:n.applicationNo)||(n==null?void 0:n.caseNo)||(u==null?void 0:u.applnNo)||"").toUpperCase(),mainNo:(n==null?void 0:n.mainNo)!==void 0?n.mainNo:(u==null?void 0:u.mainNo)||"",subNo:(n==null?void 0:n.subNo)!==void 0?n.subNo:(u==null?void 0:u.subNo)||"",searchBy:(n==null?void 0:n.searchBy)||(u==null?void 0:u.searchBy)||"Khatian",grnNo:String((n==null?void 0:n.grnNo)||(u==null?void 0:u.grnNo)||"").toUpperCase(),requestType:(n==null?void 0:n.requestType)||(u==null?void 0:u.requestType)||"",khatianType:(n==null?void 0:n.khatianType)||(u==null?void 0:u.khatianType)||"Normal",rslrSearchBy:(n==null?void 0:n.rslrSearchBy)||(u==null?void 0:u.rslrSearchBy)||"LR"})),((b=(i=window.history)==null?void 0:i.state)==null?void 0:b.idx)>0)G(-1);else{const u=s.split("/").filter(Boolean);T&&u.length>2?(u.pop(),G("/"+u.join("/"),{replace:!0})):G(-1)}},te=(i=!0)=>{i||(d.current=""),qt(),q(!0);let b=Xt;s.includes("/rs-lr/")?b=to:s.includes("/khajna-status/")?b=oo:s.includes("/mutation-case-status/")?b=no:s.includes("/mutation-case-details/")?b=ro:s.includes("/mutation-status/")?b=ao:s.includes("/land-class/")?b=io:s.includes("/warish-status/")?b=so:s.includes("/conversion-status/")?b=co:s.includes("/signed-copy/")?b=lo:s.includes("/revenue-no-dues/")?b=po:s.includes("/barga-info/")?b=fo:s.includes("/grn-search/")?b=uo:s.includes("/app-reprint/")&&(b=mo);const u={...n,districtName:(S==null?void 0:S.name)||"",blockName:(j==null?void 0:j.name)||"",mouzaName:(P==null?void 0:P.name)||""};x&&b(u,c,N,g,i).then(async w=>{if(w&&w.html){let ve=localStorage.getItem(dt)??0;w.cached&&ve++,localStorage.setItem(dt,ve);const ze=await Qt(Zt)??10;ve>ze&&_t(),console.log("html Received=>",ve,w.html);const Je=new DOMParser().parseFromString(w.html,"text/html");Je.querySelectorAll("a").forEach(xe=>{const Ke=xe.innerText.trim().toLowerCase();!Ke.includes("view ror")&&!Ke.includes("certified copy")&&xe.removeAttribute("href")});const Ye=/(MN\/\d{4}\/\d+\/\d+)/g;s.includes("/mutation-status/")?Je.querySelectorAll("td").forEach(xe=>{xe.innerText.trim().match(Ye)&&(xe.innerHTML=xe.innerHTML.replace(Ye,`<a href="javascript:void(0)" onclick="onCaseClick('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}):s.includes("/mutation-case-status/")&&Je.querySelectorAll("td").forEach(xe=>{xe.innerText.trim().match(Ye)&&(xe.innerHTML=xe.innerHTML.replace(Ye,`<a href="javascript:void(0)" onclick="showMutationCaseDetails('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}),w.html=Je.body.innerHTML,J(w.html),Z(w.cached),eo("high-low",3),Se("success_record_fetch",{totalCount:ve,cached:w.cached?"true":"false",useCache:i?"true":"false"})}else A(),de(),J(""),p("auth.sessionTimeout")}).catch(w=>{J(""),console.red("Error in record fetching",w.message),Se("record_fetch_error",{message:w.message}),p("kyp.recordView.errorLandRecordFetch",{error:w.message}),G(-1)}).finally(w=>q(!1))};R.useEffect(()=>{if(x&&d.current!==s){if(d.current=s,h=="demo"){Xn().then(i=>{J(i.html),q(!1),Se("demo_record_fetched")});return}te()}},[x,s,T,h]);const me=a("wb.landDetails.khatianType.option",{returnObjects:!0})||{},he=a("wb.landDetails.searchBy.option",{returnObjects:!0})||{},ge=String((n==null?void 0:n.searchBy)||"").trim().toLowerCase(),E=ge==="plot"||ge==="lrtors"||ge==="rstolr"||!!(n!=null&&n.plotNo)||s.includes("/rs-lr/")||s.includes("/mouza-map/"),ne=`wb-record-${s.split("/")[2]}`,X=R.useMemo(()=>{var i,b,u;if(s.includes("/land-class"))return e("recentSearch.districtClassification","District Classification");if(s.includes("/warish-status")){const w=(n==null?void 0:n.caseNo)||(n==null?void 0:n.caseNumber)||(n==null?void 0:n.applicationNo)||(n==null?void 0:n.applnNo)||"";return w?`${e("wb.warish.applnNoLabel","Warish Application Number")}: ${w}`:""}if(s.includes("/conversion-status")){const w=(n==null?void 0:n.caseNo)||(n==null?void 0:n.caseNumber)||(n==null?void 0:n.applicationNo)||(n==null?void 0:n.applnNo)||"";return w?`${e("wb.conversion.applnNoLabel","Conversion Case / Application Number")}: ${w}`:""}if(s.includes("/grn-search")){const w=[];return n!=null&&n.grnNo&&w.push(`${e("recentSearch.grnNo","GRN")}: ${n.grnNo}`),(n!=null&&n.appNo||n!=null&&n.applicationNo)&&w.push(`${e("recentSearch.appNo","App No")}: ${n.appNo||n.applicationNo}`),w.join(" | ")}if(s.includes("/app-reprint")){const w=(n==null?void 0:n.appNo)||(n==null?void 0:n.applicationNo)||(n==null?void 0:n.mainNo)||"",ve=n!=null&&n.requestTypeName?`${n.requestTypeName} - `:"",ze=n!=null&&n.khatian&&n.khatian!=="-1"?` | ${e("recentSearch.khatianNo","Khatian No")}: ${n.khatian}`:"";return w?`${ve}${e("recentSearch.appNo","App No")}: ${w}${ze}`:""}if(s.includes("/mutation-case-")){const w=(n==null?void 0:n.caseNumber)||(n==null?void 0:n.caseNo)||"";return w?`${e("recentSearch.caseNo","Case No")}: ${w}`:""}if(s.includes("/signed-copy")&&((n==null?void 0:n.searchBy)==="application"||!(n!=null&&n.mainNo)&&(n!=null&&n.applicationNo||n!=null&&n.appliNo))){const w=(n==null?void 0:n.applicationNo)||(n==null?void 0:n.appliNo)||(n==null?void 0:n.mainNo)||"";return w?`${e("recentSearch.appNo","App No")}: ${w}`:""}if(s.includes("/revenue-no-dues")&&((n==null?void 0:n.searchBy)==="Application"||!(n!=null&&n.mainNo)&&(n!=null&&n.appNo||n!=null&&n.applicationNo))){const w=(n==null?void 0:n.appNo)||(n==null?void 0:n.applicationNo)||"";return w?`${e("recentSearch.appNo","App No")}: ${w}`:""}if((n==null?void 0:n.mainNo)!==void 0&&(n==null?void 0:n.mainNo)!==null&&String(n.mainNo).trim()!==""){const w=!E&&((i=me[n==null?void 0:n.khatianType])!=null&&i.text)?`${(b=me[n==null?void 0:n.khatianType])==null?void 0:b.text} `:"",ve=((u=he[n==null?void 0:n.searchBy])==null?void 0:u.text)||(E?e("recentSearch.plotNo","Plot No"):e("recentSearch.khatianNo","Khatian No")),ze=n!=null&&n.subNo?`/${n.subNo}`:"";return`${w}${ve} - ${n.mainNo}${ze}`}return n!=null&&n.caseNumber||n!=null&&n.caseNo?`${e("recentSearch.caseNo","Case No")}: ${n.caseNumber||n.caseNo}`:n!=null&&n.applicationNo||n!=null&&n.appNo?`${e("recentSearch.appNo","App No")}: ${n.applicationNo||n.appNo}`:""},[s,n,E,me,he,e]),se=()=>{const i=Math.random().toString(36).substring(2,7),b=`${c||"0"}_${N||"0"}_${g||"0"}_`;let u="";s.includes("/land-class")?u="Land_Classification":s.includes("/warish-status")?u=`Warish_${(n==null?void 0:n.caseNo)||(n==null?void 0:n.applicationNo)||"Record"}`:s.includes("/conversion-status")?u=`Conversion_${(n==null?void 0:n.caseNo)||(n==null?void 0:n.applicationNo)||"Record"}`:s.includes("/mutation-case-")?u=`Mutation_${(n==null?void 0:n.caseNumber)||(n==null?void 0:n.caseNo)||"Record"}`:s.includes("/grn-search")?u=`GRN_${(n==null?void 0:n.grnNo)||(n==null?void 0:n.appNo)||"Record"}`:s.includes("/app-reprint")?u=`Reprint_${(n==null?void 0:n.appNo)||"Record"}`:s.includes("/revenue-no-dues")?u=`Revenue_${(n==null?void 0:n.appNo)||(n==null?void 0:n.mainNo)||"Record"}`:s.includes("/signed-copy")?u=`SignedCopy_${(n==null?void 0:n.applicationNo)||(n==null?void 0:n.appliNo)||(n==null?void 0:n.mainNo)||"Record"}`:(u=n!=null&&n.mainNo?String(n.mainNo):"Record",n!=null&&n.subNo&&(u+="_"+n.subNo));let w=`${b}${u}_${i}`;return w=w.replace(/[^a-zA-Z0-9_.-]/g,"_"),`${w}.pdf`},$=async()=>{de();try{await pt("downloads");const i=se(),b=`/storage/emulated/0/Download/${i}`;if(it(y)){const w=st(y);await window.bridgeSend("storage","fileSave",{path:b,data:w}),m("PDF saved at: "+b),Se("pdf_saved",{path:b}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+i,payload:b});return}const u=await tt(ne);if(!u)throw new Error("WebView not ready yet.");ut({id:u,path:b}).then(w=>{m("PDF saved at: "+w.path),Se("pdf_saved",{path:w.path}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+i,payload:w.path})}).catch(w=>{p("Failed to save PDF"),console.error("PDF Save Error:",w)})}catch(i){p("Failed to initialize PDF save"),console.error("PDF init error",i)}},v=async()=>{de();try{await pt("downloads");const b=`/storage/emulated/0/Download/${se()}`;if(it(y)){const w=st(y);await window.bridgeSend("storage","fileSave",{path:b,data:w}),Se("pdf_shared",{path:b}),ft({filePaths:[b],text:"Here is the land record PDF."});return}const u=await tt(ne);if(!u)throw new Error("WebView not ready yet.");ut({id:u,path:b}).then(w=>{Se("pdf_shared",{path:w.path}),ft({filePaths:[w.path],text:"Here is the land record PDF."})}).catch(w=>{p("Failed to share PDF"),console.error("PDF Share Error:",w)})}catch(i){p("Failed to initialize PDF share"),console.error("PDF share init error",i)}},O=async()=>{de();try{const i=await tt(ne);if(!i)throw new Error("WebView not ready yet.");await wo({id:i}),Se("pdf_printed",{url:s})}catch(i){p("Failed to print record"),console.error("Print Error:",i)}};return R.useEffect(()=>(l(i=>i.filter(b=>b.id!=="save_pdf_btn"&&b.id!=="share_pdf_btn"&&b.id!=="print_pdf_btn")),()=>{l(i=>i.filter(b=>b.id!=="save_pdf_btn"&&b.id!=="share_pdf_btn"&&b.id!=="print_pdf_btn"))}),[l]),!x&&!y?o.jsx(yo,{}):o.jsxs(L,{sx:{width:"100%",maxWidth:"100vw",overflowX:"hidden",boxSizing:"border-box"},children:[o.jsxs(L,{sx:{py:1},children:[o.jsx(ho,{heading:!0}),X&&o.jsx(k,{variant:"subtitle2",align:"center",sx:{mt:0},children:X}),!H&&y&&(ce.success||Q)&&o.jsxs(L,{sx:{px:2,py:.8,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1},children:[(ce.success||ce.isError||ce.isPdf)&&o.jsxs(No,{value:z,exclusive:!0,onChange:(i,b)=>{b&&(de(),pe(b))},size:"small",sx:{bgcolor:f?"rgba(255, 255, 255, 0.06)":"rgba(0, 0, 0, 0.04)",borderRadius:2,p:.3},children:[o.jsxs(mt,{value:"app",sx:{borderRadius:2,px:1.5,py:.4,fontWeight:700,fontSize:"0.78rem",textTransform:"none",gap:.6},children:[o.jsx(W,{sx:{fontSize:18},children:"dashboard"}),e("kyp.recordView.appView","App View")]}),o.jsxs(mt,{value:"html",sx:{borderRadius:2,px:1.5,py:.4,fontWeight:700,fontSize:"0.78rem",textTransform:"none",gap:.6},children:[o.jsx(W,{sx:{fontSize:18},children:"html"}),e("kyp.recordView.originalView","Original View")]})]}),Q&&o.jsx(F,{sx:{fontSize:"0.75rem",color:"text.disabled",border:"none","& span.MuiIcon-root":{color:"text.primary"},ml:"auto"},onDelete:()=>{te(!1)},deleteIcon:o.jsx(W,{children:"refresh"}),variant:"outlined",size:"small",color:"primary",label:e("kyp.recordView.cachedRecord",{timeago:Q?qn(new Date(Q),{addSuffix:!0}):""})})]}),o.jsx(St,{})]}),H?o.jsx(D,{alignItems:"center",sx:{py:10},children:o.jsx(Ut,{})}):o.jsxs(o.Fragment,{children:[(ce.success||ce.isError||ce.isPdf)&&o.jsx(L,{sx:{width:"100%",maxWidth:"100%",overflowX:"hidden",boxSizing:"border-box",display:z==="app"?"block":"none",pb:"80px"},children:o.jsx(_n,{parsedData:ce,locationInfo:{selectedDistrict:S,selectedBlock:j,selectedMouza:P},landDetails:n,onCaseAction:fe,onSwitchToHtml:()=>pe("html"),onSavePdf:$,onSharePdf:v,onPrintPdf:O,onRetry:()=>te(!1),onBack:M,darkMode:f})}),o.jsx(L,{sx:{display:z==="html"?"block":"none"},children:o.jsx(mr,{id:ne,isVisible:z==="html",margin:{bottom:90},html:y,pdfDesign:_,title:[(S==null?void 0:S.en)||(S==null?void 0:S.name)||"",(j==null?void 0:j.en)||(j==null?void 0:j.name)||"",(P==null?void 0:P.en)||(P==null?void 0:P.name)||""].filter(Boolean).join(" ➧ "),caption:X,onAction:i=>{if(console.green("Action received from WebView",JSON.stringify(i)),i.action==="DOWNLOAD_PDF"||i.action==="ACTION_SAVE_PDF"){$();return}if(i.action==="SHARE_PDF"||i.action==="ACTION_SHARE"){v();return}if(i.action==="PRINT_PDF"){O();return}if(!c||!N||!g){console.error("Location params missing during onAction",{districtId:c,blockId:N,mouzaId:g});return}if(i.action==="MUTATION_STEP_2"){const b={...n,caseNumber:i.caseNo},u=encodeURIComponent(JSON.stringify(b));console.green("MUTATION_STEP_2 URL",`/wb/mutation-case-status/${c}/${N}/${g}/${u}`),G(`/wb/mutation-case-status/${c}/${N}/${g}/${u}`,{replace:!0})}else if(i.action==="MUTATION_STEP_3"){const b=i.caseNo.replace(/\//g,"_"),u={...n,caseNumber:b},w=encodeURIComponent(JSON.stringify(u));console.green("MUTATION_STEP_3 URL",`/wb/mutation-case-details/${c}/${N}/${g}/${w}`),G(`/wb/mutation-case-details/${c}/${N}/${g}/${w}`,{replace:!0})}}})})]}),!H&&y&&o.jsxs(Io,{ariaLabel:e("wb.record.recordActions","Record Actions"),direction:z==="html"?"left":"up",sx:{position:"fixed",bottom:24,right:20,zIndex:1200,"& .MuiFab-primary":{bgcolor:i=>ye(i.palette.primary.main,.82),backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",color:"#ffffff !important",width:56,height:56,border:"1px solid rgba(255, 255, 255, 0.35)",boxShadow:"0 8px 32px 0 rgba(0,0,0,0.28), inset 0 1px 1px 0 rgba(255, 255, 255, 0.4)",transition:"all 0.3s cubic-bezier(0.4, 0, 0.2, 1)","&:hover":{bgcolor:i=>ye(i.palette.primary.dark||i.palette.primary.main,.92),boxShadow:"0 12px 36px 0 rgba(0,0,0,0.35), inset 0 1px 1px 0 rgba(255, 255, 255, 0.5)",transform:"translateY(-2px)"},"& .MuiIcon-root":{color:"#ffffff !important"},"& .MuiSpeedDialIcon-icon, & .MuiSpeedDialIcon-openIcon":{color:"#ffffff !important"}},"& .MuiSpeedDialAction-fab":{backdropFilter:"blur(10px)",WebkitBackdropFilter:"blur(10px)",bgcolor:i=>i.palette.mode==="dark"?"rgba(22, 27, 34, 0.82)":"rgba(255, 255, 255, 0.85)",border:i=>i.palette.mode==="dark"?"1px solid rgba(255, 255, 255, 0.15)":"1px solid rgba(255, 255, 255, 0.6)",boxShadow:"0 6px 20px rgba(0,0,0,0.18)","&:hover":{bgcolor:i=>i.palette.mode==="dark"?"rgba(30, 41, 59, 0.95)":"rgba(255, 255, 255, 0.95)",transform:"scale(1.08)"}},"& .MuiSpeedDialAction-staticTooltipLabel":{whiteSpace:"nowrap",fontWeight:600,fontSize:"0.82rem",backdropFilter:"blur(10px)",WebkitBackdropFilter:"blur(10px)",bgcolor:i=>i.palette.mode==="dark"?"rgba(22, 27, 34, 0.88)":"rgba(255, 255, 255, 0.9)",color:i=>i.palette.mode==="dark"?"#f1f5f9":"#1e293b",border:i=>i.palette.mode==="dark"?"1px solid rgba(255, 255, 255, 0.1)":"1px solid rgba(255, 255, 255, 0.5)",borderRadius:2,boxShadow:"0 4px 16px rgba(0,0,0,0.15)"}},icon:o.jsx(Pt,{icon:o.jsx(W,{sx:{color:"#ffffff !important"},children:"print"}),openIcon:o.jsx(W,{sx:{color:"#ffffff !important"},children:"close"})}),onClose:()=>oe(!1),onOpen:()=>oe(!0),open:Te,children:[o.jsx(qe,{icon:o.jsx(W,{sx:{color:"#d97706 !important"},children:"download"}),tooltipTitle:e("wb.record.savePdf","Save PDF"),tooltipOpen:z!=="html",tooltipPlacement:z==="html"?"top":"left",onClick:()=>{oe(!1),$()}}),o.jsx(qe,{icon:o.jsx(W,{sx:{color:"#059669 !important"},children:"share"}),tooltipTitle:e("wb.record.sharePdf","Share Record"),tooltipOpen:z!=="html",tooltipPlacement:z==="html"?"top":"left",onClick:()=>{oe(!1),v()}}),o.jsx(qe,{icon:o.jsx(W,{sx:{color:"#7c3aed !important"},children:"palette"}),tooltipTitle:r?"পিডিএফ ডিজাইন":"PDF Design",tooltipOpen:z!=="html",tooltipPlacement:z==="html"?"top":"left",onClick:()=>{oe(!1),I(!0)}}),o.jsx(qe,{icon:o.jsx(W,{sx:{color:"#2563eb !important"},children:"print"}),tooltipTitle:e("wb.record.printPdf","Print Record"),tooltipOpen:z!=="html",tooltipPlacement:z==="html"?"top":"left",onClick:()=>{oe(!1),O()}})]}),o.jsxs(So,{open:U,onClose:()=>I(!1),fullWidth:!0,maxWidth:"sm",PaperProps:{sx:{borderRadius:3,p:1,maxHeight:"85vh"}},children:[o.jsxs(jo,{sx:{pb:1,display:"flex",alignItems:"center",justifyContent:"space-between"},children:[o.jsxs(L,{sx:{display:"flex",alignItems:"center",gap:1},children:[o.jsx(W,{sx:{color:"primary.main"},children:"palette"}),o.jsx(k,{variant:"h6",fontWeight:700,children:r?"পিডিএফ ডিজাইন পছন্দ":"Select PDF Design"})]}),o.jsx(Le,{size:"small",onClick:()=>I(!1),children:o.jsx(W,{children:"close"})})]}),o.jsxs(Po,{dividers:!0,sx:{p:2},children:[o.jsx(k,{variant:"body2",color:"text.secondary",sx:{mb:2},children:r?"আপনার পছন্দের পিডিএফ লেআউটটি বেছে নিন। এটি ডাউনলোড, প্রিন্ট এবং শেয়ার করার সময় প্রযোজ্য হবে:":"Choose your preferred layout design. This style will be applied when saving, printing, or sharing as PDF:"}),o.jsx(D,{spacing:1,children:Gt.map(i=>{const b=_===i.id;return o.jsx(le,{elevation:0,onClick:()=>{de(),ee(i.id),Re.set("pdfDesign",i.id);const u=e(`pdfDesigns.${i.id}.name`);m(r?`ডিজাইন প্রয়োগ করা হয়েছে: ${u}`:`Applied ${u} design`),I(!1)},sx:{px:1.5,py:1.25,borderRadius:2.5,cursor:"pointer",border:b?"2px solid":"1px solid",borderColor:b?i.color:"divider",bgcolor:b?ye(i.color,f?.12:.05):f?"rgba(255,255,255,0.03)":"#ffffff",transition:"all 0.2s ease","&:hover":{borderColor:i.color,transform:"translateY(-1px)",boxShadow:"0 4px 12px rgba(0,0,0,0.06)"}},children:o.jsxs(L,{sx:{display:"flex",alignItems:"center",gap:1.5},children:[o.jsx(L,{sx:{width:36,height:36,borderRadius:2,bgcolor:ye(i.color,.12),color:i.color,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0},children:o.jsx(W,{sx:{fontSize:20},children:i.icon})}),o.jsxs(L,{sx:{flex:1,minWidth:0},children:[o.jsxs(L,{sx:{display:"flex",alignItems:"center",gap:.8,flexWrap:"wrap"},children:[o.jsx(k,{variant:"subtitle2",fontWeight:700,color:"text.primary",sx:{fontSize:"0.88rem"},children:e(`pdfDesigns.${i.id}.name`)}),e(`pdfDesigns.${i.id}.badge`)&&o.jsx(F,{size:"small",label:e(`pdfDesigns.${i.id}.badge`),sx:{height:18,fontSize:"0.65rem",fontWeight:700,bgcolor:ye(i.color,.1),color:i.color,border:`1px solid ${ye(i.color,.2)}`}})]}),o.jsx(k,{variant:"caption",color:"text.secondary",sx:{fontSize:"0.76rem",display:"block",lineHeight:1.3,mt:.25},children:e(`pdfDesigns.${i.id}.desc`)})]}),o.jsx(L,{sx:{ml:1,display:"flex",alignItems:"center",flexShrink:0},children:o.jsx(W,{sx:{color:b?i.color:"text.disabled",fontSize:22},children:b?"radio_button_checked":"radio_button_unchecked"})})]})},i.id)})})]}),o.jsx(To,{sx:{px:2,py:1.5},children:o.jsx(Pe,{onClick:()=>I(!1),sx:{fontWeight:600,textTransform:"none"},children:r?"বন্ধ করুন":"Close"})})]})]})}function mr({id:e,html:t,title:r,caption:a,onAction:p,isVisible:l=!0,margin:m={bottom:90},pdfDesign:f}){const h=f||Re.get("pdfDesign")||jt,A=it(t),x=R.useMemo(()=>t?A?ar({pdfData:t,title:r,caption:a}):cr({html:t,title:r,caption:a,designId:h}):"",[t,r,a,h,A]);return o.jsx(vo,{id:e,isVisible:l,margin:m,html:x,onConsoleMessage:S=>{try{const j=JSON.parse(S.message.message);j.action&&p&&p(j)}catch{}}})}export{Rr as default};
