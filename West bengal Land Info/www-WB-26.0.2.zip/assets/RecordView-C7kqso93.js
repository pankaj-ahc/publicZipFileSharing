import{p as oe,q as fe,az as he,av as me,r as A,ao as pe,ap as ge,aA as ve,v as F,j as p,B as J,ay as be,T as ye,F as we,z as Me,D as Se,S as xe,H as Ne,ae as De,aB as Te,aC as ie,aa as Pe,aD as Ce,aE as _e,t as V,aF as se,aG as Ie,aH as Ae,aI as Oe,aJ as ke,aK as Fe,aL as We,aM as Be}from"./index-BaYlfrIu.js";import{A as Re,g as Y,s as de,p as Ee,W as He}from"./Index-CGw3vQdq.js";import"./MyInputField-4PKBbPug.js";import"./TextField-Cp7tF1xA.js";import"./InputAdornment-DYhl4BZc.js";import"./MyForm-CE7s7i0w.js";import"./Alert-DWkD3kry.js";function Q(e){"@babel/helpers - typeof";return Q=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Q(e)}function N(e,t){if(t.length<e)throw new TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+t.length+" present")}function b(e){N(1,arguments);var t=Object.prototype.toString.call(e);return e instanceof Date||Q(e)==="object"&&t==="[object Date]"?new Date(e.getTime()):typeof e=="number"||t==="[object Number]"?new Date(e):((typeof e=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}var $e={};function je(){return $e}function ce(e){var t=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds()));return t.setUTCFullYear(e.getFullYear()),e.getTime()-t.getTime()}function U(e,t){N(2,arguments);var n=b(e),r=b(t),o=n.getTime()-r.getTime();return o<0?-1:o>0?1:o}function Le(e,t){N(2,arguments);var n=b(e),r=b(t),o=n.getFullYear()-r.getFullYear(),s=n.getMonth()-r.getMonth();return o*12+s}function ze(e,t){return N(2,arguments),b(e).getTime()-b(t).getTime()}var Ve={ceil:Math.ceil,round:Math.round,floor:Math.floor,trunc:function(t){return t<0?Math.ceil(t):Math.floor(t)}},Ue="trunc";function Xe(e){return Ve[Ue]}function Je(e){N(1,arguments);var t=b(e);return t.setHours(23,59,59,999),t}function Ye(e){N(1,arguments);var t=b(e),n=t.getMonth();return t.setFullYear(t.getFullYear(),n+1,0),t.setHours(23,59,59,999),t}function qe(e){N(1,arguments);var t=b(e);return Je(t).getTime()===Ye(t).getTime()}function Ke(e,t){N(2,arguments);var n=b(e),r=b(t),o=U(n,r),s=Math.abs(Le(n,r)),i;if(s<1)i=0;else{n.getMonth()===1&&n.getDate()>27&&n.setDate(30),n.setMonth(n.getMonth()-o*s);var l=U(n,r)===-o;qe(b(e))&&s===1&&U(e,r)===1&&(l=!1),i=o*(s-Number(l))}return i===0?0:i}function Qe(e,t,n){N(2,arguments);var r=ze(e,t)/1e3;return Xe()(r)}var Ge={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},Ze=function(t,n,r){var o,s=Ge[t];return typeof s=="string"?o=s:n===1?o=s.one:o=s.other.replace("{{count}}",n.toString()),r!=null&&r.addSuffix?r.comparison&&r.comparison>0?"in "+o:o+" ago":o};function q(e){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=t.width?String(t.width):e.defaultWidth,r=e.formats[n]||e.formats[e.defaultWidth];return r}}var et={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},tt={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},nt={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},at={date:q({formats:et,defaultWidth:"full"}),time:q({formats:tt,defaultWidth:"full"}),dateTime:q({formats:nt,defaultWidth:"full"})},rt={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},ot=function(t,n,r,o){return rt[t]};function $(e){return function(t,n){var r=n!=null&&n.context?String(n.context):"standalone",o;if(r==="formatting"&&e.formattingValues){var s=e.defaultFormattingWidth||e.defaultWidth,i=n!=null&&n.width?String(n.width):s;o=e.formattingValues[i]||e.formattingValues[s]}else{var l=e.defaultWidth,d=n!=null&&n.width?String(n.width):e.defaultWidth;o=e.values[d]||e.values[l]}var m=e.argumentCallback?e.argumentCallback(t):t;return o[m]}}var it={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},st={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},dt={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},ct={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},lt={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},ut={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},ft=function(t,n){var r=Number(t),o=r%100;if(o>20||o<10)switch(o%10){case 1:return r+"st";case 2:return r+"nd";case 3:return r+"rd"}return r+"th"},ht={ordinalNumber:ft,era:$({values:it,defaultWidth:"wide"}),quarter:$({values:st,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:$({values:dt,defaultWidth:"wide"}),day:$({values:ct,defaultWidth:"wide"}),dayPeriod:$({values:lt,defaultWidth:"wide",formattingValues:ut,defaultFormattingWidth:"wide"})};function j(e){return function(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=n.width,o=r&&e.matchPatterns[r]||e.matchPatterns[e.defaultMatchWidth],s=t.match(o);if(!s)return null;var i=s[0],l=r&&e.parsePatterns[r]||e.parsePatterns[e.defaultParseWidth],d=Array.isArray(l)?pt(l,function(w){return w.test(i)}):mt(l,function(w){return w.test(i)}),m;m=e.valueCallback?e.valueCallback(d):d,m=n.valueCallback?n.valueCallback(m):m;var S=t.slice(i.length);return{value:m,rest:S}}}function mt(e,t){for(var n in e)if(e.hasOwnProperty(n)&&t(e[n]))return n}function pt(e,t){for(var n=0;n<e.length;n++)if(t(e[n]))return n}function gt(e){return function(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=t.match(e.matchPattern);if(!r)return null;var o=r[0],s=t.match(e.parsePattern);if(!s)return null;var i=e.valueCallback?e.valueCallback(s[0]):s[0];i=n.valueCallback?n.valueCallback(i):i;var l=t.slice(o.length);return{value:i,rest:l}}}var vt=/^(\d+)(th|st|nd|rd)?/i,bt=/\d+/i,yt={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},wt={any:[/^b/i,/^(a|c)/i]},Mt={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},St={any:[/1/i,/2/i,/3/i,/4/i]},xt={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},Nt={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},Dt={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},Tt={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},Pt={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},Ct={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},_t={ordinalNumber:gt({matchPattern:vt,parsePattern:bt,valueCallback:function(t){return parseInt(t,10)}}),era:j({matchPatterns:yt,defaultMatchWidth:"wide",parsePatterns:wt,defaultParseWidth:"any"}),quarter:j({matchPatterns:Mt,defaultMatchWidth:"wide",parsePatterns:St,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:j({matchPatterns:xt,defaultMatchWidth:"wide",parsePatterns:Nt,defaultParseWidth:"any"}),day:j({matchPatterns:Dt,defaultMatchWidth:"wide",parsePatterns:Tt,defaultParseWidth:"any"}),dayPeriod:j({matchPatterns:Pt,defaultMatchWidth:"any",parsePatterns:Ct,defaultParseWidth:"any"})},It={code:"en-US",formatDistance:Ze,formatLong:at,formatRelative:ot,localize:ht,match:_t,options:{weekStartsOn:0,firstWeekContainsDate:1}};function ue(e,t){if(e==null)throw new TypeError("assign requires that input parameter not be null or undefined");for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n]);return e}function At(e){return ue({},e)}var le=1440,Ot=2520,K=43200,kt=86400;function Ft(e,t,n){var r,o;N(2,arguments);var s=je(),i=(r=(o=n==null?void 0:n.locale)!==null&&o!==void 0?o:s.locale)!==null&&r!==void 0?r:It;if(!i.formatDistance)throw new RangeError("locale must contain formatDistance property");var l=U(e,t);if(isNaN(l))throw new RangeError("Invalid time value");var d=ue(At(n),{addSuffix:!!(n!=null&&n.addSuffix),comparison:l}),m,S;l>0?(m=b(t),S=b(e)):(m=b(e),S=b(t));var w=Qe(S,m),W=(ce(S)-ce(m))/1e3,g=Math.round((w-W)/60),x;if(g<2)return n!=null&&n.includeSeconds?w<5?i.formatDistance("lessThanXSeconds",5,d):w<10?i.formatDistance("lessThanXSeconds",10,d):w<20?i.formatDistance("lessThanXSeconds",20,d):w<40?i.formatDistance("halfAMinute",0,d):w<60?i.formatDistance("lessThanXMinutes",1,d):i.formatDistance("xMinutes",1,d):g===0?i.formatDistance("lessThanXMinutes",1,d):i.formatDistance("xMinutes",g,d);if(g<45)return i.formatDistance("xMinutes",g,d);if(g<90)return i.formatDistance("aboutXHours",1,d);if(g<le){var O=Math.round(g/60);return i.formatDistance("aboutXHours",O,d)}else{if(g<Ot)return i.formatDistance("xDays",1,d);if(g<K){var B=Math.round(g/le);return i.formatDistance("xDays",B,d)}else if(g<kt)return x=Math.round(g/K),i.formatDistance("aboutXMonths",x,d)}if(x=Ke(S,m),x<12){var R=Math.round(g/K);return i.formatDistance("xMonths",R,d)}else{var k=x%12,E=Math.floor(x/12);return k<3?i.formatDistance("aboutXYears",E,d):k<9?i.formatDistance("overXYears",E,d):i.formatDistance("almostXYears",E+1,d)}}function Wt(e,t){return N(1,arguments),Ft(e,Date.now(),t)}function Bt(e){return new Promise(t=>{setTimeout(()=>{t({html:`
            <div style="position:relative; width:100%; min-height:100vh;">

  <!-- Full page watermark -->
  <div style="
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background-repeat:repeat;
    background-image: repeating-linear-gradient(
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 100px
    ),
    repeating-linear-gradient(
      90deg,
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 300px
    );
    z-index:9999;
  ">
    <div style="
      position:absolute;      
      top:50%;
      left:50%;
      transform:translate(-50%,-50%) rotate(-60deg);
      font-size:72px;
      color:rgba(150,150,150,0.2);
      font-weight:bold;
      white-space:nowrap;
      font-family:Arial, sans-serif;
      pointer-events:none;
    ">
      DEMO DATA - NOT REAL
    </div>
  </div>

  <!-- Disclaimer Banner -->
  <div style="
    position:sticky;
    top:0;
    background-color:rgba(255,255,0,0.9);
    color:#000;
    padding:10px;
    font-size:16px;
    text-align:center;
    font-weight:bold;
    border-bottom:2px solid #000;
    z-index:1000;
  ">
    This page displays DEMO DATA for review purposes only. No real information is shown.
  </div>

  <!-- Your existing dummy HTML -->
  <div style="position:relative; z-index:1; padding:20px; background-color:white;">

    <table width="100%" border="1" style="border-collapse: collapse;">
      <tr>
        <td width="55%">
          <div style="border: thin; position: relative; width: 100%;">
            <b style="color:#0000FF;">
              <font face="Verdana">(Demo Data Generated on 08/08/2025, 12:00:00)</font>
            </b><br/>
            <b style="color:#660033;">&nbsp;<label><font face='BN BIDISHA Opentype'>J.L No </font>:</label>&nbsp;</b>999
            <b style="color:#660033;">&nbsp;&nbsp; <font face='BN BIDISHA Opentype'>Thana </font>:&nbsp;</b>
            <font face='BN BIDISHA Opentype'>Demo Thana</font>&nbsp;<br/>
          </div>

          <div class="table-responsive" style="border: thin; position: relative; left: 3px; width: 97%;">
            <table class="table" width="95%" border="1" style="border-collapse: collapse;">
              <tr>
                <th width="43%"><div align="left"><font face='BN BIDISHA Opentype'>Khatian No</font>&nbsp;&nbsp;:&nbsp;</div></th>
                <th width="57%" bgcolor="#CCCCCC"><div align="left"><font face='BN BIDISHA Opentype'>00</font></div></th>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Nam</font>&nbsp;&nbsp;:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Name</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Pita/Swami</font>&nbsp;&nbsp;:</td>
                <td bgcolor="#CCCCCC"><font face='BN BIDISHA Opentype'>Demo Parent</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Dharan</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Type</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Thikana</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Address</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Zamir Pariman</font>:</td>
                <td bgcolor="#CCCCCC">0.00 Ekar</td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Dager Sankhyan</font>:</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <p><strong><font style="color: #0048FF;font-size:18px" face='BN BIDISHA Opentype'>Atrasbatber Dager Bibaran O Pariman:</font></strong></p>
          <p><font style="color: #8000ff;font-size:12px" face='BN BIDISHA Opentype'>(This is demo data only. No real land records are shown.)</font></p>

          <div class="table-responsive" style="border: thin none; position: relative; left: 5px; width: 97%; overflow: auto; top: -10px; margin-top:1em; margin-right: 5px;">
            <table class="table table-fixed" width="95%" align="center" style="border-collapse: collapse">
              <thead>
                <tr>
                  <th><center>Dag No</center></th>
                  <th><center>Shreni</center></th>
                  <th><center>Ansh</center></th>
                  <th><center>Ansh Pariman (ekar)</center></th>
                  <th><center>Dakhaldar</center></th>
                  <th><center>Mantaby</center></th>
                </tr>
              </thead>
              <tbody>
                <tr bgcolor="#CCCCCC">
                  <td align="center">0001</td>
                  <td align="center">Demo Class</td>
                  <td align="center">1.0000</td>
                  <td align="center">0.00</td>
                  <td align="center">Demo Holder</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
                <tr>
                  <td align="center">0002</td>
                  <td align="center">Demo Class</td>
                  <td align="center">0.5000</td>
                  <td align="center">0.00</td>
                  <td align="center">Nil</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>

        <td width="45%" valign="top">
          <div class="table-responsive" style="border: thin; width: 95%; height: 300px; overflow: auto;">
            <center style="color:gray; padding-top:120px;">Demo Map / Additional Info</center>
          </div>
        </td>
      </tr>
    </table>

  </div>
</div>
          `})},1e3)})}function Ut(){var te,ne,ae,re;const{t:e}=oe(),{t}=oe("inputField"),{errorAlert:n,setHeaderButtons:r,successAlert:o}=fe(),{user:s,logoutUser:i,isLoggedIn:l}=he(),{selectedDistrict:d,selectedBlock:m,selectedMouza:S,searchLandDetails:w}=me(),[W,g]=A.useState(!1),[x,O]=A.useState(""),[B,R]=A.useState(!0),k=pe(),E=ge(),{districtId:T,blockId:P,mouzaId:C,recordData:L}=ve(),v=E.pathname,X=A.useRef(""),a=A.useMemo(()=>{if(L)try{return JSON.parse(L)}catch(y){console.error("Failed to parse recordData from params",y)}return w},[L,w]),G=(y=!0)=>{y||(X.current=""),De(),R(!0);let M=Te;v.includes("/rs-lr/")?M=Ae:v.includes("/khajna-status/")?M=Oe:v.includes("/mutation-case-status/")?M=ke:v.includes("/mutation-case-details/")?M=Fe:v.includes("/mutation-status/")&&(M=We),l&&M(a,T,P,C,y).then(async f=>{if(f&&f.html){let c=localStorage.getItem(ie)??0;f.cached&&c++,localStorage.setItem(ie,c);const u=await Pe(Be)??10;c>u&&Ce(),console.log("html Received=>",c,f.html);const I=new DOMParser().parseFromString(f.html,"text/html");I.querySelectorAll("a").forEach(h=>{const z=h.innerText.trim().toLowerCase();!z.includes("view ror")&&!z.includes("certified copy")&&h.removeAttribute("href")});const D=/(MN\/\d{4}\/\d+\/\d+)/g;v.includes("/mutation-status/")?I.querySelectorAll("td").forEach(h=>{h.innerText.trim().match(D)&&(h.innerHTML=h.innerHTML.replace(D,`<a href="javascript:void(0)" onclick="onCaseClick('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}):v.includes("/mutation-case-status/")&&I.querySelectorAll("td").forEach(h=>{h.innerText.trim().match(D)&&(h.innerHTML=h.innerHTML.replace(D,`<a href="javascript:void(0)" onclick="showMutationCaseDetails('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}),f.html=I.body.innerHTML,O(f.html),g(f.cached),_e("high-low",3),F("success_record_fetch",{totalCount:c,cached:f.cached?"true":"false",useCache:y?"true":"false"})}else i(),V(),O(""),n("auth.sessionTimeout")}).catch(f=>{O(""),console.red("Error in record fetching",f.message),F("record_fetch_error",{message:f.message}),n("kyp.recordView.errorLandRecordFetch",{error:f.message}),k(-1)}).finally(f=>R(!1))};A.useEffect(()=>{if(l&&X.current!==v){if(X.current=v,s=="demo"){Bt().then(y=>{O(y.html),R(!1),F("demo_record_fetched")});return}G()}},[l,v,L,s]);const Z=t("wb.landDetails.khatianType.option"),ee=t("wb.landDetails.searchBy.option"),H=`wb-record-${v.split("/")[2]}`;return A.useEffect(()=>{if(!x||B)return;const y={id:"save_pdf_btn",icon:"download",tooltip:"Save PDF",onClick:async()=>{V();try{await se("downloads");const c=Math.random().toString(36).substring(2,7);let u=`${T}_${P}_${C}_`;v.includes("/mutation-case-")?u+=(a==null?void 0:a.caseNumber)||"Record":(u+=(a==null?void 0:a.mainNo)||"Record",a!=null&&a.subNo&&(u+="_"+a.subNo)),u+=`_${c}`,u=u.replace(/[^a-zA-Z0-9_.-]/g,"_");const _=`${u}.pdf`,I=`/storage/emulated/0/Download/${_}`,D=await Y(H);if(!D)throw new Error("WebView not ready yet.");de({id:D,path:I}).then(h=>{o("PDF saved at: "+h.path),F("pdf_saved",{path:h.path}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+_,payload:h.path})}).catch(h=>{n("Failed to save PDF"),console.error("PDF Save Error:",h)})}catch(c){n("Failed to initialize PDF save"),console.error("PDF init error",c)}}},M={id:"share_pdf_btn",icon:"share",tooltip:"Share Record",onClick:async()=>{V();try{await se("downloads");const c=Math.random().toString(36).substring(2,7);let u=`${T}_${P}_${C}_`;v.includes("/mutation-case-")?u+=(a==null?void 0:a.caseNumber)||"Record":(u+=(a==null?void 0:a.mainNo)||"Record",a!=null&&a.subNo&&(u+="_"+a.subNo)),u+=`_${c}`,u=u.replace(/[^a-zA-Z0-9_.-]/g,"_");const I=`/storage/emulated/0/Download/${`${u}.pdf`}`,D=await Y(H);if(!D)throw new Error("WebView not ready yet.");de({id:D,path:I}).then(h=>{F("pdf_shared",{path:h.path}),Ie({filePaths:[h.path],text:"Here is the land record PDF."})}).catch(h=>{n("Failed to share PDF"),console.error("PDF Share Error:",h)})}catch(c){n("Failed to initialize PDF share"),console.error("PDF share init error",c)}}},f={id:"print_pdf_btn",icon:"print",tooltip:"Print Record",onClick:async()=>{V();try{const c=await Y(H);if(!c)throw new Error("WebView not ready yet.");await Ee({id:c}),F("pdf_printed",{url:v})}catch(c){n("Failed to print record"),console.error("Print Error:",c)}}};return r(c=>[...c.filter(_=>_.id!=="save_pdf_btn"&&_.id!=="share_pdf_btn"&&_.id!=="print_pdf_btn"),f,M,y]),()=>{r(c=>c.filter(u=>u.id!=="save_pdf_btn"&&u.id!=="share_pdf_btn"&&u.id!=="print_pdf_btn"))}},[x,B,H,a,v,r,o,n]),!l&&!x?p.jsx(Re,{}):p.jsxs(J,{children:[p.jsxs(J,{sx:{py:1},children:[p.jsx(be,{heading:!0}),p.jsx(ye,{variant:"subtitle2",align:"center",sx:{mt:0},children:v.includes("/mutation-case-")?p.jsxs(p.Fragment,{children:["Case No: ",a==null?void 0:a.caseNumber]}):p.jsxs(p.Fragment,{children:[((te=Z[a==null?void 0:a.khatianType])==null?void 0:te.text)??""," ",((ne=ee[a==null?void 0:a.searchBy])==null?void 0:ne.text)??""," -"," ",(a==null?void 0:a.mainNo)??"",a!=null&&a.subNo?"/"+(a==null?void 0:a.subNo):""]})}),W&&p.jsx(J,{display:"flex",justifyContent:"flex-end",sx:{mr:2},children:p.jsx(we,{sx:{fontSize:1,color:"text.disabled",border:"none","& span.MuiIcon-root":{color:"text.primary"}},onDelete:()=>{G(!1)},deleteIcon:p.jsx(Me,{children:"refresh"}),variant:"outlined",size:"small",color:"primary",label:e("kyp.recordView.cachedRecord",{timeago:W?Wt(new Date(W),{addSuffix:!0}):""})})}),p.jsx(Se,{})]}),B?p.jsx(xe,{alignItems:"center",sx:{py:10},children:p.jsx(Ne,{})}):p.jsx(Rt,{id:H,html:x,title:(d==null?void 0:d.en)+" ➧ "+(m==null?void 0:m.en)+" ➧"+(S==null?void 0:S.en),caption:[((ae=Z[a==null?void 0:a.khatianType])==null?void 0:ae.text)??"",((re=ee[a==null?void 0:a.searchBy])==null?void 0:re.text)??"","-",(a==null?void 0:a.mainNo)??"",a!=null&&a.subNo?"/"+(a==null?void 0:a.subNo):""].filter(Boolean).join(" "),onAction:y=>{if(console.green("Action received from WebView",JSON.stringify(y)),!T||!P||!C){console.error("Location params missing during onAction",{districtId:T,blockId:P,mouzaId:C});return}if(y.action==="MUTATION_STEP_2"){const M={...a,caseNumber:y.caseNo},f=encodeURIComponent(JSON.stringify(M));console.green("MUTATION_STEP_2 URL",`/wb/mutation-case-status/${T}/${P}/${C}/${f}`),k(`/wb/mutation-case-status/${T}/${P}/${C}/${f}`)}else if(y.action==="MUTATION_STEP_3"){const M=y.caseNo.replace(/\//g,"_"),f={...a,caseNumber:M},c=encodeURIComponent(JSON.stringify(f));console.green("MUTATION_STEP_3 URL",`/wb/mutation-case-details/${T}/${P}/${C}/${c}`),k(`/wb/mutation-case-details/${T}/${P}/${C}/${c}`)}}})]})}function Rt({id:e,html:t,title:n,caption:r,onAction:o}){const s=`
  <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      @media screen {
        .only-print { display: none !important; }
      }
      @media print {
        .only-print { display: block !important; }
        .no-print { display: none !important; }
      }
      #print-btn {
        z-index: 10000;
        padding: 8px 18px;
        margin: 16px;
        font-size: 1.1rem;
        background: #1976d2;
        color: #fff;
        border: none;
        border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        cursor: pointer;
        transition: background 0.2s;
      }
      #print-btn:hover {
        background: #115293;
      }
      .book > .row {display:none!important}
      
      html, body { width: 100%; margin: 0; padding: 0; }
      .content-wrapper { padding: 16px; }
      
    </style>
    </head>
    <body>
    <div class="content-wrapper">
      <div style="padding: 10px;" class="only-print">
        <h3>${n}</h3>
        <h4>${r}</h4>
      </div>
      ${t}
    </div>    
    <script>
      function onCaseClick(caseNo) {
        console.log("onCaseClick triggered: " + caseNo);
        console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
      }
      function showMutationCaseDetails(caseNo, idn) {
        console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
        console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
      }
    <\/script>
    </body>
  </html>
  `;return p.jsx(He,{id:e,html:s,onConsoleMessage:i=>{try{const l=JSON.parse(i.message.message);l.action&&o&&o(l)}catch{}}})}export{Ut as default};
