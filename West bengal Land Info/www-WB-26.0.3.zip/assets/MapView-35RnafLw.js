import{aA as ee,ao as te,av as oe,p as ae,az as ie,q as re,r as l,aS as ne,aT as se,v,j as f,B as z,ay as le,D as pe,H as de,T as ce,aU as ue,t as O,aF as M,aG as fe}from"./index-DsHlmcNT.js";import"./MyInputField-BYe-qReE.js";import{e as g,A as me,W as he,g as H,s as W}from"./Index-ClN70Lk1.js";import"./TextField-CkXXL_go.js";import"./InputAdornment-kZ9pt0VE.js";import"./MyForm-CCjA22O6.js";import"./Alert-C6AMirRx.js";const R=s=>{try{let o=s.replace("MULTIPOLYGON","").trim().replace(/\(/g,"[").replace(/\)/g,"]");o=o.replace(/([-\d.]+)\s+([-\d.]+)/g,"[$1, $2]");let d=JSON.parse(o);const m=c=>c.length===2&&typeof c[0]=="number"?[c[1],c[0]]:c.map(m);return m(d)}catch(a){return console.error("Parse error",a),[]}},ge=(s,a,o,d,m,c,b)=>`
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <style>
            body { padding: 0; margin: 0; background-color: ${o.bg}; overflow: hidden; }
            #map { height: 100vh; width: 100vw; background-color: transparent !important; }
            .transparent-tooltip {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
                font-weight: 700;
                color: ${a?"#eeeeee":"#212121"};
                text-shadow: 1px 1px 0px ${a?"#000000":"rgba(255,255,255,0.8)"}, -1px -1px 0px ${a?"#000000":"rgba(255,255,255,0.8)"}, 1px -1px 0px ${a?"#000000":"rgba(255,255,255,0.8)"}, -1px 1px 0px ${a?"#000000":"rgba(255,255,255,0.8)"};
                font-size: 14px;
            }
            .print-mode-tooltip {
                font-size: 6px !important;
                font-weight: normal !important;
                text-shadow: none !important;
            }
            .selected-print-tooltip {
                font-size: 14px !important;
                font-weight: 900 !important;
                color: #ff0000 !important;
                text-shadow: 1px 1px 0px #fff, -1px -1px 0px #fff, 1px -1px 0px #fff, -1px 1px 0px #fff !important;
            }
            .leaflet-control-attribution { display: none !important; }
            @media print {
                .no-print { display: none !important; }
                .leaflet-control-zoom { display: none !important; }
            }
            #details-card {
                display: none;
                position: absolute;
                bottom: 10px;
                left: 20px;
                right: 40px;
                max-width: 500px;
                margin: 0 auto;
                z-index: 9999;
                background-color: ${a?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                box-shadow: ${o.cardBoxShadow};
                border: ${o.cardBorder};
                border-radius: 5px;
                padding: 12px;
                align-items: center;
                justify-content: space-evenly;
                font-family: sans-serif;
            }
            #details-card.visible {
                display: flex;
            }
            .card-text {
                color: ${a?"#fff":"#000"};
                font-size: 14px;
                margin: 0 8px;
            }
            .card-text-primary {
                color: ${o.base};
                font-weight: bold;
            }
            #view-btn {
                background-color: ${o.base};
                color: #fff;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }
            #action-bar {
                position: absolute;
                top: 60px;
                right: 10px;
                z-index: 9999;
                display: flex;
                gap: 8px;
            }
            #top-bar {
                position: absolute;
                top: 10px;
                left: 10px;
                right: 10px;
                z-index: 9999;
                display: flex;
                gap: 8px;
            }
            .pill-input {
                background: ${a?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                color: ${o.base};
                border: 1px solid ${o.base};
                padding: 8px 12px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
                box-shadow: ${o.cardBoxShadow};
                outline: none;
                flex: 1;
                max-width: 50%;
            }
            .pill-input::placeholder {
                color: ${o.base03};
            }
            .pill-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                background: ${a?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                color: ${o.base};
                border: 1px solid ${o.base};
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: ${o.cardBoxShadow};
                transition: background 0.2s;
            }
            .pill-btn:active {
                background-color: ${o.base03};
            }
            .pill-btn .material-icons {
                font-size: 16px;
                margin-right: 4px;
            }
        </style>
    </head>
    <body>
        <div id="print-header" style="display:none; position:absolute; top:20px; left:20px; z-index:9999; background:rgba(255,255,255,0.9); padding:10px 15px; border-radius:8px; border:2px solid #333; font-family:sans-serif; font-size:16px; font-weight:bold; color:#000; max-width:80%;">
            ${m}
        </div>
        <div id="top-bar" class="no-print">
            <select id="sheet-select" class="pill-input" onchange="console.log(JSON.stringify({action: 'SHEET_CHANGE', sheetNo: this.value}))">
                ${Object.entries(c).map(([r,x])=>`<option value="${r}" ${r==b?"selected":""}>${typeof x=="object"?x.text:x}</option>`).join("")}
            </select>
            <input type="text" id="plot-search" class="pill-input" placeholder="${d.searchPlotNo}" oninput="window.searchPlot && window.searchPlot(this.value)">
        </div>
        <div id="map"></div>
        <div id="action-bar" class="no-print">
            <label class="pill-btn">
                <input type="checkbox" id="print-labels-chk" checked style="margin-right:6px; cursor:pointer;">${d.labels}
            </label>            
            <button class="pill-btn" onclick="console.log(JSON.stringify({action: 'ACTION_SHARE'}))"><span class="material-icons">share</span>${d.share}</button>
            <button class="pill-btn" onclick="console.log(JSON.stringify({action: 'ACTION_SAVE_PDF'}))"><span class="material-icons">download</span>${d.pdf}</button>
        </div>
        <div id="details-card" class="no-print">
            <div class="card-text card-text-primary">${d.plot}: <span id="plot-val"></span></div>
            <div class="card-text" style="display: none;"><b>${d.area}:</b> <span id="area-val"></span></div>
            <button id="view-btn">${d.viewDetails}</button>
        </div>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"><\/script>
        <script>
            var map = L.map('map', { 
                crs: L.CRS.Simple, 
                zoomControl: false,
                minZoom: -5,
                maxZoom: 5 
            }).setView([0, 0], 1);
            L.control.zoom({ position: 'bottomright' }).addTo(map);
    
            var features = ${JSON.stringify(s)};
            var scheme = ${JSON.stringify(o)};
            var bounds = L.latLngBounds();
            var polygons = [];
            var selectedPlotNo = "";
    
            features.forEach(function(f) {
                var color = scheme.iconCircleColor;
                var fillColor = scheme.iconCircleBg;
                var fillOpacity = 0.6;
                var weight = 1;
    
                var polygon = L.polygon(f.positions, {
                    color: color,
                    fillColor: fillColor,
                    fillOpacity: fillOpacity,
                    weight: weight
                }).addTo(map);
                
                polygon.featureData = f;
                polygons.push(polygon);
                bounds.extend(polygon.getBounds());
    
                polygon.on('click', function() {
                    console.log(JSON.stringify({ action: 'PLOT_SELECTED', plotno: f.plotno }));
                });
            });
    
            window.isPrinting = false;
            window.printWithLabels = true;
            window.searchQuery = "";
            function updateLabels() {
                var zoom = map.getZoom();
                polygons.forEach(function(p) {
                    var f = p.featureData;
                    var pixelArea = f.plotArea * Math.pow(4, zoom);
                    var isSelected = f.plotno === selectedPlotNo;
                    var isSearched = window.searchQuery && f.plotno && f.plotno.includes(window.searchQuery);
                    var isHighlight = isSelected || isSearched;
                    
                    var showLabel = false;
                    if (window.isPrinting) {
                        showLabel = window.printWithLabels || isHighlight;
                    } else {
                        showLabel = isHighlight || (zoom >= -1 && pixelArea > 3500);
                    }
  
                    var color = isHighlight ? (window.isPrinting ? '#ff0000' : scheme.base) : scheme.iconCircleColor;
                    var fillColor = isHighlight ? (window.isPrinting ? '#ffcccc' : scheme.base03) : scheme.iconCircleBg;
                    var fillOpacity = isHighlight ? 0.9 : 0.6;
                    var weight = isHighlight ? (window.isPrinting ? 5 : 3) : 1;
                    
                    p.setStyle({
                        color: color,
                        fillColor: fillColor,
                        fillOpacity: fillOpacity,
                        weight: weight
                    });
    
                    if (showLabel) {
                        var tooltipClass = "transparent-tooltip";
                        if (window.isPrinting) {
                            tooltipClass += isHighlight ? " selected-print-tooltip" : " print-mode-tooltip";
                        }
                        
                        if (!p.getTooltip()) {
                            p.bindTooltip(f.plotno, { permanent: true, direction: "center", className: tooltipClass }).openTooltip();
                        } else {
                            var tooltip = p.getTooltip();
                            if (tooltip.options.className !== tooltipClass) {
                                p.unbindTooltip();
                                p.bindTooltip(f.plotno, { permanent: true, direction: "center", className: tooltipClass }).openTooltip();
                            }
                        }
                        
                        var tooltipObj = p.getTooltip();
                        if (tooltipObj && tooltipObj._container) {
                            if (isHighlight && window.isPrinting) {
                                tooltipObj._container.style.zIndex = 1000;
                                tooltipObj._container.style.fontSize = '14px';
                            } else {
                                var dynSize = Math.max(6, Math.min(24, Math.sqrt(pixelArea) / 4.5));
                                if (window.isPrinting) {
                                    dynSize = Math.max(4, Math.min(10, Math.sqrt(pixelArea) / 7));
                                }
                                tooltipObj._container.style.fontSize = dynSize + 'px';
                            }
                        }
                    } else {
                        if (p.getTooltip()) {
                            p.unbindTooltip();
                        }
                    }
                });
            }
    
            if (features.length > 0) {
                map.fitBounds(bounds, { padding: [10, 10] });
            }
    
            map.on('zoomend', updateLabels);
            map.on('moveend', updateLabels);
            updateLabels();
  
            window.searchPlot = function(query) {
                window.searchQuery = query || "";
                var foundBounds = L.latLngBounds();
                var foundCount = 0;
                
                polygons.forEach(function(p) {
                    var f = p.featureData;
                    if (window.searchQuery && f.plotno && f.plotno.includes(window.searchQuery)) {
                        foundBounds.extend(p.getBounds());
                        foundCount++;
                    }
                });
                
                updateLabels();
                
                if (foundCount > 0 && window.searchQuery) {
                    map.fitBounds(foundBounds, { padding: [50, 50], maxZoom: 2, animate: true });
                }
            };

            window.updateSelection = function(plotno, area) {
                selectedPlotNo = plotno;
                updateLabels();
                var card = document.getElementById('details-card');
                if (plotno) {
                    document.getElementById('plot-val').innerText = plotno;
                    document.getElementById('area-val').innerText = area || '';
                    card.classList.add('visible');
                } else {
                    card.classList.remove('visible');
                }
            };

            window.prepareForPrint = function() {
                if (features.length === 0) return;
                window.isPrinting = true;
                
                var zoomCtrl = document.querySelector('.leaflet-control-zoom');
                if (zoomCtrl) zoomCtrl.style.display = 'none';
                
                document.getElementById('print-header').style.display = 'block';
                var chk = document.getElementById('print-labels-chk');
                window.printWithLabels = chk ? chk.checked : true;
                var nw = map.project(bounds.getNorthWest(), 1);
                var se = map.project(bounds.getSouthEast(), 1);
                var w = Math.max(window.innerWidth, Math.abs(se.x - nw.x) + 200);
                var h = Math.max(window.innerHeight, Math.abs(se.y - nw.y) + 200);
                
                var mapEl = document.getElementById('map');
                mapEl.dataset.origW = mapEl.style.width;
                mapEl.dataset.origH = mapEl.style.height;
                
                mapEl.style.width = w + 'px';
                mapEl.style.height = h + 'px';
                document.body.style.overflow = 'auto';
                
                map.invalidateSize(false);
                map.fitBounds(bounds, { animate: false });
            };

            window.restoreAfterPrint = function() {
                window.isPrinting = false;
                
                var zoomCtrl = document.querySelector('.leaflet-control-zoom');
                if (zoomCtrl) zoomCtrl.style.display = '';
                
                document.getElementById('print-header').style.display = 'none';
                var mapEl = document.getElementById('map');
                mapEl.style.width = mapEl.dataset.origW || '100vw';
                mapEl.style.height = mapEl.dataset.origH || '100vh';
                document.body.style.overflow = 'hidden';
                
                map.invalidateSize(false);
                if (features.length > 0) {
                    map.fitBounds(bounds, { padding: [10, 10], animate: false });
                }
                updateLabels();
            };

            document.getElementById('view-btn').addEventListener('click', function() {
                if (selectedPlotNo) {
                    console.log(JSON.stringify({ action: 'VIEW_RECORD', plotno: selectedPlotNo }));
                }
            });
        <\/script>
    </body>
    </html>
    `,Ce=()=>{const{districtId:s,blockId:a,mouzaId:o}=ee(),d=te(),{selectedDistrict:m,selectedBlock:c,selectedMouza:b}=oe(),{t:r,i18n:x}=ae(),{user:_,logoutUser:J,isLoggedIn:N}=ie(),{darkMode:S,scheme:P,errorAlert:h,successAlert:Q,setPageTitle:D,setHeaderButtons:we}=re(),[k,be]=l.useState(""),[u,q]=l.useState(null),[xe,ye]=l.useState(1),[ve,Se]=l.useState(!1),[w,L]=l.useState(1),[A,B]=l.useState(null),[F,I]=l.useState(null),[Z,$]=l.useState(!0),[G,C]=l.useState("loadingSheets"),T=l.useCallback(async i=>{if(C("loadingData"),$(!0),_==="demo"){try{const e=await ne(()=>import("./MapData-BcNplkIj.js"),[],import.meta.url);I(e.mapData)}catch(e){console.error("Error loading dummy map data:",e)}finally{$(!1)}return}try{const e=await se(s,a,o,"LR",i).catch(t=>(console.error("Error fetching map data:",t),v("mouza_map_data_error",{message:t.message}),!1));if(e===!1){h("Failed to load map data. Please try again.");return}v("mouza_map_data_success",{sheetNo:i,districtId:s,blockId:a,mouzaId:o}),I(e)}catch(e){console.error("Error fetching map data:",e),v("mouza_map_data_error",{message:e.message}),h("Failed to load map data. Please try again.")}finally{$(!1)}},[s,a,o,h,_]);l.useEffect(()=>{D(r("wb.mapView.pageTitle"))},[r,D]),l.useEffect(()=>{if(!s||!a||!o)return;(async()=>{var e;if(N){if(_==="demo"){C("loadingSheets");const t={1:{text:`${r("wb.mapView.sheet")}- 1`}};B(t),L(1),await T(1);return}C("loadingSheets");try{const t=await ue(s,a,o,"LR");if(t===!1){J(),O(),h("auth.sessionTimeout");return}if(t&&t.result==="OK"&&Array.isArray(t.sheetNoList)&&t.sheetNoList.length>0){const p=t.sheetNoList.reduce((y,V)=>(y[V]={text:`${r("wb.mapView.sheet")}- ${V}`},y),{});console.blue("Map Sheet Options",p),B(p);let n=w;t.sheetNoList.includes(w.toString())||(n=t.sheetNoList[0],L(n)),v("mouza_map_sheets_success",{sheets_count:((e=t.sheetNoList)==null?void 0:e.length)??0,districtId:s,blockId:a,mouzaId:o}),await T(n)}else h(r("wb.mapView.noSheetsFound")),d(-1)}catch(t){console.error("Error fetching sheets:",t),v("mouza_map_sheets_error",{message:t.message})}finally{$(!1)}}})()},[s,a,o,N]);const E=l.useMemo(()=>{const i=F;if(!i)return[];if(typeof i=="string")try{return JSON.parse(i).features.map(t=>({...t,positions:R(t.polygon)}))}catch(e){return console.error("Map data parse error",e),[]}else if(i&&i.features)return i.features.map(e=>({...e,positions:R(e.polygon)}));return[]},[F]),U=async i=>{const e=Number(i);L(e),await T(e)},K=i=>{const e=i||u;if(!e)return;let t=e.plotno,p="";if(t&&t.includes("/")){const y=t.split("/");t=y[0],p=y[1]}d(`/wb/mouza-map/${s}/${a}/${o}/${encodeURIComponent(JSON.stringify({khatianType:"Normal",searchBy:"Plot",mainNo:t,subNo:p,caseNumber:""}))}`)},j=l.useMemo(()=>{if(E.length===0)return"";const i={plot:r("wb.mapView.plot"),area:r("wb.mapView.area"),viewDetails:r("wb.mapView.viewDetails"),labels:r("wb.mapView.labels",{defaultValue:"Labels"}),share:r("wb.mapView.share",{defaultValue:"Share"}),pdf:r("wb.mapView.pdf",{defaultValue:"PDF"}),searchPlotNo:r("wb.mapView.searchPlotNo",{defaultValue:"Search Plot No."})},e=x.language||"en",t=`${(m==null?void 0:m[e])||s} &rarr; ${(c==null?void 0:c[e])||a} &rarr; ${(b==null?void 0:b[e])||o} &rarr; Sheet - ${w}`;return ge(E,S,P,i,t,A||{},w.toString())},[E,S,P,r,m,c,b,x.language,w,s,a,o,A]);if(l.useEffect(()=>{g("mouza_map",`window.searchPlot && window.searchPlot("${k||""}")`)},[k]),l.useEffect(()=>{g("mouza_map",`window.updateSelection && window.updateSelection("${(u==null?void 0:u.plotno)||""}", "${(u==null?void 0:u.plotArea)||""}")`)},[u]),!N)return f.jsx(me,{});const Y=async()=>{O();try{await M("downloads");const e=`${`Map_${s}_${a}_${o}_Sheet${w}`}.pdf`,t=`/storage/emulated/0/Download/${e}`,p=await H("mouza_map");if(!p)throw new Error("WebView not ready yet.");await g("mouza_map","window.prepareForPrint && window.prepareForPrint()"),await new Promise(n=>setTimeout(n,600)),W({id:p,path:t}).then(async n=>{await g("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),Q("PDF saved at: "+n.path),window.bridgeSend("notification","showLocal",{title:"Map Downloaded",body:"Tap to open "+e,payload:n.path})}).catch(async n=>{await g("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),h("Failed to save map PDF"),console.error("Map PDF Save Error:",n)})}catch(i){h("Failed to initialize map PDF save"),console.error("Map PDF init error",i)}},X=async()=>{O();try{await M("downloads");const t=`/storage/emulated/0/Download/${`${`Map_${s}_${a}_${o}_Sheet${w}`}.pdf`}`,p=await H("mouza_map");if(!p)throw new Error("WebView not ready yet.");await g("mouza_map","window.prepareForPrint && window.prepareForPrint()"),await new Promise(n=>setTimeout(n,600)),W({id:p,path:t}).then(async n=>{await g("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),fe({filePaths:[n.path],text:"Here is the Mouza Map PDF."})}).catch(async n=>{await g("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),h("Failed to share map PDF"),console.error("Map PDF Share Error:",n)})}catch(i){h("Failed to initialize map PDF share"),console.error("Map PDF share init error",i)}};return f.jsxs(z,{children:[f.jsxs(z,{sx:{zIndex:1e3,p:2,backgroundColor:S?"rgba(13, 17, 23, 0.6)":"rgba(255, 255, 255, 0.4)",backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",borderBottom:`1px solid ${P.borderColor}`,boxShadow:S?"0 4px 30px rgba(0, 0, 0, 0.5)":"0 4px 30px rgba(0, 0, 0, 0.1)"},children:[f.jsx(z,{sx:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:f.jsx(le,{})}),f.jsx(pe,{sx:{my:1}})]}),Z?f.jsxs(z,{sx:{display:"flex",height:"100%",alignItems:"center",justifyContent:"center",flexDirection:"column"},children:[f.jsx(de,{size:60,thickness:4,sx:{color:P.primary}}),f.jsx(ce,{variant:"h6",sx:{mt:2,color:"text.secondary"},children:r(G==="loadingSheets"?"wb.mapView.loadingSheets":"wb.mapView.loadingData")})]}):j&&f.jsx(he,{id:"mouza_map",html:j,onConsoleMessage:i=>{try{const e=JSON.parse(i.message.message);if(e.action==="PLOT_SELECTED"){const t=E.find(p=>p.plotno===e.plotno);t&&q(t)}else e.action==="VIEW_RECORD"?u&&K(u):e.action==="ACTION_SHARE"?X():e.action==="ACTION_SAVE_PDF"?Y():e.action==="SHEET_CHANGE"&&U(e.sheetNo)}catch{}}})]})};export{Ce as default};
