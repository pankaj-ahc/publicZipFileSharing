const s="WB Land, Plot & Khatian Info",m="https://play.google.com/store/apps/details?id=in.svt.wblandsinfo",c="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGMAAABjCAYAAACPO76VAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAAAm4ElEQVR4Xu2deZxlVXXvv3ufc8eaurp6HmiggW67QUCERF8Q8Yl+Ep/PKCqSvCBEUXyaSHgq5H2SSIxDNKI4EwaJYpzoBBWNgnGIQRCZGqGZaeimZ7q6q+pW1R3P2e+PtfY+51YT+t58Pvm8/qOXdt17ztnDWuu3prPPPhez+NyzHYfpkCA798Rh+v9Hh8E4hOgwGIcQHQbjEKLDYBxCdBiMQ4gOg3EI0WEwDiE6DMYhRIfBOIToMBiHEJle16acA2PAAeaAYz3rnJxwzz+kH+M/Os6Tn+c/Sy43uh8myGDk4IDzejx32rxUxhickU9wOGdA/t/N9PMJN4d6BkMm1DnmcG2ANHWAw8YRthhh4giMwRgBKD/JXP5M7sgZB076BUyDtnKTG6f9HA6xioylbpG6AHUyRzZnxk1mYAbjcigBGINLUvnXcbh2gktTASOyOOfC/EbtEgfG0jMaPYPhcJjQUoRxBkgdpGCrMfFwmahaxEYWbPAXUY0/ED0Gdcl1g8nZsBfIN3J5vQUwcm2cw3VZSdbWqfvK1ApcmF0oDNNtFvrXYHPfSR2QkjYSOtMtOtNNXCcBG0mE8J6SZqyI9xycegYjU4RXhoEkxRlHcWyAeF4FG1tc6iB14sahn1CmLlE8Rm3byVljvJXnlJpZgKAiHaSvNvOt5bSMIQ6Wa5Cbfy6ZAKbwNhc2+fT86IeVNmkzoT0+S2eqgYnyKVilNHRB/Hz0n0rgxhhIUzBQXjJMceEAxhjSdipAYDTEiOieFYdTZek4zqcXcRfn5JzRPkEEdyAQOBlPgMwa+jG6gDB+3qBSDXPCgHieTCxsZ2Masa1w3jgNu50UlziiUkRp6RDFhYO4VGTznmx6hkGodzDUQh0W51Kcg+LSIeKRCrRFKOMTmFd3iON63Q+lVujDsvdiZ8SaHDKQMw4jWVJ7an/1ABlQ47vzwqtF5kJTNpe3Vh03n3QVCeNPK+BY+e5ziA+pwasTmauwoEppbECM0VuE8tEr9Q6GF8s5XOIojFaIh8tiITg1B80jQesKhFqLfDOZNVunCVv7qzGH7s6ohQvQfgRpKsoIOOm8xkgI6SLnG3qDkO/ee7JckSsakD7OFw1hSG2g4SfYfuIojFWJB4u4RBp4vHul3sHwAjmHLUQU5lUgyYWJMKkIJ30y0b3WUqcaz7mwHzpTi1qUNuhydqP27aCRWqbalolWxP5WxP5mxEQrYqZt6ARwvWd5s9B8kgc+ZzR+jhDvlCdDzkOVBxVDw52IWxgbwMRWE70O3iP1kcClmUscxfkVCosGcUkKKM+qw+655570wKnKfZzScCFNMiEkZGSubg0kzlBrWToJLKokrB7psGwgYbSQ0uzA7kaBLbWYrdOWmY5hsOioFgS8jBPvyd4TjOQswCoQWfrW63kwc3IEw/ECRIbW7hrtiTpEWmH1CEjvYOBwmpyLy4eIqyVIJIlnSn8eQA6ULdf3wMue/H2HxTGbWOoty4ljLV531DSnL51hzVCboTgVH3eGTmLY0YzYuK/ILc8M8KOtA4w3LSOllNgCqc9FMlOqjPj7IZ8rMtVnfAlp3kHByOVCACJLMt2ksaMmWOVkPBj1AQaQpJg4orRiGFuMIFXWxLBIncFqovcMdLm/P90FhChGaxsJVbmc4IDIOPY3LYMF+N/rJjh/7SSLqh1oG0gMpKoYD7p1EInX3rW3wmfuH+VfnhmkUkipRCmJJvOgIxf+dPN4wEFuDqfhMpxXsoa0mdDcNkGaphjbeybovaWy5IzcQ5D6M/LhEJ4kHOSqFkkGclGFEFJ3d6JIAxhtH6KXgjPeiFhZTbjmjJ184EV7WRR3YDbCtQwulSzpUg1FiYG2hUYErYhTFzS4/sxdXHryOK0OzHYMkefJEarALLc8B4+GcB8iHaW/MyZ3syn/jJG7bje3iOiB+gID1I2tNwaNnposhfGcGn2i9G7vCAAZJ+s54ukisEEqrQCIgclmxKqBhGvP3MVZK2ahHuPafvlBx/FjargJ3pg6XCOikBoufdE4l586TjuxNJMMfG9AHpiQnPWvpBYtbRH+0fsN5zTc5UomKWgyefqhnsHw/HYf5BgM8/pzHjCxOm+MXlSnCRqfqF1+7UssrJEYqgXHJ166h1MWNcQbVCnSVYXO85JFkWyOjoG65d3H7+dd6yeYavkFjjyTQbqcQflj/yUrJlzgQcOil8VLmcs7vVLPYAjNYbDrUKO+UQF9+YK6h/NWppaYAyBIq0sZzhhSoNaKeMcLJjlr5TTM2mCAIWI4IHJQTvVfAsUUbHbnIItEDlIJX+87cR8vWVxnoumNQcJpGNiJZxmQNSkn3ipzB4vKMeKV4L3Shy893Qf1DIbBZdHJf+YmTDGkSLjqQkkbeb4dmhuCDCqAiBP6Trct6+e1eNvaSWhHGZL4DwMlmEgifvDMEJ95YIyrN83jrvEyrmAgTmU075KAaxuGSwnvPmE/RWNoJcqDNpBwaeRmM6dNr38fCsP5YFVynJXDefl7p57BEDh0zckrVc+jbpkpLJcUUZdwKoguX0uC1746Uq3RYKbZxBhLO7G84egaS6ttaGk/b8TGQDnlJ7uqvOHHyzj/p0u4/K75XHbnGGffuoyLb1/Es20LhdSH+HDrRtNy1rI6v7W4wUzbhFLWaP5WWHR1wJ83JKlj/+wM49M1ktTJ/YhvG0gU48ELwaFH6gMMJeN0vcYnPtGQs+r2arV+GcFggmDZ4p2waI0hTVMm69Psn55izcKl/N6aE2k2U+YXWpy1fEbCiy4iOi9lMeX23RXe8bPF/PrZMpViymglYaTiaANXPTzMJbcvppZakMcqml9SSA3lKOHVK2dwWLlRNo7UFxzCvkBnLM1Om/GZKerNBi9bvYY3v+gllKKYVpJIW+c9RjsqiZPl/ejg1B8YRv54axMTUMty3iRyFuOF0z/iPQ5jRQn7Z6aZmJlhzcJl/PVrzmHDRZfykpWr2bF9F6tLMxw3nEBHaxtfnVhodAxX/GaUXQ3L0mqbghVwDVCNHEsGOnx3ywA3bh6GOMeEDz3O8OKxJsNRQjvxvilBRj4NzbTD3toUnXaHVx57Ap875x1848L38/lzL+KEpSuoNesBgOdM1Jll9kx9gSFx3i+Py3ecJG6D3N3603krkSOxtHaSsHe6xnSzzikrjuJTb7yADe+8jPe+6g0sHpnPwzu34ZodjhtpUS0mvizKFBqnPDBR4t69JeYVExKnsV5ndM5QMA5rHT/fXqWTCoDG+SoOSA3LB9osrnRopqI04c8w02yxZ3qSKHX8/gkv5qsXXMwNb3sf55z2MirFMpG1DMQFNX0/qQLiDTToqj/qCwxhOtW4n3cMq2VkrjJRkjaGZqfDs9OTtDpt/vsx6/jCORdy40V/zh+f/iqWjo4BsLc2yeN7dmHiAkuHZJ4MeQXFwM5GRL1jiG1OelW0t9OCgX2NiNmOlTDpWyoiQwXHgnJK4sSUppsN9tQmGSqVeOtpL+drf3wJXz7/Yl51/ClUSqUwRydNSFL/GM9bv/eNvOzdvPVCfYEhzxukpnL5myvILEVJvhrq7RbPTk9hgd8/4VS+ev7FfO3C93POaWcwUh0AYMe+vVz9bz/knKs/wV1PP06xXKakoceTQywQBwuLKaVIFg1FJVkS9nfKiTMMFFIqNu1etlELjiNHKZb1tqn6DIsGhnnvGb/Hhndeyuf+4F2cftwJRFEEwC8efYDfPLMZcsYVvmuWN5rQAuAe9T6oLzDI2YBUR0iAMrqe5BAWnWGm1WRPbYKBQpHzf+sMvvn293Hd+e/l1cefQqUolrZ5z07+7ocbeMNVH+PS73yV+7c/TSG2OGPYMR1p8vYVjVQ4dAzrR1usndei1rJY/4TQ+EpGOGwmhhcvqlMoSNJ2mut8yZQ4Q602y9T4Pi449Qxu/pO/4MNveCsnrlwNQKPd4l8fuo8//vKVvOmqv+Wepx9X+TWH5TTiT2T3GXqiz5uNvsGQ4TVHIII5l/mIcdDstBirDPDul/0u37zw/Xz23Hfx0mPWEUcxAPdv3cwHv3MDr//SR/nwLRt4ct9uRgYGGRkYwBpZbHxo3FJv69KLkgNILMOFDu85foKiNYw3rJbJ0iZxlp0zBU6e3+DcY2qykDjXQi3sqxs2720xZA3n/dYrOHJsCQDT9Vm+e+/tnHfdFbz1+s/wrftup5l2qBSL3WN42/feRrcx9ucTQn2BYfy9gk6fkm0+QIGaaTUZqw5y9Xnv4eNvvIBTjjwWgDRNue3xTfzp16/iTVd/nE/97PvsmplkbHCY4UoVi8GlIlA5djy0N+LR/ZFUQ3oTbZxaXcvy2iNqXPHS3SyspIw3YvbVY8YbEfsbES9d3ODzL9vNimoH19HwITFFBIkcm/ZGPL0/5cVHHcm6lasYn57iy7fdyjlXf4ILv/ZFbn3kfqI4YuHQCKVCIcNT05g3PxMACbap37Xk1269UM9gePdz/sCT5wLAGNpJhwWDI7xwxVEA1Fstbn3wXi64/tP84XVX8JVf/5xas8HCoREGi2XN0d7TFAwLz9YtP95SFA5N5ougSygty3nHTPKdV2/nw6fu47xjpnnbmik+d/ouvnXWdk4abeKaKp4PoSFsGP7lqQJpajl+xQq++quf87ovfJj3/dM/cMeWxyiVSiwYHKZgI62SfD/t7ctsvC50gjxIWhj0Qz2DkRmWZsoAQUgWiAUakjSl3moCcMfmRzjv+iu5ceOdJMDCwWGqxaIoVZOqC+WpCmIgjlK+/0SR/fUICt7SRAmhhG9FvGCwzZ+eMM5nXrqLK16ym/OOnWJBlELTarLWCbwJFx1PTBT48eYCw0NlfvT4Jt5/01d5ZM8ORqpV5lcHKUQRqfImUs1Rq1e6D88hTGvFp4Zrgo56o57BABnZVy7kHEQSrNdQt+PUGrO004QFg8OU4phU9yhJ9RF0jJGtd6F3NXbcsyvm1qeLUHSqEk85D20beXbRlqUOGpr4/VgyuBiSdRDDhkcLbJ4wDBQNtU6bgXKZedUBrNHVXA2JYZRM5Gw8tLLw58gvDuruky5NHJz6AsP5xKRlpxa53kMzd86ZQxzFlAoxDtneI88yfJyVSkzG9g+i5EFRbKGTOq7bWGKmZTFRPgxkY0gpKw9PhQdtpxWNIc0KjIJj22TE1zeVKEWOuBBTLhWIjMGlkrCEx26Hyubt/i64+IDlt+iodfYJBP2CYfyEeqftvP6N59yHkjyp+kQ3OeDkfAgAgX8jOw8cjJQdv9xe4J8fLUHJG6I306yUkPtnnTcMpypy8t0YoGi4/sEyj4xbhkoOU4ghFAYKrPE7XrRSDErNpPJ1gHxkLTIU0fbdmjgY9QWGjO8n0X8+HIuGFSHPqHbyHhVQ8dKoON4j9H/SyxDrjeXn7y6zp2ahoM/LjY7jkTV+8JyW/FxGlVNybNoT8eWNZSqxI7IWq6V24NV/MfI9BMZcRPInvCmJXPmL2flMmt6oLzDCNLo1Uv75R6U5QHLeYYzB6CovHovcNfzallZU0iyDZbiccu/umC9tLENROPY4YHSisP+yW6EOZSoSwK+4s8r2abkzJ46wunvc70DxIIhy5bFwd8JQBvUxQGaM2kCNyw+kmaVn6guMTMUemDl8eq+Zaw5OWfNIGKm6/AJf8BzjBcrmiQ0MllKu2Vjmrh0FKOn10MTvNtRlew2VGXMWKo7vPlHixkdLDJdScGDjWDzSSbI1vo8h2zrq/+HRF/Kn5LuHQsbwbAkMcxXx/NQXGNlD+W5lBHLyp9trPasCiFeAf6pG2ACQPYLN6iZH6uQ5+LN1w9/cVmG2YyD21Qoigsu2lTp9TCpKNZiSY+d0xEdvr5Kkuh5lDTaORdddGtTkrze3QQxp6FmS6KiG5XwoNOJJXbL3SX2BAWo1PlaHk2oJagxdWARVisKfi5y3trmkrxU4B/PKKbduLnHtxiqUVHEQJlQsMsXpoC52fPLOCvfttoyWU1wKxlpMLJsbvHc68jJ5wwia9xcU5OwQMrG8HKqGObnk4NQXGE4tLyNvLX56eQrYrXLJBcJoiLR6SYU1kn3CcGisdzqmMcTWUCo4PvnrMvfsKkAlp6ugvDlUTfjOY2Wu3ViW8KSLilEcY/3mMg8cGZpiWArOXM0rS55Zfz+RRUfvHZJb+6G+wPBMZA4sk4XwFU5lVUReFAdhp4WP82gBIEf58Jc7VgUMFR27Zw1/9YsqtZaR6krH8N0MqoOyY+tkzOW/qNJOoRIbUt0FaAtx17j57z7tdXMeRJ37NXRXNnL6f47ceRDqCwwN8cEK5VNWVhUDtZAujcqRIKGngsRy3TfIrf76ECXqc7I8AcyvpNzyVMyn7qpIMjdqnXnlRtAyhg/+YoBNeyNGK6nsfncOrMHEsUafrPjMIJVzvsACX1B5zvJVHyqw8qrbfHCEYqYfPPoCQ/Tp3c9XD/JdKHPRwKyGEWkrfUKsNgKQV4RDly0C+c3Wel10yXDR8dm7KtzyZBmquTtQBESqjms2lvnGQ0XmV5Oc8ThMFGOjCBxYZ3SXh/ASwnBYc9Ih0d3pfnxv9E6uSqgMhzqZLDUHPfRAfYHRTUH6Oee7rSF8V8zkON8nszMRJiSC5xjbkTqoFmA2gUt/VuWpiVjLXW1eSfnl1iIf+WWVYuwoBOXI5SiOMk8MU4shSLhURv310D0vlYaHXBExN8Tiwc2dOhj1CUamOH8sjpkxlQmjLXRRzaGWSS6wqsk6tUQxUp1Dhwi61D5GX7iZX3Y8uDfm0p8OMuuAGCjAzlnDB35aZbxuGC6KmgRbCSe2KHfd3vqDTvXGFXQvVcAjbxzaNQAloAjf+XJbYtxcbR2M+gPDx93sRKb/3KncR/AT7+WhTyDfQTONQaoef1mVEk4EJTrGqik3PR7zyTurUHUkEVz+80Hu3B4zVklJUuXXh0hrMVF8wPQSRsVoQBcLVY1OWJvjGdrPIRJmEdcLoI36gaJfMEKyFcvxrhnCKVbnz2JlGrwiX0HNJd3gEJTu1RIO1Zl0+V3Px8YxVHJc+esyP3qyxA2bynzlwRKj1TBr6Ouc/mCAtRkzLpMpf8+RPU9XXjwigVv1eJWVUJp7wHSsLsM9OPUFhsyVMeWC0uWvBptuxoNGvWM9F4O5vbe5GbysWRc/j5DDUI1Fa3/yo0H+5rYqAyVHMUJfNxCFS3sBI4+yV7rTwsIHFj+f32kCXWILOT+whiqfNzx3gticTs9PPYPhle7IK1SF9ccaart4EPkkTOiBDwkmpwQfpqVJhqDRSiwkQ43xPk6nDioFGG/AZEuenzuQsgthRsaVJRAxIB/n88HIM69iqaF7nvIiCQa+vYDgjOQ1eaXZ6iDBinqinsEQUgWZzACkxM9Emhtb5Sin3JxUclaLgNyOChee1AH69C1TjF4TjYAm9HLkKNrcnbi+IC9NHcZGoaTV6lVCo0F3nWt7/zxec4mcMxSsJP5SHMvDKMRl/U5FED3IWpVI9V/mGU4VL980BHg2jChJrGJOKMp5je/v/LK1HKpe1eT9mDkFebBlGDkjVq3fc1eCG5ENBfK6tIllU5rwL5+eDN71wpG2cVhrmWzMMlGfYdfUBJ00lcfEQdnqHZr8/UD9QdEHGKi+RFBVmh5nySr/KoDv5I9FQGE7FwdCrPWJNosPEs7EPvPx21ufDO/zlrdo6es0MfvxQ+L2sd6X2TJILuyoKg2AJbYR5VKJv7/9x5xzzSf4g+s+xcadzzBUrqgWhA/xFO3mZDn/ufPjf0x9gZEx6Z8diAaDLKr0PKk+vEpVWT5m+0YuqFV0ohrxXoMob66naJMwpz92GmpU5zig02zR2F+jOTVNqzZNszZLc2qGZm2GZm2a5lSN5qScb9VmaNVmaU3P0p5pkM422bJrF/dsfpwHd2xlttOiYOesiGbKgWCUues9UF9giO5zXqCKcajivLLmMplb8vBgZsxLeNPSQDYVGyM/OaHAeLDzYQH02UjulCR2WeIQXj0T8tNELklwnZS03SFpt0laLdJmm7SVkLY7uHaHtNUmbbVJWh2SZouk2aA92yRqdii1EgrNjvzWlC9tczlTmMiJ58Nlj9QXGDJJFiLQIELOMLqA0DZdZpJn0HsIhtlWk4nZWaYbs+yfrtHsdMKdsAfbA6MDZWavPGCg2WpRa9apt9vhnDWG1KXMtpvMtJq001QAU9CbSZvpVotm2sFgmGm3mGzMMNWoM1FvMNWcpdZs0OokuE6H1tQM7dl6lp9ygKgZyFF/WPQHhoRAnUz1IKFJz/twnKknF9/zzxzkjtc5R63ZYO/0JPPKVd59xu/ypbe+h9894RRIEp6dmqLeasl81t9QIj7pS9YwogMMCweHOGJkPvMrVVLdxpI6hzWWpUPzWDlvPpW4oB4ISeoYLlZYOTzKgsogBjhmbCEnL1/FCUtW8MKlK3jh0iM4ev5C0jSlVm9gjKE9U6c9Uw9y+Dzn84Twc4BlPi/19QsJLkmJChGlFSNSmbhUjEOTujUwUZ9l3eIj2HDRpSwanscPHribC2/4PHEUEUcRFkPiUmqNOq2kzTFjS3jdiafyplNOZ93yVQDUm01++chv+PYdP+eWB+9lx+QE5UKRwXKJyEb6YzB5h3C0koQ0SbjyD9/BK088jQe3buai665kojHLbLvNa9a/iI//4TuolMtc+6/f5xM/2EChUGS4VOIL57+HF61ew/fvvp2/+uaXueFdH+DFa9eDM0SRGMFso8FdTz7Cp2/ewF1bn2SoUsXhKI8MYeI4FA4gv0VV3zaJ6yT/db+QgLdKkDdW1VvEJX1d022xRr0IzQf769NMzkyzduFSPvSat7DhnZfxwf/5vwIQAJVSiVeeeCpXX/R+bvqzy7ns987myNEF7KvV2Dddo5MkOpOMC444iphuNtg/M83S+WO84viTOWrBEmabLVyS8Dtr17F62QqWzV/Ay9efRLVQpNZosGLeGGcefzLL5i9gsj5LrT7LgnnzGB0aYXR4mIFymYFShSXzF/DaU3+Hz7/tT1kxMp+ZZhNSR6fRzBYWReBQQGQLh71Rz2BkYcdPOOeceqWUoTlnM9ByHcZnatSbDU5duZorzr6Af37X/+Xis17P0YuWgm7F/8adP+eyf/oHfvbw/bQ7EvNftHoNf3Pu2/nBpR/hk295O6etOoZGo87eqQkaSUvrfRtywC8f24RzjiiOecGylTRbLYZLFY4/Qt67ADh26XKOGFtI0mywevFyquUKzjnueHQTxlhS/bWgXz/+MK/5yJ9z5gf/jCtu+gZJmrBu1dGc+YITqTcbYAxJq0OadAQLJ0Zp/B6wAxPo81LPYIAoNrvfDCe6j7tP0Gi1SNsdXnnc8XzxLe/kxosu44LTX8WikVEAdk6M8+V/v4Wzr/oYF3/7Wj7/bz/krV/5DH903RVsuPs2xqenADhi0RL+5DVn870PfJhrL7yE1554KiZ1PDs1wWyzCQ5KhQKP7tzGrv3jABy/8khckrB03hhrlx8ReFoyOsZxi1dAu83aZSsxxrB3coJHd22nVCgECbfv38ct9/6Kf7/rNq68+UZ2jO8FYLQ6INtBMfKrdEn265D+EbR4RpiyJ+oZjC4V+5jts3jIzC4sA/gzaxYv4yvnX8zX3/4B3njq6QyVqwBs2bubT93yz7zxqr/l/2y4nruf2Uy5WGbJ8AjOwI8evp93/uMXefPVf8sXfnozW/buBmB4YJA3/7dX8PX3/iU3XfxB3v6ys5hXqtBoNykWimzbP86DW54C4IRVR1GOI9YuXc6y+Qt5Zs8utu7ehTGWtctXQhSxZtkKAB7csplt48/quxjC/cKBYU47dh0nveCFnHfmq1k4MspMfZaHtm8ljmPJl6n/GVkx1CyddZttL9QzGKjuBe3uiA3ZfYLRGObBW798Ff/j5N9moFwB4KHtW7j8u//I67/0MT70LzfyyJ6djAwMMlodJLaW1DmKNmbB0DADlQr3bXuav7j567z+qo/ylzfdwH1PP4FzjmKhyOnrT+KLF17CTZdczprFK6g3m9SaTTZueQKAVYuWsXxoPmuXrcRayy333smPN94pfK08kiXD81i9ZBkAG596gql6nSiKghJfsnYdP7n8Cm776Bf4yB+9k3KxyHW33MwPf3MPw9VBQHOnV4evLJ1GkFBp9kZ9geHyN1pOfrvVkDFijCF1jsjY8MqYpzuefJhLvnUNZ1/1Ma746ffYNrmP0cEh3YqvP8Kl9boz8qZTbCNGBwaZVx1k+8R+rvzZ93nTNZ/goq99gVsevIdGqwXASauPY/3yI2hpnrlviwA2f3CYtStWsV5f3PnVEw9x15OPAXD0kmWcuPJIFg7PA5AXKC3YXAzoJAlT9VnGazWm67MAvPCoYzh28dLw/gk+NGm+VOWEQqcf6gsMqZdctvDj5/O1tZMbrEanxWyzTqPV4icP38fbrv80b7nmk1x7+7+yv1Fn4dAIQ5WyrHL7ciz/cMdlVuX0seZgpczC4RFmO22+ec9tXPCVz/Dmv/84N9zxE/bP1Fg+Oh9rDcVCgU3btrBz/16pytafxPqVq6g3m2zc8jQPbNtKq91i2egYZ647meGBQcanJnlw25awEdob9B2PbeJVH3o/Z/zVn3HuJ/+aLbt38vITT+Gy170FkoROkgCm63UQXQbQ4/4CVV9gOL3h9DdxMqXf8SG8DJQq7Jyc4JJvX8v513+a86//LBs23kmHlAWDIwyUSmI5qV9r0tCmY+kKlkqmwOMXI6FSLDA2OEQUx/xi80O899vXce7Vf8e9O7YyVK5SjAtsG9/Lo9u2AvDG3zmTY5ev5PEd23hqfA9b9u3mqd07WTgyyltefhZDlSqPbNvC1r17KPmXKFWHU406m3Zt5+l9u/n+3bdz3+ZHAXjp2uM5YnSMVqejXBvdR9wtST539kJ9gSEkyhFkxCH99hZwxMZgreEnjz3ALY/cD9ayYHiYclzQhO8VLCboc0zmaT4M5pcacsseToQuRDFjA0MMV6vcs/1pfvXMExTiiEJkmW41uWezhKMVi5dSLBS5/+nHqTXr7JuZ5oGtm7HWssrni6efYKZpZ5ijPvzwNFYocPTrGwsERXrbuhRy/6mjPtrLjMNZIOaz8eUPyOy89OL1Qz2B4XYTSTW//xSNzd58IByOVQeYPDFH02+4RBeutogDhz+fJ4xROaAs/friRkr7WWIYrFapaIFjkAc+9mug9/frxh3FAO0257yl5p1uH4Z7Nj5ECkcTNsPXzt9es5+Y//wg//ouP80+Xfphjlkl5/MO77+SZ/eMUtaIysT7bmKOD/vyiDzCMWkSaOlya6o2eLKXn0XdG7zwNUoOTgSj8KhDaFuPf8dN3NLwCQyhUAJ0ygOQR5LKA4hw2ijCRLEuU4gKP7niGfVOTAEzNTHPvlicpFQoUopj7nnqSZluS//jUBJu2baFQkF2G2CyFV8oV1h15DCeuPo4F80aZmpnmultv5mPf+xZRXCC2lqhYxFqLSeVVAxFc3xnpk/pam5LfOYfi8iFstYhJ5nQ1hIXDkIyNWJtGl+wxpcZYfD3gr4e2mZkZHdsvM4Qop2qTKGdIWi2aU9MkqaMQWV570mmsmDfGzon9fO83d4Vqq1Io8Yr1JzFcGWDv1AQ/ffh+eXoHxFhOX72G+YPDJIn/nRRDM014cs8u7n/mKUxk5Y1dC+WRYYj02YZxYC3JdIvGjikRwcvRA/UOhg8paUpxQZXC2ACu4xUuTUTt8vdAyp3PKdPRva9VXU4doTuU+W06chD+hJVTYyyt2Vk6Mw0cjulGgyRNsMYyVB2QZ9fGkCQdJut1nEuxNmK4UiW2utnNOabqdRKtlPwOEgxYaxkslYmMIbVQGhwkLhW6wiHW0t47TWu8Lm/65IzmYNQ7GCBKSlKiSkx5+TxRTprli6Buky0O+sF9xWXE/EPJ6sOcvMolo2Rw+I4yFtoXf6jnZJzsPqXTaNKpN3GpbHj22/bDnit95Gr9r2R7a3DCh9HCQjwupx7/tRBRqFaIiwUJ2Sq7N4rGM5MkzY54jF7rhXoHIzzylHBVWDRIYX4V2vKLZB4Ioz87JHlDClff37uQ0ZDq07lXuPQUdvKKE/JASMPM+/3GBc07RqoKhyPtdEjbiawdKVgyns9BfkYtr52Or6C6jCkByFrZCFcoyH8/I5cXnO7Lao/P0Nozg4ut3i8p7z1QH2D4P2JFJjKUVg5jS0Xo6I97BLQOJC9caOKy8kEMM4jv9SZ/nIAlbZRVXzbqQF6/cs13M/IGszUgEUeVK+FMJJEfbArknVPB9twaDC4YWTZOl7CxIa23aWybhARcJPL8hwp5Duq5mvJSGqPvY3QSmjuncc0OJlKr9cYFyoSez8X9kAOCtrMCUPzEbwMKuPuv8ifnFc7lgHAZSPKhN5WJvpTv9O0io4312DnlzwOBfxQsJ2RK+c0qUodzWjUpKA6HiS2uldDcWRMvjNTp0NjcI/UORiaD/IksaaNNY8cUyWwbIouJbE4QYUIigddWgEjIt9EQIxrJlbe+vYY06eNDTdBe9plrkyfxKK86BRGZ33tjvpNnBTUe1GSc90LUMK3BxpZ0tkVj2yRps4OJImntX+4Pwh6c+ghTGcuGzDxdx2EjQzxSJp5XxhYjsczcb+/JW4tmpVcGTvCQnG6ln5zXbqrMrp763YGxBxYMOTX7Y4KhZq0screcvXKQ154LEuBVYHVk53CdlM5Ek/ZEXV7qiUwmsRYJueR2UOodDNWWrxgyJSmXKZiClf8aWSXGFK1swXfd9wXSLwdSUG9QrSpEWx5gXRkc2elcvtHrhny5nAdDN1nnQmp4Da2Ln9A1FCOpA5OmpK2EpN4hrbdJO7J0bazJynKH/iqbgNErHL2D4fSPn0SdIz+RSwlPwExEUKv09JaSiZwn0XnuitF/qcgYxglxn0xpqr+ucXMKN2TVq9Ex/PhdjwFyJE38wPIpHu8FVS+xuqEv8JJZn0PG7RWOnnOGRkwcUrIZLUfT7IfSMAZsbCWhqyacWgp+76wGZP/dOf1v2jnC5mdpIufFBjTB6sWsr2+n3/VT3pHxc3nH9d/Vg1Jpj1O5Qj+9lp9Tw05ANrIQi+d77WTWIutUvjT3BWAv1DMYxsjqpFiRr0l1I5iamQsvjeg/a6St1e9WNg8c8C9cn9PPj5P/bvPn/TU5J3urtBoLc2XtnDE4fy7wluuf41s2OoiMbu68Xl7I5A1yq2pUP3KtN+oZjMP0X0+HwTiE6DAYhxAdBuMQosNgHEJ0GIxDiA6DcQjRYTAOIToMxiFEh8E4hOgwGIcQ/T/gfRHwTcJLGAAAAABJRU5ErkJggg==";function d(i="official"){const t=i==="compact";return`
    <div class="app-pdf-footer" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-top: 16px; padding-top: 10px; border-top: ${t?"1px solid #94a3b8":i==="bilingual"?"1px solid #c084fc":i==="legal"?"1px solid #d97706":"1px solid #cbd5e1"}; font-size: 9.5px; opacity: 0.88; color: ${t?"#334155":"#475569"}; page-break-inside: avoid; break-inside: avoid;">
      <div style="display: flex; align-items: center; gap: 6px;">
        <img src="${c}" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain; vertical-align: middle;" alt="${s} Icon" />
        <span style="font-weight: 700; color: ${t?"#1e293b":"#334155"};">${s}</span>
      </div>
      <div style="font-size: 9.5px;">
        <a href="${m}" target="_blank" style="color: ${t?"#475569":i==="bilingual"?"#7c3aed":i==="legal"?"#78350f":"#1976d2"}; text-decoration: none; font-weight: 600;">Get App: play.google.com/store/apps/details?id=in.svt.wblandsinfo</a>
      </div>
    </div>
  `}function b(i){if(!i||typeof i!="string")return"";let t=i;const a=/<a\b[^>]*onclick=["'](?:javascript:)?loadRemarksHtml\(\s*['"]([^'"]+)['"]\s*\)[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;t=t.replace(a,(e,o,p)=>{try{let r=decodeURIComponent(o);if(r.includes("%")&&!r.includes("<"))try{r=decodeURIComponent(r)}catch{}return`
        <div class="pdf-inline-remarks" style="margin: 4px 0; font-size: 11px; line-height: 1.35; color: #1e293b;">
          <div style="font-weight: 700; color: #b45309; font-size: 10.5px; margin-bottom: 2px;">মন্তব্য / Remarks:</div>
          <div style="background: #fffbeb; border: 1px solid #fef3c7; border-left: 3px solid #f59e0b; padding: 4px 8px; border-radius: 3px;">
            ${r}
          </div>
        </div>
      `}catch{return e}});const n=/<a\b[^>]*onclick=["'][^"']*unescape\(\s*['"]([^'"]+)['"]\s*\)[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;return t=t.replace(n,(e,o,p)=>{try{return`
        <div class="pdf-inline-remarks" style="margin: 4px 0; font-size: 11px; line-height: 1.35; color: #1e293b;">
          <div style="font-weight: 700; color: #b45309; font-size: 10.5px; margin-bottom: 2px;">মন্তব্য / Remarks:</div>
          <div style="background: #fffbeb; border: 1px solid #fef3c7; border-left: 3px solid #f59e0b; padding: 4px 8px; border-radius: 3px;">
            ${decodeURIComponent(o)}
          </div>
        </div>
      `}catch{return e}}),t=t.replace(/(<div\b[^>]*id=["'](?:remarks|poseser|kypRemarks|plotRemarks)["'][^>]*style=["'][^"']*?)display:\s*none;?([^"']*["'])/gi,"$1display: block !important;$2"),t=t.replace(/style=["']([^"']*)["']/gi,(e,o)=>`style="${o.replace(/overflow\s*:\s*(?:auto|scroll|hidden)\s*;?/gi,"overflow: visible !important;").replace(/height\s*:\s*\d+px\s*;?/gi,"height: auto !important;").replace(/max-height\s*:\s*\d+px\s*;?/gi,"max-height: none !important;").replace(/top\s*:\s*-\d+px\s*;?/gi,"top: 0 !important;")}"`),t=t.replace(/<td\b([^>]*)width=["']55%["']([^>]*)>/gi,'<td$1width="100%" class="wb-fullwidth-cell"$2>'),t=t.replace(/<td\b([^>]*)width=["']45%["']([^>]*)>/gi,'<td$1width="100%" class="wb-sidebox-cell"$2>'),t=t.replace(/\s+nowrap(?:=["'](?:nowrap)?["'])?/gi,""),t}function y({html:i,title:t="Land Record",caption:a="",designId:n="official"}){const e=new Date,o=e.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),p=e.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit",hour12:!0}),r=`${o}, ${p}`,l={html:b(i),title:t,caption:a,formattedDate:o,formattedTime:p,fullTimestamp:r};switch(n){case"modern":return g(l);case"compact":return h(l);case"bilingual":return x(l);case"legal":return w(l);case"official":default:return f(l)}}function f({html:i,title:t,caption:a,formattedDate:n,formattedTime:e,fullTimestamp:o}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: auto;
      min-height: auto;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1a1a1a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Bengali", "Bangla", "Times New Roman", Times, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      html, body {
        width: 100% !important;
        height: auto !important;
        min-height: auto !important;
        background: #ffffff !important;
        color: #1a1a1a !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .official-wrap {
        min-height: auto !important;
        height: auto !important;
        padding: 0 !important;
        margin: 0 auto !important;
        display: block !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      .content-body {
        display: block !important;
        flex: none !important;
        height: auto !important;
        min-height: auto !important;
        width: 100% !important;
      }
    }
    .official-wrap {
      max-width: 900px;
      min-height: auto;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      position: relative;
      display: block;
      box-sizing: border-box;
    }
    .content-body {
      display: block;
      width: 100%;
    }
    .official-header {
      border: 2px solid #175953;
      background: #f7faf9;
      border-radius: 4px;
      padding: 14px;
      margin-bottom: 12px;
      text-align: center;
      position: relative;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .gov-title-main {
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 0.8px;
      color: #175953;
      text-transform: uppercase;
      margin: 0 0 3px 0;
    }
    .gov-doc-badge {
      display: inline-block;
      background: #175953;
      color: #ffffff;
      font-size: 11.5px;
      font-weight: 700;
      padding: 4px 14px;
      border-radius: 3px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      margin: 4px 0 8px 0;
    }
    .official-meta-strip {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      background: #eef5f4;
      border-top: 1px solid #bcd8d5;
      padding: 6px 12px;
      font-size: 11px;
      font-weight: 600;
      color: #134e48;
      border-radius: 2px;
    }
    /* Scroll container & responsive wrapper reset */
    .table-responsive,
    div[style*="overflow"],
    [style*="overflow: auto"],
    [style*="overflow: scroll"],
    [style*="overflow:auto"],
    [style*="overflow:scroll"],
    div[style*="height"] {
      overflow: visible !important;
      height: auto !important;
      max-height: none !important;
      position: static !important;
    }
    /* Layout column reset: allow tables to use 100% width of A4 */
    td[width="55%"],
    td[width="45%"],
    .col-sm-7,
    .col-sm-5,
    .col-md-7,
    .col-md-5,
    .wb-fullwidth-cell,
    .wb-sidebox-cell {
      width: 100% !important;
      max-width: 100% !important;
      display: block !important;
      float: none !important;
      box-sizing: border-box !important;
    }
    td[width="45%"]:empty,
    .wb-sidebox-cell:empty {
      display: none !important;
    }
    font {
      font-family: inherit !important;
    }
    /* Standard Tables with multi-page pagination */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #175953 !important;
      font-size: 11.5px !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      table-layout: auto !important;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th {
      background-color: #175953 !important;
      color: #ffffff !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 6px 8px !important;
      border: 1px solid #10423e !important;
      text-align: left;
      white-space: normal !important;
      word-break: break-word !important;
    }
    td {
      border: 1px solid #cbd5e1 !important;
      padding: 6px 8px !important;
      font-size: 11px !important;
      color: #1e293b !important;
      white-space: normal !important;
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }
    tr:nth-child(even) td {
      background-color: #f8fafc !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .official-footer {
      margin-top: 16px;
      border-top: 1.5px solid #175953;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      line-height: 1.4;
      opacity: 0.9;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
  </style>
</head>
<body>
  <div class="official-wrap">
    <div class="official-header">
      <div class="gov-title-main">Land Record Information</div>
      <div class="gov-doc-badge">Record of Rights (RoR) / খতিয়ান ও দাগের তথ্য</div>
      <div class="official-meta-strip">
        <span><b>Location:</b> ${t}</span>
        ${a?`<span><b>Details:</b> ${a}</span>`:""}
        <span><b>Date:</b> ${o}</span>
      </div>
    </div>

    <div class="content-body">
      ${i}
    </div>

    <div class="official-footer">
      <div><b>Land Record Extract</b> • ${t}</div>
      <div>Date: ${o}</div>
    </div>

    ${d("official")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function g({html:i,title:t,caption:a,formattedDate:n,formattedTime:e,fullTimestamp:o}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: auto;
      min-height: auto;
      margin: 0;
      padding: 0;
      background: #f8fafc;
      color: #0f172a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Bengali", "Bangla", "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      html, body {
        width: 100% !important;
        height: auto !important;
        min-height: auto !important;
        background: #ffffff !important;
        color: #0f172a !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .modern-wrap {
        padding: 0 !important;
        margin: 0 auto !important;
        min-height: auto !important;
        height: auto !important;
        width: 100% !important;
        max-width: 100% !important;
        display: block !important;
      }
      .content-body {
        display: block !important;
        flex: none !important;
        height: auto !important;
        min-height: auto !important;
        width: 100% !important;
      }
    }
    .modern-wrap {
      max-width: 900px;
      min-height: auto;
      margin: 0 auto;
      padding: 14px 14px 20px 14px;
      display: block;
      box-sizing: border-box;
    }
    .content-body {
      display: block;
      width: 100%;
    }
    .modern-hero {
      background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
      color: #ffffff;
      padding: 18px 20px;
      border-radius: 10px;
      margin-bottom: 16px;
      box-shadow: 0 4px 16px rgba(37, 99, 235, 0.16);
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .hero-badge-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .hero-badge {
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 10.5px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .hero-title {
      font-size: 18px;
      font-weight: 800;
      margin: 0 0 4px 0;
      letter-spacing: -0.3px;
    }
    .hero-sub {
      font-size: 12.5px;
      color: #dbeafe;
      margin: 0;
    }
    .hero-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 12px;
    }
    .hero-tag {
      background: rgba(255, 255, 255, 0.15);
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 500;
    }
    /* Scroll container & responsive wrapper reset */
    .table-responsive,
    div[style*="overflow"],
    [style*="overflow: auto"],
    [style*="overflow: scroll"],
    [style*="overflow:auto"],
    [style*="overflow:scroll"],
    div[style*="height"] {
      overflow: visible !important;
      height: auto !important;
      max-height: none !important;
      position: static !important;
    }
    /* Layout column reset: allow tables to use 100% width of A4 */
    td[width="55%"],
    td[width="45%"],
    .col-sm-7,
    .col-sm-5,
    .col-md-7,
    .col-md-5,
    .wb-fullwidth-cell,
    .wb-sidebox-cell {
      width: 100% !important;
      max-width: 100% !important;
      display: block !important;
      float: none !important;
      box-sizing: border-box !important;
    }
    td[width="45%"]:empty,
    .wb-sidebox-cell:empty {
      display: none !important;
    }
    font {
      font-family: inherit !important;
    }
    /* Modern Card Tables with multi-page pagination */
    table {
      border-collapse: collapse !important;
      border-spacing: 0 !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 12px 0 !important;
      border-radius: 6px !important;
      border: 1px solid #cbd5e1 !important;
      background: #ffffff !important;
      box-shadow: none !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      overflow: visible !important;
      table-layout: auto !important;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th {
      background: #f1f5f9 !important;
      color: #334155 !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 8px 10px !important;
      border-bottom: 1px solid #cbd5e1 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      white-space: normal !important;
      word-break: break-word !important;
    }
    td {
      padding: 7px 10px !important;
      font-size: 11.5px !important;
      color: #1e293b !important;
      border-bottom: 1px solid #f1f5f9 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
      white-space: normal !important;
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }
    tr:last-child td { border-bottom: none !important; }
    tr:hover td { background: #f8fafc !important; }
    
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .modern-footer {
      margin-top: 16px;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 8px 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      opacity: 0.9;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
  </style>
</head>
<body>
  <div class="modern-wrap">
    <div class="modern-hero">
      <div class="hero-badge-row">
        <span class="hero-badge">Land Record</span>
        <span style="font-size: 11px; opacity: 0.85;">${t}</span>
      </div>
      <h1 class="hero-title">${t}</h1>
      ${a?`<p class="hero-sub">${a}</p>`:""}
      <div class="hero-tags">
        <span class="hero-tag">Date: ${o}</span>
        <span class="hero-tag">Format: Modern Card</span>
      </div>
    </div>

    <div class="content-body">
      ${i}
    </div>

    <div class="modern-footer">
      <div><b>Record Details</b> • ${t}</div>
      <div>Date: ${o}</div>
    </div>

    ${d("modern")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function h({html:i,title:t,caption:a,formattedDate:n,formattedTime:e,fullTimestamp:o}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Print Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: auto;
      min-height: auto;
      margin: 0;
      padding: 0;
      background: #ffffff !important;
      color: #000000 !important;
      font-family: Arial, "Noto Sans Bengali", "Bangla", Helvetica, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 8mm 6mm 8mm 6mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      html, body {
        width: 100% !important;
        height: auto !important;
        min-height: auto !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .compact-wrap {
        min-height: auto !important;
        height: auto !important;
        padding: 0 !important;
        margin: 0 auto !important;
        display: block !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      .content-body {
        display: block !important;
        flex: none !important;
        height: auto !important;
        min-height: auto !important;
        width: 100% !important;
      }
    }
    .compact-wrap {
      max-width: 900px;
      min-height: auto;
      margin: 0 auto;
      padding: 10px 12px 16px 12px;
      display: block;
      box-sizing: border-box;
    }
    .content-body {
      display: block;
      width: 100%;
    }
    .compact-header {
      border-bottom: 2px solid #000000;
      padding-bottom: 6px;
      margin-bottom: 8px;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .compact-title {
      font-size: 15px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 0 0 3px 0;
    }
    .compact-meta {
      font-size: 11px;
      font-weight: 600;
      color: #000000;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    /* Scroll container & responsive wrapper reset */
    .table-responsive,
    div[style*="overflow"],
    [style*="overflow: auto"],
    [style*="overflow: scroll"],
    [style*="overflow:auto"],
    [style*="overflow:scroll"],
    div[style*="height"] {
      overflow: visible !important;
      height: auto !important;
      max-height: none !important;
      position: static !important;
    }
    /* Layout column reset: allow tables to use 100% width of A4 */
    td[width="55%"],
    td[width="45%"],
    .col-sm-7,
    .col-sm-5,
    .col-md-7,
    .col-md-5,
    .wb-fullwidth-cell,
    .wb-sidebox-cell {
      width: 100% !important;
      max-width: 100% !important;
      display: block !important;
      float: none !important;
      box-sizing: border-box !important;
    }
    td[width="45%"]:empty,
    .wb-sidebox-cell:empty {
      display: none !important;
    }
    font {
      font-family: inherit !important;
    }
    /* Strictly Monochrome Ink-Saver Tables with multi-page pagination */
    table, tr, td, th {
      background: #ffffff !important;
      background-color: #ffffff !important;
      color: #000000 !important;
      border-color: #000000 !important;
    }
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      max-width: 100% !important;
      border: 1.5px solid #000000 !important;
      margin: 6px 0 !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      table-layout: auto !important;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th {
      font-size: 11px !important;
      font-weight: 800 !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      text-transform: uppercase;
      white-space: normal !important;
      word-break: break-word !important;
    }
    td {
      font-size: 10.5px !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      line-height: 1.25 !important;
      white-space: normal !important;
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .compact-footer {
      border-top: 1px solid #333333;
      margin-top: 12px;
      padding-top: 4px;
      display: flex;
      justify-content: space-between;
      font-size: 9.5px;
      font-weight: 600;
      color: #1e293b;
      opacity: 0.92;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
  </style>
</head>
<body>
  <div class="compact-wrap">
    <div class="compact-header">
      <div class="compact-title">WEST BENGAL LAND RECORD (RoR) - PRINT LAYOUT</div>
      <div class="compact-meta">
        <span><b>Location:</b> ${t}</span>
        ${a?`<span><b>Details:</b> ${a}</span>`:""}
        <span><b>Date:</b> ${o}</span>
      </div>
    </div>

    <div class="content-body">
      ${i}
    </div>

    <div class="compact-footer">
      <span>Eco Ink-Saver Layout • ${t}</span>
      <span>Date: ${o}</span>
    </div>

    ${d("compact")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function x({html:i,title:t,caption:a,formattedDate:n,formattedTime:e,fullTimestamp:o}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Bilingual Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: auto;
      min-height: auto;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1e1b4b;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Bengali", "Bangla", "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      html, body {
        width: 100% !important;
        height: auto !important;
        min-height: auto !important;
        background: #ffffff !important;
        color: #1e1b4b !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .bilingual-wrap {
        min-height: auto !important;
        height: auto !important;
        padding: 0 !important;
        margin: 0 auto !important;
        display: block !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      .content-body {
        display: block !important;
        flex: none !important;
        height: auto !important;
        min-height: auto !important;
        width: 100% !important;
      }
    }
    .bilingual-wrap {
      max-width: 900px;
      min-height: auto;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: block;
      box-sizing: border-box;
    }
    .content-body {
      display: block;
      width: 100%;
    }
    .bilingual-header {
      background: linear-gradient(135deg, #4c1d95 0%, #7c3aed 100%);
      color: #ffffff;
      padding: 16px 18px;
      border-radius: 8px;
      margin-bottom: 12px;
      border-bottom: 3px solid #c084fc;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .bilingual-top-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 6px;
    }
    .bilingual-title-en {
      font-size: 16px;
      font-weight: 800;
      letter-spacing: 0.4px;
    }
    .bilingual-title-bn {
      font-size: 13.5px;
      font-weight: 600;
      color: #f3e8ff;
      margin-top: 2px;
    }
    .bilingual-docket {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      background: #faf5ff;
      border: 1px solid #e9d5ff;
      border-radius: 6px;
      padding: 10px 14px;
      margin-bottom: 12px;
      font-size: 11.5px;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .bilingual-docket-col b {
      color: #6b21a8;
    }
    /* Scroll container & responsive wrapper reset */
    .table-responsive,
    div[style*="overflow"],
    [style*="overflow: auto"],
    [style*="overflow: scroll"],
    [style*="overflow:auto"],
    [style*="overflow:scroll"],
    div[style*="height"] {
      overflow: visible !important;
      height: auto !important;
      max-height: none !important;
      position: static !important;
    }
    /* Layout column reset: allow tables to use 100% width of A4 */
    td[width="55%"],
    td[width="45%"],
    .col-sm-7,
    .col-sm-5,
    .col-md-7,
    .col-md-5,
    .wb-fullwidth-cell,
    .wb-sidebox-cell {
      width: 100% !important;
      max-width: 100% !important;
      display: block !important;
      float: none !important;
      box-sizing: border-box !important;
    }
    td[width="45%"]:empty,
    .wb-sidebox-cell:empty {
      display: none !important;
    }
    font {
      font-family: inherit !important;
    }
    /* Bilingual Tables with multi-page pagination */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      max-width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #7c3aed !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      table-layout: auto !important;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th {
      background: #7c3aed !important;
      color: #ffffff !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 7px 8px !important;
      border: 1px solid #6d28d9 !important;
      text-align: left;
      white-space: normal !important;
      word-break: break-word !important;
    }
    td {
      border: 1px solid #e9d5ff !important;
      padding: 6px 8px !important;
      font-size: 11px !important;
      color: #1e1b4b !important;
      white-space: normal !important;
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }
    tr:nth-child(even) td {
      background-color: #faf5ff !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .bilingual-footer {
      margin-top: 16px;
      border-top: 2px solid #7c3aed;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #4c1d95;
      font-weight: 600;
      opacity: 0.9;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
  </style>
</head>
<body>
  <div class="bilingual-wrap">
    <div class="bilingual-header">
      <div class="bilingual-top-row">
        <div>
          <div class="bilingual-title-en">LAND & REVENUE RECORD</div>
          <div class="bilingual-title-bn">ভূমি ও খতিয়ান-দাগের তথ্য বিবরণী</div>
        </div>
        <div style="font-size: 11px; color: #f3e8ff; text-align: right;">
          <div>${t}</div>
          <div>${n}</div>
        </div>
      </div>
    </div>

    <div class="bilingual-docket">
      <div class="bilingual-docket-col">
        <div><b>Location (অবস্থান):</b> ${t}</div>
        ${a?`<div><b>Record Info (বিবরণ):</b> ${a}</div>`:""}
      </div>
      <div class="bilingual-docket-col">
        <div><b>Format (ফরম্যাট):</b> Bilingual Layout</div>
        <div><b>Date (তারিখ):</b> ${o}</div>
      </div>
    </div>

    <div class="content-body">
      ${i}
    </div>

    <div class="bilingual-footer">
      <span>Bilingual Record • উভয় ভাষায় তথ্য বিবরণী</span>
      <span>${t} • ${o}</span>
    </div>

    ${d("bilingual")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function w({html:i,title:t,caption:a,formattedDate:n,formattedTime:e,fullTimestamp:o}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t} - Classic Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      height: auto;
      min-height: auto;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1c1917;
      font-family: "Times New Roman", "Noto Sans Bengali", "Bangla", Times, Georgia, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      html, body {
        width: 100% !important;
        height: auto !important;
        min-height: auto !important;
        background: #ffffff !important;
        color: #1c1917 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .legal-wrap {
        min-height: auto !important;
        height: auto !important;
        padding: 0 !important;
        margin: 0 auto !important;
        display: block !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      .content-body {
        display: block !important;
        flex: none !important;
        height: auto !important;
        min-height: auto !important;
        width: 100% !important;
      }
    }
    .legal-wrap {
      max-width: 900px;
      min-height: auto;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: block;
      box-sizing: border-box;
    }
    .content-body {
      display: block;
      width: 100%;
    }
    .legal-header {
      border: 3px double #78350f;
      background: #fffbeb;
      padding: 14px;
      text-align: center;
      margin-bottom: 12px;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .legal-title {
      font-size: 16px;
      font-weight: 900;
      text-transform: uppercase;
      color: #78350f;
      letter-spacing: 0.8px;
      margin: 0 0 4px 0;
    }
    .legal-sub {
      font-size: 11.5px;
      font-weight: 600;
      color: #92400e;
      margin: 0;
    }
    .legal-docket-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0;
      font-size: 11.5px;
      border: 1.5px solid #78350f;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .legal-docket-table td {
      padding: 6px 10px;
      border: 1px solid #d97706;
    }
    .legal-docket-label {
      font-weight: bold;
      background: #fef3c7;
      color: #78350f;
      width: 25%;
    }
    /* Scroll container & responsive wrapper reset */
    .table-responsive,
    div[style*="overflow"],
    [style*="overflow: auto"],
    [style*="overflow: scroll"],
    [style*="overflow:auto"],
    [style*="overflow:scroll"],
    div[style*="height"] {
      overflow: visible !important;
      height: auto !important;
      max-height: none !important;
      position: static !important;
    }
    /* Layout column reset: allow tables to use 100% width of A4 */
    td[width="55%"],
    td[width="45%"],
    .col-sm-7,
    .col-sm-5,
    .col-md-7,
    .col-md-5,
    .wb-fullwidth-cell,
    .wb-sidebox-cell {
      width: 100% !important;
      max-width: 100% !important;
      display: block !important;
      float: none !important;
      box-sizing: border-box !important;
    }
    td[width="45%"]:empty,
    .wb-sidebox-cell:empty {
      display: none !important;
    }
    font {
      font-family: inherit !important;
    }
    /* Strict Ledger Grid with multi-page pagination */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      max-width: 100% !important;
      border: 1.5px solid #78350f !important;
      margin: 10px 0 !important;
      page-break-inside: auto !important;
      break-inside: auto !important;
      table-layout: auto !important;
    }
    thead {
      display: table-header-group !important;
    }
    tfoot {
      display: table-footer-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    th {
      background: #78350f !important;
      color: #ffffff !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      padding: 6px 8px !important;
      border: 1px solid #451a03 !important;
      text-transform: uppercase;
      white-space: normal !important;
      word-break: break-word !important;
    }
    td {
      border: 1px solid #d97706 !important;
      padding: 5px 8px !important;
      font-size: 11px !important;
      color: #1c1917 !important;
      white-space: normal !important;
      word-break: break-word !important;
      overflow-wrap: break-word !important;
    }
    tr:nth-child(even) td {
      background-color: #fffdf5 !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .legal-footer {
      margin-top: 16px;
      border-top: 1.5px solid #78350f;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #78350f;
      font-weight: 600;
      opacity: 0.9;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
  </style>
</head>
<body>
  <div class="legal-wrap">
    <div class="legal-header">
      <div class="legal-title">LAND & PROPERTY RECORD</div>
      <div class="legal-sub">Khatian & Plot Record Particulars</div>
    </div>

    <table class="legal-docket-table">
      <tr>
        <td class="legal-docket-label">Record Date:</td>
        <td>${o}</td>
        <td class="legal-docket-label">Format:</td>
        <td>Classic Ledger Grid</td>
      </tr>
      <tr>
        <td class="legal-docket-label">Location:</td>
        <td colspan="3">${t}</td>
      </tr>
      ${a?`
      <tr>
        <td class="legal-docket-label">Particulars:</td>
        <td colspan="3">${a}</td>
      </tr>
      `:""}
    </table>

    <div class="content-body">
      ${i}
    </div>

    <div class="legal-footer">
      <span>Classic Ledger Format • ${t}</span>
      <span>Date: ${o}</span>
    </div>

    ${d("legal")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}export{s as A,m as a,y as g};
