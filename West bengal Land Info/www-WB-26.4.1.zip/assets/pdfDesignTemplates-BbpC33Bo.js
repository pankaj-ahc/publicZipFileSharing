import{r as p,a6 as w,a7 as k,a8 as z,j as g,ab as N,ac as T,ad as M,az as C,ay as f,l as I,d as L,a as h}from"./index-CchXlTOM.js";const V=p.createContext();function U(t){return w("MuiTable",t)}k("MuiTable",["root","stickyHeader"]);const E=t=>{const{classes:o,stickyHeader:e}=t;return M({root:["root",e&&"stickyHeader"]},U,o)},Q=N("table",{name:"MuiTable",slot:"Root",overridesResolver:(t,o)=>{const{ownerState:e}=t;return[o.root,e.stickyHeader&&o.stickyHeader]}})(C(({theme:t})=>({display:"table",width:"100%",borderCollapse:"collapse",borderSpacing:0,"& caption":{...t.typography.body2,padding:t.spacing(2),color:(t.vars||t).palette.text.secondary,textAlign:"left",captionSide:"bottom"},variants:[{props:({ownerState:o})=>o.stickyHeader,style:{borderCollapse:"separate"}}]}))),J="table",ct=p.forwardRef(function(o,e){const i=z({props:o,name:"MuiTable"}),{className:n,component:a=J,padding:r="normal",size:s="medium",stickyHeader:l=!1,...c}=i,d={...i,component:a,padding:r,size:s,stickyHeader:l},b=E(d),R=p.useMemo(()=>({padding:r,size:s,stickyHeader:l}),[r,s,l]);return g.jsx(V.Provider,{value:R,children:g.jsx(Q,{as:a,role:a===J?null:"table",ref:e,className:T(b.root,n),ownerState:d,...c})})}),A=p.createContext();function B(t){return w("MuiTableBody",t)}k("MuiTableBody",["root"]);const F=t=>{const{classes:o}=t;return M({root:["root"]},B,o)},K=N("tbody",{name:"MuiTableBody",slot:"Root",overridesResolver:(t,o)=>o.root})({display:"table-row-group"}),X={variant:"body"},S="tbody",mt=p.forwardRef(function(o,e){const i=z({props:o,name:"MuiTableBody"}),{className:n,component:a=S,...r}=i,s={...i,component:a},l=F(s);return g.jsx(A.Provider,{value:X,children:g.jsx(K,{className:T(l.root,n),as:a,ref:e,role:a===S?null:"rowgroup",ownerState:s,...r})})});function Z(t){return w("MuiTableCell",t)}const q=k("MuiTableCell",["root","head","body","footer","sizeSmall","sizeMedium","paddingCheckbox","paddingNone","alignLeft","alignCenter","alignRight","alignJustify","stickyHeader"]),$=t=>{const{classes:o,variant:e,align:i,padding:n,size:a,stickyHeader:r}=t,s={root:["root",e,r&&"stickyHeader",i!=="inherit"&&`align${f(i)}`,n!=="normal"&&`padding${f(n)}`,`size${f(a)}`]};return M(s,Z,o)},_=N("td",{name:"MuiTableCell",slot:"Root",overridesResolver:(t,o)=>{const{ownerState:e}=t;return[o.root,o[e.variant],o[`size${f(e.size)}`],e.padding!=="normal"&&o[`padding${f(e.padding)}`],e.align!=="inherit"&&o[`align${f(e.align)}`],e.stickyHeader&&o.stickyHeader]}})(C(({theme:t})=>({...t.typography.body2,display:"table-cell",verticalAlign:"inherit",borderBottom:t.vars?`1px solid ${t.vars.palette.TableCell.border}`:`1px solid
    ${t.palette.mode==="light"?I(h(t.palette.divider,1),.88):L(h(t.palette.divider,1),.68)}`,textAlign:"left",padding:16,variants:[{props:{variant:"head"},style:{color:(t.vars||t).palette.text.primary,lineHeight:t.typography.pxToRem(24),fontWeight:t.typography.fontWeightMedium}},{props:{variant:"body"},style:{color:(t.vars||t).palette.text.primary}},{props:{variant:"footer"},style:{color:(t.vars||t).palette.text.secondary,lineHeight:t.typography.pxToRem(21),fontSize:t.typography.pxToRem(12)}},{props:{size:"small"},style:{padding:"6px 16px",[`&.${q.paddingCheckbox}`]:{width:24,padding:"0 12px 0 16px","& > *":{padding:0}}}},{props:{padding:"checkbox"},style:{width:48,padding:"0 0 0 4px"}},{props:{padding:"none"},style:{padding:0}},{props:{align:"left"},style:{textAlign:"left"}},{props:{align:"center"},style:{textAlign:"center"}},{props:{align:"right"},style:{textAlign:"right",flexDirection:"row-reverse"}},{props:{align:"justify"},style:{textAlign:"justify"}},{props:({ownerState:o})=>o.stickyHeader,style:{position:"sticky",top:0,zIndex:2,backgroundColor:(t.vars||t).palette.background.default}}]}))),ft=p.forwardRef(function(o,e){const i=z({props:o,name:"MuiTableCell"}),{align:n="inherit",className:a,component:r,padding:s,scope:l,size:c,sortDirection:d,variant:b,...R}=i,m=p.useContext(V),u=p.useContext(A),P=u&&u.variant==="head";let x;r?x=r:x=P?"th":"td";let v=l;x==="td"?v=void 0:!v&&P&&(v="col");const O=b||u&&u.variant,j={...i,align:n,component:x,padding:s||(m&&m.padding?m.padding:"normal"),size:c||(m&&m.size?m.size:"medium"),sortDirection:d,stickyHeader:O==="head"&&m&&m.stickyHeader,variant:O},W=$(j);let D=null;return d&&(D=d==="asc"?"ascending":"descending"),g.jsx(_,{as:x,ref:e,className:T(W.root,a),"aria-sort":D,scope:v,ownerState:j,...R})});function tt(t){return w("MuiTableRow",t)}const G=k("MuiTableRow",["root","selected","hover","head","footer"]),ot=t=>{const{classes:o,selected:e,hover:i,head:n,footer:a}=t;return M({root:["root",e&&"selected",i&&"hover",n&&"head",a&&"footer"]},tt,o)},et=N("tr",{name:"MuiTableRow",slot:"Root",overridesResolver:(t,o)=>{const{ownerState:e}=t;return[o.root,e.head&&o.head,e.footer&&o.footer]}})(C(({theme:t})=>({color:"inherit",display:"table-row",verticalAlign:"middle",outline:0,[`&.${G.hover}:hover`]:{backgroundColor:(t.vars||t).palette.action.hover},[`&.${G.selected}`]:{backgroundColor:t.vars?`rgba(${t.vars.palette.primary.mainChannel} / ${t.vars.palette.action.selectedOpacity})`:h(t.palette.primary.main,t.palette.action.selectedOpacity),"&:hover":{backgroundColor:t.vars?`rgba(${t.vars.palette.primary.mainChannel} / calc(${t.vars.palette.action.selectedOpacity} + ${t.vars.palette.action.hoverOpacity}))`:h(t.palette.primary.main,t.palette.action.selectedOpacity+t.palette.action.hoverOpacity)}}}))),Y="tr",gt=p.forwardRef(function(o,e){const i=z({props:o,name:"MuiTableRow"}),{className:n,component:a=Y,hover:r=!1,selected:s=!1,...l}=i,c=p.useContext(A),d={...i,component:a,hover:r,selected:s,head:c&&c.variant==="head",footer:c&&c.variant==="footer"},b=ot(d);return g.jsx(et,{as:a,ref:e,className:T(b.root,n),role:a===Y?null:"row",ownerState:d,...l})}),H="WB Land, Plot & Khatian Info",at="https://play.google.com/store/apps/details?id=in.svt.wblandsinfo",it="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGMAAABjCAYAAACPO76VAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAAAm4ElEQVR4Xu2deZxlVXXvv3ufc8eaurp6HmiggW67QUCERF8Q8Yl+Ep/PKCqSvCBEUXyaSHgq5H2SSIxDNKI4EwaJYpzoBBWNgnGIQRCZGqGZaeimZ7q6q+pW1R3P2e+PtfY+51YT+t58Pvm8/qOXdt17ztnDWuu3prPPPhez+NyzHYfpkCA798Rh+v9Hh8E4hOgwGIcQHQbjEKLDYBxCdBiMQ4gOg3EI0WEwDiE6DMYhRIfBOIToMBiHEJle16acA2PAAeaAYz3rnJxwzz+kH+M/Os6Tn+c/Sy43uh8myGDk4IDzejx32rxUxhickU9wOGdA/t/N9PMJN4d6BkMm1DnmcG2ANHWAw8YRthhh4giMwRgBKD/JXP5M7sgZB076BUyDtnKTG6f9HA6xioylbpG6AHUyRzZnxk1mYAbjcigBGINLUvnXcbh2gktTASOyOOfC/EbtEgfG0jMaPYPhcJjQUoRxBkgdpGCrMfFwmahaxEYWbPAXUY0/ED0Gdcl1g8nZsBfIN3J5vQUwcm2cw3VZSdbWqfvK1ApcmF0oDNNtFvrXYHPfSR2QkjYSOtMtOtNNXCcBG0mE8J6SZqyI9xycegYjU4RXhoEkxRlHcWyAeF4FG1tc6iB14sahn1CmLlE8Rm3byVljvJXnlJpZgKAiHaSvNvOt5bSMIQ6Wa5Cbfy6ZAKbwNhc2+fT86IeVNmkzoT0+S2eqgYnyKVilNHRB/Hz0n0rgxhhIUzBQXjJMceEAxhjSdipAYDTEiOieFYdTZek4zqcXcRfn5JzRPkEEdyAQOBlPgMwa+jG6gDB+3qBSDXPCgHieTCxsZ2Masa1w3jgNu50UlziiUkRp6RDFhYO4VGTznmx6hkGodzDUQh0W51Kcg+LSIeKRCrRFKOMTmFd3iON63Q+lVujDsvdiZ8SaHDKQMw4jWVJ7an/1ABlQ47vzwqtF5kJTNpe3Vh03n3QVCeNPK+BY+e5ziA+pwasTmauwoEppbECM0VuE8tEr9Q6GF8s5XOIojFaIh8tiITg1B80jQesKhFqLfDOZNVunCVv7qzGH7s6ohQvQfgRpKsoIOOm8xkgI6SLnG3qDkO/ee7JckSsakD7OFw1hSG2g4SfYfuIojFWJB4u4RBp4vHul3sHwAjmHLUQU5lUgyYWJMKkIJ30y0b3WUqcaz7mwHzpTi1qUNuhydqP27aCRWqbalolWxP5WxP5mxEQrYqZt6ARwvWd5s9B8kgc+ZzR+jhDvlCdDzkOVBxVDw52IWxgbwMRWE70O3iP1kcClmUscxfkVCosGcUkKKM+qw+655570wKnKfZzScCFNMiEkZGSubg0kzlBrWToJLKokrB7psGwgYbSQ0uzA7kaBLbWYrdOWmY5hsOioFgS8jBPvyd4TjOQswCoQWfrW63kwc3IEw/ECRIbW7hrtiTpEWmH1CEjvYOBwmpyLy4eIqyVIJIlnSn8eQA6ULdf3wMue/H2HxTGbWOoty4ljLV531DSnL51hzVCboTgVH3eGTmLY0YzYuK/ILc8M8KOtA4w3LSOllNgCqc9FMlOqjPj7IZ8rMtVnfAlp3kHByOVCACJLMt2ksaMmWOVkPBj1AQaQpJg4orRiGFuMIFXWxLBIncFqovcMdLm/P90FhChGaxsJVbmc4IDIOPY3LYMF+N/rJjh/7SSLqh1oG0gMpKoYD7p1EInX3rW3wmfuH+VfnhmkUkipRCmJJvOgIxf+dPN4wEFuDqfhMpxXsoa0mdDcNkGaphjbeybovaWy5IzcQ5D6M/LhEJ4kHOSqFkkGclGFEFJ3d6JIAxhtH6KXgjPeiFhZTbjmjJ184EV7WRR3YDbCtQwulSzpUg1FiYG2hUYErYhTFzS4/sxdXHryOK0OzHYMkefJEarALLc8B4+GcB8iHaW/MyZ3syn/jJG7bje3iOiB+gID1I2tNwaNnposhfGcGn2i9G7vCAAZJ+s54ukisEEqrQCIgclmxKqBhGvP3MVZK2ahHuPafvlBx/FjargJ3pg6XCOikBoufdE4l586TjuxNJMMfG9AHpiQnPWvpBYtbRH+0fsN5zTc5UomKWgyefqhnsHw/HYf5BgM8/pzHjCxOm+MXlSnCRqfqF1+7UssrJEYqgXHJ166h1MWNcQbVCnSVYXO85JFkWyOjoG65d3H7+dd6yeYavkFjjyTQbqcQflj/yUrJlzgQcOil8VLmcs7vVLPYAjNYbDrUKO+UQF9+YK6h/NWppaYAyBIq0sZzhhSoNaKeMcLJjlr5TTM2mCAIWI4IHJQTvVfAsUUbHbnIItEDlIJX+87cR8vWVxnoumNQcJpGNiJZxmQNSkn3ipzB4vKMeKV4L3Shy893Qf1DIbBZdHJf+YmTDGkSLjqQkkbeb4dmhuCDCqAiBP6Trct6+e1eNvaSWhHGZL4DwMlmEgifvDMEJ95YIyrN83jrvEyrmAgTmU075KAaxuGSwnvPmE/RWNoJcqDNpBwaeRmM6dNr38fCsP5YFVynJXDefl7p57BEDh0zckrVc+jbpkpLJcUUZdwKoguX0uC1746Uq3RYKbZxBhLO7G84egaS6ttaGk/b8TGQDnlJ7uqvOHHyzj/p0u4/K75XHbnGGffuoyLb1/Es20LhdSH+HDrRtNy1rI6v7W4wUzbhFLWaP5WWHR1wJ83JKlj/+wM49M1ktTJ/YhvG0gU48ELwaFH6gMMJeN0vcYnPtGQs+r2arV+GcFggmDZ4p2waI0hTVMm69Psn55izcKl/N6aE2k2U+YXWpy1fEbCiy4iOi9lMeX23RXe8bPF/PrZMpViymglYaTiaANXPTzMJbcvppZakMcqml9SSA3lKOHVK2dwWLlRNo7UFxzCvkBnLM1Om/GZKerNBi9bvYY3v+gllKKYVpJIW+c9RjsqiZPl/ejg1B8YRv54axMTUMty3iRyFuOF0z/iPQ5jRQn7Z6aZmJlhzcJl/PVrzmHDRZfykpWr2bF9F6tLMxw3nEBHaxtfnVhodAxX/GaUXQ3L0mqbghVwDVCNHEsGOnx3ywA3bh6GOMeEDz3O8OKxJsNRQjvxvilBRj4NzbTD3toUnXaHVx57Ap875x1848L38/lzL+KEpSuoNesBgOdM1Jll9kx9gSFx3i+Py3ecJG6D3N3603krkSOxtHaSsHe6xnSzzikrjuJTb7yADe+8jPe+6g0sHpnPwzu34ZodjhtpUS0mvizKFBqnPDBR4t69JeYVExKnsV5ndM5QMA5rHT/fXqWTCoDG+SoOSA3LB9osrnRopqI04c8w02yxZ3qSKHX8/gkv5qsXXMwNb3sf55z2MirFMpG1DMQFNX0/qQLiDTToqj/qCwxhOtW4n3cMq2VkrjJRkjaGZqfDs9OTtDpt/vsx6/jCORdy40V/zh+f/iqWjo4BsLc2yeN7dmHiAkuHZJ4MeQXFwM5GRL1jiG1OelW0t9OCgX2NiNmOlTDpWyoiQwXHgnJK4sSUppsN9tQmGSqVeOtpL+drf3wJXz7/Yl51/ClUSqUwRydNSFL/GM9bv/eNvOzdvPVCfYEhzxukpnL5myvILEVJvhrq7RbPTk9hgd8/4VS+ev7FfO3C93POaWcwUh0AYMe+vVz9bz/knKs/wV1PP06xXKakoceTQywQBwuLKaVIFg1FJVkS9nfKiTMMFFIqNu1etlELjiNHKZb1tqn6DIsGhnnvGb/Hhndeyuf+4F2cftwJRFEEwC8efYDfPLMZcsYVvmuWN5rQAuAe9T6oLzDI2YBUR0iAMrqe5BAWnWGm1WRPbYKBQpHzf+sMvvn293Hd+e/l1cefQqUolrZ5z07+7ocbeMNVH+PS73yV+7c/TSG2OGPYMR1p8vYVjVQ4dAzrR1usndei1rJY/4TQ+EpGOGwmhhcvqlMoSNJ2mut8yZQ4Q602y9T4Pi449Qxu/pO/4MNveCsnrlwNQKPd4l8fuo8//vKVvOmqv+Wepx9X+TWH5TTiT2T3GXqiz5uNvsGQ4TVHIII5l/mIcdDstBirDPDul/0u37zw/Xz23Hfx0mPWEUcxAPdv3cwHv3MDr//SR/nwLRt4ct9uRgYGGRkYwBpZbHxo3FJv69KLkgNILMOFDu85foKiNYw3rJbJ0iZxlp0zBU6e3+DcY2qykDjXQi3sqxs2720xZA3n/dYrOHJsCQDT9Vm+e+/tnHfdFbz1+s/wrftup5l2qBSL3WN42/feRrcx9ucTQn2BYfy9gk6fkm0+QIGaaTUZqw5y9Xnv4eNvvIBTjjwWgDRNue3xTfzp16/iTVd/nE/97PvsmplkbHCY4UoVi8GlIlA5djy0N+LR/ZFUQ3oTbZxaXcvy2iNqXPHS3SyspIw3YvbVY8YbEfsbES9d3ODzL9vNimoH19HwITFFBIkcm/ZGPL0/5cVHHcm6lasYn57iy7fdyjlXf4ILv/ZFbn3kfqI4YuHQCKVCIcNT05g3PxMACbap37Xk1269UM9gePdz/sCT5wLAGNpJhwWDI7xwxVEA1Fstbn3wXi64/tP84XVX8JVf/5xas8HCoREGi2XN0d7TFAwLz9YtP95SFA5N5ougSygty3nHTPKdV2/nw6fu47xjpnnbmik+d/ouvnXWdk4abeKaKp4PoSFsGP7lqQJpajl+xQq++quf87ovfJj3/dM/cMeWxyiVSiwYHKZgI62SfD/t7ctsvC50gjxIWhj0Qz2DkRmWZsoAQUgWiAUakjSl3moCcMfmRzjv+iu5ceOdJMDCwWGqxaIoVZOqC+WpCmIgjlK+/0SR/fUICt7SRAmhhG9FvGCwzZ+eMM5nXrqLK16ym/OOnWJBlELTarLWCbwJFx1PTBT48eYCw0NlfvT4Jt5/01d5ZM8ORqpV5lcHKUQRqfImUs1Rq1e6D88hTGvFp4Zrgo56o57BABnZVy7kHEQSrNdQt+PUGrO004QFg8OU4phU9yhJ9RF0jJGtd6F3NXbcsyvm1qeLUHSqEk85D20beXbRlqUOGpr4/VgyuBiSdRDDhkcLbJ4wDBQNtU6bgXKZedUBrNHVXA2JYZRM5Gw8tLLw58gvDuruky5NHJz6AsP5xKRlpxa53kMzd86ZQxzFlAoxDtneI88yfJyVSkzG9g+i5EFRbKGTOq7bWGKmZTFRPgxkY0gpKw9PhQdtpxWNIc0KjIJj22TE1zeVKEWOuBBTLhWIjMGlkrCEx26Hyubt/i64+IDlt+iodfYJBP2CYfyEeqftvP6N59yHkjyp+kQ3OeDkfAgAgX8jOw8cjJQdv9xe4J8fLUHJG6I306yUkPtnnTcMpypy8t0YoGi4/sEyj4xbhkoOU4ghFAYKrPE7XrRSDErNpPJ1gHxkLTIU0fbdmjgY9QWGjO8n0X8+HIuGFSHPqHbyHhVQ8dKoON4j9H/SyxDrjeXn7y6zp2ahoM/LjY7jkTV+8JyW/FxGlVNybNoT8eWNZSqxI7IWq6V24NV/MfI9BMZcRPInvCmJXPmL2flMmt6oLzDCNLo1Uv75R6U5QHLeYYzB6CovHovcNfzallZU0iyDZbiccu/umC9tLENROPY4YHSisP+yW6EOZSoSwK+4s8r2abkzJ46wunvc70DxIIhy5bFwd8JQBvUxQGaM2kCNyw+kmaVn6guMTMUemDl8eq+Zaw5OWfNIGKm6/AJf8BzjBcrmiQ0MllKu2Vjmrh0FKOn10MTvNtRlew2VGXMWKo7vPlHixkdLDJdScGDjWDzSSbI1vo8h2zrq/+HRF/Kn5LuHQsbwbAkMcxXx/NQXGNlD+W5lBHLyp9trPasCiFeAf6pG2ACQPYLN6iZH6uQ5+LN1w9/cVmG2YyD21Qoigsu2lTp9TCpKNZiSY+d0xEdvr5Kkuh5lDTaORdddGtTkrze3QQxp6FmS6KiG5XwoNOJJXbL3SX2BAWo1PlaHk2oJagxdWARVisKfi5y3trmkrxU4B/PKKbduLnHtxiqUVHEQJlQsMsXpoC52fPLOCvfttoyWU1wKxlpMLJsbvHc68jJ5wwia9xcU5OwQMrG8HKqGObnk4NQXGE4tLyNvLX56eQrYrXLJBcJoiLR6SYU1kn3CcGisdzqmMcTWUCo4PvnrMvfsKkAlp6ugvDlUTfjOY2Wu3ViW8KSLilEcY/3mMg8cGZpiWArOXM0rS55Zfz+RRUfvHZJb+6G+wPBMZA4sk4XwFU5lVUReFAdhp4WP82gBIEf58Jc7VgUMFR27Zw1/9YsqtZaR6krH8N0MqoOyY+tkzOW/qNJOoRIbUt0FaAtx17j57z7tdXMeRJ37NXRXNnL6f47ceRDqCwwN8cEK5VNWVhUDtZAujcqRIKGngsRy3TfIrf76ECXqc7I8AcyvpNzyVMyn7qpIMjdqnXnlRtAyhg/+YoBNeyNGK6nsfncOrMHEsUafrPjMIJVzvsACX1B5zvJVHyqw8qrbfHCEYqYfPPoCQ/Tp3c9XD/JdKHPRwKyGEWkrfUKsNgKQV4RDly0C+c3Wel10yXDR8dm7KtzyZBmquTtQBESqjms2lvnGQ0XmV5Oc8ThMFGOjCBxYZ3SXh/ASwnBYc9Ih0d3pfnxv9E6uSqgMhzqZLDUHPfRAfYHRTUH6Oee7rSF8V8zkON8nszMRJiSC5xjbkTqoFmA2gUt/VuWpiVjLXW1eSfnl1iIf+WWVYuwoBOXI5SiOMk8MU4shSLhURv310D0vlYaHXBExN8Tiwc2dOhj1CUamOH8sjpkxlQmjLXRRzaGWSS6wqsk6tUQxUp1Dhwi61D5GX7iZX3Y8uDfm0p8OMuuAGCjAzlnDB35aZbxuGC6KmgRbCSe2KHfd3vqDTvXGFXQvVcAjbxzaNQAloAjf+XJbYtxcbR2M+gPDx93sRKb/3KncR/AT7+WhTyDfQTONQaoef1mVEk4EJTrGqik3PR7zyTurUHUkEVz+80Hu3B4zVklJUuXXh0hrMVF8wPQSRsVoQBcLVY1OWJvjGdrPIRJmEdcLoI36gaJfMEKyFcvxrhnCKVbnz2JlGrwiX0HNJd3gEJTu1RIO1Zl0+V3Px8YxVHJc+esyP3qyxA2bynzlwRKj1TBr6Ouc/mCAtRkzLpMpf8+RPU9XXjwigVv1eJWVUJp7wHSsLsM9OPUFhsyVMeWC0uWvBptuxoNGvWM9F4O5vbe5GbysWRc/j5DDUI1Fa3/yo0H+5rYqAyVHMUJfNxCFS3sBI4+yV7rTwsIHFj+f32kCXWILOT+whiqfNzx3gticTs9PPYPhle7IK1SF9ccaart4EPkkTOiBDwkmpwQfpqVJhqDRSiwkQ43xPk6nDioFGG/AZEuenzuQsgthRsaVJRAxIB/n88HIM69iqaF7nvIiCQa+vYDgjOQ1eaXZ6iDBinqinsEQUgWZzACkxM9Emhtb5Sin3JxUclaLgNyOChee1AH69C1TjF4TjYAm9HLkKNrcnbi+IC9NHcZGoaTV6lVCo0F3nWt7/zxec4mcMxSsJP5SHMvDKMRl/U5FED3IWpVI9V/mGU4VL980BHg2jChJrGJOKMp5je/v/LK1HKpe1eT9mDkFebBlGDkjVq3fc1eCG5ENBfK6tIllU5rwL5+eDN71wpG2cVhrmWzMMlGfYdfUBJ00lcfEQdnqHZr8/UD9QdEHGKi+RFBVmh5nySr/KoDv5I9FQGE7FwdCrPWJNosPEs7EPvPx21ufDO/zlrdo6es0MfvxQ+L2sd6X2TJILuyoKg2AJbYR5VKJv7/9x5xzzSf4g+s+xcadzzBUrqgWhA/xFO3mZDn/ufPjf0x9gZEx6Z8diAaDLKr0PKk+vEpVWT5m+0YuqFV0ohrxXoMob66naJMwpz92GmpU5zig02zR2F+jOTVNqzZNszZLc2qGZm2GZm2a5lSN5qScb9VmaNVmaU3P0p5pkM422bJrF/dsfpwHd2xlttOiYOesiGbKgWCUues9UF9giO5zXqCKcajivLLmMplb8vBgZsxLeNPSQDYVGyM/OaHAeLDzYQH02UjulCR2WeIQXj0T8tNELklwnZS03SFpt0laLdJmm7SVkLY7uHaHtNUmbbVJWh2SZouk2aA92yRqdii1EgrNjvzWlC9tczlTmMiJ58Nlj9QXGDJJFiLQIELOMLqA0DZdZpJn0HsIhtlWk4nZWaYbs+yfrtHsdMKdsAfbA6MDZWavPGCg2WpRa9apt9vhnDWG1KXMtpvMtJq001QAU9CbSZvpVotm2sFgmGm3mGzMMNWoM1FvMNWcpdZs0OokuE6H1tQM7dl6lp9ygKgZyFF/WPQHhoRAnUz1IKFJz/twnKknF9/zzxzkjtc5R63ZYO/0JPPKVd59xu/ypbe+h9894RRIEp6dmqLeasl81t9QIj7pS9YwogMMCweHOGJkPvMrVVLdxpI6hzWWpUPzWDlvPpW4oB4ISeoYLlZYOTzKgsogBjhmbCEnL1/FCUtW8MKlK3jh0iM4ev5C0jSlVm9gjKE9U6c9Uw9y+Dzn84Twc4BlPi/19QsJLkmJChGlFSNSmbhUjEOTujUwUZ9l3eIj2HDRpSwanscPHribC2/4PHEUEUcRFkPiUmqNOq2kzTFjS3jdiafyplNOZ93yVQDUm01++chv+PYdP+eWB+9lx+QE5UKRwXKJyEb6YzB5h3C0koQ0SbjyD9/BK088jQe3buai665kojHLbLvNa9a/iI//4TuolMtc+6/f5xM/2EChUGS4VOIL57+HF61ew/fvvp2/+uaXueFdH+DFa9eDM0SRGMFso8FdTz7Cp2/ewF1bn2SoUsXhKI8MYeI4FA4gv0VV3zaJ6yT/db+QgLdKkDdW1VvEJX1d022xRr0IzQf769NMzkyzduFSPvSat7DhnZfxwf/5vwIQAJVSiVeeeCpXX/R+bvqzy7ns987myNEF7KvV2Dddo5MkOpOMC444iphuNtg/M83S+WO84viTOWrBEmabLVyS8Dtr17F62QqWzV/Ay9efRLVQpNZosGLeGGcefzLL5i9gsj5LrT7LgnnzGB0aYXR4mIFymYFShSXzF/DaU3+Hz7/tT1kxMp+ZZhNSR6fRzBYWReBQQGQLh71Rz2BkYcdPOOeceqWUoTlnM9ByHcZnatSbDU5duZorzr6Af37X/+Xis17P0YuWgm7F/8adP+eyf/oHfvbw/bQ7EvNftHoNf3Pu2/nBpR/hk295O6etOoZGo87eqQkaSUvrfRtywC8f24RzjiiOecGylTRbLYZLFY4/Qt67ADh26XKOGFtI0mywevFyquUKzjnueHQTxlhS/bWgXz/+MK/5yJ9z5gf/jCtu+gZJmrBu1dGc+YITqTcbYAxJq0OadAQLJ0Zp/B6wAxPo81LPYIAoNrvfDCe6j7tP0Gi1SNsdXnnc8XzxLe/kxosu44LTX8WikVEAdk6M8+V/v4Wzr/oYF3/7Wj7/bz/krV/5DH903RVsuPs2xqenADhi0RL+5DVn870PfJhrL7yE1554KiZ1PDs1wWyzCQ5KhQKP7tzGrv3jABy/8khckrB03hhrlx8ReFoyOsZxi1dAu83aZSsxxrB3coJHd22nVCgECbfv38ct9/6Kf7/rNq68+UZ2jO8FYLQ6INtBMfKrdEn265D+EbR4RpiyJ+oZjC4V+5jts3jIzC4sA/gzaxYv4yvnX8zX3/4B3njq6QyVqwBs2bubT93yz7zxqr/l/2y4nruf2Uy5WGbJ8AjOwI8evp93/uMXefPVf8sXfnozW/buBmB4YJA3/7dX8PX3/iU3XfxB3v6ys5hXqtBoNykWimzbP86DW54C4IRVR1GOI9YuXc6y+Qt5Zs8utu7ehTGWtctXQhSxZtkKAB7csplt48/quxjC/cKBYU47dh0nveCFnHfmq1k4MspMfZaHtm8ljmPJl6n/GVkx1CyddZttL9QzGKjuBe3uiA3ZfYLRGObBW798Ff/j5N9moFwB4KHtW7j8u//I67/0MT70LzfyyJ6djAwMMlodJLaW1DmKNmbB0DADlQr3bXuav7j567z+qo/ylzfdwH1PP4FzjmKhyOnrT+KLF17CTZdczprFK6g3m9SaTTZueQKAVYuWsXxoPmuXrcRayy333smPN94pfK08kiXD81i9ZBkAG596gql6nSiKghJfsnYdP7n8Cm776Bf4yB+9k3KxyHW33MwPf3MPw9VBQHOnV4evLJ1GkFBp9kZ9geHyN1pOfrvVkDFijCF1jsjY8MqYpzuefJhLvnUNZ1/1Ma746ffYNrmP0cEh3YqvP8Kl9boz8qZTbCNGBwaZVx1k+8R+rvzZ93nTNZ/goq99gVsevIdGqwXASauPY/3yI2hpnrlviwA2f3CYtStWsV5f3PnVEw9x15OPAXD0kmWcuPJIFg7PA5AXKC3YXAzoJAlT9VnGazWm67MAvPCoYzh28dLw/gk+NGm+VOWEQqcf6gsMqZdctvDj5/O1tZMbrEanxWyzTqPV4icP38fbrv80b7nmk1x7+7+yv1Fn4dAIQ5WyrHL7ciz/cMdlVuX0seZgpczC4RFmO22+ec9tXPCVz/Dmv/84N9zxE/bP1Fg+Oh9rDcVCgU3btrBz/16pytafxPqVq6g3m2zc8jQPbNtKq91i2egYZ647meGBQcanJnlw25awEdob9B2PbeJVH3o/Z/zVn3HuJ/+aLbt38vITT+Gy170FkoROkgCm63UQXQbQ4/4CVV9gOL3h9DdxMqXf8SG8DJQq7Jyc4JJvX8v513+a86//LBs23kmHlAWDIwyUSmI5qV9r0tCmY+kKlkqmwOMXI6FSLDA2OEQUx/xi80O899vXce7Vf8e9O7YyVK5SjAtsG9/Lo9u2AvDG3zmTY5ev5PEd23hqfA9b9u3mqd07WTgyyltefhZDlSqPbNvC1r17KPmXKFWHU406m3Zt5+l9u/n+3bdz3+ZHAXjp2uM5YnSMVqejXBvdR9wtST539kJ9gSEkyhFkxCH99hZwxMZgreEnjz3ALY/cD9ayYHiYclzQhO8VLCboc0zmaT4M5pcacsseToQuRDFjA0MMV6vcs/1pfvXMExTiiEJkmW41uWezhKMVi5dSLBS5/+nHqTXr7JuZ5oGtm7HWssrni6efYKpZp6jPOzwNFYocPTrGwsERXrbuhRy/6mjPtrLjMNZIOaz8eUPyOy89OL1Qz2B4XYTSTW//xSNzd58IByOVQeYPDFH02+4RBeutogDhz+fJ4xROaAs/friRkr7WWIYrFapaIFjkAc+9mug9/frxh3FAO0257yl5p1uH4Z7Nj5ECkcTNsPXzt9es5+Y//wg//ouP80+Xfphjlkl5/MO77+SZ/eMUtaIysT7bmKOD/vyiDzCMWkSaOlya6o2eLKXn0XdG7zwNUoOTgSj8KhDaFuPf8dN3NLwCQyhUAJ0ygOQR5LKA4hw2ijCRLEuU4gKP7niGfVOTAEzNTHPvlicpFQoUopj7nnqSZluS//jUBJu2baFQkF2G2CyFV8oV1h15DCeuPo4F80aZmpnmultv5mPf+xZRXCC2lqhYxFqLSeVVAxFc3xnpk/pam5LfOYfi8iFstYhJ5nQ1hIXDkIyNWJtGl+wxpcZYfD3gr4e2mZkZHdsvM4Qop2qTKGdIWi2aU9MkqaMQWV570mmsmDfGzon9fO83d4Vqq1Io8Yr1JzFcGWDv1AQ/ffh+eXoHxFhOX72G+YPDJIn/nRRDM014cs8u7n/mKUxk5Y1dC+WRYYj02YZxYC3JdIvGjikRwcvRA/UOhg8paUpxQZXC2ACu4xUuTUTt8vdAyp3PKdPRva9VXU4doTuU+W06chD+hJVTYyyt2Vk6Mw0cjulGgyRNsMYyVB2QZ9fGkCQdJut1nEuxNmK4UiW2utnNOabqdRKtlPwOEgxYaxkslYmMIbVQGhwkLhW6wiHW0t47TWu8Lm/65IzmYNQ7GCBKSlKiSkx5+TxRTprli6Buky0O+sF9xWXE/EPJ6sOcvMolo2Rw+I4yFtoXf6jnZJzsPqXTaNKpN3GpbHj22/bDnit95Gr9r2R7a3DCh9HCQjwupx7/tRBRqFaIiwUJ2Sq7N4rGM5MkzY54jF7rhXoHIzzylHBVWDRIYX4V2vKLZB4Ioz87JHlDClff37uQ0ZDq07lXuPQUdvKKE/JASMPM+/3GBc07RqoKhyPtdEjbiawdKVgyns9BfkYtr52Or6C6jCkByFrZCFcoyH8/I5cXnO7Lao/P0Nozg4ut3i8p7z1QH2D4P2JFJjKUVg5jS0Xo6I97BLQOJC9caOKy8kEMM4jv9SZ/nIAlbZRVXzbqQF6/cs13M/IGszUgEUeVK+FMJJEfbArknVPB9twaDC4YWTZOl7CxIa23aWybhARcJPL8hwp5Duq5mvJSGqPvY3QSmjuncc0OJlKr9cYFyoSez8X9kAOCtrMCUPzEbwMKuPuv8ifnFc7lgHAZSPKhN5WJvpTv9O0io4312DnlzwOBfxQsJ2RK+c0qUodzWjUpKA6HiS2uldDcWRMvjNTp0NjcI/UORiaD/IksaaNNY8cUyWwbIouJbE4QYUIigddWgEjIt9EQIxrJlbe+vYY06eNDTdBe9plrkyfxKK86BRGZ33tjvpNnBTUe1GSc90LUMK3BxpZ0tkVj2yRps4OJImntX+4Pwh6c+ghTGcuGzDxdx2EjQzxSJp5XxhYjsczcb/+JW4tmpVcGTvCQnG6ln5zXbqrMrp763YGxBxYMOTX7Y4KhZq0screcvXKQ154LEuBVYHVk53CdlM5Ek/ZEXV7qiUwmsRYJueR2UOodDNWWrxgyJSmXKZiClf8aWSXGFK1swXfd9wXSLwdSUG9QrSpEWx5gXRkc2elcvtHrhny5nAdDN1nnQmp4Da2Ln9A1FCOpA5OmpK2EpN4hrbdJO7J0bazJynKH/iqbgNErHL2D4fSPn0SdIz+RSwlPwExEUKv09JaSiZwn0XnuitF/qcgYxglxn0xpqr+ucXMKN2TVq9Ex/PhdjwFyJE38wPIpHu8FVS+xuqEv8JJZn0PG7RWOnnOGRkwcUrIZLUfT7IfSMAZsbCWhqyacWgp+76wGZP/dOf1v2jnC5mdpIufFBjTB6sWsr2+n3/VT3pHxc3nH9d/Vg1Jpj1O5Qj+9lp9Tw05ANrIQi+d77WTWIutUvjT3BWAv1DMYxsjqpFiRr0l1I5iamQsvjeg/a6St1e9WNg8c8C9cn9PPj5P/bvPn/TU5J3urtBoLc2XtnDE4fy7wluuf41s2OoiMbu68Xl7I5A1yq2pUP3KtN+oZjMP0X0+HwTiE6DAYhxAdBuMQosNgHEJ0GIxDiA6DcQjRYTAOIToMxiFEh8E4hOgwGIcQ/T/gfRHwTcJLGAAAAABJRU5ErkJggg==";function y(t="official"){const o=t==="compact";return`
    <div class="app-pdf-footer" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-top: auto; padding-top: 10px; border-top: ${o?"1px solid #94a3b8":t==="bilingual"?"1px solid #c084fc":t==="legal"?"1px solid #d97706":"1px solid #cbd5e1"}; font-size: 9.5px; opacity: 0.88; color: ${o?"#334155":"#475569"};">
      <div style="display: flex; align-items: center; gap: 6px;">
        <img src="${it}" style="width: 18px; height: 18px; border-radius: 4px; object-fit: contain; vertical-align: middle;" alt="${H} Icon" />
        <span style="font-weight: 700; color: ${o?"#1e293b":"#334155"};">${H}</span>
      </div>
      <div style="font-size: 9.5px;">
        <a href="${at}" target="_blank" style="color: ${o?"#475569":t==="bilingual"?"#7c3aed":t==="legal"?"#78350f":"#1976d2"}; text-decoration: none; font-weight: 600;">Get App: play.google.com/store/apps/details?id=in.svt.wblandsinfo</a>
      </div>
    </div>
  `}function bt({html:t,title:o="Land Record",caption:e="",designId:i="official"}){const n=new Date,a=n.toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),r=n.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit",hour12:!0}),s=`${a}, ${r}`,l={html:t,title:o,caption:e,formattedDate:a,formattedTime:r,fullTimestamp:s};switch(i){case"modern":return rt(l);case"compact":return lt(l);case"bilingual":return st(l);case"legal":return pt(l);case"official":default:return nt(l)}}function nt({html:t,title:o,caption:e,formattedDate:i,formattedTime:n,fullTimestamp:a}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${o} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1a1a1a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Times New Roman", Times, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .official-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .official-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      position: relative;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .official-header {
      border: 2px solid #175953;
      background: #f7faf9;
      border-radius: 4px;
      padding: 14px;
      margin-bottom: 12px;
      text-align: center;
      position: relative;
    }
    .gov-title-main {
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 0.8px;
      color: #175953;
      text-transform: uppercase;
      margin: 0 0 3px 0;
    }
    .gov-doc-badge {
      display: inline-block;
      background: #175953;
      color: #ffffff;
      font-size: 11.5px;
      font-weight: 700;
      padding: 4px 14px;
      border-radius: 3px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      margin: 4px 0 8px 0;
    }
    .official-meta-strip {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      background: #eef5f4;
      border-top: 1px solid #bcd8d5;
      padding: 6px 12px;
      font-size: 11px;
      font-weight: 600;
      color: #134e48;
      border-radius: 2px;
    }
    /* Standard Tables */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #175953 !important;
      font-size: 12px !important;
      page-break-inside: avoid;
    }
    th {
      background-color: #175953 !important;
      color: #ffffff !important;
      font-size: 12px !important;
      font-weight: 700 !important;
      padding: 7px 8px !important;
      border: 1px solid #10423e !important;
      text-align: left;
    }
    td {
      border: 1px solid #cbd5e1 !important;
      padding: 6px 8px !important;
      font-size: 12px !important;
      color: #1e293b !important;
    }
    tr:nth-child(even) td {
      background-color: #f8fafc !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .official-footer {
      margin-top: 20px;
      border-top: 1.5px solid #175953;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      line-height: 1.4;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="official-wrap">
    <div class="official-header">
      <div class="gov-title-main">Land Record Information</div>
      <div class="gov-doc-badge">Record of Rights (RoR) / খতিয়ান ও দাগের তথ্য</div>
      <div class="official-meta-strip">
        <span><b>Location:</b> ${o}</span>
        ${e?`<span><b>Details:</b> ${e}</span>`:""}
        <span><b>Date:</b> ${a}</span>
      </div>
    </div>

    <div class="content-body">
      ${t}
    </div>

    <div class="official-footer">
      <div><b>Land Record Extract</b> • ${o}</div>
      <div>Date: ${a}</div>
    </div>

    ${y("official")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function rt({html:t,title:o,caption:e,formattedDate:i,formattedTime:n,fullTimestamp:a}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${o} - Land Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #f8fafc;
      color: #0f172a;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { background: #ffffff !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .modern-wrap { padding: 0 !important; min-height: 96vh !important; }
    }
    .modern-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 14px 20px 14px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .modern-hero {
      background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
      color: #ffffff;
      padding: 18px 20px;
      border-radius: 12px;
      margin-bottom: 16px;
      box-shadow: 0 4px 16px rgba(37, 99, 235, 0.16);
    }
    .hero-badge-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .hero-badge {
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 10.5px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .hero-title {
      font-size: 18px;
      font-weight: 800;
      margin: 0 0 4px 0;
      letter-spacing: -0.3px;
    }
    .hero-sub {
      font-size: 12.5px;
      color: #dbeafe;
      margin: 0;
    }
    .hero-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 12px;
    }
    .hero-tag {
      background: rgba(255, 255, 255, 0.15);
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 500;
    }
    /* Modern Card Tables */
    table {
      border-collapse: separate !important;
      border-spacing: 0 !important;
      width: 100% !important;
      margin: 12px 0 !important;
      border-radius: 10px !important;
      overflow: hidden !important;
      border: 1px solid #e2e8f0 !important;
      background: #ffffff !important;
      box-shadow: 0 2px 8px rgba(0,0,0,0.03) !important;
      page-break-inside: avoid;
    }
    th {
      background: #f1f5f9 !important;
      color: #334155 !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 10px 12px !important;
      border-bottom: 1px solid #cbd5e1 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
      text-transform: uppercase;
      letter-spacing: 0.4px;
    }
    td {
      padding: 8px 12px !important;
      font-size: 12px !important;
      color: #1e293b !important;
      border-bottom: 1px solid #f1f5f9 !important;
      border-top: none !important;
      border-left: none !important;
      border-right: none !important;
    }
    tr:last-child td { border-bottom: none !important; }
    tr:hover td { background: #f8fafc !important; }
    
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .modern-footer {
      margin-top: 20px;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 10px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #334155;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="modern-wrap">
    <div class="modern-hero">
      <div class="hero-badge-row">
        <span class="hero-badge">Land Record</span>
        <span style="font-size: 11px; opacity: 0.85;">${o}</span>
      </div>
      <h1 class="hero-title">${o}</h1>
      ${e?`<p class="hero-sub">${e}</p>`:""}
      <div class="hero-tags">
        <span class="hero-tag">Date: ${a}</span>
        <span class="hero-tag">Format: Modern Card</span>
      </div>
    </div>

    <div class="content-body">
      ${t}
    </div>

    <div class="modern-footer">
      <div><b>Record Details</b> • ${o}</div>
      <div>Date: ${a}</div>
    </div>

    ${y("modern")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function lt({html:t,title:o,caption:e,formattedDate:i,formattedTime:n,fullTimestamp:a}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${o} - Print Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff !important;
      color: #000000 !important;
      font-family: Arial, Helvetica, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 8mm 6mm 8mm 6mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .compact-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .compact-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 10px 12px 16px 12px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .compact-header {
      border-bottom: 2px solid #000000;
      padding-bottom: 6px;
      margin-bottom: 8px;
    }
    .compact-title {
      font-size: 15px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 0 0 3px 0;
    }
    .compact-meta {
      font-size: 11px;
      font-weight: 600;
      color: #000000;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    /* Strictly Monochrome Ink-Saver Tables */
    table, tr, td, th {
      background: #ffffff !important;
      background-color: #ffffff !important;
      color: #000000 !important;
      border-color: #000000 !important;
    }
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      border: 1.5px solid #000000 !important;
      margin: 6px 0 !important;
      page-break-inside: avoid;
    }
    th {
      font-size: 11.5px !important;
      font-weight: 800 !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      text-transform: uppercase;
    }
    td {
      font-size: 11px !important;
      padding: 4px 6px !important;
      border: 1px solid #000000 !important;
      line-height: 1.2 !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .compact-footer {
      border-top: 1px solid #333333;
      margin-top: 12px;
      padding-top: 4px;
      display: flex;
      justify-content: space-between;
      font-size: 9.5px;
      font-weight: 600;
      color: #1e293b;
      opacity: 0.92;
    }
  </style>
</head>
<body>
  <div class="compact-wrap">
    <div class="compact-header">
      <div class="compact-title">WEST BENGAL LAND RECORD (RoR) - PRINT LAYOUT</div>
      <div class="compact-meta">
        <span><b>Location:</b> ${o}</span>
        ${e?`<span><b>Details:</b> ${e}</span>`:""}
        <span><b>Date:</b> ${a}</span>
      </div>
    </div>

    <div class="content-body">
      ${t}
    </div>

    <div class="compact-footer">
      <span>Eco Ink-Saver Layout • ${o}</span>
      <span>Date: ${a}</span>
    </div>

    ${y("compact")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function st({html:t,title:o,caption:e,formattedDate:i,formattedTime:n,fullTimestamp:a}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${o} - Bilingual Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1e1b4b;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .bilingual-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .bilingual-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .bilingual-header {
      background: linear-gradient(135deg, #4c1d95 0%, #7c3aed 100%);
      color: #ffffff;
      padding: 16px 18px;
      border-radius: 8px;
      margin-bottom: 12px;
      border-bottom: 3px solid #c084fc;
    }
    .bilingual-top-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 6px;
    }
    .bilingual-title-en {
      font-size: 16px;
      font-weight: 800;
      letter-spacing: 0.4px;
    }
    .bilingual-title-bn {
      font-size: 13.5px;
      font-weight: 600;
      color: #f3e8ff;
      margin-top: 2px;
    }
    .bilingual-docket {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      background: #faf5ff;
      border: 1px solid #e9d5ff;
      border-radius: 6px;
      padding: 10px 14px;
      margin-bottom: 12px;
      font-size: 11.5px;
    }
    .bilingual-docket-col b {
      color: #6b21a8;
    }
    /* Bilingual Tables */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      margin: 10px 0 !important;
      border: 1.5px solid #7c3aed !important;
      page-break-inside: avoid;
    }
    th {
      background: #7c3aed !important;
      color: #ffffff !important;
      font-size: 12px !important;
      font-weight: 700 !important;
      padding: 8px 10px !important;
      border: 1px solid #6d28d9 !important;
      text-align: left;
    }
    td {
      border: 1px solid #e9d5ff !important;
      padding: 7px 10px !important;
      font-size: 12px !important;
      color: #1e1b4b !important;
    }
    tr:nth-child(even) td {
      background-color: #faf5ff !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .bilingual-footer {
      margin-top: 20px;
      border-top: 2px solid #7c3aed;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      color: #4c1d95;
      font-weight: 600;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="bilingual-wrap">
    <div class="bilingual-header">
      <div class="bilingual-top-row">
        <div>
          <div class="bilingual-title-en">LAND & REVENUE RECORD</div>
          <div class="bilingual-title-bn">ভূমি ও খতিয়ান-দাগের তথ্য বিবরণী</div>
        </div>
        <div style="font-size: 11px; color: #f3e8ff; text-align: right;">
          <div>${o}</div>
          <div>${i}</div>
        </div>
      </div>
    </div>

    <div class="bilingual-docket">
      <div class="bilingual-docket-col">
        <div><b>Location (অবস্থান):</b> ${o}</div>
        ${e?`<div><b>Record Info (বিবরণ):</b> ${e}</div>`:""}
      </div>
      <div class="bilingual-docket-col">
        <div><b>Format (ফরম্যাট):</b> Bilingual Layout</div>
        <div><b>Date (তারিখ):</b> ${a}</div>
      </div>
    </div>

    <div class="content-body">
      ${t}
    </div>

    <div class="bilingual-footer">
      <span>Bilingual Record • উভয় ভাষায় তথ্য বিবরণী</span>
      <span>${o} • ${a}</span>
    </div>

    ${y("bilingual")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}function pt({html:t,title:o,caption:e,formattedDate:i,formattedTime:n,fullTimestamp:a}){return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${o} - Classic Record</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      width: 100%;
      min-height: 100vh;
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #1c1917;
      font-family: "Times New Roman", Times, Georgia, serif;
    }
    @page {
      size: A4 portrait;
      margin: 10mm 8mm 10mm 8mm;
    }
    @media screen {
      .only-print { display: none !important; }
    }
    @media print {
      .only-print { display: block !important; }
      .no-print { display: none !important; }
      body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      .legal-wrap { min-height: 96vh !important; padding-bottom: 0 !important; }
    }
    .legal-wrap {
      max-width: 900px;
      min-height: 100vh;
      margin: 0 auto;
      padding: 14px 16px 20px 16px;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }
    .content-body {
      flex: 1 0 auto;
    }
    .legal-header {
      border: 3px double #78350f;
      background: #fffbeb;
      padding: 14px;
      text-align: center;
      margin-bottom: 12px;
    }
    .legal-title {
      font-size: 16px;
      font-weight: 900;
      text-transform: uppercase;
      color: #78350f;
      letter-spacing: 0.8px;
      margin: 0 0 4px 0;
    }
    .legal-sub {
      font-size: 11.5px;
      font-weight: 600;
      color: #92400e;
      margin: 0;
    }
    .legal-docket-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0;
      font-size: 11.5px;
      border: 1.5px solid #78350f;
    }
    .legal-docket-table td {
      padding: 6px 10px;
      border: 1px solid #d97706;
    }
    .legal-docket-label {
      font-weight: bold;
      background: #fef3c7;
      color: #78350f;
      width: 25%;
    }
    /* Strict Ledger Grid */
    table {
      border-collapse: collapse !important;
      width: 100% !important;
      border: 1.5px solid #78350f !important;
      margin: 10px 0 !important;
      page-break-inside: avoid;
    }
    th {
      background: #78350f !important;
      color: #ffffff !important;
      font-size: 11.5px !important;
      font-weight: 700 !important;
      padding: 7px 8px !important;
      border: 1px solid #451a03 !important;
      text-transform: uppercase;
    }
    td {
      border: 1px solid #d97706 !important;
      padding: 6px 8px !important;
      font-size: 11.5px !important;
      color: #1c1917 !important;
    }
    tr:nth-child(even) td {
      background-color: #fffdf5 !important;
    }
    .book > .row { display: none !important; }
    #print-btn { display: none !important; }
    
    .legal-footer {
      margin-top: 18px;
      border-top: 1.5px solid #78350f;
      padding-top: 8px;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #78350f;
      font-weight: 600;
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="legal-wrap">
    <div class="legal-header">
      <div class="legal-title">LAND & PROPERTY RECORD</div>
      <div class="legal-sub">Khatian & Plot Record Particulars</div>
    </div>

    <table class="legal-docket-table">
      <tr>
        <td class="legal-docket-label">Record Date:</td>
        <td>${a}</td>
        <td class="legal-docket-label">Format:</td>
        <td>Classic Ledger Grid</td>
      </tr>
      <tr>
        <td class="legal-docket-label">Location:</td>
        <td colspan="3">${o}</td>
      </tr>
      ${e?`
      <tr>
        <td class="legal-docket-label">Particulars:</td>
        <td colspan="3">${e}</td>
      </tr>
      `:""}
    </table>

    <div class="content-body">
      ${t}
    </div>

    <div class="legal-footer">
      <span>Classic Ledger Format • ${o}</span>
      <span>Date: ${a}</span>
    </div>

    ${y("legal")}
  </div>

  <script>
    function onCaseClick(caseNo) {
      console.log("onCaseClick triggered: " + caseNo);
      console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
    }
    function showMutationCaseDetails(caseNo, idn) {
      console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
      console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
    }
  <\/script>
</body>
</html>`}export{H as A,A as T,ct as a,gt as b,ft as c,mt as d,at as e,bt as g};
