import{t as ge,v as De,as as Ce,ap as Ae,r as W,Z as Te,ak as Me,aK as ke,x as j,j as S,B as G,T as _e,K as Ie,E as Fe,C as Oe,S as Re,N as Ee,aL as Le,ah as We,aM as Be,aN as be,ac as He,aO as je,aP as $e,aQ as ze,w as Q,aR as ve,aS as ye,aT as Ve,aU as Ue,aV as qe,aW as Je,aX as Xe,aY as Ke,aZ as Ye,a_ as Ge,a$ as Qe,b0 as Ze,b1 as et,b2 as tt,b3 as at}from"./index-BURI_Vyi.js";import{B as nt}from"./BreadcrumbsNav-DKizSmGj.js";import{A as rt,g as ee,s as we,p as ot,W as it}from"./Index-n3Eed7zL.js";import"./MyInputField-DpaZf2Fu.js";import"./dataConversion-7N66zdy6.js";import"./ToggleButtonGroup-DVQD-T8a.js";import"./MyForm-BwDEMfSD.js";import"./FormControlLabel-CfSc3Zru.js";import"./SwitchBase-8ptbYBcl.js";import"./Alert-Cn_8ei8X.js";import"./Collapse-DfZ2Tx59.js";function ne(e){"@babel/helpers - typeof";return ne=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},ne(e)}function E(e,t){if(t.length<e)throw new TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+t.length+" present")}function k(e){E(1,arguments);var t=Object.prototype.toString.call(e);return e instanceof Date||ne(e)==="object"&&t==="[object Date]"?new Date(e.getTime()):typeof e=="number"||t==="[object Number]"?new Date(e):((typeof e=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}var st={};function dt(){return st}function xe(e){var t=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds()));return t.setUTCFullYear(e.getFullYear()),e.getTime()-t.getTime()}function Z(e,t){E(2,arguments);var a=k(e),o=k(t),n=a.getTime()-o.getTime();return n<0?-1:n>0?1:n}function lt(e,t){E(2,arguments);var a=k(e),o=k(t),n=a.getFullYear()-o.getFullYear(),l=a.getMonth()-o.getMonth();return n*12+l}function ct(e,t){return E(2,arguments),k(e).getTime()-k(t).getTime()}var ut={ceil:Math.ceil,round:Math.round,floor:Math.floor,trunc:function(t){return t<0?Math.ceil(t):Math.floor(t)}},ft="trunc";function ht(e){return ut[ft]}function pt(e){E(1,arguments);var t=k(e);return t.setHours(23,59,59,999),t}function mt(e){E(1,arguments);var t=k(e),a=t.getMonth();return t.setFullYear(t.getFullYear(),a+1,0),t.setHours(23,59,59,999),t}function gt(e){E(1,arguments);var t=k(e);return pt(t).getTime()===mt(t).getTime()}function bt(e,t){E(2,arguments);var a=k(e),o=k(t),n=Z(a,o),l=Math.abs(lt(a,o)),i;if(l<1)i=0;else{a.getMonth()===1&&a.getDate()>27&&a.setDate(30),a.setMonth(a.getMonth()-n*l);var y=Z(a,o)===-n;gt(k(e))&&l===1&&Z(e,o)===1&&(y=!1),i=n*(l-Number(y))}return i===0?0:i}function vt(e,t,a){E(2,arguments);var o=ct(e,t)/1e3;return ht()(o)}var yt={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},wt=function(t,a,o){var n,l=yt[t];return typeof l=="string"?n=l:a===1?n=l.one:n=l.other.replace("{{count}}",a.toString()),o!=null&&o.addSuffix?o.comparison&&o.comparison>0?"in "+n:n+" ago":n};function te(e){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=t.width?String(t.width):e.defaultWidth,o=e.formats[a]||e.formats[e.defaultWidth];return o}}var xt={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},Nt={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},St={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},Pt={date:te({formats:xt,defaultWidth:"full"}),time:te({formats:Nt,defaultWidth:"full"}),dateTime:te({formats:St,defaultWidth:"full"})},Dt={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},Ct=function(t,a,o,n){return Dt[t]};function q(e){return function(t,a){var o=a!=null&&a.context?String(a.context):"standalone",n;if(o==="formatting"&&e.formattingValues){var l=e.defaultFormattingWidth||e.defaultWidth,i=a!=null&&a.width?String(a.width):l;n=e.formattingValues[i]||e.formattingValues[l]}else{var y=e.defaultWidth,c=a!=null&&a.width?String(a.width):e.defaultWidth;n=e.values[c]||e.values[y]}var b=e.argumentCallback?e.argumentCallback(t):t;return n[b]}}var At={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},Tt={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},Mt={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},kt={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},_t={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},It={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},Ft=function(t,a){var o=Number(t),n=o%100;if(n>20||n<10)switch(n%10){case 1:return o+"st";case 2:return o+"nd";case 3:return o+"rd"}return o+"th"},Ot={ordinalNumber:Ft,era:q({values:At,defaultWidth:"wide"}),quarter:q({values:Tt,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:q({values:Mt,defaultWidth:"wide"}),day:q({values:kt,defaultWidth:"wide"}),dayPeriod:q({values:_t,defaultWidth:"wide",formattingValues:It,defaultFormattingWidth:"wide"})};function J(e){return function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},o=a.width,n=o&&e.matchPatterns[o]||e.matchPatterns[e.defaultMatchWidth],l=t.match(n);if(!l)return null;var i=l[0],y=o&&e.parsePatterns[o]||e.parsePatterns[e.defaultParseWidth],c=Array.isArray(y)?Et(y,function(x){return x.test(i)}):Rt(y,function(x){return x.test(i)}),b;b=e.valueCallback?e.valueCallback(c):c,b=a.valueCallback?a.valueCallback(b):b;var C=t.slice(i.length);return{value:b,rest:C}}}function Rt(e,t){for(var a in e)if(e.hasOwnProperty(a)&&t(e[a]))return a}function Et(e,t){for(var a=0;a<e.length;a++)if(t(e[a]))return a}function Lt(e){return function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},o=t.match(e.matchPattern);if(!o)return null;var n=o[0],l=t.match(e.parsePattern);if(!l)return null;var i=e.valueCallback?e.valueCallback(l[0]):l[0];i=a.valueCallback?a.valueCallback(i):i;var y=t.slice(n.length);return{value:i,rest:y}}}var Wt=/^(\d+)(th|st|nd|rd)?/i,Bt=/\d+/i,Ht={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},jt={any:[/^b/i,/^(a|c)/i]},$t={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},zt={any:[/1/i,/2/i,/3/i,/4/i]},Vt={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},Ut={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},qt={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},Jt={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},Xt={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},Kt={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},Yt={ordinalNumber:Lt({matchPattern:Wt,parsePattern:Bt,valueCallback:function(t){return parseInt(t,10)}}),era:J({matchPatterns:Ht,defaultMatchWidth:"wide",parsePatterns:jt,defaultParseWidth:"any"}),quarter:J({matchPatterns:$t,defaultMatchWidth:"wide",parsePatterns:zt,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:J({matchPatterns:Vt,defaultMatchWidth:"wide",parsePatterns:Ut,defaultParseWidth:"any"}),day:J({matchPatterns:qt,defaultMatchWidth:"wide",parsePatterns:Jt,defaultParseWidth:"any"}),dayPeriod:J({matchPatterns:Xt,defaultMatchWidth:"any",parsePatterns:Kt,defaultParseWidth:"any"})},Gt={code:"en-US",formatDistance:wt,formatLong:Pt,formatRelative:Ct,localize:Ot,match:Yt,options:{weekStartsOn:0,firstWeekContainsDate:1}};function Pe(e,t){if(e==null)throw new TypeError("assign requires that input parameter not be null or undefined");for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a]);return e}function Qt(e){return Pe({},e)}var Ne=1440,Zt=2520,ae=43200,ea=86400;function ta(e,t,a){var o,n;E(2,arguments);var l=dt(),i=(o=(n=a==null?void 0:a.locale)!==null&&n!==void 0?n:l.locale)!==null&&o!==void 0?o:Gt;if(!i.formatDistance)throw new RangeError("locale must contain formatDistance property");var y=Z(e,t);if(isNaN(y))throw new RangeError("Invalid time value");var c=Pe(Qt(a),{addSuffix:!!(a!=null&&a.addSuffix),comparison:y}),b,C;y>0?(b=k(t),C=k(e)):(b=k(e),C=k(t));var x=vt(C,b),$=(xe(C)-xe(b))/1e3,w=Math.round((x-$)/60),R;if(w<2)return a!=null&&a.includeSeconds?x<5?i.formatDistance("lessThanXSeconds",5,c):x<10?i.formatDistance("lessThanXSeconds",10,c):x<20?i.formatDistance("lessThanXSeconds",20,c):x<40?i.formatDistance("halfAMinute",0,c):x<60?i.formatDistance("lessThanXMinutes",1,c):i.formatDistance("xMinutes",1,c):w===0?i.formatDistance("lessThanXMinutes",1,c):i.formatDistance("xMinutes",w,c);if(w<45)return i.formatDistance("xMinutes",w,c);if(w<90)return i.formatDistance("aboutXHours",1,c);if(w<Ne){var g=Math.round(w/60);return i.formatDistance("aboutXHours",g,c)}else{if(w<Zt)return i.formatDistance("xDays",1,c);if(w<ae){var u=Math.round(w/Ne);return i.formatDistance("xDays",u,c)}else if(w<ea)return R=Math.round(w/ae),i.formatDistance("aboutXMonths",R,c)}if(R=bt(C,b),R<12){var A=Math.round(w/ae);return i.formatDistance("xMonths",A,c)}else{var T=R%12,F=Math.floor(R/12);return T<3?i.formatDistance("aboutXYears",F,c):T<9?i.formatDistance("overXYears",F,c):i.formatDistance("almostXYears",F+1,c)}}function aa(e,t){return E(1,arguments),ta(e,Date.now(),t)}function na(e){return new Promise(t=>{setTimeout(()=>{t({html:`
            <div style="position:relative; width:100%; min-height:100vh;">

  <!-- Full page watermark -->
  <div style="
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background-repeat:repeat;
    background-image: repeating-linear-gradient(
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 100px
    ),
    repeating-linear-gradient(
      90deg,
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 300px
    );
    z-index:9999;
  ">
    <div style="
      position:absolute;      
      top:50%;
      left:50%;
      transform:translate(-50%,-50%) rotate(-60deg);
      font-size:72px;
      color:rgba(150,150,150,0.2);
      font-weight:bold;
      white-space:nowrap;
      font-family:Arial, sans-serif;
      pointer-events:none;
    ">
      DEMO DATA - NOT REAL
    </div>
  </div>

  <!-- Disclaimer Banner -->
  <div style="
    position:sticky;
    top:0;
    background-color:rgba(255,255,0,0.9);
    color:#000;
    padding:10px;
    font-size:16px;
    text-align:center;
    font-weight:bold;
    border-bottom:2px solid #000;
    z-index:1000;
  ">
    This page displays DEMO DATA for review purposes only. No real information is shown.
  </div>

  <!-- Your existing dummy HTML -->
  <div style="position:relative; z-index:1; padding:20px; background-color:white;">

    <table width="100%" border="1" style="border-collapse: collapse;">
      <tr>
        <td width="55%">
          <div style="border: thin; position: relative; width: 100%;">
            <b style="color:#0000FF;">
              <font face="Verdana">(Demo Data Generated on 08/08/2025, 12:00:00)</font>
            </b><br/>
            <b style="color:#660033;">&nbsp;<label><font face='BN BIDISHA Opentype'>J.L No </font>:</label>&nbsp;</b>999
            <b style="color:#660033;">&nbsp;&nbsp; <font face='BN BIDISHA Opentype'>Thana </font>:&nbsp;</b>
            <font face='BN BIDISHA Opentype'>Demo Thana</font>&nbsp;<br/>
          </div>

          <div class="table-responsive" style="border: thin; position: relative; left: 3px; width: 97%;">
            <table class="table" width="95%" border="1" style="border-collapse: collapse;">
              <tr>
                <th width="43%"><div align="left"><font face='BN BIDISHA Opentype'>Khatian No</font>&nbsp;&nbsp;:&nbsp;</div></th>
                <th width="57%" bgcolor="#CCCCCC"><div align="left"><font face='BN BIDISHA Opentype'>00</font></div></th>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Nam</font>&nbsp;&nbsp;:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Name</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Pita/Swami</font>&nbsp;&nbsp;:</td>
                <td bgcolor="#CCCCCC"><font face='BN BIDISHA Opentype'>Demo Parent</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Dharan</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Type</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Thikana</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Address</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Zamir Pariman</font>:</td>
                <td bgcolor="#CCCCCC">0.00 Ekar</td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Dager Sankhyan</font>:</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <p><strong><font style="color: #0048FF;font-size:18px" face='BN BIDISHA Opentype'>Atrasbatber Dager Bibaran O Pariman:</font></strong></p>
          <p><font style="color: #8000ff;font-size:12px" face='BN BIDISHA Opentype'>(This is demo data only. No real land records are shown.)</font></p>

          <div class="table-responsive" style="border: thin none; position: relative; left: 5px; width: 97%; overflow: auto; top: -10px; margin-top:1em; margin-right: 5px;">
            <table class="table table-fixed" width="95%" align="center" style="border-collapse: collapse">
              <thead>
                <tr>
                  <th><center>Dag No</center></th>
                  <th><center>Shreni</center></th>
                  <th><center>Ansh</center></th>
                  <th><center>Ansh Pariman (ekar)</center></th>
                  <th><center>Dakhaldar</center></th>
                  <th><center>Mantaby</center></th>
                </tr>
              </thead>
              <tbody>
                <tr bgcolor="#CCCCCC">
                  <td align="center">0001</td>
                  <td align="center">Demo Class</td>
                  <td align="center">1.0000</td>
                  <td align="center">0.00</td>
                  <td align="center">Demo Holder</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
                <tr>
                  <td align="center">0002</td>
                  <td align="center">Demo Class</td>
                  <td align="center">0.5000</td>
                  <td align="center">0.00</td>
                  <td align="center">Nil</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>

        <td width="45%" valign="top">
          <div class="table-responsive" style="border: thin; width: 95%; height: 300px; overflow: auto;">
            <center style="color:gray; padding-top:120px;">Demo Map / Additional Info</center>
          </div>
        </td>
      </tr>
    </table>

  </div>
</div>
          `})},1e3)})}function V(e){if(!e||typeof e!="string")return e;const t=["০","১","২","৩","৪","৫","৬","৭","৮","৯"];return e.replace(/[০-৯]/g,a=>t.indexOf(a))}function B(e){return e?e.replace(/&nbsp;/g," ").replace(/\s+/g," ").replace(/^[:\-–\s]+/,"").replace(/[:\-–\s]+$/,"").trim():""}const ra={"dag no":"Plot No (দাগ নং)",dag:"Plot No (দাগ নং)",dags:"Plot No (দাগ নং)","দাগ নং":"Plot No (দাগ নং)",দাগ:"Plot No (দাগ নং)","lr dag no":"LR Plot (এল.আর দাগ)","হাল দাগ নং":"LR Plot (এল.আর দাগ)","rs dag no":"RS Plot (আর.এস দাগ)","সাবেক দাগ নং":"RS Plot (আর.এস দাগ)",shreni:"Land Character (শ্রেণি)",classification:"Land Character (শ্রেণি)",শ্রেণি:"Land Character (শ্রেণি)",শ্রেণী:"Land Character (শ্রেণি)",ansh:"Share (অংশ)",অংশ:"Share (অংশ)","ansh pariman (ekar)":"Share Area (Acres)","ansh pariman":"Share Area (Acres)","অংশ পরিমাণ(একর)":"Share Area (Acres)","অংশ পরিমাণ":"Share Area (Acres)",pariman:"Area (Acres)",পরিমাণ:"Area (Acres)","zamir moat pariman(ekar)":"Total Plot Area (Acres)","জমির মোট পরিমাণ(একর)":"Total Plot Area (Acres)",dakhaldar:"Possessor (দখলদার)",দখলদার:"Possessor (দখলদার)",mantaby:"Remarks (মন্তব্য)",mantabya:"Remarks (মন্তব্য)",remarks:"Remarks (মন্তব্য)",মন্তব্য:"Remarks (মন্তব্য)","raiter nam":"Owner Name (মালিকের নাম)","owner name":"Owner Name (মালিকের নাম)","রায়তের নাম":"Owner Name (মালিকের নাম)","মালিকের নাম":"Owner Name (মালিকের নাম)","pita/swami":"Father/Husband (পিতা/স্বামী)","পিতা/স্বামী":"Father/Husband (পিতা/স্বামী)",পিতা:"Father (পিতা)",স্বামী:"Husband (স্বামী)","khatian no":"Khatian No (খতিয়ান নং)",khatian:"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)","খতিয়ান নং":"Khatian No (খতিয়ান নং)","case no":"Case No (কেস নং)",txtcaseno:"Case No (কেস নং)","কেস নং":"Case No (কেস নং)","hearing date":"Hearing Date (শুনানির তারিখ)",status:"Status (অবস্থা)",demand:"Demand (দাবি)",due:"Dues (বকেয়া)","dager myap":"Plot Map (নকশা)","দাগের ম্যাপ":"Plot Map (নকশা)"};function Se(e){const t=B(e).toLowerCase();for(const[a,o]of Object.entries(ra))if(t===a.toLowerCase()||t.includes(a.toLowerCase()))return o;return B(e)}function oa(e){if(!e)return"";let t=B(e);return(t.includes("Demo Data")||t.includes("demo data"))&&(t=t.replace(/\(.*Demo Data.*?\)/gi,"").replace(/Demo Data.*?Generated.*?\)/gi,"")),t.includes("Atrasbatber Dager Bibaran")||t.includes("Bibaran O Pariman")||t.includes("দাগের বিবরণ ও পরিমাণ")?"Plot Details & Area Share (দাগের বিবরণ ও পরিমাণ)":(t.includes("Khatian")||t.includes("খতিয়ান")||t.includes("খতিয়ান"))&&(t.includes("Bibaran")||t.includes("বিবরণ")||t.includes("List"))?"Associated Khatians & Owners (খতিয়ান ও মালিকের বিবরণ)":(t.includes("RS")||t.includes("সাবেক"))&&(t.includes("LR")||t.includes("হাল"))?"RS-LR Plot Cross Reference (আর.এস - এল.আর দাগ রূপান্তর)":t.includes("Mutation")||t.includes("Case")||t.includes("মিউটেশন")?"Mutation Case Docket (মিউটেশন কেস বিবরণ)":B(t)}function ia(e,t=""){if(!e||typeof e!="string")return{success:!1,metadata:{},tables:[]};try{const o=new DOMParser().parseFromString(e,"text/html");o.querySelectorAll("script, style, noscript").forEach(g=>g.remove());const n={},l=[],i=[],y=/(MN\/\d{4}\/\d+\/\d+)/g,b=(o.body.innerText||"").match(y);b&&b.forEach(g=>{i.includes(g)||i.push(g)}),o.querySelectorAll("b, label, span, div").forEach(g=>{const u=g.innerText.trim();if(u.includes("J.L No")||u.includes("J.L. No")||u.includes("JL No")||u.includes("J.l No")||u.includes("জে.এল নং")||u.includes("জে.এল. নং")){const A=u.match(/(?:J\.?[Ll]\.?\s*No|জে\.?এল\.?\s*নং)\s*[:\-]?\s*([০-৯\d]+)/i);A&&!n.jlNo&&(n.jlNo=V(A[1]))}if(u.includes("Thana")||u.includes("Police Station")||u.includes("থানা")){const A=u.match(/(?:Thana|Police Station|থানা)\s*[:\-]?\s*([A-Za-z\u0980-\u09FF\s]+)/i);if(A&&!n.thana){const T=B(A[1].split(`
`)[0]);T&&T.length>1&&(n.thana=T)}}});const C=o.querySelectorAll("table"),x=[];C.forEach(g=>{const u=Array.from(g.querySelectorAll("tr"));if(u.length===0)return;if(u.length===2||u.length===1&&g.querySelector("th")&&g.querySelector("td")){const _=u[0],I=u.length>1?u[1]:null;if(_&&I){const P=Array.from(_.querySelectorAll("th, td")).map(v=>B(v.innerText).toLowerCase()),h=Array.from(I.querySelectorAll("td, th")).map(v=>B(v.innerText)),s=P.some(v=>v.includes("dag no")||v.includes("দাগ নং")),D=P.some(v=>v.includes("pariman")||v.includes("পরিমাণ"));if(s&&D&&h.length>=3){P.forEach((v,f)=>{const H=h[f];H&&((v.includes("dag no")||v.includes("দাগ নং"))&&!n.plotNo&&(n.plotNo=V(H)),(v.includes("shreni")||v.includes("শ্রেণি")||v.includes("শ্রেণী"))&&!n.classification&&(n.classification=H),(v.includes("pariman")||v.includes("পরিমাণ"))&&!n.totalArea&&(n.totalArea=V(H)))});return}}}let A=!0;const T=[];if(u.forEach(_=>{const I=Array.from(_.querySelectorAll("td, th"));if(I.length===2){const P=B(I[0].innerText),h=B(I[1].innerText);if(P&&h&&h!=="-"){T.push({key:P,value:h});const s=P.toLowerCase();(s.includes("khatian")||s.includes("খতিয়ান")||s.includes("খতিয়ান"))&&!n.khatianNo&&(n.khatianNo=V(h)),(s.includes("raiter nam")||s.includes("owner name")||s.includes("রায়তের নাম")||s.includes("মালিকের নাম"))&&!n.ownerName&&(n.ownerName=h),(s.includes("pita")||s.includes("father")||s.includes("husband")||s.includes("পিতা")||s.includes("স্বামী"))&&!n.fatherHusband&&(n.fatherHusband=h),(s.includes("thikana")||s.includes("address")||s.includes("ঠিকানা"))&&!n.address&&(n.address=h),(s.includes("pariman")||s.includes("area")||s.includes("পরিমাণ"))&&!n.totalArea&&(n.totalArea=V(h)),(s.includes("sankhya")||s.includes("count")||s.includes("সংখ্যা"))&&!n.plotCount&&(n.plotCount=V(h)),(s.includes("shreni")||s.includes("classification")||s.includes("শ্রেণি")||s.includes("শ্রেণী"))&&!n.classification&&(n.classification=h),(s.includes("dharan")||s.includes("type")||s.includes("ধরন"))&&!n.tenantType&&(n.tenantType=h)}}else A=!1}),A&&T.length>=2){x.push(...T);return}let F=[];const z=g.querySelector("thead");if(z){const _=z.querySelectorAll("th, td");F=Array.from(_).map(I=>Se(I.innerText))}else if(u.length>1){const _=Array.from(u[0].querySelectorAll("th, td"));(u[0].querySelector("th")!==null||_.length>2)&&(F=_.map(P=>Se(P.innerText)))}if(F.length>=2){const _=[],I=z?0:1;for(let P=I;P<u.length;P++){const h=u[P];if(z&&h.parentElement===z)continue;const s=Array.from(h.querySelectorAll("td, th")).map(D=>B(D.innerText));if(s.length>0&&s.some(D=>D.length>0)){const D=s.map(v=>{const f=v.toLowerCase();return f==="nil"||v==="-"||f==="na"||f==="n/a"?"—":v});_.push(D)}}if(_.length>0){let P="",h=g.previousElementSibling;for(;h&&!P;)h.tagName.match(/^H[1-6]|P|STRONG|B$/i)&&(P=oa(h.innerText)),h=h.previousElementSibling;l.push({title:P||"Detailed Records",headers:F,rows:_})}}});const $=["khatian","খতিয়ান","খতিয়ান","raiter nam","owner name","রায়তের নাম","মালিকের নাম","pita","swami","father","husband","পিতা","স্বামী","zamir pariman","জমির পরিমাণ","pariman","পরিমাণ","dager sankhyan","dager sankhya","দাগের সংখ্যা","plot count","jl no","জে.এল নং","thana","থানা"],w=[],R=new Set;return x.forEach(g=>{const u=g.key.toLowerCase().trim();!$.some(T=>u.includes(T))&&!R.has(u)&&(R.add(u),w.push(g))}),w.length>0&&(n.summaryItems=w),{success:Object.keys(n).length>0||l.length>0,metadata:n,tables:l,caseNumbers:i,rawHtml:e}}catch(a){return console.warn("Failed to parse WB HTML:",a),{success:!1,metadata:{},tables:[],rawHtml:e}}}function re(e){if(!e||typeof e!="string")return!1;const t=e.trim();return!!(t.startsWith("%PDF-")||t.startsWith("%PDF")||t.startsWith("JVBE")||t.startsWith("data:application/pdf")||t.substring(0,200).includes("%PDF-")&&!t.substring(0,200).toLowerCase().includes("<html"))}function oe(e){if(!e||typeof e!="string")return"";const t=e.trim();if(t.startsWith("JVBE"))return t;if(t.startsWith("data:application/pdf;base64,"))return t.replace("data:application/pdf;base64,","").trim();try{const a=e.length;let o="";const n=8192;for(let l=0;l<a;l+=n){const i=Math.min(l+n,a),y=new Uint8Array(i-l);for(let c=l;c<i;c++)y[c-l]=e.charCodeAt(c)&255;o+=String.fromCharCode.apply(null,y)}return btoa(o)}catch(a){return console.error("[pdfViewerHelper] Failed to convert raw PDF to Base64",a),""}}function sa({pdfData:e,title:t="Certificate PDF",caption:a=""}){const o=oe(e);return`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=yes">
  <title>${t}</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js"><\/script>
  <style>
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      min-height: 100%;
      background: #343a40;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #fff;
    }

    .pdf-top-bar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: #212529;
      padding: 10px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 2px 10px rgba(0,0,0,0.4);
      border-bottom: 1px solid #444;
    }

    .pdf-meta {
      display: flex;
      flex-direction: column;
      overflow: hidden;
      margin-right: 12px;
    }

    .pdf-main-title {
      font-size: 14px;
      font-weight: 700;
      color: #f8f9fa;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-sub-title {
      font-size: 12px;
      color: #adb5bd;
      margin-top: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .pdf-btn-group {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }

    .pdf-btn {
      background: #1976d2;
      color: #fff;
      border: none;
      padding: 7px 14px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: background 0.15s ease-in-out;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    .pdf-btn:hover, .pdf-btn:active {
      background: #1565c0;
    }

    .pdf-btn.secondary {
      background: #495057;
    }

    .pdf-btn.secondary:hover, .pdf-btn.secondary:active {
      background: #5a6268;
    }

    #loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 50px 20px;
      gap: 16px;
      text-align: center;
    }

    .loading-spinner {
      width: 44px;
      height: 44px;
      border: 4px solid rgba(255, 255, 255, 0.2);
      border-top-color: #1976d2;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .loading-text {
      font-size: 14px;
      font-weight: 600;
      color: #dee2e6;
    }

    #pages-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px 8px 40px;
      gap: 20px;
      width: 100%;
    }

    .pdf-page-card {
      background: #ffffff;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35);
      border-radius: 4px;
      overflow: hidden;
      max-width: 100%;
      display: flex;
      justify-content: center;
    }

    .pdf-page-card canvas {
      display: block;
      max-width: 100%;
      height: auto !important;
    }

    .fallback-box {
      max-width: 440px;
      margin: 10px auto;
      background: #2b3035;
      border-radius: 12px;
      padding: 30px 24px;
      text-align: center;
      border: 1px solid #444;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }

    @media print {
      .pdf-top-bar {
        display: none !important;
      }
      body {
        background: #fff !important;
      }
      #pages-wrapper {
        padding: 0 !important;
        gap: 0 !important;
      }
      .pdf-page-card {
        box-shadow: none !important;
        border-radius: 0 !important;
        margin: 0 !important;
        page-break-after: always;
      }
    }
  </style>
</head>
<body>
  <div class="pdf-top-bar no-print">
    <div class="pdf-meta">
      <div class="pdf-main-title">${t||"Revenue No Due Certificate"}</div>
      <div class="pdf-sub-title">${a||"Certified Document"}</div>
    </div>
    <div class="pdf-btn-group">
      <button class="pdf-btn" onclick="downloadPdf()">
        Download
      </button>
      <button class="pdf-btn secondary" onclick="printPdf()">
        Print
      </button>
    </div>
  </div>

  <div id="loading-container">
    <div class="loading-spinner"></div>
    <div class="loading-text">Loading Certificate PDF...</div>
  </div>

  <div id="pages-wrapper"></div>

  <script>
    const base64Data = "${o}";

    function getPdfBytes() {
      const raw = atob(base64Data);
      const len = raw.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = raw.charCodeAt(i);
      }
      return bytes;
    }

    function downloadPdf() {
      // Primary: notify container through WebView console message bridge
      try {
        console.log(JSON.stringify({ action: "DOWNLOAD_PDF" }));
      } catch (e) {}

      // Fallback for standard browser
      try {
        const bytes = getPdfBytes();
        const blob = new Blob([bytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = '${(t||"Certificate").replace(/[^a-zA-Z0-9_-]/g,"_")}.pdf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 10000);
      } catch (_) {}
    }

    function printPdf() {
      try {
        console.log(JSON.stringify({ action: "PRINT_PDF" }));
      } catch (e) {}
      try {
        window.print();
      } catch (_) {}
    }

    function renderPdf() {
      if (!window.pdfjsLib) {
        showFallback('PDF renderer not available');
        return;
      }

      try {
        // Disable external worker to avoid Cross-Origin SecurityError in WebView.
        // PDF.js will use FakeWorker in main thread.
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = '';

        const bytes = getPdfBytes();
        const loadingTask = pdfjsLib.getDocument({
          data: bytes,
        });

        loadingTask.promise.then(function(pdf) {
          const loadingEl = document.getElementById('loading-container');
          if (loadingEl) loadingEl.style.display = 'none';

          const container = document.getElementById('pages-wrapper');
          container.innerHTML = '';

          for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            pdf.getPage(pageNum).then(function(page) {
              const scale = 1.5; // High resolution rendering
              const viewport = page.getViewport({ scale: scale });

              const pageCard = document.createElement('div');
              pageCard.className = 'pdf-page-card';

              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              canvas.height = viewport.height;
              canvas.width = viewport.width;

              pageCard.appendChild(canvas);
              container.appendChild(pageCard);

              page.render({ canvasContext: ctx, viewport: viewport });
            });
          }
        }).catch(function(err) {
          console.error('[PDF.js] Render Error:', err);
          showFallback(err.message);
        });
      } catch (e) {
        showFallback(e.message);
      }
    }

    function showFallback(msg) {
      const loadingEl = document.getElementById('loading-container');
      if (loadingEl) {
        loadingEl.innerHTML = \`
          <div class="fallback-box">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: #1976d2; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
            </div>
            <h3 style="margin-top:0; color:#fff; font-size:17px;">\${'${t||"Revenue No Due Certificate"}'}</h3>
            <p style="color:#ced4da; font-size:14px; line-height: 1.5; margin-bottom: 24px;">
              Certified PDF certificate ready. Tap below to download and save it to your device.
            </p>
            <button onclick="downloadPdf()" class="pdf-btn" style="padding:12px 28px; font-size:15px; margin: 0 auto; box-shadow: 0 4px 12px rgba(25, 118, 210, 0.4);">
              Download Certificate PDF
            </button>
          </div>
        \`;
      }
    }

    if (window.pdfjsLib) {
      renderPdf();
    } else {
      let attempts = 0;
      const timer = setInterval(() => {
        attempts++;
        if (window.pdfjsLib) {
          clearInterval(timer);
          renderPdf();
        } else if (attempts > 30) { // 3 seconds timeout
          clearInterval(timer);
          showFallback('PDF engine timed out');
        }
      }, 100);
    }
  <\/script>
</body>
</html>`}function xa(){var fe,he,pe,me;const{t:e}=ge(),{t}=ge("inputField"),{errorAlert:a,setHeaderButtons:o,successAlert:n,darkMode:l}=De(),{user:i,logoutUser:y,isLoggedIn:c}=Ce(),{selectedDistrict:b,selectedBlock:C,selectedMouza:x,searchLandDetails:$}=Ae(),[w,R]=W.useState(!1),[g,u]=W.useState(""),[A,T]=W.useState(!0),F=Le===!0,[z,_]=W.useState("html");W.useEffect(()=>{_("html")},[F]);const I=Te(),P=Me(),{districtId:h,blockId:s,mouzaId:D,recordData:v}=ke(),f=P.pathname,H=W.useRef(""),r=W.useMemo(()=>{if(v)try{return JSON.parse(v)}catch(p){console.error("Failed to parse recordData from params",p)}return $},[v,$]);W.useMemo(()=>ia(g,f),[g,f]);const ie=(p=!0)=>{p||(H.current=""),We(),T(!0);let d=Be;f.includes("/rs-lr/")?d=Ve:f.includes("/khajna-status/")?d=Ue:f.includes("/mutation-case-status/")?d=qe:f.includes("/mutation-case-details/")?d=Je:f.includes("/mutation-status/")?d=Xe:f.includes("/land-class/")?d=Ke:f.includes("/warish-status/")?d=Ye:f.includes("/conversion-status/")?d=Ge:f.includes("/signed-copy/")?d=Qe:f.includes("/revenue-no-dues/")?d=Ze:f.includes("/barga-info/")?d=et:f.includes("/grn-search/")?d=tt:f.includes("/app-reprint/")&&(d=at);const O={...r,districtName:(b==null?void 0:b.name)||"",blockName:(C==null?void 0:C.name)||"",mouzaName:(x==null?void 0:x.name)||""};c&&d(O,h,s,D,p).then(async m=>{if(m&&m.html){let M=localStorage.getItem(be)??0;m.cached&&M++,localStorage.setItem(be,M);const N=await He(je)??10;M>N&&$e(),console.log("html Received=>",M,m.html);const X=new DOMParser().parseFromString(m.html,"text/html");X.querySelectorAll("a").forEach(L=>{const Y=L.innerText.trim().toLowerCase();!Y.includes("view ror")&&!Y.includes("certified copy")&&L.removeAttribute("href")});const K=/(MN\/\d{4}\/\d+\/\d+)/g;f.includes("/mutation-status/")?X.querySelectorAll("td").forEach(L=>{L.innerText.trim().match(K)&&(L.innerHTML=L.innerHTML.replace(K,`<a href="javascript:void(0)" onclick="onCaseClick('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}):f.includes("/mutation-case-status/")&&X.querySelectorAll("td").forEach(L=>{L.innerText.trim().match(K)&&(L.innerHTML=L.innerHTML.replace(K,`<a href="javascript:void(0)" onclick="showMutationCaseDetails('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}),m.html=X.body.innerHTML,u(m.html),R(m.cached),ze("high-low",3),j("success_record_fetch",{totalCount:M,cached:m.cached?"true":"false",useCache:p?"true":"false"})}else y(),Q(),u(""),a("auth.sessionTimeout")}).catch(m=>{u(""),console.red("Error in record fetching",m.message),j("record_fetch_error",{message:m.message}),a("kyp.recordView.errorLandRecordFetch",{error:m.message}),I(-1)}).finally(m=>T(!1))};W.useEffect(()=>{if(c&&H.current!==f){if(H.current=f,i=="demo"){na().then(p=>{u(p.html),T(!1),j("demo_record_fetched")});return}ie()}},[c,f,v,i]);const se=t("wb.landDetails.khatianType.option"),de=t("wb.landDetails.searchBy.option"),U=`wb-record-${f.split("/")[2]}`,le=async()=>{Q();try{await ve("downloads");const p=Math.random().toString(36).substring(2,7);let d=`${h}_${s}_${D}_`;f.includes("/mutation-case-")?d+=(r==null?void 0:r.caseNumber)||"Record":f.includes("/revenue-no-dues/")?d+=(r==null?void 0:r.appNo)||(r==null?void 0:r.mainNo)||"Revenue_Certificate":(d+=(r==null?void 0:r.mainNo)||"Record",r!=null&&r.subNo&&(d+="_"+r.subNo)),d+=`_${p}`,d=d.replace(/[^a-zA-Z0-9_.-]/g,"_");const O=`${d}.pdf`,m=`/storage/emulated/0/Download/${O}`;if(re(g)){const N=oe(g);await window.bridgeSend("storage","fileSave",{path:m,data:N}),n("PDF saved at: "+m),j("pdf_saved",{path:m}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+O,payload:m});return}const M=await ee(U);if(!M)throw new Error("WebView not ready yet.");we({id:M,path:m}).then(N=>{n("PDF saved at: "+N.path),j("pdf_saved",{path:N.path}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+O,payload:N.path})}).catch(N=>{a("Failed to save PDF"),console.error("PDF Save Error:",N)})}catch(p){a("Failed to initialize PDF save"),console.error("PDF init error",p)}},ce=async()=>{Q();try{await ve("downloads");const p=Math.random().toString(36).substring(2,7);let d=`${h}_${s}_${D}_`;f.includes("/mutation-case-")?d+=(r==null?void 0:r.caseNumber)||"Record":f.includes("/revenue-no-dues/")?d+=(r==null?void 0:r.appNo)||(r==null?void 0:r.mainNo)||"Revenue_Certificate":(d+=(r==null?void 0:r.mainNo)||"Record",r!=null&&r.subNo&&(d+="_"+r.subNo)),d+=`_${p}`,d=d.replace(/[^a-zA-Z0-9_.-]/g,"_");const m=`/storage/emulated/0/Download/${`${d}.pdf`}`;if(re(g)){const N=oe(g);await window.bridgeSend("storage","fileSave",{path:m,data:N}),j("pdf_shared",{path:m}),ye({filePaths:[m],text:"Here is the certified PDF."});return}const M=await ee(U);if(!M)throw new Error("WebView not ready yet.");we({id:M,path:m}).then(N=>{j("pdf_shared",{path:N.path}),ye({filePaths:[N.path],text:"Here is the land record PDF."})}).catch(N=>{a("Failed to share PDF"),console.error("PDF Share Error:",N)})}catch(p){a("Failed to initialize PDF share"),console.error("PDF share init error",p)}},ue=async()=>{Q();try{const p=await ee(U);if(!p)throw new Error("WebView not ready yet.");await ot({id:p}),j("pdf_printed",{url:f})}catch(p){a("Failed to print record"),console.error("Print Error:",p)}};return W.useEffect(()=>{if(!g||A)return;const p={id:"save_pdf_btn",icon:"download",tooltip:"Save PDF",onClick:le},d={id:"share_pdf_btn",icon:"share",tooltip:"Share Record",onClick:ce},O={id:"print_pdf_btn",icon:"print",tooltip:"Print Record",onClick:ue};return o(m=>[...m.filter(N=>N.id!=="save_pdf_btn"&&N.id!=="share_pdf_btn"&&N.id!=="print_pdf_btn"),O,d,p]),()=>{o(m=>m.filter(M=>M.id!=="save_pdf_btn"&&M.id!=="share_pdf_btn"&&M.id!=="print_pdf_btn"))}},[g,A,U,r,f,o,n,a]),!c&&!g?S.jsx(rt,{}):S.jsxs(G,{sx:{width:"100%",maxWidth:"100vw",overflowX:"hidden",boxSizing:"border-box"},children:[S.jsxs(G,{sx:{py:1},children:[S.jsx(nt,{heading:!0}),S.jsx(_e,{variant:"subtitle2",align:"center",sx:{mt:0},children:f.includes("/mutation-case-")?S.jsxs(S.Fragment,{children:["Case No: ",r==null?void 0:r.caseNumber]}):S.jsxs(S.Fragment,{children:[((fe=se[r==null?void 0:r.khatianType])==null?void 0:fe.text)??""," ",((he=de[r==null?void 0:r.searchBy])==null?void 0:he.text)??""," -"," ",(r==null?void 0:r.mainNo)??"",r!=null&&r.subNo?"/"+(r==null?void 0:r.subNo):""]})}),!A&&g&&w&&S.jsxs(G,{sx:{px:2,py:.8,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:1},children:[F,w&&S.jsx(Ie,{sx:{fontSize:"0.75rem",color:"text.disabled",border:"none","& span.MuiIcon-root":{color:"text.primary"},ml:"auto"},onDelete:()=>{ie(!1)},deleteIcon:S.jsx(Fe,{children:"refresh"}),variant:"outlined",size:"small",color:"primary",label:e("kyp.recordView.cachedRecord",{timeago:w?aa(new Date(w),{addSuffix:!0}):""})})]}),S.jsx(Oe,{})]}),A?S.jsx(Re,{alignItems:"center",sx:{py:10},children:S.jsx(Ee,{})}):S.jsxs(S.Fragment,{children:[F,S.jsx(G,{sx:{display:"block"},children:S.jsx(da,{id:U,isVisible:!F,html:g,title:(b==null?void 0:b.en)+" ➧ "+(C==null?void 0:C.en)+" ➧"+(x==null?void 0:x.en),caption:[((pe=se[r==null?void 0:r.khatianType])==null?void 0:pe.text)??"",((me=de[r==null?void 0:r.searchBy])==null?void 0:me.text)??"","-",(r==null?void 0:r.mainNo)??"",r!=null&&r.subNo?"/"+(r==null?void 0:r.subNo):""].filter(Boolean).join(" "),onAction:p=>{if(console.green("Action received from WebView",JSON.stringify(p)),p.action==="DOWNLOAD_PDF"||p.action==="ACTION_SAVE_PDF"){le();return}if(p.action==="SHARE_PDF"||p.action==="ACTION_SHARE"){ce();return}if(p.action==="PRINT_PDF"){ue();return}if(!h||!s||!D){console.error("Location params missing during onAction",{districtId:h,blockId:s,mouzaId:D});return}if(p.action==="MUTATION_STEP_2"){const d={...r,caseNumber:p.caseNo},O=encodeURIComponent(JSON.stringify(d));console.green("MUTATION_STEP_2 URL",`/wb/mutation-case-status/${h}/${s}/${D}/${O}`),I(`/wb/mutation-case-status/${h}/${s}/${D}/${O}`)}else if(p.action==="MUTATION_STEP_3"){const d=p.caseNo.replace(/\//g,"_"),O={...r,caseNumber:d},m=encodeURIComponent(JSON.stringify(O));console.green("MUTATION_STEP_3 URL",`/wb/mutation-case-details/${h}/${s}/${D}/${m}`),I(`/wb/mutation-case-details/${h}/${s}/${D}/${m}`)}}})})]})]})}function da({id:e,html:t,title:a,caption:o,onAction:n,isVisible:l=!0}){const y=re(t)?sa({pdfData:t,title:a,caption:o}):`
  <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      @media screen {
        .only-print { display: none !important; }
      }
      @media print {
        .only-print { display: block !important; }
        .no-print { display: none !important; }
      }
      #print-btn {
        z-index: 10000;
        padding: 8px 18px;
        margin: 16px;
        font-size: 1.1rem;
        background: #1976d2;
        color: #fff;
        border: none;
        border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        cursor: pointer;
        transition: background 0.2s;
      }
      #print-btn:hover {
        background: #115293;
      }
      .book > .row {display:none!important}
      
      html, body { width: 100%; margin: 0; padding: 0; }
      .content-wrapper { padding: 16px; }
      
    </style>
    </head>
    <body>
    <div class="content-wrapper">
      <div style="padding: 10px;" class="only-print">
        <h3>${a}</h3>
        <h4>${o}</h4>
      </div>
      ${t}
    </div>    
    <script>
      function onCaseClick(caseNo) {
        console.log("onCaseClick triggered: " + caseNo);
        console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
      }
      function showMutationCaseDetails(caseNo, idn) {
        console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
        console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
      }
    <\/script>
    </body>
  </html>
  `;return S.jsx(it,{id:e,isVisible:l,html:y,onConsoleMessage:c=>{try{const b=JSON.parse(c.message.message);b.action&&n&&n(b)}catch{}}})}export{xa as default};
