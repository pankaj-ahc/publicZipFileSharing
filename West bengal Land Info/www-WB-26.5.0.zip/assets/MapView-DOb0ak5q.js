import{k as he,m as ge,u as we,a6 as xe,a7 as be,h as N,L as ye,d as I,a8 as ve,C as X,J as Se}from"./index-BfZ5zObU.js";import{a5 as ze,aL as $e,s as Pe,u as Ce,r as l,j as a,B as y,z as Le,o as B,I as F,d as j,e as v,p as ee,f as H,n as Ee}from"./vendor-framework-5FR5Ypkt.js";import"./vendor-utils-KPWY5UL0.js";import"./vendor-firebase-DP68oww1.js";import{e as S,W as _e,g as te,s as ae}from"./WebVIew-y49Kcocd.js";import{A as Ne}from"./Index-D9K9VIoG.js";const oe=u=>{try{let o=u.replace("MULTIPOLYGON","").trim().replace(/\(/g,"[").replace(/\)/g,"]");o=o.replace(/([-\d.]+)\s+([-\d.]+)/g,"[$1, $2]");let g=JSON.parse(o);const x=s=>s.length===2&&typeof s[0]=="number"?[s[1],s[0]]:s.map(x);return x(g)}catch(n){return console.error("Parse error",n),[]}},je=(u,n,o,g,x,s,c)=>`
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <style>
            body { padding: 0; margin: 0; background-color: ${o.bg}; overflow: hidden; }
            #map { height: 100vh; width: 100vw; background-color: transparent !important; }
            .transparent-tooltip {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
                font-weight: 700;
                color: ${n?"#eeeeee":"#212121"};
                text-shadow: 1px 1px 0px ${n?"#000000":"rgba(255,255,255,0.8)"}, -1px -1px 0px ${n?"#000000":"rgba(255,255,255,0.8)"}, 1px -1px 0px ${n?"#000000":"rgba(255,255,255,0.8)"}, -1px 1px 0px ${n?"#000000":"rgba(255,255,255,0.8)"};
                font-size: 14px;
                -webkit-text-size-adjust: none !important;
                text-size-adjust: none !important;
            }
            .print-mode-tooltip {
                font-weight: normal !important;
                text-shadow: none !important;
            }
            .selected-print-tooltip {
                font-weight: 900 !important;
                color: #ff0000 !important;
                text-shadow: 1px 1px 0px #fff, -1px -1px 0px #fff, 1px -1px 0px #fff, -1px 1px 0px #fff !important;
            }
            .leaflet-control-attribution { display: none !important; }
            @media print {
                .no-print { display: none !important; }
                .leaflet-control-zoom { display: none !important; }
            }
            #details-card {
                display: none;
                position: absolute;
                bottom: 10px;
                left: 20px;
                right: 40px;
                max-width: 500px;
                margin: 0 auto;
                z-index: 9999;
                background-color: ${n?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                box-shadow: ${o.cardBoxShadow};
                border: ${o.cardBorder};
                border-radius: 5px;
                padding: 12px;
                align-items: center;
                justify-content: space-evenly;
                font-family: sans-serif;
            }
            #details-card.visible {
                display: flex;
            }
            .card-text {
                color: ${n?"#fff":"#000"};
                font-size: 14px;
                margin: 0 8px;
            }
            .card-text-primary {
                color: ${o.base};
                font-weight: bold;
            }
            #view-btn {
                background-color: ${o.base};
                color: #fff;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }
            #action-bar {
                position: absolute;
                top: 60px;
                right: 10px;
                z-index: 9999;
                display: flex;
                gap: 8px;
            }
            #top-bar {
                position: absolute;
                top: 10px;
                left: 10px;
                right: 10px;
                z-index: 9999;
                display: flex;
                gap: 8px;
            }
            .pill-input {
                background: ${n?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                color: ${o.base};
                border: 1px solid ${o.base};
                padding: 8px 12px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
                box-shadow: ${o.cardBoxShadow};
                outline: none;
                flex: 1;
                max-width: 50%;
            }
            .pill-input::placeholder {
                color: ${o.base03};
            }
            .pill-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                background: ${n?"rgba(22, 27, 34, 0.8)":"rgba(255, 255, 255, 0.8)"};
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                color: ${o.base};
                border: 1px solid ${o.base};
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: ${o.cardBoxShadow};
                transition: background 0.2s;
            }
            .pill-btn:active {
                background-color: ${o.base03};
            }
            .pill-btn .material-icons {
                font-size: 16px;
                margin-right: 4px;
            }
        </style>
    </head>
    <body>
        <div id="print-header" style="display:none; position:absolute; top:20px; left:20px; z-index:9999; background:rgba(255,255,255,0.9); padding:10px 15px; border-radius:8px; border:2px solid #333; font-family:sans-serif; font-size:16px; font-weight:bold; color:#000; max-width:80%;">
            ${x}
        </div>
        <div id="top-bar" class="no-print">
            <select id="sheet-select" class="pill-input" onchange="console.log(JSON.stringify({action: 'SHEET_CHANGE', sheetNo: this.value}))">
                ${Object.entries(s).map(([d,r])=>`<option value="${d}" ${d==c?"selected":""}>${typeof r=="object"?r.text:r}</option>`).join("")}
            </select>
            <input type="text" id="plot-search" class="pill-input" placeholder="${g.searchPlotNo}" oninput="window.searchPlot && window.searchPlot(this.value)">
        </div>
        <div id="fontsize-slider-container" class="no-print" style="position: absolute; right: 15px; top: 120px; z-index: 9999; display: flex; flex-direction: column; align-items: center; gap: 6px; background: rgba(255,255,255,0.7); border: 1px solid #ccc; border-radius: 8px; padding: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.15);">
            <span class="material-icons" style="color: #333; font-size: 18px; cursor: default; user-select: none;">format_size</span>
            <input type="range" id="fontsize-slider" min="1" max="20" value="12" style="writing-mode: vertical-lr; direction: rtl; width: 10px; height: 120px; cursor: pointer; accent-color: #333; margin: 6px 0;" oninput="window.updateFontSize && window.updateFontSize(this.value)">
            <span id="fontsize-label" style="font-family: sans-serif; font-size: 11px; font-weight: bold; color: #333; min-width: 30px; text-align: center; cursor: default; user-select: none;">Auto</span>
        </div>
        <div id="map"></div>
        <div id="action-bar" class="no-print">
            <button class="pill-btn" onclick="console.log(JSON.stringify({action: 'ACTION_SHARE'}))"><span class="material-icons">share</span>${g.share}</button>
            <button class="pill-btn" onclick="console.log(JSON.stringify({action: 'ACTION_SAVE_PDF'}))"><span class="material-icons">download</span>${g.pdf}</button>
        </div>
        <div id="details-card" class="no-print">
            <div class="card-text card-text-primary">${g.plot}: <span id="plot-val"></span></div>
            <div class="card-text" style="display: none;"><b>${g.area}:</b> <span id="area-val"></span></div>
            <button id="view-btn">${g.viewDetails}</button>
        </div>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"><\/script>
        <script>
            var map = L.map('map', { 
                crs: L.CRS.Simple, 
                zoomControl: false,
                minZoom: -5,
                maxZoom: 5 
            }).setView([0, 0], 1);
            L.control.zoom({ position: 'bottomright' }).addTo(map);
    
            var features = ${JSON.stringify(u)};
            var scheme = ${JSON.stringify(o)};
            var bounds = L.latLngBounds();
            var polygons = [];
            var selectedPlotNo = "";
    
            features.forEach(function(f) {
                var color = scheme.iconCircleColor;
                var fillColor = scheme.iconCircleBg;
                var fillOpacity = 0.6;
                var weight = 1;
    
                var polygon = L.polygon(f.positions, {
                    color: color,
                    fillColor: fillColor,
                    fillOpacity: fillOpacity,
                    weight: weight
                }).addTo(map);
                
                polygon.featureData = f;
                polygons.push(polygon);
                bounds.extend(polygon.getBounds());
    
                polygon.on('click', function() {
                    console.log(JSON.stringify({ action: 'PLOT_SELECTED', plotno: f.plotno }));
                });
            });
    
            window.isPrinting = false;
            window.printWithLabels = true;
            window.searchQuery = "";
            window.currentFontSize = 12;
            window.fontSizeMode = "auto";
            window.printScale = 1.0;
            window.updateFontSize = function(val) {
                window.fontSizeMode = "manual";
                var sz = parseInt(val);
                window.currentFontSize = sz;
                var label = document.getElementById("fontsize-label");
                if (label) label.innerText = sz + "px";
                updateLabels();
            };

            function updateLabels() {
                var zoom = map.getZoom();
                var scaleFactor = window.isPrinting ? window.printScale : 1.0;
                var baseFontSize = window.currentFontSize * scaleFactor;

                polygons.forEach(function(p) {
                    var f = p.featureData;
                    var pixelArea = f.plotArea * Math.pow(4, zoom);
                    var isSelected = f.plotno === selectedPlotNo;
                    var isSearched = window.searchQuery && f.plotno && f.plotno.includes(window.searchQuery);
                    var isHighlight = isSelected || isSearched;
                    
                    var showLabel = false;
                    if (window.fontSizeMode === "manual") {
                        showLabel = true;
                    } else {
                        if (window.isPrinting) {
                            showLabel = window.printWithLabels || isHighlight;
                        } else {
                            showLabel = isHighlight || (zoom >= -1 && pixelArea > 3500);
                        }
                    }
  
                    var color = isHighlight ? (window.isPrinting ? '#ff0000' : scheme.base) : scheme.iconCircleColor;
                    var fillColor = isHighlight ? (window.isPrinting ? '#ffcccc' : scheme.base03) : scheme.iconCircleBg;
                    var fillOpacity = isHighlight ? 0.9 : 0.6;
                    var weight = isHighlight ? (window.isPrinting ? 5 : 3) : 1;
                    
                    p.setStyle({
                        color: color,
                        fillColor: fillColor,
                        fillOpacity: fillOpacity,
                        weight: weight
                    });
    
                    if (showLabel) {
                        var tooltipClass = "transparent-tooltip";
                        if (window.isPrinting) {
                            tooltipClass += isHighlight ? " selected-print-tooltip" : " print-mode-tooltip";
                        }
                        
                        var contentHtml = '<span class="tooltip-inner" style="display:inline-block;">' + f.plotno + '</span>';
                        if (!p.getTooltip()) {
                            p.bindTooltip(contentHtml, { permanent: true, direction: "center", className: tooltipClass }).openTooltip();
                        } else {
                            var tooltip = p.getTooltip();
                            if (tooltip.options.className !== tooltipClass) {
                                p.unbindTooltip();
                                p.bindTooltip(contentHtml, { permanent: true, direction: "center", className: tooltipClass }).openTooltip();
                            }
                        }
                        
                        var tooltipObj = p.getTooltip();
                        if (tooltipObj && tooltipObj._container) {
                            var inner = tooltipObj._container.querySelector('.tooltip-inner');
                            if (inner) {
                                var targetSize = baseFontSize;
                                if (window.fontSizeMode !== "manual") {
                                    if (isHighlight && window.isPrinting) {
                                        targetSize = 14 * scaleFactor;
                                    } else {
                                        var dynSize = Math.max(6, Math.min(24, Math.sqrt(pixelArea) / 4.5));
                                        if (window.isPrinting) {
                                            dynSize = Math.max(4, Math.min(10, Math.sqrt(pixelArea) / 7)) * scaleFactor;
                                        }
                                        targetSize = dynSize;
                                    }
                                }

                                if (targetSize < 6) {
                                    var scale = targetSize / 10;
                                    inner.style.fontSize = '10px';
                                    inner.style.transform = 'scale(' + scale + ')';
                                    inner.style.transformOrigin = 'center';
                                } else {
                                    inner.style.fontSize = targetSize + 'px';
                                    inner.style.transform = 'none';
                                }
                            }
                            if (isHighlight && window.isPrinting) {
                                tooltipObj._container.style.zIndex = 1000;
                            }
                        }
                    } else {
                        if (p.getTooltip()) {
                            p.unbindTooltip();
                        }
                    }
                });
            }
    
            if (features.length > 0) {
                map.fitBounds(bounds, { padding: [10, 10], maxZoom: 1 });
            }
    
            map.on('zoomend', updateLabels);
            map.on('moveend', updateLabels);
            updateLabels();
  
            window.searchPlot = function(query) {
                window.searchQuery = query || "";
                var foundBounds = L.latLngBounds();
                var foundCount = 0;
                
                polygons.forEach(function(p) {
                    var f = p.featureData;
                    if (window.searchQuery && f.plotno && f.plotno.includes(window.searchQuery)) {
                        foundBounds.extend(p.getBounds());
                        foundCount++;
                    }
                });
                
                updateLabels();
                
                if (foundCount > 0 && window.searchQuery) {
                    map.fitBounds(foundBounds, { padding: [50, 50], maxZoom: 2, animate: true });
                }
            };

            window.updateSelection = function(plotno, area) {
                selectedPlotNo = plotno;
                updateLabels();
                var card = document.getElementById('details-card');
                if (plotno) {
                    document.getElementById('plot-val').innerText = plotno;
                    document.getElementById('area-val').innerText = area || '';
                    card.classList.add('visible');
                } else {
                    card.classList.remove('visible');
                }
            };

            window.prepareForPrint = function() {
                if (features.length === 0) return;
                window.isPrinting = true;
                
                var zoomCtrl = document.querySelector('.leaflet-control-zoom');
                if (zoomCtrl) zoomCtrl.style.display = 'none';
                
                document.getElementById('print-header').style.display = 'block';
                window.printWithLabels = true;
                var nw = map.project(bounds.getNorthWest(), 1);
                var se = map.project(bounds.getSouthEast(), 1);
                var w = Math.max(window.innerWidth, Math.abs(se.x - nw.x) + 200);
                var h = Math.max(window.innerHeight, Math.abs(se.y - nw.y) + 200);
                
                window.printScale = w / window.innerWidth;
                
                var mapEl = document.getElementById('map');
                mapEl.dataset.origW = mapEl.style.width;
                mapEl.dataset.origH = mapEl.style.height;
                
                mapEl.style.width = w + 'px';
                mapEl.style.height = h + 'px';
                document.body.style.overflow = 'auto';
                
                map.invalidateSize(false);
                map.fitBounds(bounds, { animate: false });
                updateLabels();
            };
 
            window.restoreAfterPrint = function() {
                window.isPrinting = false;
                window.printScale = 1.0;
                
                var zoomCtrl = document.querySelector('.leaflet-control-zoom');
                if (zoomCtrl) zoomCtrl.style.display = '';
                
                document.getElementById('print-header').style.display = 'none';
                var mapEl = document.getElementById('map');
                mapEl.style.width = mapEl.dataset.origW || '100vw';
                mapEl.style.height = mapEl.dataset.origH || '100vh';
                document.body.style.overflow = 'hidden';
                
                map.invalidateSize(false);
                if (features.length > 0) {
                    map.fitBounds(bounds, { padding: [10, 10], maxZoom: 1, animate: false });
                }
                updateLabels();
            };

            document.getElementById('view-btn').addEventListener('click', function() {
                if (selectedPlotNo) {
                    console.log(JSON.stringify({ action: 'VIEW_RECORD', plotno: selectedPlotNo }));
                }
            });
        <\/script>
    </body>
    </html>
    `,He=()=>{const{districtId:u,blockId:n,mouzaId:o}=ze(),[g]=$e(),x=Pe(),{selectedDistrict:s,selectedBlock:c,selectedMouza:d}=he(),{t:r,i18n:P}=Ce(),{user:O,logoutUser:ie,isLoggedIn:M}=ge(),{darkMode:A,scheme:h,errorAlert:b,successAlert:ne,setPageTitle:J,setHeaderButtons:Te}=we(),[Q,Ie]=l.useState(""),[w,re]=l.useState(null),[Fe,Oe]=l.useState(1),[Me,Ae]=l.useState(!1),[z,D]=l.useState(1),[q,Z]=l.useState(null),[G,U]=l.useState(null),[se,$]=l.useState(!!o),[le,V]=l.useState("loadingSheets"),[f,R]=l.useState(g.get("type")||"LR"),[pe,k]=l.useState(!1),C=u||(s==null?void 0:s.id),L=n||(c==null?void 0:c.id),E=o||(d==null?void 0:d.id),de=!!(C&&L&&E),W=l.useCallback(async i=>{if(V("loadingData"),$(!0),O==="demo"){try{const e=await xe(()=>import("./MapData-BcNplkIj.js"),[],import.meta.url);U(e.mapData)}catch(e){console.error("Error loading dummy map data:",e)}finally{$(!1)}return}try{const e=await be(C,L,E,f,i).catch(t=>(console.error("Error fetching map data:",t),N("mouza_map_data_error",{message:t.message}),!1));if(e===!1){b("Failed to load map data. Please try again.");return}N("mouza_map_data_success",{sheetNo:i,districtId:C,blockId:L,mouzaId:E}),U(e)}catch(e){console.error("Error fetching map data:",e),N("mouza_map_data_error",{message:e.message}),b("Failed to load map data. Please try again.")}finally{$(!1)}},[C,L,E,f,b,O]);l.useEffect(()=>{J(r("wb.mapView.pageTitle"))},[r,J]),l.useEffect(()=>{if(!u||!n||!o){$(!1);return}(async()=>{var e;if(M){if(k(!1),$(!0),O==="demo"){V("loadingSheets");const t={1:{text:`${r("wb.mapView.sheet")}- 1`}};Z(t),D(1),await W(1);return}V("loadingSheets");try{const t=await ve(u,n,o,f);if(t===!1){ie(),I(),b("auth.sessionTimeout");return}if(t&&t.result==="OK"&&Array.isArray(t.sheetNoList)&&t.sheetNoList.length>0){const m=t.sheetNoList.reduce((_,Y)=>(_[Y]={text:`${r("wb.mapView.sheet")}- ${Y}`},_),{});console.blue("Map Sheet Options",m),Z(m);let p=z;t.sheetNoList.includes(z.toString())||(p=t.sheetNoList[0],D(p)),N("mouza_map_sheets_success",{sheets_count:((e=t.sheetNoList)==null?void 0:e.length)??0,districtId:u,blockId:n,mouzaId:o}),await W(p)}else k(!0),b(r("wb.mapView.noSheetsFound"))}catch(t){console.error("Error fetching sheets:",t),N("mouza_map_sheets_error",{message:t.message}),k(!0)}finally{$(!1)}}})()},[u,n,o,M,f]);const T=l.useMemo(()=>{const i=G;if(!i)return[];if(typeof i=="string")try{return JSON.parse(i).features.map(t=>({...t,positions:oe(t.polygon)}))}catch(e){return console.error("Map data parse error",e),[]}else if(i&&i.features)return i.features.map(e=>({...e,positions:oe(e.polygon)}));return[]},[G]),ce=async i=>{const e=Number(i);D(e),await W(e)},ue=i=>{const e=i||w;if(!e)return;let t=e.plotno,m="";if(t&&t.includes("/")){const _=t.split("/");t=_[0],m=_[1]}x(`/wb/mouza-map/${u}/${n}/${o}/${encodeURIComponent(JSON.stringify({khatianType:"Normal",searchBy:"Plot",mainNo:t,subNo:m,caseNumber:""}))}`,{replace:!0})},K=l.useMemo(()=>{if(T.length===0)return"";const i={plot:r("wb.mapView.plot"),area:r("wb.mapView.area"),viewDetails:r("wb.mapView.viewDetails"),labels:r("wb.mapView.labels",{defaultValue:"Labels"}),share:r("wb.mapView.share",{defaultValue:"Share"}),pdf:r("wb.mapView.pdf",{defaultValue:"PDF"}),searchPlotNo:r("wb.mapView.searchPlotNo",{defaultValue:"Search Plot No."})},e=P.language||"en",t=`${(s==null?void 0:s[e])||u} &rarr; ${(c==null?void 0:c[e])||n} &rarr; ${(d==null?void 0:d[e])||o} &rarr; Sheet - ${z}`;return je(T,A,h,i,t,q||{},z.toString())},[T,A,h,r,s,c,d,P.language,z,u,n,o,q]);if(l.useEffect(()=>{S("mouza_map",`window.searchPlot && window.searchPlot("${Q||""}")`)},[Q]),l.useEffect(()=>{S("mouza_map",`window.updateSelection && window.updateSelection("${(w==null?void 0:w.plotno)||""}", "${(w==null?void 0:w.plotArea)||""}")`)},[w]),!M)return a.jsx(Ne,{});const fe=async()=>{I();try{await X("downloads");const e=`${`Map_${u}_${n}_${o}_Sheet${z}`}.pdf`,t=`/storage/emulated/0/Download/${e}`,m=await te("mouza_map");if(!m)throw new Error("WebView not ready yet.");await S("mouza_map","window.prepareForPrint && window.prepareForPrint()"),await new Promise(p=>setTimeout(p,600)),ae({id:m,path:t}).then(async p=>{await S("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),ne("PDF saved at: "+p.path),window.bridgeSend("notification","showLocal",{title:"Map Downloaded",body:"Tap to open "+e,payload:p.path})}).catch(async p=>{await S("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),b("Failed to save map PDF"),console.error("Map PDF Save Error:",p)})}catch(i){b("Failed to initialize map PDF save"),console.error("Map PDF init error",i)}},me=async()=>{I();try{await X("downloads");const t=`/storage/emulated/0/Download/${`${`Map_${u}_${n}_${o}_Sheet${z}`}.pdf`}`,m=await te("mouza_map");if(!m)throw new Error("WebView not ready yet.");await S("mouza_map","window.prepareForPrint && window.prepareForPrint()"),await new Promise(p=>setTimeout(p,600)),ae({id:m,path:t}).then(async p=>{await S("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),Se({filePaths:[p.path],text:"Here is the Mouza Map PDF."})}).catch(async p=>{await S("mouza_map","window.restoreAfterPrint && window.restoreAfterPrint()"),b("Failed to share map PDF"),console.error("Map PDF Share Error:",p)})}catch(i){b("Failed to initialize map PDF share"),console.error("Map PDF share init error",i)}};return a.jsx(y,{sx:{width:"100%",height:"100%"},children:o?se?a.jsxs(y,{sx:{display:"flex",height:"60vh",alignItems:"center",justifyContent:"center",flexDirection:"column"},children:[a.jsx(Ee,{size:50,thickness:4,sx:{color:h.baseColor||"primary.main"}}),a.jsx(v,{variant:"body1",fontWeight:600,sx:{mt:2,color:"text.secondary"},children:r(le==="loadingSheets"?"wb.mapView.loadingSheets":"wb.mapView.loadingData")})]}):pe?a.jsxs(y,{sx:{display:"flex",minHeight:"50vh",alignItems:"center",justifyContent:"center",flexDirection:"column",p:3,textAlign:"center"},children:[a.jsx(F,{sx:{fontSize:48,color:"warning.main",mb:1.5},children:"map"}),a.jsx(v,{variant:"h6",fontWeight:700,gutterBottom:!0,children:r("wb.mapView.noSheetsFound","No map sheets found for this Mouza.")}),a.jsx(v,{variant:"body2",color:"text.secondary",sx:{maxWidth:400,mb:3},children:"Digital map sheets are currently not available online for this selected Mouza or Map Type."}),a.jsxs(B,{direction:"row",spacing:2,children:[a.jsxs(H,{variant:"outlined",onClick:()=>{R(f==="LR"?"RS":"LR")},children:["Try ",f==="LR"?"RS":"LR"," Map"]}),a.jsx(H,{variant:"contained",onClick:()=>x("/wb/mouza-map"),children:"Change Mouza"})]})]}):K&&a.jsx(_e,{id:"mouza_map",html:K,onConsoleMessage:i=>{try{const e=JSON.parse(i.message.message);if(e.action==="PLOT_SELECTED"){const t=T.find(m=>m.plotno===e.plotno);t&&re(t)}else e.action==="VIEW_RECORD"?w&&ue(w):e.action==="ACTION_SHARE"?me():e.action==="ACTION_SAVE_PDF"?fe():e.action==="SHEET_CHANGE"&&ce(e.sheetNo)}catch{}}}):a.jsxs(y,{sx:{p:2,maxWidth:640,mx:"auto"},children:[a.jsx(ye,{onLocationChange:({district:i,block:e,mouza:t})=>{i!=null&&i.id&&(e!=null&&e.id)&&(t!=null&&t.id)&&x(`/wb/mouza-map/${i.id}/${e.id}/${t.id}${f!=="LR"?`?type=${f}`:""}`)}}),de?a.jsx(Le,{elevation:0,sx:{mt:2,p:3,borderRadius:3.5,border:"1px solid",borderColor:j(h.baseColor||"#16a34a",.3),bgcolor:j(h.baseColor||"#16a34a",.04),textAlign:"center",boxShadow:`0 8px 24px ${j(h.baseColor||"#16a34a",.12)}`},children:a.jsxs(B,{spacing:2.5,alignItems:"center",children:[a.jsx(y,{sx:{width:60,height:60,borderRadius:3.5,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:j(h.baseColor||"#16a34a",.12),color:h.baseColor||"#16a34a"},children:a.jsx(F,{sx:{fontSize:36},children:"travel_explorer"})}),a.jsxs(y,{children:[a.jsx(v,{variant:"h6",fontWeight:800,color:"text.primary",children:(d==null?void 0:d[P.language])||(d==null?void 0:d.en)||"Selected Mouza"}),a.jsxs(v,{variant:"body2",color:"text.secondary",sx:{mt:.5},children:[(s==null?void 0:s[P.language])||(s==null?void 0:s.en)," › ",(c==null?void 0:c[P.language])||(c==null?void 0:c.en)]})]}),a.jsxs(B,{direction:"row",spacing:1,alignItems:"center",children:[a.jsx(v,{variant:"body2",fontWeight:700,color:"text.secondary",children:"Map Type:"}),a.jsx(ee,{label:"LR (Land Reforms)",clickable:!0,color:f==="LR"?"primary":"default",variant:f==="LR"?"filled":"outlined",onClick:()=>R("LR"),sx:{fontWeight:700}}),a.jsx(ee,{label:"RS (Revisional)",disabled:!0,clickable:!0,color:f==="RS"?"primary":"default",variant:f==="RS"?"filled":"outlined",onClick:()=>R("RS"),sx:{fontWeight:700}})]}),a.jsx(H,{variant:"contained",size:"large",startIcon:a.jsx(F,{children:"map"}),onClick:()=>{I(),x(`/wb/mouza-map/${C}/${L}/${E}${f!=="LR"?`?type=${f}`:""}`)},sx:{px:4,py:1.4,borderRadius:2.5,fontWeight:800,fontSize:"1.05rem",background:`linear-gradient(135deg, ${h.baseColor||"#16a34a"} 0%, ${h.base03Color||"#047857"} 100%)`,boxShadow:`0 6px 20px ${j(h.baseColor||"#16a34a",.35)}`},children:r("wb.mapView.viewMapBtn","View Mouza Map")})]})}):a.jsxs(y,{sx:{display:"flex",minHeight:"50vh",alignItems:"center",justifyContent:"center",flexDirection:"column",p:3,textAlign:"center"},children:[a.jsx(y,{sx:{width:64,height:64,borderRadius:4,display:"flex",alignItems:"center",justifyContent:"center",bgcolor:A?"rgba(255,255,255,0.05)":"rgba(0,0,0,0.04)",color:h.baseColor||"primary.main",mb:2},children:a.jsx(F,{sx:{fontSize:36},children:"travel_explorer"})}),a.jsx(v,{variant:"h6",fontWeight:700,gutterBottom:!0,children:r("wb.mapView.pageTitle","Mouza Map Viewer")}),a.jsx(v,{variant:"body2",color:"text.secondary",sx:{maxWidth:360},children:"Please select your District, Block, and Mouza above to explore plot-wise maps and boundary information."})]})]})})};export{He as default};
