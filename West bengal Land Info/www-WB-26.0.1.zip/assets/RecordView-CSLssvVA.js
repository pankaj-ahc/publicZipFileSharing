import{F as re,G as ue,aE as fe,aA as he,r as k,aq as me,ar as pe,aF as ge,E as F,j as g,A as X,aD as ve,T as be,C as ye,aG as we,S as Me,H as Se,ag as Ne,aH as xe,aI as oe,ac as De,aJ as Te,aK as Pe,D as V,aL as ie,aM as Ce,aN as _e,aO as Ae,aP as Ie,aQ as Oe,aR as ke,aS as Fe}from"./index-ag_3jwuQ.js";import{A as We,g as J,s as se,p as Be,W as Re}from"./Index-B8YyoDor.js";import"./MyInputField-EIw0RAUe.js";import"./TextField-BtDi1zK2.js";import"./MyForm-JKNJNQj9.js";import"./Alert-BHAFP59h.js";function Q(e){"@babel/helpers - typeof";return Q=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Q(e)}function x(e,t){if(t.length<e)throw new TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+t.length+" present")}function v(e){x(1,arguments);var t=Object.prototype.toString.call(e);return e instanceof Date||Q(e)==="object"&&t==="[object Date]"?new Date(e.getTime()):typeof e=="number"||t==="[object Number]"?new Date(e):((typeof e=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}var Ee={};function He(){return Ee}function de(e){var t=new Date(Date.UTC(e.getFullYear(),e.getMonth(),e.getDate(),e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds()));return t.setUTCFullYear(e.getFullYear()),e.getTime()-t.getTime()}function U(e,t){x(2,arguments);var a=v(e),r=v(t),o=a.getTime()-r.getTime();return o<0?-1:o>0?1:o}function $e(e,t){x(2,arguments);var a=v(e),r=v(t),o=a.getFullYear()-r.getFullYear(),s=a.getMonth()-r.getMonth();return o*12+s}function je(e,t){return x(2,arguments),v(e).getTime()-v(t).getTime()}var Le={ceil:Math.ceil,round:Math.round,floor:Math.floor,trunc:function(t){return t<0?Math.ceil(t):Math.floor(t)}},ze="trunc";function Ve(e){return Le[ze]}function Ue(e){x(1,arguments);var t=v(e);return t.setHours(23,59,59,999),t}function Xe(e){x(1,arguments);var t=v(e),a=t.getMonth();return t.setFullYear(t.getFullYear(),a+1,0),t.setHours(23,59,59,999),t}function Je(e){x(1,arguments);var t=v(e);return Ue(t).getTime()===Xe(t).getTime()}function Ye(e,t){x(2,arguments);var a=v(e),r=v(t),o=U(a,r),s=Math.abs($e(a,r)),i;if(s<1)i=0;else{a.getMonth()===1&&a.getDate()>27&&a.setDate(30),a.setMonth(a.getMonth()-o*s);var l=U(a,r)===-o;Je(v(e))&&s===1&&U(e,r)===1&&(l=!1),i=o*(s-Number(l))}return i===0?0:i}function qe(e,t,a){x(2,arguments);var r=je(e,t)/1e3;return Ve()(r)}var Qe={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},Ke=function(t,a,r){var o,s=Qe[t];return typeof s=="string"?o=s:a===1?o=s.one:o=s.other.replace("{{count}}",a.toString()),r!=null&&r.addSuffix?r.comparison&&r.comparison>0?"in "+o:o+" ago":o};function Y(e){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=t.width?String(t.width):e.defaultWidth,r=e.formats[a]||e.formats[e.defaultWidth];return r}}var Ge={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},Ze={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},et={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},tt={date:Y({formats:Ge,defaultWidth:"full"}),time:Y({formats:Ze,defaultWidth:"full"}),dateTime:Y({formats:et,defaultWidth:"full"})},at={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},nt=function(t,a,r,o){return at[t]};function $(e){return function(t,a){var r=a!=null&&a.context?String(a.context):"standalone",o;if(r==="formatting"&&e.formattingValues){var s=e.defaultFormattingWidth||e.defaultWidth,i=a!=null&&a.width?String(a.width):s;o=e.formattingValues[i]||e.formattingValues[s]}else{var l=e.defaultWidth,d=a!=null&&a.width?String(a.width):e.defaultWidth;o=e.values[d]||e.values[l]}var m=e.argumentCallback?e.argumentCallback(t):t;return o[m]}}var rt={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},ot={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},it={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},st={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},dt={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},ct={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},lt=function(t,a){var r=Number(t),o=r%100;if(o>20||o<10)switch(o%10){case 1:return r+"st";case 2:return r+"nd";case 3:return r+"rd"}return r+"th"},ut={ordinalNumber:lt,era:$({values:rt,defaultWidth:"wide"}),quarter:$({values:ot,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:$({values:it,defaultWidth:"wide"}),day:$({values:st,defaultWidth:"wide"}),dayPeriod:$({values:dt,defaultWidth:"wide",formattingValues:ct,defaultFormattingWidth:"wide"})};function j(e){return function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=a.width,o=r&&e.matchPatterns[r]||e.matchPatterns[e.defaultMatchWidth],s=t.match(o);if(!s)return null;var i=s[0],l=r&&e.parsePatterns[r]||e.parsePatterns[e.defaultParseWidth],d=Array.isArray(l)?ht(l,function(w){return w.test(i)}):ft(l,function(w){return w.test(i)}),m;m=e.valueCallback?e.valueCallback(d):d,m=a.valueCallback?a.valueCallback(m):m;var S=t.slice(i.length);return{value:m,rest:S}}}function ft(e,t){for(var a in e)if(e.hasOwnProperty(a)&&t(e[a]))return a}function ht(e,t){for(var a=0;a<e.length;a++)if(t(e[a]))return a}function mt(e){return function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=t.match(e.matchPattern);if(!r)return null;var o=r[0],s=t.match(e.parsePattern);if(!s)return null;var i=e.valueCallback?e.valueCallback(s[0]):s[0];i=a.valueCallback?a.valueCallback(i):i;var l=t.slice(o.length);return{value:i,rest:l}}}var pt=/^(\d+)(th|st|nd|rd)?/i,gt=/\d+/i,vt={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},bt={any:[/^b/i,/^(a|c)/i]},yt={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},wt={any:[/1/i,/2/i,/3/i,/4/i]},Mt={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},St={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},Nt={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},xt={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},Dt={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},Tt={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},Pt={ordinalNumber:mt({matchPattern:pt,parsePattern:gt,valueCallback:function(t){return parseInt(t,10)}}),era:j({matchPatterns:vt,defaultMatchWidth:"wide",parsePatterns:bt,defaultParseWidth:"any"}),quarter:j({matchPatterns:yt,defaultMatchWidth:"wide",parsePatterns:wt,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:j({matchPatterns:Mt,defaultMatchWidth:"wide",parsePatterns:St,defaultParseWidth:"any"}),day:j({matchPatterns:Nt,defaultMatchWidth:"wide",parsePatterns:xt,defaultParseWidth:"any"}),dayPeriod:j({matchPatterns:Dt,defaultMatchWidth:"any",parsePatterns:Tt,defaultParseWidth:"any"})},Ct={code:"en-US",formatDistance:Ke,formatLong:tt,formatRelative:nt,localize:ut,match:Pt,options:{weekStartsOn:0,firstWeekContainsDate:1}};function le(e,t){if(e==null)throw new TypeError("assign requires that input parameter not be null or undefined");for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a]);return e}function _t(e){return le({},e)}var ce=1440,At=2520,q=43200,It=86400;function Ot(e,t,a){var r,o;x(2,arguments);var s=He(),i=(r=(o=a==null?void 0:a.locale)!==null&&o!==void 0?o:s.locale)!==null&&r!==void 0?r:Ct;if(!i.formatDistance)throw new RangeError("locale must contain formatDistance property");var l=U(e,t);if(isNaN(l))throw new RangeError("Invalid time value");var d=le(_t(a),{addSuffix:!!(a!=null&&a.addSuffix),comparison:l}),m,S;l>0?(m=v(t),S=v(e)):(m=v(e),S=v(t));var w=qe(S,m),W=(de(S)-de(m))/1e3,p=Math.round((w-W)/60),N;if(p<2)return a!=null&&a.includeSeconds?w<5?i.formatDistance("lessThanXSeconds",5,d):w<10?i.formatDistance("lessThanXSeconds",10,d):w<20?i.formatDistance("lessThanXSeconds",20,d):w<40?i.formatDistance("halfAMinute",0,d):w<60?i.formatDistance("lessThanXMinutes",1,d):i.formatDistance("xMinutes",1,d):p===0?i.formatDistance("lessThanXMinutes",1,d):i.formatDistance("xMinutes",p,d);if(p<45)return i.formatDistance("xMinutes",p,d);if(p<90)return i.formatDistance("aboutXHours",1,d);if(p<ce){var I=Math.round(p/60);return i.formatDistance("aboutXHours",I,d)}else{if(p<At)return i.formatDistance("xDays",1,d);if(p<q){var B=Math.round(p/ce);return i.formatDistance("xDays",B,d)}else if(p<It)return N=Math.round(p/q),i.formatDistance("aboutXMonths",N,d)}if(N=Ye(S,m),N<12){var R=Math.round(p/q);return i.formatDistance("xMonths",R,d)}else{var O=N%12,E=Math.floor(N/12);return O<3?i.formatDistance("aboutXYears",E,d):O<9?i.formatDistance("overXYears",E,d):i.formatDistance("almostXYears",E+1,d)}}function kt(e,t){return x(1,arguments),Ot(e,Date.now(),t)}function Ft(e){return new Promise(t=>{setTimeout(()=>{t({html:`
            <div style="position:relative; width:100%; min-height:100vh;">

  <!-- Full page watermark -->
  <div style="
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background-repeat:repeat;
    background-image: repeating-linear-gradient(
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 100px
    ),
    repeating-linear-gradient(
      90deg,
      rgba(200,200,200,0.15) 0px,
      rgba(200,200,200,0.15) 1px,
      transparent 1px,
      transparent 300px
    );
    z-index:9999;
  ">
    <div style="
      position:absolute;      
      top:50%;
      left:50%;
      transform:translate(-50%,-50%) rotate(-60deg);
      font-size:72px;
      color:rgba(150,150,150,0.2);
      font-weight:bold;
      white-space:nowrap;
      font-family:Arial, sans-serif;
      pointer-events:none;
    ">
      DEMO DATA - NOT REAL
    </div>
  </div>

  <!-- Disclaimer Banner -->
  <div style="
    position:sticky;
    top:0;
    background-color:rgba(255,255,0,0.9);
    color:#000;
    padding:10px;
    font-size:16px;
    text-align:center;
    font-weight:bold;
    border-bottom:2px solid #000;
    z-index:1000;
  ">
    This page displays DEMO DATA for review purposes only. No real information is shown.
  </div>

  <!-- Your existing dummy HTML -->
  <div style="position:relative; z-index:1; padding:20px; background-color:white;">

    <table width="100%" border="1" style="border-collapse: collapse;">
      <tr>
        <td width="55%">
          <div style="border: thin; position: relative; width: 100%;">
            <b style="color:#0000FF;">
              <font face="Verdana">(Demo Data Generated on 08/08/2025, 12:00:00)</font>
            </b><br/>
            <b style="color:#660033;">&nbsp;<label><font face='BN BIDISHA Opentype'>J.L No </font>:</label>&nbsp;</b>999
            <b style="color:#660033;">&nbsp;&nbsp; <font face='BN BIDISHA Opentype'>Thana </font>:&nbsp;</b>
            <font face='BN BIDISHA Opentype'>Demo Thana</font>&nbsp;<br/>
          </div>

          <div class="table-responsive" style="border: thin; position: relative; left: 3px; width: 97%;">
            <table class="table" width="95%" border="1" style="border-collapse: collapse;">
              <tr>
                <th width="43%"><div align="left"><font face='BN BIDISHA Opentype'>Khatian No</font>&nbsp;&nbsp;:&nbsp;</div></th>
                <th width="57%" bgcolor="#CCCCCC"><div align="left"><font face='BN BIDISHA Opentype'>00</font></div></th>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Nam</font>&nbsp;&nbsp;:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Name</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Pita/Swami</font>&nbsp;&nbsp;:</td>
                <td bgcolor="#CCCCCC"><font face='BN BIDISHA Opentype'>Demo Parent</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Raiter Dharan</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Type</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Thikana</font>:</td>
                <td><font face='BN BIDISHA Opentype'>Demo Address</font></td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Zamir Pariman</font>:</td>
                <td bgcolor="#CCCCCC">0.00 Ekar</td>
              </tr>
              <tr>
                <td><font face='BN BIDISHA Opentype'>Dager Sankhyan</font>:</td>
                <td>0</td>
              </tr>
            </table>
          </div>

          <p><strong><font style="color: #0048FF;font-size:18px" face='BN BIDISHA Opentype'>Atrasbatber Dager Bibaran O Pariman:</font></strong></p>
          <p><font style="color: #8000ff;font-size:12px" face='BN BIDISHA Opentype'>(This is demo data only. No real land records are shown.)</font></p>

          <div class="table-responsive" style="border: thin none; position: relative; left: 5px; width: 97%; overflow: auto; top: -10px; margin-top:1em; margin-right: 5px;">
            <table class="table table-fixed" width="95%" align="center" style="border-collapse: collapse">
              <thead>
                <tr>
                  <th><center>Dag No</center></th>
                  <th><center>Shreni</center></th>
                  <th><center>Ansh</center></th>
                  <th><center>Ansh Pariman (ekar)</center></th>
                  <th><center>Dakhaldar</center></th>
                  <th><center>Mantaby</center></th>
                </tr>
              </thead>
              <tbody>
                <tr bgcolor="#CCCCCC">
                  <td align="center">0001</td>
                  <td align="center">Demo Class</td>
                  <td align="center">1.0000</td>
                  <td align="center">0.00</td>
                  <td align="center">Demo Holder</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
                <tr>
                  <td align="center">0002</td>
                  <td align="center">Demo Class</td>
                  <td align="center">0.5000</td>
                  <td align="center">0.00</td>
                  <td align="center">Nil</td>
                  <td align="center" style="color:red;">Nil</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>

        <td width="45%" valign="top">
          <div class="table-responsive" style="border: thin; width: 95%; height: 300px; overflow: auto;">
            <center style="color:gray; padding-top:120px;">Demo Map / Additional Info</center>
          </div>
        </td>
      </tr>
    </table>

  </div>
</div>
          `})},1e3)})}function Lt(){var ee,te,ae,ne;const{t:e}=re(),{t}=re("inputField"),{errorAlert:a,setHeaderButtons:r,successAlert:o}=ue(),{user:s,logoutUser:i,isLoggedIn:l}=fe(),{selectedDistrict:d,selectedBlock:m,selectedMouza:S,searchLandDetails:w}=he(),[W,p]=k.useState(!1),[N,I]=k.useState(""),[B,R]=k.useState(!0),O=me(),E=pe(),{districtId:T,blockId:P,mouzaId:C,recordData:L}=ge(),b=E.pathname,n=k.useMemo(()=>{if(L)try{return JSON.parse(L)}catch(y){console.error("Failed to parse recordData from params",y)}return w},[L,w]),K=(y=!0)=>{Ne(),R(!0);let M=xe;b.includes("/rs-lr/")?M=_e:b.includes("/khajna-status/")?M=Ae:b.includes("/mutation-case-status/")?M=Ie:b.includes("/mutation-case-details/")?M=Oe:b.includes("/mutation-status/")&&(M=ke),l&&M(n,T,P,C,y).then(async f=>{if(f&&f.html){let c=localStorage.getItem(oe)??0;f.cached&&c++,localStorage.setItem(oe,c);const u=await De(Fe)??10;c>u&&Te(),console.log("html Received=>",c,f.html);const A=new DOMParser().parseFromString(f.html,"text/html");A.querySelectorAll("a").forEach(h=>{const z=h.innerText.trim().toLowerCase();!z.includes("view ror")&&!z.includes("certified copy")&&h.removeAttribute("href")});const D=/(MN\/\d{4}\/\d+\/\d+)/g;b.includes("/mutation-status/")?A.querySelectorAll("td").forEach(h=>{h.innerText.trim().match(D)&&(h.innerHTML=h.innerHTML.replace(D,`<a href="javascript:void(0)" onclick="onCaseClick('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}):b.includes("/mutation-case-status/")&&A.querySelectorAll("td").forEach(h=>{h.innerText.trim().match(D)&&(h.innerHTML=h.innerHTML.replace(D,`<a href="javascript:void(0)" onclick="showMutationCaseDetails('$1')" style="color: #1976d2; font-weight: bold; text-decoration: underline;">$1</a>`))}),f.html=A.body.innerHTML,I(f.html),p(f.cached),Pe("high-low",3),F("success_record_fetch",{totalCount:c,cached:f.cached?"true":"false",useCache:y?"true":"false"})}else i(),V(),I(""),a("auth.sessionTimeout")}).catch(f=>{I(""),console.red("Error in record fetching",f.message),F("record_fetch_error",{message:f.message}),a("kyp.recordView.errorLandRecordFetch",{error:f.message}),O(-1)}).finally(f=>R(!1))};k.useEffect(()=>{if(s=="demo"){Ft().then(y=>{I(y.html),R(!1),F("demo_record_fetched")});return}K()},[l,b,L]);const G=t("wb.landDetails.khatianType.option"),Z=t("wb.landDetails.searchBy.option"),H=`wb-record-${b.split("/")[2]}`;return k.useEffect(()=>{if(!N||B)return;const y={id:"save_pdf_btn",icon:"download",tooltip:"Save PDF",onClick:async()=>{V();try{await ie("downloads");const c=Math.random().toString(36).substring(2,7);let u=`${T}_${P}_${C}_`;b.includes("/mutation-case-")?u+=(n==null?void 0:n.caseNumber)||"Record":(u+=(n==null?void 0:n.mainNo)||"Record",n!=null&&n.subNo&&(u+="_"+n.subNo)),u+=`_${c}`,u=u.replace(/[^a-zA-Z0-9_.-]/g,"_");const _=`${u}.pdf`,A=`/storage/emulated/0/Download/${_}`,D=await J(H);if(!D)throw new Error("WebView not ready yet.");se({id:D,path:A}).then(h=>{o("PDF saved at: "+h.path),F("pdf_saved",{path:h.path}),window.bridgeSend("notification","showLocal",{title:"PDF Downloaded",body:"Tap to open "+_,payload:h.path})}).catch(h=>{a("Failed to save PDF"),console.error("PDF Save Error:",h)})}catch(c){a("Failed to initialize PDF save"),console.error("PDF init error",c)}}},M={id:"share_pdf_btn",icon:"share",tooltip:"Share Record",onClick:async()=>{V();try{await ie("downloads");const c=Math.random().toString(36).substring(2,7);let u=`${T}_${P}_${C}_`;b.includes("/mutation-case-")?u+=(n==null?void 0:n.caseNumber)||"Record":(u+=(n==null?void 0:n.mainNo)||"Record",n!=null&&n.subNo&&(u+="_"+n.subNo)),u+=`_${c}`,u=u.replace(/[^a-zA-Z0-9_.-]/g,"_");const A=`/storage/emulated/0/Download/${`${u}.pdf`}`,D=await J(H);if(!D)throw new Error("WebView not ready yet.");se({id:D,path:A}).then(h=>{F("pdf_shared",{path:h.path}),Ce({filePaths:[h.path],text:"Here is the land record PDF."})}).catch(h=>{a("Failed to share PDF"),console.error("PDF Share Error:",h)})}catch(c){a("Failed to initialize PDF share"),console.error("PDF share init error",c)}}},f={id:"print_pdf_btn",icon:"print",tooltip:"Print Record",onClick:async()=>{V();try{const c=await J(H);if(!c)throw new Error("WebView not ready yet.");await Be({id:c}),F("pdf_printed",{url:b})}catch(c){a("Failed to print record"),console.error("Print Error:",c)}}};return r(c=>[...c.filter(_=>_.id!=="save_pdf_btn"&&_.id!=="share_pdf_btn"&&_.id!=="print_pdf_btn"),f,M,y]),()=>{r(c=>c.filter(u=>u.id!=="save_pdf_btn"&&u.id!=="share_pdf_btn"&&u.id!=="print_pdf_btn"))}},[N,B,H,n,b,r,o,a]),!l&&!N?g.jsx(We,{}):g.jsxs(X,{children:[g.jsxs(X,{sx:{py:1},children:[g.jsx(ve,{heading:!0}),g.jsx(be,{variant:"subtitle2",align:"center",sx:{mt:0},children:b.includes("/mutation-case-")?g.jsxs(g.Fragment,{children:["Case No: ",n==null?void 0:n.caseNumber]}):g.jsxs(g.Fragment,{children:[((ee=G[n==null?void 0:n.khatianType])==null?void 0:ee.text)??""," ",((te=Z[n==null?void 0:n.searchBy])==null?void 0:te.text)??""," -"," ",(n==null?void 0:n.mainNo)??"",n!=null&&n.subNo?"/"+(n==null?void 0:n.subNo):""]})}),W&&g.jsx(X,{display:"flex",justifyContent:"flex-end",sx:{mr:2},children:g.jsx(ye,{sx:{fontSize:1,color:"text.disabled",border:"none","& span.MuiIcon-root":{color:"text.primary"}},onDelete:()=>{K(!1)},variant:"outlined",size:"small",color:"primary",label:e("kyp.recordView.cachedRecord",{timeago:W?kt(new Date(W),{addSuffix:!0}):""})})}),g.jsx(we,{})]}),B?g.jsx(Me,{alignItems:"center",sx:{py:10},children:g.jsx(Se,{})}):g.jsx(Wt,{id:H,html:N,title:(d==null?void 0:d.en)+" ➧ "+(m==null?void 0:m.en)+" ➧"+(S==null?void 0:S.en),caption:[((ae=G[n==null?void 0:n.khatianType])==null?void 0:ae.text)??"",((ne=Z[n==null?void 0:n.searchBy])==null?void 0:ne.text)??"","-",(n==null?void 0:n.mainNo)??"",n!=null&&n.subNo?"/"+(n==null?void 0:n.subNo):""].filter(Boolean).join(" "),onAction:y=>{if(console.green("Action received from WebView",JSON.stringify(y)),!T||!P||!C){console.error("Location params missing during onAction",{districtId:T,blockId:P,mouzaId:C});return}if(y.action==="MUTATION_STEP_2"){const M={...n,caseNumber:y.caseNo},f=encodeURIComponent(JSON.stringify(M));console.green("MUTATION_STEP_2 URL",`/wb/mutation-case-status/${T}/${P}/${C}/${f}`),O(`/wb/mutation-case-status/${T}/${P}/${C}/${f}`)}else if(y.action==="MUTATION_STEP_3"){const M=y.caseNo.replace(/\//g,"_"),f={...n,caseNumber:M},c=encodeURIComponent(JSON.stringify(f));console.green("MUTATION_STEP_3 URL",`/wb/mutation-case-details/${T}/${P}/${C}/${c}`),O(`/wb/mutation-case-details/${T}/${P}/${C}/${c}`)}}})]})}function Wt({id:e,html:t,title:a,caption:r,onAction:o}){const s=`
  <html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      @media screen {
        .only-print { display: none !important; }
      }
      @media print {
        .only-print { display: block !important; }
        .no-print { display: none !important; }
      }
      #print-btn {
        z-index: 10000;
        padding: 8px 18px;
        margin: 16px;
        font-size: 1.1rem;
        background: #1976d2;
        color: #fff;
        border: none;
        border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        cursor: pointer;
        transition: background 0.2s;
      }
      #print-btn:hover {
        background: #115293;
      }
      .book > .row {display:none!important}
      
      html, body { width: 100%; margin: 0; padding: 0; }
      .content-wrapper { padding: 16px; }
      
    </style>
    </head>
    <body>
    <div class="content-wrapper">
      <div style="padding: 10px;" class="only-print">
        <h3>${a}</h3>
        <h4>${r}</h4>
      </div>
      ${t}
    </div>    
    <script>
      function onCaseClick(caseNo) {
        console.log("onCaseClick triggered: " + caseNo);
        console.log(JSON.stringify({ action: "MUTATION_STEP_2", caseNo: caseNo }));
      }
      function showMutationCaseDetails(caseNo, idn) {
        console.log("showMutationCaseDetails triggered: " + caseNo + ", " + idn);
        console.log(JSON.stringify({ action: "MUTATION_STEP_3", caseNo: caseNo, idn: idn }));
      }
    <\/script>
    </body>
  </html>
  `;return g.jsx(Re,{id:e,html:s,onConsoleMessage:i=>{try{const l=JSON.parse(i.message.message);l.action&&o&&o(l)}catch{}}})}export{Lt as default};
